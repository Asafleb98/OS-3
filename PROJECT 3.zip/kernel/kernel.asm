
kernel/kernel:     file format elf64-littleriscv


Disassembly of section .text:

0000000080000000 <_entry>:
    80000000:	00009117          	auipc	sp,0x9
    80000004:	21013103          	ld	sp,528(sp) # 80009210 <_GLOBAL_OFFSET_TABLE_+0x8>
    80000008:	6505                	lui	a0,0x1
    8000000a:	f14025f3          	csrr	a1,mhartid
    8000000e:	0585                	addi	a1,a1,1
    80000010:	02b50533          	mul	a0,a0,a1
    80000014:	912a                	add	sp,sp,a0
    80000016:	078000ef          	jal	ra,8000008e <start>

000000008000001a <spin>:
    8000001a:	a001                	j	8000001a <spin>

000000008000001c <timerinit>:
// at timervec in kernelvec.S,
// which turns them into software interrupts for
// devintr() in trap.c.
void
timerinit()
{
    8000001c:	1141                	addi	sp,sp,-16
    8000001e:	e422                	sd	s0,8(sp)
    80000020:	0800                	addi	s0,sp,16
// which hart (core) is this?
static inline uint64
r_mhartid()
{
  uint64 x;
  asm volatile("csrr %0, mhartid" : "=r" (x) );
    80000022:	f14027f3          	csrr	a5,mhartid
  // each CPU has a separate source of timer interrupts.
  int id = r_mhartid();
    80000026:	0007869b          	sext.w	a3,a5

  // ask the CLINT for a timer interrupt.
  int interval = 1000000; // cycles; about 1/10th second in qemu.
  *(uint64*)CLINT_MTIMECMP(id) = *(uint64*)CLINT_MTIME + interval;
    8000002a:	0037979b          	slliw	a5,a5,0x3
    8000002e:	02004737          	lui	a4,0x2004
    80000032:	97ba                	add	a5,a5,a4
    80000034:	0200c737          	lui	a4,0x200c
    80000038:	ff873583          	ld	a1,-8(a4) # 200bff8 <_entry-0x7dff4008>
    8000003c:	000f4637          	lui	a2,0xf4
    80000040:	24060613          	addi	a2,a2,576 # f4240 <_entry-0x7ff0bdc0>
    80000044:	95b2                	add	a1,a1,a2
    80000046:	e38c                	sd	a1,0(a5)

  // prepare information in scratch[] for timervec.
  // scratch[0..2] : space for timervec to save registers.
  // scratch[3] : address of CLINT MTIMECMP register.
  // scratch[4] : desired interval (in cycles) between timer interrupts.
  uint64 *scratch = &timer_scratch[id][0];
    80000048:	00269713          	slli	a4,a3,0x2
    8000004c:	9736                	add	a4,a4,a3
    8000004e:	00371693          	slli	a3,a4,0x3
    80000052:	00009717          	auipc	a4,0x9
    80000056:	21e70713          	addi	a4,a4,542 # 80009270 <timer_scratch>
    8000005a:	9736                	add	a4,a4,a3
  scratch[3] = CLINT_MTIMECMP(id);
    8000005c:	ef1c                	sd	a5,24(a4)
  scratch[4] = interval;
    8000005e:	f310                	sd	a2,32(a4)
}

static inline void 
w_mscratch(uint64 x)
{
  asm volatile("csrw mscratch, %0" : : "r" (x));
    80000060:	34071073          	csrw	mscratch,a4
  asm volatile("csrw mtvec, %0" : : "r" (x));
    80000064:	00006797          	auipc	a5,0x6
    80000068:	ccc78793          	addi	a5,a5,-820 # 80005d30 <timervec>
    8000006c:	30579073          	csrw	mtvec,a5
  asm volatile("csrr %0, mstatus" : "=r" (x) );
    80000070:	300027f3          	csrr	a5,mstatus

  // set the machine-mode trap handler.
  w_mtvec((uint64)timervec);

  // enable machine-mode interrupts.
  w_mstatus(r_mstatus() | MSTATUS_MIE);
    80000074:	0087e793          	ori	a5,a5,8
  asm volatile("csrw mstatus, %0" : : "r" (x));
    80000078:	30079073          	csrw	mstatus,a5
  asm volatile("csrr %0, mie" : "=r" (x) );
    8000007c:	304027f3          	csrr	a5,mie

  // enable machine-mode timer interrupts.
  w_mie(r_mie() | MIE_MTIE);
    80000080:	0807e793          	ori	a5,a5,128
  asm volatile("csrw mie, %0" : : "r" (x));
    80000084:	30479073          	csrw	mie,a5
}
    80000088:	6422                	ld	s0,8(sp)
    8000008a:	0141                	addi	sp,sp,16
    8000008c:	8082                	ret

000000008000008e <start>:
{
    8000008e:	1141                	addi	sp,sp,-16
    80000090:	e406                	sd	ra,8(sp)
    80000092:	e022                	sd	s0,0(sp)
    80000094:	0800                	addi	s0,sp,16
  asm volatile("csrr %0, mstatus" : "=r" (x) );
    80000096:	300027f3          	csrr	a5,mstatus
  x &= ~MSTATUS_MPP_MASK;
    8000009a:	7779                	lui	a4,0xffffe
    8000009c:	7ff70713          	addi	a4,a4,2047 # ffffffffffffe7ff <end+0xffffffff7ffd6967>
    800000a0:	8ff9                	and	a5,a5,a4
  x |= MSTATUS_MPP_S;
    800000a2:	6705                	lui	a4,0x1
    800000a4:	80070713          	addi	a4,a4,-2048 # 800 <_entry-0x7ffff800>
    800000a8:	8fd9                	or	a5,a5,a4
  asm volatile("csrw mstatus, %0" : : "r" (x));
    800000aa:	30079073          	csrw	mstatus,a5
  asm volatile("csrw mepc, %0" : : "r" (x));
    800000ae:	00001797          	auipc	a5,0x1
    800000b2:	dca78793          	addi	a5,a5,-566 # 80000e78 <main>
    800000b6:	34179073          	csrw	mepc,a5
  asm volatile("csrw satp, %0" : : "r" (x));
    800000ba:	4781                	li	a5,0
    800000bc:	18079073          	csrw	satp,a5
  asm volatile("csrw medeleg, %0" : : "r" (x));
    800000c0:	67c1                	lui	a5,0x10
    800000c2:	17fd                	addi	a5,a5,-1
    800000c4:	30279073          	csrw	medeleg,a5
  asm volatile("csrw mideleg, %0" : : "r" (x));
    800000c8:	30379073          	csrw	mideleg,a5
  asm volatile("csrr %0, sie" : "=r" (x) );
    800000cc:	104027f3          	csrr	a5,sie
  w_sie(r_sie() | SIE_SEIE | SIE_STIE | SIE_SSIE);
    800000d0:	2227e793          	ori	a5,a5,546
  asm volatile("csrw sie, %0" : : "r" (x));
    800000d4:	10479073          	csrw	sie,a5
  asm volatile("csrw pmpaddr0, %0" : : "r" (x));
    800000d8:	57fd                	li	a5,-1
    800000da:	83a9                	srli	a5,a5,0xa
    800000dc:	3b079073          	csrw	pmpaddr0,a5
  asm volatile("csrw pmpcfg0, %0" : : "r" (x));
    800000e0:	47bd                	li	a5,15
    800000e2:	3a079073          	csrw	pmpcfg0,a5
  timerinit();
    800000e6:	00000097          	auipc	ra,0x0
    800000ea:	f36080e7          	jalr	-202(ra) # 8000001c <timerinit>
  asm volatile("csrr %0, mhartid" : "=r" (x) );
    800000ee:	f14027f3          	csrr	a5,mhartid
  w_tp(id);
    800000f2:	2781                	sext.w	a5,a5
}

static inline void 
w_tp(uint64 x)
{
  asm volatile("mv tp, %0" : : "r" (x));
    800000f4:	823e                	mv	tp,a5
  asm volatile("mret");
    800000f6:	30200073          	mret
}
    800000fa:	60a2                	ld	ra,8(sp)
    800000fc:	6402                	ld	s0,0(sp)
    800000fe:	0141                	addi	sp,sp,16
    80000100:	8082                	ret

0000000080000102 <consolewrite>:
//
// user write()s to the console go here.
//
int
consolewrite(int user_src, uint64 src, int n)
{
    80000102:	715d                	addi	sp,sp,-80
    80000104:	e486                	sd	ra,72(sp)
    80000106:	e0a2                	sd	s0,64(sp)
    80000108:	fc26                	sd	s1,56(sp)
    8000010a:	f84a                	sd	s2,48(sp)
    8000010c:	f44e                	sd	s3,40(sp)
    8000010e:	f052                	sd	s4,32(sp)
    80000110:	ec56                	sd	s5,24(sp)
    80000112:	0880                	addi	s0,sp,80
  int i;

  for(i = 0; i < n; i++){
    80000114:	04c05663          	blez	a2,80000160 <consolewrite+0x5e>
    80000118:	8a2a                	mv	s4,a0
    8000011a:	84ae                	mv	s1,a1
    8000011c:	89b2                	mv	s3,a2
    8000011e:	4901                	li	s2,0
    char c;
    if(either_copyin(&c, user_src, src+i, 1) == -1)
    80000120:	5afd                	li	s5,-1
    80000122:	4685                	li	a3,1
    80000124:	8626                	mv	a2,s1
    80000126:	85d2                	mv	a1,s4
    80000128:	fbf40513          	addi	a0,s0,-65
    8000012c:	00002097          	auipc	ra,0x2
    80000130:	446080e7          	jalr	1094(ra) # 80002572 <either_copyin>
    80000134:	01550c63          	beq	a0,s5,8000014c <consolewrite+0x4a>
      break;
    uartputc(c);
    80000138:	fbf44503          	lbu	a0,-65(s0)
    8000013c:	00000097          	auipc	ra,0x0
    80000140:	780080e7          	jalr	1920(ra) # 800008bc <uartputc>
  for(i = 0; i < n; i++){
    80000144:	2905                	addiw	s2,s2,1
    80000146:	0485                	addi	s1,s1,1
    80000148:	fd299de3          	bne	s3,s2,80000122 <consolewrite+0x20>
  }

  return i;
}
    8000014c:	854a                	mv	a0,s2
    8000014e:	60a6                	ld	ra,72(sp)
    80000150:	6406                	ld	s0,64(sp)
    80000152:	74e2                	ld	s1,56(sp)
    80000154:	7942                	ld	s2,48(sp)
    80000156:	79a2                	ld	s3,40(sp)
    80000158:	7a02                	ld	s4,32(sp)
    8000015a:	6ae2                	ld	s5,24(sp)
    8000015c:	6161                	addi	sp,sp,80
    8000015e:	8082                	ret
  for(i = 0; i < n; i++){
    80000160:	4901                	li	s2,0
    80000162:	b7ed                	j	8000014c <consolewrite+0x4a>

0000000080000164 <consoleread>:
// user_dist indicates whether dst is a user
// or kernel address.
//
int
consoleread(int user_dst, uint64 dst, int n)
{
    80000164:	7159                	addi	sp,sp,-112
    80000166:	f486                	sd	ra,104(sp)
    80000168:	f0a2                	sd	s0,96(sp)
    8000016a:	eca6                	sd	s1,88(sp)
    8000016c:	e8ca                	sd	s2,80(sp)
    8000016e:	e4ce                	sd	s3,72(sp)
    80000170:	e0d2                	sd	s4,64(sp)
    80000172:	fc56                	sd	s5,56(sp)
    80000174:	f85a                	sd	s6,48(sp)
    80000176:	f45e                	sd	s7,40(sp)
    80000178:	f062                	sd	s8,32(sp)
    8000017a:	ec66                	sd	s9,24(sp)
    8000017c:	e86a                	sd	s10,16(sp)
    8000017e:	1880                	addi	s0,sp,112
    80000180:	8aaa                	mv	s5,a0
    80000182:	8a2e                	mv	s4,a1
    80000184:	89b2                	mv	s3,a2
  uint target;
  int c;
  char cbuf;

  target = n;
    80000186:	00060b1b          	sext.w	s6,a2
  acquire(&cons.lock);
    8000018a:	00011517          	auipc	a0,0x11
    8000018e:	22650513          	addi	a0,a0,550 # 800113b0 <cons>
    80000192:	00001097          	auipc	ra,0x1
    80000196:	a44080e7          	jalr	-1468(ra) # 80000bd6 <acquire>
  while(n > 0){
    // wait until interrupt handler has put some
    // input into cons.buffer.
    while(cons.r == cons.w){
    8000019a:	00011497          	auipc	s1,0x11
    8000019e:	21648493          	addi	s1,s1,534 # 800113b0 <cons>
      if(killed(myproc())){
        release(&cons.lock);
        return -1;
      }
      sleep(&cons.r, &cons.lock);
    800001a2:	00011917          	auipc	s2,0x11
    800001a6:	2a690913          	addi	s2,s2,678 # 80011448 <cons+0x98>
    }

    c = cons.buf[cons.r++ % INPUT_BUF_SIZE];

    if(c == C('D')){  // end-of-file
    800001aa:	4b91                	li	s7,4
      break;
    }

    // copy the input byte to the user-space buffer.
    cbuf = c;
    if(either_copyout(user_dst, dst, &cbuf, 1) == -1)
    800001ac:	5c7d                	li	s8,-1
      break;

    dst++;
    --n;

    if(c == '\n'){
    800001ae:	4ca9                	li	s9,10
  while(n > 0){
    800001b0:	07305b63          	blez	s3,80000226 <consoleread+0xc2>
    while(cons.r == cons.w){
    800001b4:	0984a783          	lw	a5,152(s1)
    800001b8:	09c4a703          	lw	a4,156(s1)
    800001bc:	02f71763          	bne	a4,a5,800001ea <consoleread+0x86>
      if(killed(myproc())){
    800001c0:	00002097          	auipc	ra,0x2
    800001c4:	822080e7          	jalr	-2014(ra) # 800019e2 <myproc>
    800001c8:	00002097          	auipc	ra,0x2
    800001cc:	1f4080e7          	jalr	500(ra) # 800023bc <killed>
    800001d0:	e535                	bnez	a0,8000023c <consoleread+0xd8>
      sleep(&cons.r, &cons.lock);
    800001d2:	85a6                	mv	a1,s1
    800001d4:	854a                	mv	a0,s2
    800001d6:	00002097          	auipc	ra,0x2
    800001da:	f3e080e7          	jalr	-194(ra) # 80002114 <sleep>
    while(cons.r == cons.w){
    800001de:	0984a783          	lw	a5,152(s1)
    800001e2:	09c4a703          	lw	a4,156(s1)
    800001e6:	fcf70de3          	beq	a4,a5,800001c0 <consoleread+0x5c>
    c = cons.buf[cons.r++ % INPUT_BUF_SIZE];
    800001ea:	0017871b          	addiw	a4,a5,1
    800001ee:	08e4ac23          	sw	a4,152(s1)
    800001f2:	07f7f713          	andi	a4,a5,127
    800001f6:	9726                	add	a4,a4,s1
    800001f8:	01874703          	lbu	a4,24(a4)
    800001fc:	00070d1b          	sext.w	s10,a4
    if(c == C('D')){  // end-of-file
    80000200:	077d0563          	beq	s10,s7,8000026a <consoleread+0x106>
    cbuf = c;
    80000204:	f8e40fa3          	sb	a4,-97(s0)
    if(either_copyout(user_dst, dst, &cbuf, 1) == -1)
    80000208:	4685                	li	a3,1
    8000020a:	f9f40613          	addi	a2,s0,-97
    8000020e:	85d2                	mv	a1,s4
    80000210:	8556                	mv	a0,s5
    80000212:	00002097          	auipc	ra,0x2
    80000216:	30a080e7          	jalr	778(ra) # 8000251c <either_copyout>
    8000021a:	01850663          	beq	a0,s8,80000226 <consoleread+0xc2>
    dst++;
    8000021e:	0a05                	addi	s4,s4,1
    --n;
    80000220:	39fd                	addiw	s3,s3,-1
    if(c == '\n'){
    80000222:	f99d17e3          	bne	s10,s9,800001b0 <consoleread+0x4c>
      // a whole line has arrived, return to
      // the user-level read().
      break;
    }
  }
  release(&cons.lock);
    80000226:	00011517          	auipc	a0,0x11
    8000022a:	18a50513          	addi	a0,a0,394 # 800113b0 <cons>
    8000022e:	00001097          	auipc	ra,0x1
    80000232:	a5c080e7          	jalr	-1444(ra) # 80000c8a <release>

  return target - n;
    80000236:	413b053b          	subw	a0,s6,s3
    8000023a:	a811                	j	8000024e <consoleread+0xea>
        release(&cons.lock);
    8000023c:	00011517          	auipc	a0,0x11
    80000240:	17450513          	addi	a0,a0,372 # 800113b0 <cons>
    80000244:	00001097          	auipc	ra,0x1
    80000248:	a46080e7          	jalr	-1466(ra) # 80000c8a <release>
        return -1;
    8000024c:	557d                	li	a0,-1
}
    8000024e:	70a6                	ld	ra,104(sp)
    80000250:	7406                	ld	s0,96(sp)
    80000252:	64e6                	ld	s1,88(sp)
    80000254:	6946                	ld	s2,80(sp)
    80000256:	69a6                	ld	s3,72(sp)
    80000258:	6a06                	ld	s4,64(sp)
    8000025a:	7ae2                	ld	s5,56(sp)
    8000025c:	7b42                	ld	s6,48(sp)
    8000025e:	7ba2                	ld	s7,40(sp)
    80000260:	7c02                	ld	s8,32(sp)
    80000262:	6ce2                	ld	s9,24(sp)
    80000264:	6d42                	ld	s10,16(sp)
    80000266:	6165                	addi	sp,sp,112
    80000268:	8082                	ret
      if(n < target){
    8000026a:	0009871b          	sext.w	a4,s3
    8000026e:	fb677ce3          	bgeu	a4,s6,80000226 <consoleread+0xc2>
        cons.r--;
    80000272:	00011717          	auipc	a4,0x11
    80000276:	1cf72b23          	sw	a5,470(a4) # 80011448 <cons+0x98>
    8000027a:	b775                	j	80000226 <consoleread+0xc2>

000000008000027c <consputc>:
{
    8000027c:	1141                	addi	sp,sp,-16
    8000027e:	e406                	sd	ra,8(sp)
    80000280:	e022                	sd	s0,0(sp)
    80000282:	0800                	addi	s0,sp,16
  if(c == BACKSPACE){
    80000284:	10000793          	li	a5,256
    80000288:	00f50a63          	beq	a0,a5,8000029c <consputc+0x20>
    uartputc_sync(c);
    8000028c:	00000097          	auipc	ra,0x0
    80000290:	55e080e7          	jalr	1374(ra) # 800007ea <uartputc_sync>
}
    80000294:	60a2                	ld	ra,8(sp)
    80000296:	6402                	ld	s0,0(sp)
    80000298:	0141                	addi	sp,sp,16
    8000029a:	8082                	ret
    uartputc_sync('\b'); uartputc_sync(' '); uartputc_sync('\b');
    8000029c:	4521                	li	a0,8
    8000029e:	00000097          	auipc	ra,0x0
    800002a2:	54c080e7          	jalr	1356(ra) # 800007ea <uartputc_sync>
    800002a6:	02000513          	li	a0,32
    800002aa:	00000097          	auipc	ra,0x0
    800002ae:	540080e7          	jalr	1344(ra) # 800007ea <uartputc_sync>
    800002b2:	4521                	li	a0,8
    800002b4:	00000097          	auipc	ra,0x0
    800002b8:	536080e7          	jalr	1334(ra) # 800007ea <uartputc_sync>
    800002bc:	bfe1                	j	80000294 <consputc+0x18>

00000000800002be <consoleintr>:
// do erase/kill processing, append to cons.buf,
// wake up consoleread() if a whole line has arrived.
//
void
consoleintr(int c)
{
    800002be:	1101                	addi	sp,sp,-32
    800002c0:	ec06                	sd	ra,24(sp)
    800002c2:	e822                	sd	s0,16(sp)
    800002c4:	e426                	sd	s1,8(sp)
    800002c6:	e04a                	sd	s2,0(sp)
    800002c8:	1000                	addi	s0,sp,32
    800002ca:	84aa                	mv	s1,a0
  acquire(&cons.lock);
    800002cc:	00011517          	auipc	a0,0x11
    800002d0:	0e450513          	addi	a0,a0,228 # 800113b0 <cons>
    800002d4:	00001097          	auipc	ra,0x1
    800002d8:	902080e7          	jalr	-1790(ra) # 80000bd6 <acquire>

  switch(c){
    800002dc:	47d5                	li	a5,21
    800002de:	0af48663          	beq	s1,a5,8000038a <consoleintr+0xcc>
    800002e2:	0297ca63          	blt	a5,s1,80000316 <consoleintr+0x58>
    800002e6:	47a1                	li	a5,8
    800002e8:	0ef48763          	beq	s1,a5,800003d6 <consoleintr+0x118>
    800002ec:	47c1                	li	a5,16
    800002ee:	10f49a63          	bne	s1,a5,80000402 <consoleintr+0x144>
  case C('P'):  // Print process list.
    procdump();
    800002f2:	00002097          	auipc	ra,0x2
    800002f6:	2d6080e7          	jalr	726(ra) # 800025c8 <procdump>
      }
    }
    break;
  }
  
  release(&cons.lock);
    800002fa:	00011517          	auipc	a0,0x11
    800002fe:	0b650513          	addi	a0,a0,182 # 800113b0 <cons>
    80000302:	00001097          	auipc	ra,0x1
    80000306:	988080e7          	jalr	-1656(ra) # 80000c8a <release>
}
    8000030a:	60e2                	ld	ra,24(sp)
    8000030c:	6442                	ld	s0,16(sp)
    8000030e:	64a2                	ld	s1,8(sp)
    80000310:	6902                	ld	s2,0(sp)
    80000312:	6105                	addi	sp,sp,32
    80000314:	8082                	ret
  switch(c){
    80000316:	07f00793          	li	a5,127
    8000031a:	0af48e63          	beq	s1,a5,800003d6 <consoleintr+0x118>
    if(c != 0 && cons.e-cons.r < INPUT_BUF_SIZE){
    8000031e:	00011717          	auipc	a4,0x11
    80000322:	09270713          	addi	a4,a4,146 # 800113b0 <cons>
    80000326:	0a072783          	lw	a5,160(a4)
    8000032a:	09872703          	lw	a4,152(a4)
    8000032e:	9f99                	subw	a5,a5,a4
    80000330:	07f00713          	li	a4,127
    80000334:	fcf763e3          	bltu	a4,a5,800002fa <consoleintr+0x3c>
      c = (c == '\r') ? '\n' : c;
    80000338:	47b5                	li	a5,13
    8000033a:	0cf48763          	beq	s1,a5,80000408 <consoleintr+0x14a>
      consputc(c);
    8000033e:	8526                	mv	a0,s1
    80000340:	00000097          	auipc	ra,0x0
    80000344:	f3c080e7          	jalr	-196(ra) # 8000027c <consputc>
      cons.buf[cons.e++ % INPUT_BUF_SIZE] = c;
    80000348:	00011797          	auipc	a5,0x11
    8000034c:	06878793          	addi	a5,a5,104 # 800113b0 <cons>
    80000350:	0a07a683          	lw	a3,160(a5)
    80000354:	0016871b          	addiw	a4,a3,1
    80000358:	0007061b          	sext.w	a2,a4
    8000035c:	0ae7a023          	sw	a4,160(a5)
    80000360:	07f6f693          	andi	a3,a3,127
    80000364:	97b6                	add	a5,a5,a3
    80000366:	00978c23          	sb	s1,24(a5)
      if(c == '\n' || c == C('D') || cons.e-cons.r == INPUT_BUF_SIZE){
    8000036a:	47a9                	li	a5,10
    8000036c:	0cf48563          	beq	s1,a5,80000436 <consoleintr+0x178>
    80000370:	4791                	li	a5,4
    80000372:	0cf48263          	beq	s1,a5,80000436 <consoleintr+0x178>
    80000376:	00011797          	auipc	a5,0x11
    8000037a:	0d27a783          	lw	a5,210(a5) # 80011448 <cons+0x98>
    8000037e:	9f1d                	subw	a4,a4,a5
    80000380:	08000793          	li	a5,128
    80000384:	f6f71be3          	bne	a4,a5,800002fa <consoleintr+0x3c>
    80000388:	a07d                	j	80000436 <consoleintr+0x178>
    while(cons.e != cons.w &&
    8000038a:	00011717          	auipc	a4,0x11
    8000038e:	02670713          	addi	a4,a4,38 # 800113b0 <cons>
    80000392:	0a072783          	lw	a5,160(a4)
    80000396:	09c72703          	lw	a4,156(a4)
          cons.buf[(cons.e-1) % INPUT_BUF_SIZE] != '\n'){
    8000039a:	00011497          	auipc	s1,0x11
    8000039e:	01648493          	addi	s1,s1,22 # 800113b0 <cons>
    while(cons.e != cons.w &&
    800003a2:	4929                	li	s2,10
    800003a4:	f4f70be3          	beq	a4,a5,800002fa <consoleintr+0x3c>
          cons.buf[(cons.e-1) % INPUT_BUF_SIZE] != '\n'){
    800003a8:	37fd                	addiw	a5,a5,-1
    800003aa:	07f7f713          	andi	a4,a5,127
    800003ae:	9726                	add	a4,a4,s1
    while(cons.e != cons.w &&
    800003b0:	01874703          	lbu	a4,24(a4)
    800003b4:	f52703e3          	beq	a4,s2,800002fa <consoleintr+0x3c>
      cons.e--;
    800003b8:	0af4a023          	sw	a5,160(s1)
      consputc(BACKSPACE);
    800003bc:	10000513          	li	a0,256
    800003c0:	00000097          	auipc	ra,0x0
    800003c4:	ebc080e7          	jalr	-324(ra) # 8000027c <consputc>
    while(cons.e != cons.w &&
    800003c8:	0a04a783          	lw	a5,160(s1)
    800003cc:	09c4a703          	lw	a4,156(s1)
    800003d0:	fcf71ce3          	bne	a4,a5,800003a8 <consoleintr+0xea>
    800003d4:	b71d                	j	800002fa <consoleintr+0x3c>
    if(cons.e != cons.w){
    800003d6:	00011717          	auipc	a4,0x11
    800003da:	fda70713          	addi	a4,a4,-38 # 800113b0 <cons>
    800003de:	0a072783          	lw	a5,160(a4)
    800003e2:	09c72703          	lw	a4,156(a4)
    800003e6:	f0f70ae3          	beq	a4,a5,800002fa <consoleintr+0x3c>
      cons.e--;
    800003ea:	37fd                	addiw	a5,a5,-1
    800003ec:	00011717          	auipc	a4,0x11
    800003f0:	06f72223          	sw	a5,100(a4) # 80011450 <cons+0xa0>
      consputc(BACKSPACE);
    800003f4:	10000513          	li	a0,256
    800003f8:	00000097          	auipc	ra,0x0
    800003fc:	e84080e7          	jalr	-380(ra) # 8000027c <consputc>
    80000400:	bded                	j	800002fa <consoleintr+0x3c>
    if(c != 0 && cons.e-cons.r < INPUT_BUF_SIZE){
    80000402:	ee048ce3          	beqz	s1,800002fa <consoleintr+0x3c>
    80000406:	bf21                	j	8000031e <consoleintr+0x60>
      consputc(c);
    80000408:	4529                	li	a0,10
    8000040a:	00000097          	auipc	ra,0x0
    8000040e:	e72080e7          	jalr	-398(ra) # 8000027c <consputc>
      cons.buf[cons.e++ % INPUT_BUF_SIZE] = c;
    80000412:	00011797          	auipc	a5,0x11
    80000416:	f9e78793          	addi	a5,a5,-98 # 800113b0 <cons>
    8000041a:	0a07a703          	lw	a4,160(a5)
    8000041e:	0017069b          	addiw	a3,a4,1
    80000422:	0006861b          	sext.w	a2,a3
    80000426:	0ad7a023          	sw	a3,160(a5)
    8000042a:	07f77713          	andi	a4,a4,127
    8000042e:	97ba                	add	a5,a5,a4
    80000430:	4729                	li	a4,10
    80000432:	00e78c23          	sb	a4,24(a5)
        cons.w = cons.e;
    80000436:	00011797          	auipc	a5,0x11
    8000043a:	00c7ab23          	sw	a2,22(a5) # 8001144c <cons+0x9c>
        wakeup(&cons.r);
    8000043e:	00011517          	auipc	a0,0x11
    80000442:	00a50513          	addi	a0,a0,10 # 80011448 <cons+0x98>
    80000446:	00002097          	auipc	ra,0x2
    8000044a:	d32080e7          	jalr	-718(ra) # 80002178 <wakeup>
    8000044e:	b575                	j	800002fa <consoleintr+0x3c>

0000000080000450 <consoleinit>:

void
consoleinit(void)
{
    80000450:	1141                	addi	sp,sp,-16
    80000452:	e406                	sd	ra,8(sp)
    80000454:	e022                	sd	s0,0(sp)
    80000456:	0800                	addi	s0,sp,16
  initlock(&cons.lock, "cons");
    80000458:	00008597          	auipc	a1,0x8
    8000045c:	bb858593          	addi	a1,a1,-1096 # 80008010 <etext+0x10>
    80000460:	00011517          	auipc	a0,0x11
    80000464:	f5050513          	addi	a0,a0,-176 # 800113b0 <cons>
    80000468:	00000097          	auipc	ra,0x0
    8000046c:	6de080e7          	jalr	1758(ra) # 80000b46 <initlock>

  uartinit();
    80000470:	00000097          	auipc	ra,0x0
    80000474:	32a080e7          	jalr	810(ra) # 8000079a <uartinit>

  // connect read and write system calls
  // to consoleread and consolewrite.
  devsw[CONSOLE].read = consoleread;
    80000478:	00021797          	auipc	a5,0x21
    8000047c:	2d078793          	addi	a5,a5,720 # 80021748 <devsw>
    80000480:	00000717          	auipc	a4,0x0
    80000484:	ce470713          	addi	a4,a4,-796 # 80000164 <consoleread>
    80000488:	eb98                	sd	a4,16(a5)
  devsw[CONSOLE].write = consolewrite;
    8000048a:	00000717          	auipc	a4,0x0
    8000048e:	c7870713          	addi	a4,a4,-904 # 80000102 <consolewrite>
    80000492:	ef98                	sd	a4,24(a5)
}
    80000494:	60a2                	ld	ra,8(sp)
    80000496:	6402                	ld	s0,0(sp)
    80000498:	0141                	addi	sp,sp,16
    8000049a:	8082                	ret

000000008000049c <printint>:

static char digits[] = "0123456789abcdef";

static void
printint(int xx, int base, int sign)
{
    8000049c:	7179                	addi	sp,sp,-48
    8000049e:	f406                	sd	ra,40(sp)
    800004a0:	f022                	sd	s0,32(sp)
    800004a2:	ec26                	sd	s1,24(sp)
    800004a4:	e84a                	sd	s2,16(sp)
    800004a6:	1800                	addi	s0,sp,48
  char buf[16];
  int i;
  uint x;

  if(sign && (sign = xx < 0))
    800004a8:	c219                	beqz	a2,800004ae <printint+0x12>
    800004aa:	08054663          	bltz	a0,80000536 <printint+0x9a>
    x = -xx;
  else
    x = xx;
    800004ae:	2501                	sext.w	a0,a0
    800004b0:	4881                	li	a7,0
    800004b2:	fd040693          	addi	a3,s0,-48

  i = 0;
    800004b6:	4701                	li	a4,0
  do {
    buf[i++] = digits[x % base];
    800004b8:	2581                	sext.w	a1,a1
    800004ba:	00008617          	auipc	a2,0x8
    800004be:	b8660613          	addi	a2,a2,-1146 # 80008040 <digits>
    800004c2:	883a                	mv	a6,a4
    800004c4:	2705                	addiw	a4,a4,1
    800004c6:	02b577bb          	remuw	a5,a0,a1
    800004ca:	1782                	slli	a5,a5,0x20
    800004cc:	9381                	srli	a5,a5,0x20
    800004ce:	97b2                	add	a5,a5,a2
    800004d0:	0007c783          	lbu	a5,0(a5)
    800004d4:	00f68023          	sb	a5,0(a3)
  } while((x /= base) != 0);
    800004d8:	0005079b          	sext.w	a5,a0
    800004dc:	02b5553b          	divuw	a0,a0,a1
    800004e0:	0685                	addi	a3,a3,1
    800004e2:	feb7f0e3          	bgeu	a5,a1,800004c2 <printint+0x26>

  if(sign)
    800004e6:	00088b63          	beqz	a7,800004fc <printint+0x60>
    buf[i++] = '-';
    800004ea:	fe040793          	addi	a5,s0,-32
    800004ee:	973e                	add	a4,a4,a5
    800004f0:	02d00793          	li	a5,45
    800004f4:	fef70823          	sb	a5,-16(a4)
    800004f8:	0028071b          	addiw	a4,a6,2

  while(--i >= 0)
    800004fc:	02e05763          	blez	a4,8000052a <printint+0x8e>
    80000500:	fd040793          	addi	a5,s0,-48
    80000504:	00e784b3          	add	s1,a5,a4
    80000508:	fff78913          	addi	s2,a5,-1
    8000050c:	993a                	add	s2,s2,a4
    8000050e:	377d                	addiw	a4,a4,-1
    80000510:	1702                	slli	a4,a4,0x20
    80000512:	9301                	srli	a4,a4,0x20
    80000514:	40e90933          	sub	s2,s2,a4
    consputc(buf[i]);
    80000518:	fff4c503          	lbu	a0,-1(s1)
    8000051c:	00000097          	auipc	ra,0x0
    80000520:	d60080e7          	jalr	-672(ra) # 8000027c <consputc>
  while(--i >= 0)
    80000524:	14fd                	addi	s1,s1,-1
    80000526:	ff2499e3          	bne	s1,s2,80000518 <printint+0x7c>
}
    8000052a:	70a2                	ld	ra,40(sp)
    8000052c:	7402                	ld	s0,32(sp)
    8000052e:	64e2                	ld	s1,24(sp)
    80000530:	6942                	ld	s2,16(sp)
    80000532:	6145                	addi	sp,sp,48
    80000534:	8082                	ret
    x = -xx;
    80000536:	40a0053b          	negw	a0,a0
  if(sign && (sign = xx < 0))
    8000053a:	4885                	li	a7,1
    x = -xx;
    8000053c:	bf9d                	j	800004b2 <printint+0x16>

000000008000053e <panic>:
    release(&pr.lock);
}

void
panic(char *s)
{
    8000053e:	1101                	addi	sp,sp,-32
    80000540:	ec06                	sd	ra,24(sp)
    80000542:	e822                	sd	s0,16(sp)
    80000544:	e426                	sd	s1,8(sp)
    80000546:	1000                	addi	s0,sp,32
    80000548:	84aa                	mv	s1,a0
  pr.locking = 0;
    8000054a:	00011797          	auipc	a5,0x11
    8000054e:	f207a323          	sw	zero,-218(a5) # 80011470 <pr+0x18>
  printf("panic: ");
    80000552:	00008517          	auipc	a0,0x8
    80000556:	ac650513          	addi	a0,a0,-1338 # 80008018 <etext+0x18>
    8000055a:	00000097          	auipc	ra,0x0
    8000055e:	02e080e7          	jalr	46(ra) # 80000588 <printf>
  printf(s);
    80000562:	8526                	mv	a0,s1
    80000564:	00000097          	auipc	ra,0x0
    80000568:	024080e7          	jalr	36(ra) # 80000588 <printf>
  printf("\n");
    8000056c:	00008517          	auipc	a0,0x8
    80000570:	b6c50513          	addi	a0,a0,-1172 # 800080d8 <digits+0x98>
    80000574:	00000097          	auipc	ra,0x0
    80000578:	014080e7          	jalr	20(ra) # 80000588 <printf>
  panicked = 1; // freeze uart output from other CPUs
    8000057c:	4785                	li	a5,1
    8000057e:	00009717          	auipc	a4,0x9
    80000582:	caf72923          	sw	a5,-846(a4) # 80009230 <panicked>
  for(;;)
    80000586:	a001                	j	80000586 <panic+0x48>

0000000080000588 <printf>:
{
    80000588:	7131                	addi	sp,sp,-192
    8000058a:	fc86                	sd	ra,120(sp)
    8000058c:	f8a2                	sd	s0,112(sp)
    8000058e:	f4a6                	sd	s1,104(sp)
    80000590:	f0ca                	sd	s2,96(sp)
    80000592:	ecce                	sd	s3,88(sp)
    80000594:	e8d2                	sd	s4,80(sp)
    80000596:	e4d6                	sd	s5,72(sp)
    80000598:	e0da                	sd	s6,64(sp)
    8000059a:	fc5e                	sd	s7,56(sp)
    8000059c:	f862                	sd	s8,48(sp)
    8000059e:	f466                	sd	s9,40(sp)
    800005a0:	f06a                	sd	s10,32(sp)
    800005a2:	ec6e                	sd	s11,24(sp)
    800005a4:	0100                	addi	s0,sp,128
    800005a6:	8a2a                	mv	s4,a0
    800005a8:	e40c                	sd	a1,8(s0)
    800005aa:	e810                	sd	a2,16(s0)
    800005ac:	ec14                	sd	a3,24(s0)
    800005ae:	f018                	sd	a4,32(s0)
    800005b0:	f41c                	sd	a5,40(s0)
    800005b2:	03043823          	sd	a6,48(s0)
    800005b6:	03143c23          	sd	a7,56(s0)
  locking = pr.locking;
    800005ba:	00011d97          	auipc	s11,0x11
    800005be:	eb6dad83          	lw	s11,-330(s11) # 80011470 <pr+0x18>
  if(locking)
    800005c2:	020d9b63          	bnez	s11,800005f8 <printf+0x70>
  if (fmt == 0)
    800005c6:	040a0263          	beqz	s4,8000060a <printf+0x82>
  va_start(ap, fmt);
    800005ca:	00840793          	addi	a5,s0,8
    800005ce:	f8f43423          	sd	a5,-120(s0)
  for(i = 0; (c = fmt[i] & 0xff) != 0; i++){
    800005d2:	000a4503          	lbu	a0,0(s4)
    800005d6:	14050f63          	beqz	a0,80000734 <printf+0x1ac>
    800005da:	4981                	li	s3,0
    if(c != '%'){
    800005dc:	02500a93          	li	s5,37
    switch(c){
    800005e0:	07000b93          	li	s7,112
  consputc('x');
    800005e4:	4d41                	li	s10,16
    consputc(digits[x >> (sizeof(uint64) * 8 - 4)]);
    800005e6:	00008b17          	auipc	s6,0x8
    800005ea:	a5ab0b13          	addi	s6,s6,-1446 # 80008040 <digits>
    switch(c){
    800005ee:	07300c93          	li	s9,115
    800005f2:	06400c13          	li	s8,100
    800005f6:	a82d                	j	80000630 <printf+0xa8>
    acquire(&pr.lock);
    800005f8:	00011517          	auipc	a0,0x11
    800005fc:	e6050513          	addi	a0,a0,-416 # 80011458 <pr>
    80000600:	00000097          	auipc	ra,0x0
    80000604:	5d6080e7          	jalr	1494(ra) # 80000bd6 <acquire>
    80000608:	bf7d                	j	800005c6 <printf+0x3e>
    panic("null fmt");
    8000060a:	00008517          	auipc	a0,0x8
    8000060e:	a1e50513          	addi	a0,a0,-1506 # 80008028 <etext+0x28>
    80000612:	00000097          	auipc	ra,0x0
    80000616:	f2c080e7          	jalr	-212(ra) # 8000053e <panic>
      consputc(c);
    8000061a:	00000097          	auipc	ra,0x0
    8000061e:	c62080e7          	jalr	-926(ra) # 8000027c <consputc>
  for(i = 0; (c = fmt[i] & 0xff) != 0; i++){
    80000622:	2985                	addiw	s3,s3,1
    80000624:	013a07b3          	add	a5,s4,s3
    80000628:	0007c503          	lbu	a0,0(a5)
    8000062c:	10050463          	beqz	a0,80000734 <printf+0x1ac>
    if(c != '%'){
    80000630:	ff5515e3          	bne	a0,s5,8000061a <printf+0x92>
    c = fmt[++i] & 0xff;
    80000634:	2985                	addiw	s3,s3,1
    80000636:	013a07b3          	add	a5,s4,s3
    8000063a:	0007c783          	lbu	a5,0(a5)
    8000063e:	0007849b          	sext.w	s1,a5
    if(c == 0)
    80000642:	cbed                	beqz	a5,80000734 <printf+0x1ac>
    switch(c){
    80000644:	05778a63          	beq	a5,s7,80000698 <printf+0x110>
    80000648:	02fbf663          	bgeu	s7,a5,80000674 <printf+0xec>
    8000064c:	09978863          	beq	a5,s9,800006dc <printf+0x154>
    80000650:	07800713          	li	a4,120
    80000654:	0ce79563          	bne	a5,a4,8000071e <printf+0x196>
      printint(va_arg(ap, int), 16, 1);
    80000658:	f8843783          	ld	a5,-120(s0)
    8000065c:	00878713          	addi	a4,a5,8
    80000660:	f8e43423          	sd	a4,-120(s0)
    80000664:	4605                	li	a2,1
    80000666:	85ea                	mv	a1,s10
    80000668:	4388                	lw	a0,0(a5)
    8000066a:	00000097          	auipc	ra,0x0
    8000066e:	e32080e7          	jalr	-462(ra) # 8000049c <printint>
      break;
    80000672:	bf45                	j	80000622 <printf+0x9a>
    switch(c){
    80000674:	09578f63          	beq	a5,s5,80000712 <printf+0x18a>
    80000678:	0b879363          	bne	a5,s8,8000071e <printf+0x196>
      printint(va_arg(ap, int), 10, 1);
    8000067c:	f8843783          	ld	a5,-120(s0)
    80000680:	00878713          	addi	a4,a5,8
    80000684:	f8e43423          	sd	a4,-120(s0)
    80000688:	4605                	li	a2,1
    8000068a:	45a9                	li	a1,10
    8000068c:	4388                	lw	a0,0(a5)
    8000068e:	00000097          	auipc	ra,0x0
    80000692:	e0e080e7          	jalr	-498(ra) # 8000049c <printint>
      break;
    80000696:	b771                	j	80000622 <printf+0x9a>
      printptr(va_arg(ap, uint64));
    80000698:	f8843783          	ld	a5,-120(s0)
    8000069c:	00878713          	addi	a4,a5,8
    800006a0:	f8e43423          	sd	a4,-120(s0)
    800006a4:	0007b903          	ld	s2,0(a5)
  consputc('0');
    800006a8:	03000513          	li	a0,48
    800006ac:	00000097          	auipc	ra,0x0
    800006b0:	bd0080e7          	jalr	-1072(ra) # 8000027c <consputc>
  consputc('x');
    800006b4:	07800513          	li	a0,120
    800006b8:	00000097          	auipc	ra,0x0
    800006bc:	bc4080e7          	jalr	-1084(ra) # 8000027c <consputc>
    800006c0:	84ea                	mv	s1,s10
    consputc(digits[x >> (sizeof(uint64) * 8 - 4)]);
    800006c2:	03c95793          	srli	a5,s2,0x3c
    800006c6:	97da                	add	a5,a5,s6
    800006c8:	0007c503          	lbu	a0,0(a5)
    800006cc:	00000097          	auipc	ra,0x0
    800006d0:	bb0080e7          	jalr	-1104(ra) # 8000027c <consputc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
    800006d4:	0912                	slli	s2,s2,0x4
    800006d6:	34fd                	addiw	s1,s1,-1
    800006d8:	f4ed                	bnez	s1,800006c2 <printf+0x13a>
    800006da:	b7a1                	j	80000622 <printf+0x9a>
      if((s = va_arg(ap, char*)) == 0)
    800006dc:	f8843783          	ld	a5,-120(s0)
    800006e0:	00878713          	addi	a4,a5,8
    800006e4:	f8e43423          	sd	a4,-120(s0)
    800006e8:	6384                	ld	s1,0(a5)
    800006ea:	cc89                	beqz	s1,80000704 <printf+0x17c>
      for(; *s; s++)
    800006ec:	0004c503          	lbu	a0,0(s1)
    800006f0:	d90d                	beqz	a0,80000622 <printf+0x9a>
        consputc(*s);
    800006f2:	00000097          	auipc	ra,0x0
    800006f6:	b8a080e7          	jalr	-1142(ra) # 8000027c <consputc>
      for(; *s; s++)
    800006fa:	0485                	addi	s1,s1,1
    800006fc:	0004c503          	lbu	a0,0(s1)
    80000700:	f96d                	bnez	a0,800006f2 <printf+0x16a>
    80000702:	b705                	j	80000622 <printf+0x9a>
        s = "(null)";
    80000704:	00008497          	auipc	s1,0x8
    80000708:	91c48493          	addi	s1,s1,-1764 # 80008020 <etext+0x20>
      for(; *s; s++)
    8000070c:	02800513          	li	a0,40
    80000710:	b7cd                	j	800006f2 <printf+0x16a>
      consputc('%');
    80000712:	8556                	mv	a0,s5
    80000714:	00000097          	auipc	ra,0x0
    80000718:	b68080e7          	jalr	-1176(ra) # 8000027c <consputc>
      break;
    8000071c:	b719                	j	80000622 <printf+0x9a>
      consputc('%');
    8000071e:	8556                	mv	a0,s5
    80000720:	00000097          	auipc	ra,0x0
    80000724:	b5c080e7          	jalr	-1188(ra) # 8000027c <consputc>
      consputc(c);
    80000728:	8526                	mv	a0,s1
    8000072a:	00000097          	auipc	ra,0x0
    8000072e:	b52080e7          	jalr	-1198(ra) # 8000027c <consputc>
      break;
    80000732:	bdc5                	j	80000622 <printf+0x9a>
  if(locking)
    80000734:	020d9163          	bnez	s11,80000756 <printf+0x1ce>
}
    80000738:	70e6                	ld	ra,120(sp)
    8000073a:	7446                	ld	s0,112(sp)
    8000073c:	74a6                	ld	s1,104(sp)
    8000073e:	7906                	ld	s2,96(sp)
    80000740:	69e6                	ld	s3,88(sp)
    80000742:	6a46                	ld	s4,80(sp)
    80000744:	6aa6                	ld	s5,72(sp)
    80000746:	6b06                	ld	s6,64(sp)
    80000748:	7be2                	ld	s7,56(sp)
    8000074a:	7c42                	ld	s8,48(sp)
    8000074c:	7ca2                	ld	s9,40(sp)
    8000074e:	7d02                	ld	s10,32(sp)
    80000750:	6de2                	ld	s11,24(sp)
    80000752:	6129                	addi	sp,sp,192
    80000754:	8082                	ret
    release(&pr.lock);
    80000756:	00011517          	auipc	a0,0x11
    8000075a:	d0250513          	addi	a0,a0,-766 # 80011458 <pr>
    8000075e:	00000097          	auipc	ra,0x0
    80000762:	52c080e7          	jalr	1324(ra) # 80000c8a <release>
}
    80000766:	bfc9                	j	80000738 <printf+0x1b0>

0000000080000768 <printfinit>:
    ;
}

void
printfinit(void)
{
    80000768:	1101                	addi	sp,sp,-32
    8000076a:	ec06                	sd	ra,24(sp)
    8000076c:	e822                	sd	s0,16(sp)
    8000076e:	e426                	sd	s1,8(sp)
    80000770:	1000                	addi	s0,sp,32
  initlock(&pr.lock, "pr");
    80000772:	00011497          	auipc	s1,0x11
    80000776:	ce648493          	addi	s1,s1,-794 # 80011458 <pr>
    8000077a:	00008597          	auipc	a1,0x8
    8000077e:	8be58593          	addi	a1,a1,-1858 # 80008038 <etext+0x38>
    80000782:	8526                	mv	a0,s1
    80000784:	00000097          	auipc	ra,0x0
    80000788:	3c2080e7          	jalr	962(ra) # 80000b46 <initlock>
  pr.locking = 1;
    8000078c:	4785                	li	a5,1
    8000078e:	cc9c                	sw	a5,24(s1)
}
    80000790:	60e2                	ld	ra,24(sp)
    80000792:	6442                	ld	s0,16(sp)
    80000794:	64a2                	ld	s1,8(sp)
    80000796:	6105                	addi	sp,sp,32
    80000798:	8082                	ret

000000008000079a <uartinit>:

void uartstart();

void
uartinit(void)
{
    8000079a:	1141                	addi	sp,sp,-16
    8000079c:	e406                	sd	ra,8(sp)
    8000079e:	e022                	sd	s0,0(sp)
    800007a0:	0800                	addi	s0,sp,16
  // disable interrupts.
  WriteReg(IER, 0x00);
    800007a2:	100007b7          	lui	a5,0x10000
    800007a6:	000780a3          	sb	zero,1(a5) # 10000001 <_entry-0x6fffffff>

  // special mode to set baud rate.
  WriteReg(LCR, LCR_BAUD_LATCH);
    800007aa:	f8000713          	li	a4,-128
    800007ae:	00e781a3          	sb	a4,3(a5)

  // LSB for baud rate of 38.4K.
  WriteReg(0, 0x03);
    800007b2:	470d                	li	a4,3
    800007b4:	00e78023          	sb	a4,0(a5)

  // MSB for baud rate of 38.4K.
  WriteReg(1, 0x00);
    800007b8:	000780a3          	sb	zero,1(a5)

  // leave set-baud mode,
  // and set word length to 8 bits, no parity.
  WriteReg(LCR, LCR_EIGHT_BITS);
    800007bc:	00e781a3          	sb	a4,3(a5)

  // reset and enable FIFOs.
  WriteReg(FCR, FCR_FIFO_ENABLE | FCR_FIFO_CLEAR);
    800007c0:	469d                	li	a3,7
    800007c2:	00d78123          	sb	a3,2(a5)

  // enable transmit and receive interrupts.
  WriteReg(IER, IER_TX_ENABLE | IER_RX_ENABLE);
    800007c6:	00e780a3          	sb	a4,1(a5)

  initlock(&uart_tx_lock, "uart");
    800007ca:	00008597          	auipc	a1,0x8
    800007ce:	88e58593          	addi	a1,a1,-1906 # 80008058 <digits+0x18>
    800007d2:	00011517          	auipc	a0,0x11
    800007d6:	ca650513          	addi	a0,a0,-858 # 80011478 <uart_tx_lock>
    800007da:	00000097          	auipc	ra,0x0
    800007de:	36c080e7          	jalr	876(ra) # 80000b46 <initlock>
}
    800007e2:	60a2                	ld	ra,8(sp)
    800007e4:	6402                	ld	s0,0(sp)
    800007e6:	0141                	addi	sp,sp,16
    800007e8:	8082                	ret

00000000800007ea <uartputc_sync>:
// use interrupts, for use by kernel printf() and
// to echo characters. it spins waiting for the uart's
// output register to be empty.
void
uartputc_sync(int c)
{
    800007ea:	1101                	addi	sp,sp,-32
    800007ec:	ec06                	sd	ra,24(sp)
    800007ee:	e822                	sd	s0,16(sp)
    800007f0:	e426                	sd	s1,8(sp)
    800007f2:	1000                	addi	s0,sp,32
    800007f4:	84aa                	mv	s1,a0
  push_off();
    800007f6:	00000097          	auipc	ra,0x0
    800007fa:	394080e7          	jalr	916(ra) # 80000b8a <push_off>

  if(panicked){
    800007fe:	00009797          	auipc	a5,0x9
    80000802:	a327a783          	lw	a5,-1486(a5) # 80009230 <panicked>
    for(;;)
      ;
  }

  // wait for Transmit Holding Empty to be set in LSR.
  while((ReadReg(LSR) & LSR_TX_IDLE) == 0)
    80000806:	10000737          	lui	a4,0x10000
  if(panicked){
    8000080a:	c391                	beqz	a5,8000080e <uartputc_sync+0x24>
    for(;;)
    8000080c:	a001                	j	8000080c <uartputc_sync+0x22>
  while((ReadReg(LSR) & LSR_TX_IDLE) == 0)
    8000080e:	00574783          	lbu	a5,5(a4) # 10000005 <_entry-0x6ffffffb>
    80000812:	0207f793          	andi	a5,a5,32
    80000816:	dfe5                	beqz	a5,8000080e <uartputc_sync+0x24>
    ;
  WriteReg(THR, c);
    80000818:	0ff4f513          	andi	a0,s1,255
    8000081c:	100007b7          	lui	a5,0x10000
    80000820:	00a78023          	sb	a0,0(a5) # 10000000 <_entry-0x70000000>

  pop_off();
    80000824:	00000097          	auipc	ra,0x0
    80000828:	406080e7          	jalr	1030(ra) # 80000c2a <pop_off>
}
    8000082c:	60e2                	ld	ra,24(sp)
    8000082e:	6442                	ld	s0,16(sp)
    80000830:	64a2                	ld	s1,8(sp)
    80000832:	6105                	addi	sp,sp,32
    80000834:	8082                	ret

0000000080000836 <uartstart>:
// called from both the top- and bottom-half.
void
uartstart()
{
  while(1){
    if(uart_tx_w == uart_tx_r){
    80000836:	00009797          	auipc	a5,0x9
    8000083a:	a027b783          	ld	a5,-1534(a5) # 80009238 <uart_tx_r>
    8000083e:	00009717          	auipc	a4,0x9
    80000842:	a0273703          	ld	a4,-1534(a4) # 80009240 <uart_tx_w>
    80000846:	06f70a63          	beq	a4,a5,800008ba <uartstart+0x84>
{
    8000084a:	7139                	addi	sp,sp,-64
    8000084c:	fc06                	sd	ra,56(sp)
    8000084e:	f822                	sd	s0,48(sp)
    80000850:	f426                	sd	s1,40(sp)
    80000852:	f04a                	sd	s2,32(sp)
    80000854:	ec4e                	sd	s3,24(sp)
    80000856:	e852                	sd	s4,16(sp)
    80000858:	e456                	sd	s5,8(sp)
    8000085a:	0080                	addi	s0,sp,64
      // transmit buffer is empty.
      return;
    }
    
    if((ReadReg(LSR) & LSR_TX_IDLE) == 0){
    8000085c:	10000937          	lui	s2,0x10000
      // so we cannot give it another byte.
      // it will interrupt when it's ready for a new byte.
      return;
    }
    
    int c = uart_tx_buf[uart_tx_r % UART_TX_BUF_SIZE];
    80000860:	00011a17          	auipc	s4,0x11
    80000864:	c18a0a13          	addi	s4,s4,-1000 # 80011478 <uart_tx_lock>
    uart_tx_r += 1;
    80000868:	00009497          	auipc	s1,0x9
    8000086c:	9d048493          	addi	s1,s1,-1584 # 80009238 <uart_tx_r>
    if(uart_tx_w == uart_tx_r){
    80000870:	00009997          	auipc	s3,0x9
    80000874:	9d098993          	addi	s3,s3,-1584 # 80009240 <uart_tx_w>
    if((ReadReg(LSR) & LSR_TX_IDLE) == 0){
    80000878:	00594703          	lbu	a4,5(s2) # 10000005 <_entry-0x6ffffffb>
    8000087c:	02077713          	andi	a4,a4,32
    80000880:	c705                	beqz	a4,800008a8 <uartstart+0x72>
    int c = uart_tx_buf[uart_tx_r % UART_TX_BUF_SIZE];
    80000882:	01f7f713          	andi	a4,a5,31
    80000886:	9752                	add	a4,a4,s4
    80000888:	01874a83          	lbu	s5,24(a4)
    uart_tx_r += 1;
    8000088c:	0785                	addi	a5,a5,1
    8000088e:	e09c                	sd	a5,0(s1)
    
    // maybe uartputc() is waiting for space in the buffer.
    wakeup(&uart_tx_r);
    80000890:	8526                	mv	a0,s1
    80000892:	00002097          	auipc	ra,0x2
    80000896:	8e6080e7          	jalr	-1818(ra) # 80002178 <wakeup>
    
    WriteReg(THR, c);
    8000089a:	01590023          	sb	s5,0(s2)
    if(uart_tx_w == uart_tx_r){
    8000089e:	609c                	ld	a5,0(s1)
    800008a0:	0009b703          	ld	a4,0(s3)
    800008a4:	fcf71ae3          	bne	a4,a5,80000878 <uartstart+0x42>
  }
}
    800008a8:	70e2                	ld	ra,56(sp)
    800008aa:	7442                	ld	s0,48(sp)
    800008ac:	74a2                	ld	s1,40(sp)
    800008ae:	7902                	ld	s2,32(sp)
    800008b0:	69e2                	ld	s3,24(sp)
    800008b2:	6a42                	ld	s4,16(sp)
    800008b4:	6aa2                	ld	s5,8(sp)
    800008b6:	6121                	addi	sp,sp,64
    800008b8:	8082                	ret
    800008ba:	8082                	ret

00000000800008bc <uartputc>:
{
    800008bc:	7179                	addi	sp,sp,-48
    800008be:	f406                	sd	ra,40(sp)
    800008c0:	f022                	sd	s0,32(sp)
    800008c2:	ec26                	sd	s1,24(sp)
    800008c4:	e84a                	sd	s2,16(sp)
    800008c6:	e44e                	sd	s3,8(sp)
    800008c8:	e052                	sd	s4,0(sp)
    800008ca:	1800                	addi	s0,sp,48
    800008cc:	8a2a                	mv	s4,a0
  acquire(&uart_tx_lock);
    800008ce:	00011517          	auipc	a0,0x11
    800008d2:	baa50513          	addi	a0,a0,-1110 # 80011478 <uart_tx_lock>
    800008d6:	00000097          	auipc	ra,0x0
    800008da:	300080e7          	jalr	768(ra) # 80000bd6 <acquire>
  if(panicked){
    800008de:	00009797          	auipc	a5,0x9
    800008e2:	9527a783          	lw	a5,-1710(a5) # 80009230 <panicked>
    800008e6:	e7c9                	bnez	a5,80000970 <uartputc+0xb4>
  while(uart_tx_w == uart_tx_r + UART_TX_BUF_SIZE){
    800008e8:	00009717          	auipc	a4,0x9
    800008ec:	95873703          	ld	a4,-1704(a4) # 80009240 <uart_tx_w>
    800008f0:	00009797          	auipc	a5,0x9
    800008f4:	9487b783          	ld	a5,-1720(a5) # 80009238 <uart_tx_r>
    800008f8:	02078793          	addi	a5,a5,32
    sleep(&uart_tx_r, &uart_tx_lock);
    800008fc:	00011997          	auipc	s3,0x11
    80000900:	b7c98993          	addi	s3,s3,-1156 # 80011478 <uart_tx_lock>
    80000904:	00009497          	auipc	s1,0x9
    80000908:	93448493          	addi	s1,s1,-1740 # 80009238 <uart_tx_r>
  while(uart_tx_w == uart_tx_r + UART_TX_BUF_SIZE){
    8000090c:	00009917          	auipc	s2,0x9
    80000910:	93490913          	addi	s2,s2,-1740 # 80009240 <uart_tx_w>
    80000914:	00e79f63          	bne	a5,a4,80000932 <uartputc+0x76>
    sleep(&uart_tx_r, &uart_tx_lock);
    80000918:	85ce                	mv	a1,s3
    8000091a:	8526                	mv	a0,s1
    8000091c:	00001097          	auipc	ra,0x1
    80000920:	7f8080e7          	jalr	2040(ra) # 80002114 <sleep>
  while(uart_tx_w == uart_tx_r + UART_TX_BUF_SIZE){
    80000924:	00093703          	ld	a4,0(s2)
    80000928:	609c                	ld	a5,0(s1)
    8000092a:	02078793          	addi	a5,a5,32
    8000092e:	fee785e3          	beq	a5,a4,80000918 <uartputc+0x5c>
  uart_tx_buf[uart_tx_w % UART_TX_BUF_SIZE] = c;
    80000932:	00011497          	auipc	s1,0x11
    80000936:	b4648493          	addi	s1,s1,-1210 # 80011478 <uart_tx_lock>
    8000093a:	01f77793          	andi	a5,a4,31
    8000093e:	97a6                	add	a5,a5,s1
    80000940:	01478c23          	sb	s4,24(a5)
  uart_tx_w += 1;
    80000944:	0705                	addi	a4,a4,1
    80000946:	00009797          	auipc	a5,0x9
    8000094a:	8ee7bd23          	sd	a4,-1798(a5) # 80009240 <uart_tx_w>
  uartstart();
    8000094e:	00000097          	auipc	ra,0x0
    80000952:	ee8080e7          	jalr	-280(ra) # 80000836 <uartstart>
  release(&uart_tx_lock);
    80000956:	8526                	mv	a0,s1
    80000958:	00000097          	auipc	ra,0x0
    8000095c:	332080e7          	jalr	818(ra) # 80000c8a <release>
}
    80000960:	70a2                	ld	ra,40(sp)
    80000962:	7402                	ld	s0,32(sp)
    80000964:	64e2                	ld	s1,24(sp)
    80000966:	6942                	ld	s2,16(sp)
    80000968:	69a2                	ld	s3,8(sp)
    8000096a:	6a02                	ld	s4,0(sp)
    8000096c:	6145                	addi	sp,sp,48
    8000096e:	8082                	ret
    for(;;)
    80000970:	a001                	j	80000970 <uartputc+0xb4>

0000000080000972 <uartgetc>:

// read one input character from the UART.
// return -1 if none is waiting.
int
uartgetc(void)
{
    80000972:	1141                	addi	sp,sp,-16
    80000974:	e422                	sd	s0,8(sp)
    80000976:	0800                	addi	s0,sp,16
  if(ReadReg(LSR) & 0x01){
    80000978:	100007b7          	lui	a5,0x10000
    8000097c:	0057c783          	lbu	a5,5(a5) # 10000005 <_entry-0x6ffffffb>
    80000980:	8b85                	andi	a5,a5,1
    80000982:	cb91                	beqz	a5,80000996 <uartgetc+0x24>
    // input data is ready.
    return ReadReg(RHR);
    80000984:	100007b7          	lui	a5,0x10000
    80000988:	0007c503          	lbu	a0,0(a5) # 10000000 <_entry-0x70000000>
    8000098c:	0ff57513          	andi	a0,a0,255
  } else {
    return -1;
  }
}
    80000990:	6422                	ld	s0,8(sp)
    80000992:	0141                	addi	sp,sp,16
    80000994:	8082                	ret
    return -1;
    80000996:	557d                	li	a0,-1
    80000998:	bfe5                	j	80000990 <uartgetc+0x1e>

000000008000099a <uartintr>:
// handle a uart interrupt, raised because input has
// arrived, or the uart is ready for more output, or
// both. called from devintr().
void
uartintr(void)
{
    8000099a:	1101                	addi	sp,sp,-32
    8000099c:	ec06                	sd	ra,24(sp)
    8000099e:	e822                	sd	s0,16(sp)
    800009a0:	e426                	sd	s1,8(sp)
    800009a2:	1000                	addi	s0,sp,32
  // read and process incoming characters.
  while(1){
    int c = uartgetc();
    if(c == -1)
    800009a4:	54fd                	li	s1,-1
    800009a6:	a029                	j	800009b0 <uartintr+0x16>
      break;
    consoleintr(c);
    800009a8:	00000097          	auipc	ra,0x0
    800009ac:	916080e7          	jalr	-1770(ra) # 800002be <consoleintr>
    int c = uartgetc();
    800009b0:	00000097          	auipc	ra,0x0
    800009b4:	fc2080e7          	jalr	-62(ra) # 80000972 <uartgetc>
    if(c == -1)
    800009b8:	fe9518e3          	bne	a0,s1,800009a8 <uartintr+0xe>
  }

  // send buffered characters.
  acquire(&uart_tx_lock);
    800009bc:	00011497          	auipc	s1,0x11
    800009c0:	abc48493          	addi	s1,s1,-1348 # 80011478 <uart_tx_lock>
    800009c4:	8526                	mv	a0,s1
    800009c6:	00000097          	auipc	ra,0x0
    800009ca:	210080e7          	jalr	528(ra) # 80000bd6 <acquire>
  uartstart();
    800009ce:	00000097          	auipc	ra,0x0
    800009d2:	e68080e7          	jalr	-408(ra) # 80000836 <uartstart>
  release(&uart_tx_lock);
    800009d6:	8526                	mv	a0,s1
    800009d8:	00000097          	auipc	ra,0x0
    800009dc:	2b2080e7          	jalr	690(ra) # 80000c8a <release>
}
    800009e0:	60e2                	ld	ra,24(sp)
    800009e2:	6442                	ld	s0,16(sp)
    800009e4:	64a2                	ld	s1,8(sp)
    800009e6:	6105                	addi	sp,sp,32
    800009e8:	8082                	ret

00000000800009ea <kfree>:
// which normally should have been returned by a
// call to kalloc().  (The exception is when
// initializing the allocator; see kinit above.)
void
kfree(void *pa)
{
    800009ea:	1101                	addi	sp,sp,-32
    800009ec:	ec06                	sd	ra,24(sp)
    800009ee:	e822                	sd	s0,16(sp)
    800009f0:	e426                	sd	s1,8(sp)
    800009f2:	e04a                	sd	s2,0(sp)
    800009f4:	1000                	addi	s0,sp,32
  struct run *r;

  if(((uint64)pa % PGSIZE) != 0 || (char*)pa < end || (uint64)pa >= PHYSTOP)
    800009f6:	03451793          	slli	a5,a0,0x34
    800009fa:	ebb9                	bnez	a5,80000a50 <kfree+0x66>
    800009fc:	84aa                	mv	s1,a0
    800009fe:	00027797          	auipc	a5,0x27
    80000a02:	49a78793          	addi	a5,a5,1178 # 80027e98 <end>
    80000a06:	04f56563          	bltu	a0,a5,80000a50 <kfree+0x66>
    80000a0a:	47c5                	li	a5,17
    80000a0c:	07ee                	slli	a5,a5,0x1b
    80000a0e:	04f57163          	bgeu	a0,a5,80000a50 <kfree+0x66>
    panic("kfree");

  // Fill with junk to catch dangling refs.
  memset(pa, 1, PGSIZE);
    80000a12:	6605                	lui	a2,0x1
    80000a14:	4585                	li	a1,1
    80000a16:	00000097          	auipc	ra,0x0
    80000a1a:	2bc080e7          	jalr	700(ra) # 80000cd2 <memset>

  r = (struct run*)pa;

  acquire(&kmem.lock);
    80000a1e:	00011917          	auipc	s2,0x11
    80000a22:	a9290913          	addi	s2,s2,-1390 # 800114b0 <kmem>
    80000a26:	854a                	mv	a0,s2
    80000a28:	00000097          	auipc	ra,0x0
    80000a2c:	1ae080e7          	jalr	430(ra) # 80000bd6 <acquire>
  r->next = kmem.freelist;
    80000a30:	01893783          	ld	a5,24(s2)
    80000a34:	e09c                	sd	a5,0(s1)
  kmem.freelist = r;
    80000a36:	00993c23          	sd	s1,24(s2)
  release(&kmem.lock);
    80000a3a:	854a                	mv	a0,s2
    80000a3c:	00000097          	auipc	ra,0x0
    80000a40:	24e080e7          	jalr	590(ra) # 80000c8a <release>
}
    80000a44:	60e2                	ld	ra,24(sp)
    80000a46:	6442                	ld	s0,16(sp)
    80000a48:	64a2                	ld	s1,8(sp)
    80000a4a:	6902                	ld	s2,0(sp)
    80000a4c:	6105                	addi	sp,sp,32
    80000a4e:	8082                	ret
    panic("kfree");
    80000a50:	00007517          	auipc	a0,0x7
    80000a54:	61050513          	addi	a0,a0,1552 # 80008060 <digits+0x20>
    80000a58:	00000097          	auipc	ra,0x0
    80000a5c:	ae6080e7          	jalr	-1306(ra) # 8000053e <panic>

0000000080000a60 <freerange>:
{
    80000a60:	7179                	addi	sp,sp,-48
    80000a62:	f406                	sd	ra,40(sp)
    80000a64:	f022                	sd	s0,32(sp)
    80000a66:	ec26                	sd	s1,24(sp)
    80000a68:	e84a                	sd	s2,16(sp)
    80000a6a:	e44e                	sd	s3,8(sp)
    80000a6c:	e052                	sd	s4,0(sp)
    80000a6e:	1800                	addi	s0,sp,48
  p = (char*)PGROUNDUP((uint64)pa_start);
    80000a70:	6785                	lui	a5,0x1
    80000a72:	fff78493          	addi	s1,a5,-1 # fff <_entry-0x7ffff001>
    80000a76:	94aa                	add	s1,s1,a0
    80000a78:	757d                	lui	a0,0xfffff
    80000a7a:	8ce9                	and	s1,s1,a0
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    80000a7c:	94be                	add	s1,s1,a5
    80000a7e:	0095ee63          	bltu	a1,s1,80000a9a <freerange+0x3a>
    80000a82:	892e                	mv	s2,a1
    kfree(p);
    80000a84:	7a7d                	lui	s4,0xfffff
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    80000a86:	6985                	lui	s3,0x1
    kfree(p);
    80000a88:	01448533          	add	a0,s1,s4
    80000a8c:	00000097          	auipc	ra,0x0
    80000a90:	f5e080e7          	jalr	-162(ra) # 800009ea <kfree>
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    80000a94:	94ce                	add	s1,s1,s3
    80000a96:	fe9979e3          	bgeu	s2,s1,80000a88 <freerange+0x28>
}
    80000a9a:	70a2                	ld	ra,40(sp)
    80000a9c:	7402                	ld	s0,32(sp)
    80000a9e:	64e2                	ld	s1,24(sp)
    80000aa0:	6942                	ld	s2,16(sp)
    80000aa2:	69a2                	ld	s3,8(sp)
    80000aa4:	6a02                	ld	s4,0(sp)
    80000aa6:	6145                	addi	sp,sp,48
    80000aa8:	8082                	ret

0000000080000aaa <kinit>:
{
    80000aaa:	1141                	addi	sp,sp,-16
    80000aac:	e406                	sd	ra,8(sp)
    80000aae:	e022                	sd	s0,0(sp)
    80000ab0:	0800                	addi	s0,sp,16
  initlock(&kmem.lock, "kmem");
    80000ab2:	00007597          	auipc	a1,0x7
    80000ab6:	5b658593          	addi	a1,a1,1462 # 80008068 <digits+0x28>
    80000aba:	00011517          	auipc	a0,0x11
    80000abe:	9f650513          	addi	a0,a0,-1546 # 800114b0 <kmem>
    80000ac2:	00000097          	auipc	ra,0x0
    80000ac6:	084080e7          	jalr	132(ra) # 80000b46 <initlock>
  freerange(end, (void*)PHYSTOP);
    80000aca:	45c5                	li	a1,17
    80000acc:	05ee                	slli	a1,a1,0x1b
    80000ace:	00027517          	auipc	a0,0x27
    80000ad2:	3ca50513          	addi	a0,a0,970 # 80027e98 <end>
    80000ad6:	00000097          	auipc	ra,0x0
    80000ada:	f8a080e7          	jalr	-118(ra) # 80000a60 <freerange>
}
    80000ade:	60a2                	ld	ra,8(sp)
    80000ae0:	6402                	ld	s0,0(sp)
    80000ae2:	0141                	addi	sp,sp,16
    80000ae4:	8082                	ret

0000000080000ae6 <kalloc>:
// Allocate one 4096-byte page of physical memory.
// Returns a pointer that the kernel can use.
// Returns 0 if the memory cannot be allocated.
void *
kalloc(void)
{
    80000ae6:	1101                	addi	sp,sp,-32
    80000ae8:	ec06                	sd	ra,24(sp)
    80000aea:	e822                	sd	s0,16(sp)
    80000aec:	e426                	sd	s1,8(sp)
    80000aee:	1000                	addi	s0,sp,32
  struct run *r;

  acquire(&kmem.lock);
    80000af0:	00011497          	auipc	s1,0x11
    80000af4:	9c048493          	addi	s1,s1,-1600 # 800114b0 <kmem>
    80000af8:	8526                	mv	a0,s1
    80000afa:	00000097          	auipc	ra,0x0
    80000afe:	0dc080e7          	jalr	220(ra) # 80000bd6 <acquire>
  r = kmem.freelist;
    80000b02:	6c84                	ld	s1,24(s1)
  if(r)
    80000b04:	c885                	beqz	s1,80000b34 <kalloc+0x4e>
    kmem.freelist = r->next;
    80000b06:	609c                	ld	a5,0(s1)
    80000b08:	00011517          	auipc	a0,0x11
    80000b0c:	9a850513          	addi	a0,a0,-1624 # 800114b0 <kmem>
    80000b10:	ed1c                	sd	a5,24(a0)
  release(&kmem.lock);
    80000b12:	00000097          	auipc	ra,0x0
    80000b16:	178080e7          	jalr	376(ra) # 80000c8a <release>

  if(r)
    memset((char*)r, 5, PGSIZE); // fill with junk
    80000b1a:	6605                	lui	a2,0x1
    80000b1c:	4595                	li	a1,5
    80000b1e:	8526                	mv	a0,s1
    80000b20:	00000097          	auipc	ra,0x0
    80000b24:	1b2080e7          	jalr	434(ra) # 80000cd2 <memset>
  return (void*)r;
}
    80000b28:	8526                	mv	a0,s1
    80000b2a:	60e2                	ld	ra,24(sp)
    80000b2c:	6442                	ld	s0,16(sp)
    80000b2e:	64a2                	ld	s1,8(sp)
    80000b30:	6105                	addi	sp,sp,32
    80000b32:	8082                	ret
  release(&kmem.lock);
    80000b34:	00011517          	auipc	a0,0x11
    80000b38:	97c50513          	addi	a0,a0,-1668 # 800114b0 <kmem>
    80000b3c:	00000097          	auipc	ra,0x0
    80000b40:	14e080e7          	jalr	334(ra) # 80000c8a <release>
  if(r)
    80000b44:	b7d5                	j	80000b28 <kalloc+0x42>

0000000080000b46 <initlock>:
#include "proc.h"
#include "defs.h"

void
initlock(struct spinlock *lk, char *name)
{
    80000b46:	1141                	addi	sp,sp,-16
    80000b48:	e422                	sd	s0,8(sp)
    80000b4a:	0800                	addi	s0,sp,16
  lk->name = name;
    80000b4c:	e50c                	sd	a1,8(a0)
  lk->locked = 0;
    80000b4e:	00052023          	sw	zero,0(a0)
  lk->cpu = 0;
    80000b52:	00053823          	sd	zero,16(a0)
}
    80000b56:	6422                	ld	s0,8(sp)
    80000b58:	0141                	addi	sp,sp,16
    80000b5a:	8082                	ret

0000000080000b5c <holding>:
// Interrupts must be off.
int
holding(struct spinlock *lk)
{
  int r;
  r = (lk->locked && lk->cpu == mycpu());
    80000b5c:	411c                	lw	a5,0(a0)
    80000b5e:	e399                	bnez	a5,80000b64 <holding+0x8>
    80000b60:	4501                	li	a0,0
  return r;
}
    80000b62:	8082                	ret
{
    80000b64:	1101                	addi	sp,sp,-32
    80000b66:	ec06                	sd	ra,24(sp)
    80000b68:	e822                	sd	s0,16(sp)
    80000b6a:	e426                	sd	s1,8(sp)
    80000b6c:	1000                	addi	s0,sp,32
  r = (lk->locked && lk->cpu == mycpu());
    80000b6e:	6904                	ld	s1,16(a0)
    80000b70:	00001097          	auipc	ra,0x1
    80000b74:	e56080e7          	jalr	-426(ra) # 800019c6 <mycpu>
    80000b78:	40a48533          	sub	a0,s1,a0
    80000b7c:	00153513          	seqz	a0,a0
}
    80000b80:	60e2                	ld	ra,24(sp)
    80000b82:	6442                	ld	s0,16(sp)
    80000b84:	64a2                	ld	s1,8(sp)
    80000b86:	6105                	addi	sp,sp,32
    80000b88:	8082                	ret

0000000080000b8a <push_off>:
// it takes two pop_off()s to undo two push_off()s.  Also, if interrupts
// are initially off, then push_off, pop_off leaves them off.

void
push_off(void)
{
    80000b8a:	1101                	addi	sp,sp,-32
    80000b8c:	ec06                	sd	ra,24(sp)
    80000b8e:	e822                	sd	s0,16(sp)
    80000b90:	e426                	sd	s1,8(sp)
    80000b92:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80000b94:	100024f3          	csrr	s1,sstatus
    80000b98:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() & ~SSTATUS_SIE);
    80000b9c:	9bf5                	andi	a5,a5,-3
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80000b9e:	10079073          	csrw	sstatus,a5
  int old = intr_get();

  intr_off();
  if(mycpu()->noff == 0)
    80000ba2:	00001097          	auipc	ra,0x1
    80000ba6:	e24080e7          	jalr	-476(ra) # 800019c6 <mycpu>
    80000baa:	5d3c                	lw	a5,120(a0)
    80000bac:	cf89                	beqz	a5,80000bc6 <push_off+0x3c>
    mycpu()->intena = old;
  mycpu()->noff += 1;
    80000bae:	00001097          	auipc	ra,0x1
    80000bb2:	e18080e7          	jalr	-488(ra) # 800019c6 <mycpu>
    80000bb6:	5d3c                	lw	a5,120(a0)
    80000bb8:	2785                	addiw	a5,a5,1
    80000bba:	dd3c                	sw	a5,120(a0)
}
    80000bbc:	60e2                	ld	ra,24(sp)
    80000bbe:	6442                	ld	s0,16(sp)
    80000bc0:	64a2                	ld	s1,8(sp)
    80000bc2:	6105                	addi	sp,sp,32
    80000bc4:	8082                	ret
    mycpu()->intena = old;
    80000bc6:	00001097          	auipc	ra,0x1
    80000bca:	e00080e7          	jalr	-512(ra) # 800019c6 <mycpu>
  return (x & SSTATUS_SIE) != 0;
    80000bce:	8085                	srli	s1,s1,0x1
    80000bd0:	8885                	andi	s1,s1,1
    80000bd2:	dd64                	sw	s1,124(a0)
    80000bd4:	bfe9                	j	80000bae <push_off+0x24>

0000000080000bd6 <acquire>:
{
    80000bd6:	1101                	addi	sp,sp,-32
    80000bd8:	ec06                	sd	ra,24(sp)
    80000bda:	e822                	sd	s0,16(sp)
    80000bdc:	e426                	sd	s1,8(sp)
    80000bde:	1000                	addi	s0,sp,32
    80000be0:	84aa                	mv	s1,a0
  push_off(); // disable interrupts to avoid deadlock.
    80000be2:	00000097          	auipc	ra,0x0
    80000be6:	fa8080e7          	jalr	-88(ra) # 80000b8a <push_off>
  if(holding(lk))
    80000bea:	8526                	mv	a0,s1
    80000bec:	00000097          	auipc	ra,0x0
    80000bf0:	f70080e7          	jalr	-144(ra) # 80000b5c <holding>
  while(__sync_lock_test_and_set(&lk->locked, 1) != 0)
    80000bf4:	4705                	li	a4,1
  if(holding(lk))
    80000bf6:	e115                	bnez	a0,80000c1a <acquire+0x44>
  while(__sync_lock_test_and_set(&lk->locked, 1) != 0)
    80000bf8:	87ba                	mv	a5,a4
    80000bfa:	0cf4a7af          	amoswap.w.aq	a5,a5,(s1)
    80000bfe:	2781                	sext.w	a5,a5
    80000c00:	ffe5                	bnez	a5,80000bf8 <acquire+0x22>
  __sync_synchronize();
    80000c02:	0ff0000f          	fence
  lk->cpu = mycpu();
    80000c06:	00001097          	auipc	ra,0x1
    80000c0a:	dc0080e7          	jalr	-576(ra) # 800019c6 <mycpu>
    80000c0e:	e888                	sd	a0,16(s1)
}
    80000c10:	60e2                	ld	ra,24(sp)
    80000c12:	6442                	ld	s0,16(sp)
    80000c14:	64a2                	ld	s1,8(sp)
    80000c16:	6105                	addi	sp,sp,32
    80000c18:	8082                	ret
    panic("acquire");
    80000c1a:	00007517          	auipc	a0,0x7
    80000c1e:	45650513          	addi	a0,a0,1110 # 80008070 <digits+0x30>
    80000c22:	00000097          	auipc	ra,0x0
    80000c26:	91c080e7          	jalr	-1764(ra) # 8000053e <panic>

0000000080000c2a <pop_off>:

void
pop_off(void)
{
    80000c2a:	1141                	addi	sp,sp,-16
    80000c2c:	e406                	sd	ra,8(sp)
    80000c2e:	e022                	sd	s0,0(sp)
    80000c30:	0800                	addi	s0,sp,16
  struct cpu *c = mycpu();
    80000c32:	00001097          	auipc	ra,0x1
    80000c36:	d94080e7          	jalr	-620(ra) # 800019c6 <mycpu>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80000c3a:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80000c3e:	8b89                	andi	a5,a5,2
  if(intr_get())
    80000c40:	e78d                	bnez	a5,80000c6a <pop_off+0x40>
    panic("pop_off - interruptible");
  if(c->noff < 1)
    80000c42:	5d3c                	lw	a5,120(a0)
    80000c44:	02f05b63          	blez	a5,80000c7a <pop_off+0x50>
    panic("pop_off");
  c->noff -= 1;
    80000c48:	37fd                	addiw	a5,a5,-1
    80000c4a:	0007871b          	sext.w	a4,a5
    80000c4e:	dd3c                	sw	a5,120(a0)
  if(c->noff == 0 && c->intena)
    80000c50:	eb09                	bnez	a4,80000c62 <pop_off+0x38>
    80000c52:	5d7c                	lw	a5,124(a0)
    80000c54:	c799                	beqz	a5,80000c62 <pop_off+0x38>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80000c56:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    80000c5a:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80000c5e:	10079073          	csrw	sstatus,a5
    intr_on();
}
    80000c62:	60a2                	ld	ra,8(sp)
    80000c64:	6402                	ld	s0,0(sp)
    80000c66:	0141                	addi	sp,sp,16
    80000c68:	8082                	ret
    panic("pop_off - interruptible");
    80000c6a:	00007517          	auipc	a0,0x7
    80000c6e:	40e50513          	addi	a0,a0,1038 # 80008078 <digits+0x38>
    80000c72:	00000097          	auipc	ra,0x0
    80000c76:	8cc080e7          	jalr	-1844(ra) # 8000053e <panic>
    panic("pop_off");
    80000c7a:	00007517          	auipc	a0,0x7
    80000c7e:	41650513          	addi	a0,a0,1046 # 80008090 <digits+0x50>
    80000c82:	00000097          	auipc	ra,0x0
    80000c86:	8bc080e7          	jalr	-1860(ra) # 8000053e <panic>

0000000080000c8a <release>:
{
    80000c8a:	1101                	addi	sp,sp,-32
    80000c8c:	ec06                	sd	ra,24(sp)
    80000c8e:	e822                	sd	s0,16(sp)
    80000c90:	e426                	sd	s1,8(sp)
    80000c92:	1000                	addi	s0,sp,32
    80000c94:	84aa                	mv	s1,a0
  if(!holding(lk))
    80000c96:	00000097          	auipc	ra,0x0
    80000c9a:	ec6080e7          	jalr	-314(ra) # 80000b5c <holding>
    80000c9e:	c115                	beqz	a0,80000cc2 <release+0x38>
  lk->cpu = 0;
    80000ca0:	0004b823          	sd	zero,16(s1)
  __sync_synchronize();
    80000ca4:	0ff0000f          	fence
  __sync_lock_release(&lk->locked);
    80000ca8:	0f50000f          	fence	iorw,ow
    80000cac:	0804a02f          	amoswap.w	zero,zero,(s1)
  pop_off();
    80000cb0:	00000097          	auipc	ra,0x0
    80000cb4:	f7a080e7          	jalr	-134(ra) # 80000c2a <pop_off>
}
    80000cb8:	60e2                	ld	ra,24(sp)
    80000cba:	6442                	ld	s0,16(sp)
    80000cbc:	64a2                	ld	s1,8(sp)
    80000cbe:	6105                	addi	sp,sp,32
    80000cc0:	8082                	ret
    panic("release");
    80000cc2:	00007517          	auipc	a0,0x7
    80000cc6:	3d650513          	addi	a0,a0,982 # 80008098 <digits+0x58>
    80000cca:	00000097          	auipc	ra,0x0
    80000cce:	874080e7          	jalr	-1932(ra) # 8000053e <panic>

0000000080000cd2 <memset>:
#include "types.h"

void*
memset(void *dst, int c, uint n)
{
    80000cd2:	1141                	addi	sp,sp,-16
    80000cd4:	e422                	sd	s0,8(sp)
    80000cd6:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
    80000cd8:	ca19                	beqz	a2,80000cee <memset+0x1c>
    80000cda:	87aa                	mv	a5,a0
    80000cdc:	1602                	slli	a2,a2,0x20
    80000cde:	9201                	srli	a2,a2,0x20
    80000ce0:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
    80000ce4:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
    80000ce8:	0785                	addi	a5,a5,1
    80000cea:	fee79de3          	bne	a5,a4,80000ce4 <memset+0x12>
  }
  return dst;
}
    80000cee:	6422                	ld	s0,8(sp)
    80000cf0:	0141                	addi	sp,sp,16
    80000cf2:	8082                	ret

0000000080000cf4 <memcmp>:

int
memcmp(const void *v1, const void *v2, uint n)
{
    80000cf4:	1141                	addi	sp,sp,-16
    80000cf6:	e422                	sd	s0,8(sp)
    80000cf8:	0800                	addi	s0,sp,16
  const uchar *s1, *s2;

  s1 = v1;
  s2 = v2;
  while(n-- > 0){
    80000cfa:	ca05                	beqz	a2,80000d2a <memcmp+0x36>
    80000cfc:	fff6069b          	addiw	a3,a2,-1
    80000d00:	1682                	slli	a3,a3,0x20
    80000d02:	9281                	srli	a3,a3,0x20
    80000d04:	0685                	addi	a3,a3,1
    80000d06:	96aa                	add	a3,a3,a0
    if(*s1 != *s2)
    80000d08:	00054783          	lbu	a5,0(a0)
    80000d0c:	0005c703          	lbu	a4,0(a1)
    80000d10:	00e79863          	bne	a5,a4,80000d20 <memcmp+0x2c>
      return *s1 - *s2;
    s1++, s2++;
    80000d14:	0505                	addi	a0,a0,1
    80000d16:	0585                	addi	a1,a1,1
  while(n-- > 0){
    80000d18:	fed518e3          	bne	a0,a3,80000d08 <memcmp+0x14>
  }

  return 0;
    80000d1c:	4501                	li	a0,0
    80000d1e:	a019                	j	80000d24 <memcmp+0x30>
      return *s1 - *s2;
    80000d20:	40e7853b          	subw	a0,a5,a4
}
    80000d24:	6422                	ld	s0,8(sp)
    80000d26:	0141                	addi	sp,sp,16
    80000d28:	8082                	ret
  return 0;
    80000d2a:	4501                	li	a0,0
    80000d2c:	bfe5                	j	80000d24 <memcmp+0x30>

0000000080000d2e <memmove>:

void*
memmove(void *dst, const void *src, uint n)
{
    80000d2e:	1141                	addi	sp,sp,-16
    80000d30:	e422                	sd	s0,8(sp)
    80000d32:	0800                	addi	s0,sp,16
  const char *s;
  char *d;

  if(n == 0)
    80000d34:	c205                	beqz	a2,80000d54 <memmove+0x26>
    return dst;
  
  s = src;
  d = dst;
  if(s < d && s + n > d){
    80000d36:	02a5e263          	bltu	a1,a0,80000d5a <memmove+0x2c>
    s += n;
    d += n;
    while(n-- > 0)
      *--d = *--s;
  } else
    while(n-- > 0)
    80000d3a:	1602                	slli	a2,a2,0x20
    80000d3c:	9201                	srli	a2,a2,0x20
    80000d3e:	00c587b3          	add	a5,a1,a2
{
    80000d42:	872a                	mv	a4,a0
      *d++ = *s++;
    80000d44:	0585                	addi	a1,a1,1
    80000d46:	0705                	addi	a4,a4,1
    80000d48:	fff5c683          	lbu	a3,-1(a1)
    80000d4c:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
    80000d50:	fef59ae3          	bne	a1,a5,80000d44 <memmove+0x16>

  return dst;
}
    80000d54:	6422                	ld	s0,8(sp)
    80000d56:	0141                	addi	sp,sp,16
    80000d58:	8082                	ret
  if(s < d && s + n > d){
    80000d5a:	02061693          	slli	a3,a2,0x20
    80000d5e:	9281                	srli	a3,a3,0x20
    80000d60:	00d58733          	add	a4,a1,a3
    80000d64:	fce57be3          	bgeu	a0,a4,80000d3a <memmove+0xc>
    d += n;
    80000d68:	96aa                	add	a3,a3,a0
    while(n-- > 0)
    80000d6a:	fff6079b          	addiw	a5,a2,-1
    80000d6e:	1782                	slli	a5,a5,0x20
    80000d70:	9381                	srli	a5,a5,0x20
    80000d72:	fff7c793          	not	a5,a5
    80000d76:	97ba                	add	a5,a5,a4
      *--d = *--s;
    80000d78:	177d                	addi	a4,a4,-1
    80000d7a:	16fd                	addi	a3,a3,-1
    80000d7c:	00074603          	lbu	a2,0(a4)
    80000d80:	00c68023          	sb	a2,0(a3)
    while(n-- > 0)
    80000d84:	fee79ae3          	bne	a5,a4,80000d78 <memmove+0x4a>
    80000d88:	b7f1                	j	80000d54 <memmove+0x26>

0000000080000d8a <memcpy>:

// memcpy exists to placate GCC.  Use memmove.
void*
memcpy(void *dst, const void *src, uint n)
{
    80000d8a:	1141                	addi	sp,sp,-16
    80000d8c:	e406                	sd	ra,8(sp)
    80000d8e:	e022                	sd	s0,0(sp)
    80000d90:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
    80000d92:	00000097          	auipc	ra,0x0
    80000d96:	f9c080e7          	jalr	-100(ra) # 80000d2e <memmove>
}
    80000d9a:	60a2                	ld	ra,8(sp)
    80000d9c:	6402                	ld	s0,0(sp)
    80000d9e:	0141                	addi	sp,sp,16
    80000da0:	8082                	ret

0000000080000da2 <strncmp>:

int
strncmp(const char *p, const char *q, uint n)
{
    80000da2:	1141                	addi	sp,sp,-16
    80000da4:	e422                	sd	s0,8(sp)
    80000da6:	0800                	addi	s0,sp,16
  while(n > 0 && *p && *p == *q)
    80000da8:	ce11                	beqz	a2,80000dc4 <strncmp+0x22>
    80000daa:	00054783          	lbu	a5,0(a0)
    80000dae:	cf89                	beqz	a5,80000dc8 <strncmp+0x26>
    80000db0:	0005c703          	lbu	a4,0(a1)
    80000db4:	00f71a63          	bne	a4,a5,80000dc8 <strncmp+0x26>
    n--, p++, q++;
    80000db8:	367d                	addiw	a2,a2,-1
    80000dba:	0505                	addi	a0,a0,1
    80000dbc:	0585                	addi	a1,a1,1
  while(n > 0 && *p && *p == *q)
    80000dbe:	f675                	bnez	a2,80000daa <strncmp+0x8>
  if(n == 0)
    return 0;
    80000dc0:	4501                	li	a0,0
    80000dc2:	a809                	j	80000dd4 <strncmp+0x32>
    80000dc4:	4501                	li	a0,0
    80000dc6:	a039                	j	80000dd4 <strncmp+0x32>
  if(n == 0)
    80000dc8:	ca09                	beqz	a2,80000dda <strncmp+0x38>
  return (uchar)*p - (uchar)*q;
    80000dca:	00054503          	lbu	a0,0(a0)
    80000dce:	0005c783          	lbu	a5,0(a1)
    80000dd2:	9d1d                	subw	a0,a0,a5
}
    80000dd4:	6422                	ld	s0,8(sp)
    80000dd6:	0141                	addi	sp,sp,16
    80000dd8:	8082                	ret
    return 0;
    80000dda:	4501                	li	a0,0
    80000ddc:	bfe5                	j	80000dd4 <strncmp+0x32>

0000000080000dde <strncpy>:

char*
strncpy(char *s, const char *t, int n)
{
    80000dde:	1141                	addi	sp,sp,-16
    80000de0:	e422                	sd	s0,8(sp)
    80000de2:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while(n-- > 0 && (*s++ = *t++) != 0)
    80000de4:	872a                	mv	a4,a0
    80000de6:	8832                	mv	a6,a2
    80000de8:	367d                	addiw	a2,a2,-1
    80000dea:	01005963          	blez	a6,80000dfc <strncpy+0x1e>
    80000dee:	0705                	addi	a4,a4,1
    80000df0:	0005c783          	lbu	a5,0(a1)
    80000df4:	fef70fa3          	sb	a5,-1(a4)
    80000df8:	0585                	addi	a1,a1,1
    80000dfa:	f7f5                	bnez	a5,80000de6 <strncpy+0x8>
    ;
  while(n-- > 0)
    80000dfc:	86ba                	mv	a3,a4
    80000dfe:	00c05c63          	blez	a2,80000e16 <strncpy+0x38>
    *s++ = 0;
    80000e02:	0685                	addi	a3,a3,1
    80000e04:	fe068fa3          	sb	zero,-1(a3)
  while(n-- > 0)
    80000e08:	fff6c793          	not	a5,a3
    80000e0c:	9fb9                	addw	a5,a5,a4
    80000e0e:	010787bb          	addw	a5,a5,a6
    80000e12:	fef048e3          	bgtz	a5,80000e02 <strncpy+0x24>
  return os;
}
    80000e16:	6422                	ld	s0,8(sp)
    80000e18:	0141                	addi	sp,sp,16
    80000e1a:	8082                	ret

0000000080000e1c <safestrcpy>:

// Like strncpy but guaranteed to NUL-terminate.
char*
safestrcpy(char *s, const char *t, int n)
{
    80000e1c:	1141                	addi	sp,sp,-16
    80000e1e:	e422                	sd	s0,8(sp)
    80000e20:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  if(n <= 0)
    80000e22:	02c05363          	blez	a2,80000e48 <safestrcpy+0x2c>
    80000e26:	fff6069b          	addiw	a3,a2,-1
    80000e2a:	1682                	slli	a3,a3,0x20
    80000e2c:	9281                	srli	a3,a3,0x20
    80000e2e:	96ae                	add	a3,a3,a1
    80000e30:	87aa                	mv	a5,a0
    return os;
  while(--n > 0 && (*s++ = *t++) != 0)
    80000e32:	00d58963          	beq	a1,a3,80000e44 <safestrcpy+0x28>
    80000e36:	0585                	addi	a1,a1,1
    80000e38:	0785                	addi	a5,a5,1
    80000e3a:	fff5c703          	lbu	a4,-1(a1)
    80000e3e:	fee78fa3          	sb	a4,-1(a5)
    80000e42:	fb65                	bnez	a4,80000e32 <safestrcpy+0x16>
    ;
  *s = 0;
    80000e44:	00078023          	sb	zero,0(a5)
  return os;
}
    80000e48:	6422                	ld	s0,8(sp)
    80000e4a:	0141                	addi	sp,sp,16
    80000e4c:	8082                	ret

0000000080000e4e <strlen>:

int
strlen(const char *s)
{
    80000e4e:	1141                	addi	sp,sp,-16
    80000e50:	e422                	sd	s0,8(sp)
    80000e52:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
    80000e54:	00054783          	lbu	a5,0(a0)
    80000e58:	cf91                	beqz	a5,80000e74 <strlen+0x26>
    80000e5a:	0505                	addi	a0,a0,1
    80000e5c:	87aa                	mv	a5,a0
    80000e5e:	4685                	li	a3,1
    80000e60:	9e89                	subw	a3,a3,a0
    80000e62:	00f6853b          	addw	a0,a3,a5
    80000e66:	0785                	addi	a5,a5,1
    80000e68:	fff7c703          	lbu	a4,-1(a5)
    80000e6c:	fb7d                	bnez	a4,80000e62 <strlen+0x14>
    ;
  return n;
}
    80000e6e:	6422                	ld	s0,8(sp)
    80000e70:	0141                	addi	sp,sp,16
    80000e72:	8082                	ret
  for(n = 0; s[n]; n++)
    80000e74:	4501                	li	a0,0
    80000e76:	bfe5                	j	80000e6e <strlen+0x20>

0000000080000e78 <main>:
volatile static int started = 0;

// start() jumps here in supervisor mode on all CPUs.
void
main()
{
    80000e78:	1141                	addi	sp,sp,-16
    80000e7a:	e406                	sd	ra,8(sp)
    80000e7c:	e022                	sd	s0,0(sp)
    80000e7e:	0800                	addi	s0,sp,16
  if(cpuid() == 0){
    80000e80:	00001097          	auipc	ra,0x1
    80000e84:	b36080e7          	jalr	-1226(ra) # 800019b6 <cpuid>
    userinit();      // first user process
    kproc_create(display_daemon, "displaydaemon"); // GPU auto-commit daemon
    __sync_synchronize();
    started = 1;
  } else {
    while(started == 0)
    80000e88:	00008717          	auipc	a4,0x8
    80000e8c:	3c070713          	addi	a4,a4,960 # 80009248 <started>
  if(cpuid() == 0){
    80000e90:	c139                	beqz	a0,80000ed6 <main+0x5e>
    while(started == 0)
    80000e92:	431c                	lw	a5,0(a4)
    80000e94:	2781                	sext.w	a5,a5
    80000e96:	dff5                	beqz	a5,80000e92 <main+0x1a>
      ;
    __sync_synchronize();
    80000e98:	0ff0000f          	fence
    printf("hart %d starting\n", cpuid());
    80000e9c:	00001097          	auipc	ra,0x1
    80000ea0:	b1a080e7          	jalr	-1254(ra) # 800019b6 <cpuid>
    80000ea4:	85aa                	mv	a1,a0
    80000ea6:	00007517          	auipc	a0,0x7
    80000eaa:	22250513          	addi	a0,a0,546 # 800080c8 <digits+0x88>
    80000eae:	fffff097          	auipc	ra,0xfffff
    80000eb2:	6da080e7          	jalr	1754(ra) # 80000588 <printf>
    kvminithart();    // turn on paging
    80000eb6:	00000097          	auipc	ra,0x0
    80000eba:	0f8080e7          	jalr	248(ra) # 80000fae <kvminithart>
    trapinithart();   // install kernel trap vector
    80000ebe:	00002097          	auipc	ra,0x2
    80000ec2:	84a080e7          	jalr	-1974(ra) # 80002708 <trapinithart>
    plicinithart();   // ask PLIC for device interrupts
    80000ec6:	00005097          	auipc	ra,0x5
    80000eca:	eaa080e7          	jalr	-342(ra) # 80005d70 <plicinithart>
  }

  scheduler();        
    80000ece:	00001097          	auipc	ra,0x1
    80000ed2:	094080e7          	jalr	148(ra) # 80001f62 <scheduler>
    consoleinit();
    80000ed6:	fffff097          	auipc	ra,0xfffff
    80000eda:	57a080e7          	jalr	1402(ra) # 80000450 <consoleinit>
    printfinit();
    80000ede:	00000097          	auipc	ra,0x0
    80000ee2:	88a080e7          	jalr	-1910(ra) # 80000768 <printfinit>
    printf("\n");
    80000ee6:	00007517          	auipc	a0,0x7
    80000eea:	1f250513          	addi	a0,a0,498 # 800080d8 <digits+0x98>
    80000eee:	fffff097          	auipc	ra,0xfffff
    80000ef2:	69a080e7          	jalr	1690(ra) # 80000588 <printf>
    printf("xv6 kernel is booting\n");
    80000ef6:	00007517          	auipc	a0,0x7
    80000efa:	1aa50513          	addi	a0,a0,426 # 800080a0 <digits+0x60>
    80000efe:	fffff097          	auipc	ra,0xfffff
    80000f02:	68a080e7          	jalr	1674(ra) # 80000588 <printf>
    printf("\n");
    80000f06:	00007517          	auipc	a0,0x7
    80000f0a:	1d250513          	addi	a0,a0,466 # 800080d8 <digits+0x98>
    80000f0e:	fffff097          	auipc	ra,0xfffff
    80000f12:	67a080e7          	jalr	1658(ra) # 80000588 <printf>
    kinit();         // physical page allocator
    80000f16:	00000097          	auipc	ra,0x0
    80000f1a:	b94080e7          	jalr	-1132(ra) # 80000aaa <kinit>
    kvminit();       // create kernel page table
    80000f1e:	00000097          	auipc	ra,0x0
    80000f22:	35c080e7          	jalr	860(ra) # 8000127a <kvminit>
    kvminithart();   // turn on paging
    80000f26:	00000097          	auipc	ra,0x0
    80000f2a:	088080e7          	jalr	136(ra) # 80000fae <kvminithart>
    procinit();      // process table
    80000f2e:	00001097          	auipc	ra,0x1
    80000f32:	9d4080e7          	jalr	-1580(ra) # 80001902 <procinit>
    trapinit();      // trap vectors
    80000f36:	00001097          	auipc	ra,0x1
    80000f3a:	7aa080e7          	jalr	1962(ra) # 800026e0 <trapinit>
    trapinithart();  // install kernel trap vector
    80000f3e:	00001097          	auipc	ra,0x1
    80000f42:	7ca080e7          	jalr	1994(ra) # 80002708 <trapinithart>
    plicinit();      // set up interrupt controller
    80000f46:	00005097          	auipc	ra,0x5
    80000f4a:	e14080e7          	jalr	-492(ra) # 80005d5a <plicinit>
    plicinithart();  // ask PLIC for device interrupts
    80000f4e:	00005097          	auipc	ra,0x5
    80000f52:	e22080e7          	jalr	-478(ra) # 80005d70 <plicinithart>
    binit();         // buffer cache
    80000f56:	00002097          	auipc	ra,0x2
    80000f5a:	fa4080e7          	jalr	-92(ra) # 80002efa <binit>
    iinit();         // inode table
    80000f5e:	00002097          	auipc	ra,0x2
    80000f62:	648080e7          	jalr	1608(ra) # 800035a6 <iinit>
    fileinit();      // file table
    80000f66:	00003097          	auipc	ra,0x3
    80000f6a:	5e6080e7          	jalr	1510(ra) # 8000454c <fileinit>
    virtio_disk_init(); // emulated hard disk
    80000f6e:	00005097          	auipc	ra,0x5
    80000f72:	f0a080e7          	jalr	-246(ra) # 80005e78 <virtio_disk_init>
    virtio_gpu_init();  // virtio GPU display window
    80000f76:	00005097          	auipc	ra,0x5
    80000f7a:	6ce080e7          	jalr	1742(ra) # 80006644 <virtio_gpu_init>
    userinit();      // first user process
    80000f7e:	00001097          	auipc	ra,0x1
    80000f82:	d60080e7          	jalr	-672(ra) # 80001cde <userinit>
    kproc_create(display_daemon, "displaydaemon"); // GPU auto-commit daemon
    80000f86:	00007597          	auipc	a1,0x7
    80000f8a:	13258593          	addi	a1,a1,306 # 800080b8 <digits+0x78>
    80000f8e:	00006517          	auipc	a0,0x6
    80000f92:	ad450513          	addi	a0,a0,-1324 # 80006a62 <display_daemon>
    80000f96:	00001097          	auipc	ra,0x1
    80000f9a:	dca080e7          	jalr	-566(ra) # 80001d60 <kproc_create>
    __sync_synchronize();
    80000f9e:	0ff0000f          	fence
    started = 1;
    80000fa2:	4785                	li	a5,1
    80000fa4:	00008717          	auipc	a4,0x8
    80000fa8:	2af72223          	sw	a5,676(a4) # 80009248 <started>
    80000fac:	b70d                	j	80000ece <main+0x56>

0000000080000fae <kvminithart>:

// Switch h/w page table register to the kernel's page table,
// and enable paging.
void
kvminithart()
{
    80000fae:	1141                	addi	sp,sp,-16
    80000fb0:	e422                	sd	s0,8(sp)
    80000fb2:	0800                	addi	s0,sp,16
// flush the TLB.
static inline void
sfence_vma()
{
  // the zero, zero means flush all TLB entries.
  asm volatile("sfence.vma zero, zero");
    80000fb4:	12000073          	sfence.vma
  // wait for any previous writes to the page table memory to finish.
  sfence_vma();

  w_satp(MAKE_SATP(kernel_pagetable));
    80000fb8:	00008797          	auipc	a5,0x8
    80000fbc:	2987b783          	ld	a5,664(a5) # 80009250 <kernel_pagetable>
    80000fc0:	83b1                	srli	a5,a5,0xc
    80000fc2:	577d                	li	a4,-1
    80000fc4:	177e                	slli	a4,a4,0x3f
    80000fc6:	8fd9                	or	a5,a5,a4
  asm volatile("csrw satp, %0" : : "r" (x));
    80000fc8:	18079073          	csrw	satp,a5
  asm volatile("sfence.vma zero, zero");
    80000fcc:	12000073          	sfence.vma

  // flush stale entries from the TLB.
  sfence_vma();
}
    80000fd0:	6422                	ld	s0,8(sp)
    80000fd2:	0141                	addi	sp,sp,16
    80000fd4:	8082                	ret

0000000080000fd6 <walk>:
//   21..29 -- 9 bits of level-1 index.
//   12..20 -- 9 bits of level-0 index.
//    0..11 -- 12 bits of byte offset within the page.
pte_t *
walk(pagetable_t pagetable, uint64 va, int alloc)
{
    80000fd6:	7139                	addi	sp,sp,-64
    80000fd8:	fc06                	sd	ra,56(sp)
    80000fda:	f822                	sd	s0,48(sp)
    80000fdc:	f426                	sd	s1,40(sp)
    80000fde:	f04a                	sd	s2,32(sp)
    80000fe0:	ec4e                	sd	s3,24(sp)
    80000fe2:	e852                	sd	s4,16(sp)
    80000fe4:	e456                	sd	s5,8(sp)
    80000fe6:	e05a                	sd	s6,0(sp)
    80000fe8:	0080                	addi	s0,sp,64
    80000fea:	84aa                	mv	s1,a0
    80000fec:	89ae                	mv	s3,a1
    80000fee:	8ab2                	mv	s5,a2
  if(va >= MAXVA)
    80000ff0:	57fd                	li	a5,-1
    80000ff2:	83e9                	srli	a5,a5,0x1a
    80000ff4:	4a79                	li	s4,30
    panic("walk");

  for(int level = 2; level > 0; level--) {
    80000ff6:	4b31                	li	s6,12
  if(va >= MAXVA)
    80000ff8:	04b7f263          	bgeu	a5,a1,8000103c <walk+0x66>
    panic("walk");
    80000ffc:	00007517          	auipc	a0,0x7
    80001000:	0e450513          	addi	a0,a0,228 # 800080e0 <digits+0xa0>
    80001004:	fffff097          	auipc	ra,0xfffff
    80001008:	53a080e7          	jalr	1338(ra) # 8000053e <panic>
    pte_t *pte = &pagetable[PX(level, va)];
    if(*pte & PTE_V) {
      pagetable = (pagetable_t)PTE2PA(*pte);
    } else {
      if(!alloc || (pagetable = (pde_t*)kalloc()) == 0)
    8000100c:	060a8663          	beqz	s5,80001078 <walk+0xa2>
    80001010:	00000097          	auipc	ra,0x0
    80001014:	ad6080e7          	jalr	-1322(ra) # 80000ae6 <kalloc>
    80001018:	84aa                	mv	s1,a0
    8000101a:	c529                	beqz	a0,80001064 <walk+0x8e>
        return 0;
      memset(pagetable, 0, PGSIZE);
    8000101c:	6605                	lui	a2,0x1
    8000101e:	4581                	li	a1,0
    80001020:	00000097          	auipc	ra,0x0
    80001024:	cb2080e7          	jalr	-846(ra) # 80000cd2 <memset>
      *pte = PA2PTE(pagetable) | PTE_V;
    80001028:	00c4d793          	srli	a5,s1,0xc
    8000102c:	07aa                	slli	a5,a5,0xa
    8000102e:	0017e793          	ori	a5,a5,1
    80001032:	00f93023          	sd	a5,0(s2)
  for(int level = 2; level > 0; level--) {
    80001036:	3a5d                	addiw	s4,s4,-9
    80001038:	036a0063          	beq	s4,s6,80001058 <walk+0x82>
    pte_t *pte = &pagetable[PX(level, va)];
    8000103c:	0149d933          	srl	s2,s3,s4
    80001040:	1ff97913          	andi	s2,s2,511
    80001044:	090e                	slli	s2,s2,0x3
    80001046:	9926                	add	s2,s2,s1
    if(*pte & PTE_V) {
    80001048:	00093483          	ld	s1,0(s2)
    8000104c:	0014f793          	andi	a5,s1,1
    80001050:	dfd5                	beqz	a5,8000100c <walk+0x36>
      pagetable = (pagetable_t)PTE2PA(*pte);
    80001052:	80a9                	srli	s1,s1,0xa
    80001054:	04b2                	slli	s1,s1,0xc
    80001056:	b7c5                	j	80001036 <walk+0x60>
    }
  }
  return &pagetable[PX(0, va)];
    80001058:	00c9d513          	srli	a0,s3,0xc
    8000105c:	1ff57513          	andi	a0,a0,511
    80001060:	050e                	slli	a0,a0,0x3
    80001062:	9526                	add	a0,a0,s1
}
    80001064:	70e2                	ld	ra,56(sp)
    80001066:	7442                	ld	s0,48(sp)
    80001068:	74a2                	ld	s1,40(sp)
    8000106a:	7902                	ld	s2,32(sp)
    8000106c:	69e2                	ld	s3,24(sp)
    8000106e:	6a42                	ld	s4,16(sp)
    80001070:	6aa2                	ld	s5,8(sp)
    80001072:	6b02                	ld	s6,0(sp)
    80001074:	6121                	addi	sp,sp,64
    80001076:	8082                	ret
        return 0;
    80001078:	4501                	li	a0,0
    8000107a:	b7ed                	j	80001064 <walk+0x8e>

000000008000107c <walkaddr>:
walkaddr(pagetable_t pagetable, uint64 va)
{
  pte_t *pte;
  uint64 pa;

  if(va >= MAXVA)
    8000107c:	57fd                	li	a5,-1
    8000107e:	83e9                	srli	a5,a5,0x1a
    80001080:	00b7f463          	bgeu	a5,a1,80001088 <walkaddr+0xc>
    return 0;
    80001084:	4501                	li	a0,0
    return 0;
  if((*pte & PTE_U) == 0)
    return 0;
  pa = PTE2PA(*pte);
  return pa;
}
    80001086:	8082                	ret
{
    80001088:	1141                	addi	sp,sp,-16
    8000108a:	e406                	sd	ra,8(sp)
    8000108c:	e022                	sd	s0,0(sp)
    8000108e:	0800                	addi	s0,sp,16
  pte = walk(pagetable, va, 0);
    80001090:	4601                	li	a2,0
    80001092:	00000097          	auipc	ra,0x0
    80001096:	f44080e7          	jalr	-188(ra) # 80000fd6 <walk>
  if(pte == 0)
    8000109a:	c105                	beqz	a0,800010ba <walkaddr+0x3e>
  if((*pte & PTE_V) == 0)
    8000109c:	611c                	ld	a5,0(a0)
  if((*pte & PTE_U) == 0)
    8000109e:	0117f693          	andi	a3,a5,17
    800010a2:	4745                	li	a4,17
    return 0;
    800010a4:	4501                	li	a0,0
  if((*pte & PTE_U) == 0)
    800010a6:	00e68663          	beq	a3,a4,800010b2 <walkaddr+0x36>
}
    800010aa:	60a2                	ld	ra,8(sp)
    800010ac:	6402                	ld	s0,0(sp)
    800010ae:	0141                	addi	sp,sp,16
    800010b0:	8082                	ret
  pa = PTE2PA(*pte);
    800010b2:	00a7d513          	srli	a0,a5,0xa
    800010b6:	0532                	slli	a0,a0,0xc
  return pa;
    800010b8:	bfcd                	j	800010aa <walkaddr+0x2e>
    return 0;
    800010ba:	4501                	li	a0,0
    800010bc:	b7fd                	j	800010aa <walkaddr+0x2e>

00000000800010be <mappages>:
// physical addresses starting at pa. va and size might not
// be page-aligned. Returns 0 on success, -1 if walk() couldn't
// allocate a needed page-table page.
int
mappages(pagetable_t pagetable, uint64 va, uint64 size, uint64 pa, int perm)
{
    800010be:	715d                	addi	sp,sp,-80
    800010c0:	e486                	sd	ra,72(sp)
    800010c2:	e0a2                	sd	s0,64(sp)
    800010c4:	fc26                	sd	s1,56(sp)
    800010c6:	f84a                	sd	s2,48(sp)
    800010c8:	f44e                	sd	s3,40(sp)
    800010ca:	f052                	sd	s4,32(sp)
    800010cc:	ec56                	sd	s5,24(sp)
    800010ce:	e85a                	sd	s6,16(sp)
    800010d0:	e45e                	sd	s7,8(sp)
    800010d2:	0880                	addi	s0,sp,80
  uint64 a, last;
  pte_t *pte;

  if(size == 0)
    800010d4:	c639                	beqz	a2,80001122 <mappages+0x64>
    800010d6:	8aaa                	mv	s5,a0
    800010d8:	8b3a                	mv	s6,a4
    panic("mappages: size");
  
  a = PGROUNDDOWN(va);
    800010da:	77fd                	lui	a5,0xfffff
    800010dc:	00f5fa33          	and	s4,a1,a5
  last = PGROUNDDOWN(va + size - 1);
    800010e0:	15fd                	addi	a1,a1,-1
    800010e2:	00c589b3          	add	s3,a1,a2
    800010e6:	00f9f9b3          	and	s3,s3,a5
  a = PGROUNDDOWN(va);
    800010ea:	8952                	mv	s2,s4
    800010ec:	41468a33          	sub	s4,a3,s4
    if(*pte & PTE_V)
      panic("mappages: remap");
    *pte = PA2PTE(pa) | perm | PTE_V;
    if(a == last)
      break;
    a += PGSIZE;
    800010f0:	6b85                	lui	s7,0x1
    800010f2:	012a04b3          	add	s1,s4,s2
    if((pte = walk(pagetable, a, 1)) == 0)
    800010f6:	4605                	li	a2,1
    800010f8:	85ca                	mv	a1,s2
    800010fa:	8556                	mv	a0,s5
    800010fc:	00000097          	auipc	ra,0x0
    80001100:	eda080e7          	jalr	-294(ra) # 80000fd6 <walk>
    80001104:	cd1d                	beqz	a0,80001142 <mappages+0x84>
    if(*pte & PTE_V)
    80001106:	611c                	ld	a5,0(a0)
    80001108:	8b85                	andi	a5,a5,1
    8000110a:	e785                	bnez	a5,80001132 <mappages+0x74>
    *pte = PA2PTE(pa) | perm | PTE_V;
    8000110c:	80b1                	srli	s1,s1,0xc
    8000110e:	04aa                	slli	s1,s1,0xa
    80001110:	0164e4b3          	or	s1,s1,s6
    80001114:	0014e493          	ori	s1,s1,1
    80001118:	e104                	sd	s1,0(a0)
    if(a == last)
    8000111a:	05390063          	beq	s2,s3,8000115a <mappages+0x9c>
    a += PGSIZE;
    8000111e:	995e                	add	s2,s2,s7
    if((pte = walk(pagetable, a, 1)) == 0)
    80001120:	bfc9                	j	800010f2 <mappages+0x34>
    panic("mappages: size");
    80001122:	00007517          	auipc	a0,0x7
    80001126:	fc650513          	addi	a0,a0,-58 # 800080e8 <digits+0xa8>
    8000112a:	fffff097          	auipc	ra,0xfffff
    8000112e:	414080e7          	jalr	1044(ra) # 8000053e <panic>
      panic("mappages: remap");
    80001132:	00007517          	auipc	a0,0x7
    80001136:	fc650513          	addi	a0,a0,-58 # 800080f8 <digits+0xb8>
    8000113a:	fffff097          	auipc	ra,0xfffff
    8000113e:	404080e7          	jalr	1028(ra) # 8000053e <panic>
      return -1;
    80001142:	557d                	li	a0,-1
    pa += PGSIZE;
  }
  return 0;
}
    80001144:	60a6                	ld	ra,72(sp)
    80001146:	6406                	ld	s0,64(sp)
    80001148:	74e2                	ld	s1,56(sp)
    8000114a:	7942                	ld	s2,48(sp)
    8000114c:	79a2                	ld	s3,40(sp)
    8000114e:	7a02                	ld	s4,32(sp)
    80001150:	6ae2                	ld	s5,24(sp)
    80001152:	6b42                	ld	s6,16(sp)
    80001154:	6ba2                	ld	s7,8(sp)
    80001156:	6161                	addi	sp,sp,80
    80001158:	8082                	ret
  return 0;
    8000115a:	4501                	li	a0,0
    8000115c:	b7e5                	j	80001144 <mappages+0x86>

000000008000115e <kvmmap>:
{
    8000115e:	1141                	addi	sp,sp,-16
    80001160:	e406                	sd	ra,8(sp)
    80001162:	e022                	sd	s0,0(sp)
    80001164:	0800                	addi	s0,sp,16
    80001166:	87b6                	mv	a5,a3
  if(mappages(kpgtbl, va, sz, pa, perm) != 0)
    80001168:	86b2                	mv	a3,a2
    8000116a:	863e                	mv	a2,a5
    8000116c:	00000097          	auipc	ra,0x0
    80001170:	f52080e7          	jalr	-174(ra) # 800010be <mappages>
    80001174:	e509                	bnez	a0,8000117e <kvmmap+0x20>
}
    80001176:	60a2                	ld	ra,8(sp)
    80001178:	6402                	ld	s0,0(sp)
    8000117a:	0141                	addi	sp,sp,16
    8000117c:	8082                	ret
    panic("kvmmap");
    8000117e:	00007517          	auipc	a0,0x7
    80001182:	f8a50513          	addi	a0,a0,-118 # 80008108 <digits+0xc8>
    80001186:	fffff097          	auipc	ra,0xfffff
    8000118a:	3b8080e7          	jalr	952(ra) # 8000053e <panic>

000000008000118e <kvmmake>:
{
    8000118e:	1101                	addi	sp,sp,-32
    80001190:	ec06                	sd	ra,24(sp)
    80001192:	e822                	sd	s0,16(sp)
    80001194:	e426                	sd	s1,8(sp)
    80001196:	e04a                	sd	s2,0(sp)
    80001198:	1000                	addi	s0,sp,32
  kpgtbl = (pagetable_t) kalloc();
    8000119a:	00000097          	auipc	ra,0x0
    8000119e:	94c080e7          	jalr	-1716(ra) # 80000ae6 <kalloc>
    800011a2:	84aa                	mv	s1,a0
  memset(kpgtbl, 0, PGSIZE);
    800011a4:	6605                	lui	a2,0x1
    800011a6:	4581                	li	a1,0
    800011a8:	00000097          	auipc	ra,0x0
    800011ac:	b2a080e7          	jalr	-1238(ra) # 80000cd2 <memset>
  kvmmap(kpgtbl, UART0, UART0, PGSIZE, PTE_R | PTE_W);
    800011b0:	4719                	li	a4,6
    800011b2:	6685                	lui	a3,0x1
    800011b4:	10000637          	lui	a2,0x10000
    800011b8:	100005b7          	lui	a1,0x10000
    800011bc:	8526                	mv	a0,s1
    800011be:	00000097          	auipc	ra,0x0
    800011c2:	fa0080e7          	jalr	-96(ra) # 8000115e <kvmmap>
  kvmmap(kpgtbl, VIRTIO0, VIRTIO0, PGSIZE, PTE_R | PTE_W);
    800011c6:	4719                	li	a4,6
    800011c8:	6685                	lui	a3,0x1
    800011ca:	10001637          	lui	a2,0x10001
    800011ce:	100015b7          	lui	a1,0x10001
    800011d2:	8526                	mv	a0,s1
    800011d4:	00000097          	auipc	ra,0x0
    800011d8:	f8a080e7          	jalr	-118(ra) # 8000115e <kvmmap>
  kvmmap(kpgtbl, VIRTIO1, VIRTIO1, PGSIZE, PTE_R | PTE_W);
    800011dc:	4719                	li	a4,6
    800011de:	6685                	lui	a3,0x1
    800011e0:	10002637          	lui	a2,0x10002
    800011e4:	100025b7          	lui	a1,0x10002
    800011e8:	8526                	mv	a0,s1
    800011ea:	00000097          	auipc	ra,0x0
    800011ee:	f74080e7          	jalr	-140(ra) # 8000115e <kvmmap>
  kvmmap(kpgtbl, PLIC, PLIC, 0x400000, PTE_R | PTE_W);
    800011f2:	4719                	li	a4,6
    800011f4:	004006b7          	lui	a3,0x400
    800011f8:	0c000637          	lui	a2,0xc000
    800011fc:	0c0005b7          	lui	a1,0xc000
    80001200:	8526                	mv	a0,s1
    80001202:	00000097          	auipc	ra,0x0
    80001206:	f5c080e7          	jalr	-164(ra) # 8000115e <kvmmap>
  kvmmap(kpgtbl, KERNBASE, KERNBASE, (uint64)etext-KERNBASE, PTE_R | PTE_X);
    8000120a:	00007917          	auipc	s2,0x7
    8000120e:	df690913          	addi	s2,s2,-522 # 80008000 <etext>
    80001212:	4729                	li	a4,10
    80001214:	80007697          	auipc	a3,0x80007
    80001218:	dec68693          	addi	a3,a3,-532 # 8000 <_entry-0x7fff8000>
    8000121c:	4605                	li	a2,1
    8000121e:	067e                	slli	a2,a2,0x1f
    80001220:	85b2                	mv	a1,a2
    80001222:	8526                	mv	a0,s1
    80001224:	00000097          	auipc	ra,0x0
    80001228:	f3a080e7          	jalr	-198(ra) # 8000115e <kvmmap>
  kvmmap(kpgtbl, (uint64)etext, (uint64)etext, PHYSTOP-(uint64)etext, PTE_R | PTE_W);
    8000122c:	4719                	li	a4,6
    8000122e:	46c5                	li	a3,17
    80001230:	06ee                	slli	a3,a3,0x1b
    80001232:	412686b3          	sub	a3,a3,s2
    80001236:	864a                	mv	a2,s2
    80001238:	85ca                	mv	a1,s2
    8000123a:	8526                	mv	a0,s1
    8000123c:	00000097          	auipc	ra,0x0
    80001240:	f22080e7          	jalr	-222(ra) # 8000115e <kvmmap>
  kvmmap(kpgtbl, TRAMPOLINE, (uint64)trampoline, PGSIZE, PTE_R | PTE_X);
    80001244:	4729                	li	a4,10
    80001246:	6685                	lui	a3,0x1
    80001248:	00006617          	auipc	a2,0x6
    8000124c:	db860613          	addi	a2,a2,-584 # 80007000 <_trampoline>
    80001250:	040005b7          	lui	a1,0x4000
    80001254:	15fd                	addi	a1,a1,-1
    80001256:	05b2                	slli	a1,a1,0xc
    80001258:	8526                	mv	a0,s1
    8000125a:	00000097          	auipc	ra,0x0
    8000125e:	f04080e7          	jalr	-252(ra) # 8000115e <kvmmap>
  proc_mapstacks(kpgtbl);
    80001262:	8526                	mv	a0,s1
    80001264:	00000097          	auipc	ra,0x0
    80001268:	608080e7          	jalr	1544(ra) # 8000186c <proc_mapstacks>
}
    8000126c:	8526                	mv	a0,s1
    8000126e:	60e2                	ld	ra,24(sp)
    80001270:	6442                	ld	s0,16(sp)
    80001272:	64a2                	ld	s1,8(sp)
    80001274:	6902                	ld	s2,0(sp)
    80001276:	6105                	addi	sp,sp,32
    80001278:	8082                	ret

000000008000127a <kvminit>:
{
    8000127a:	1141                	addi	sp,sp,-16
    8000127c:	e406                	sd	ra,8(sp)
    8000127e:	e022                	sd	s0,0(sp)
    80001280:	0800                	addi	s0,sp,16
  kernel_pagetable = kvmmake();
    80001282:	00000097          	auipc	ra,0x0
    80001286:	f0c080e7          	jalr	-244(ra) # 8000118e <kvmmake>
    8000128a:	00008797          	auipc	a5,0x8
    8000128e:	fca7b323          	sd	a0,-58(a5) # 80009250 <kernel_pagetable>
}
    80001292:	60a2                	ld	ra,8(sp)
    80001294:	6402                	ld	s0,0(sp)
    80001296:	0141                	addi	sp,sp,16
    80001298:	8082                	ret

000000008000129a <uvmunmap>:
// Remove npages of mappings starting from va. va must be
// page-aligned. The mappings must exist.
// Optionally free the physical memory.
void
uvmunmap(pagetable_t pagetable, uint64 va, uint64 npages, int do_free)
{
    8000129a:	715d                	addi	sp,sp,-80
    8000129c:	e486                	sd	ra,72(sp)
    8000129e:	e0a2                	sd	s0,64(sp)
    800012a0:	fc26                	sd	s1,56(sp)
    800012a2:	f84a                	sd	s2,48(sp)
    800012a4:	f44e                	sd	s3,40(sp)
    800012a6:	f052                	sd	s4,32(sp)
    800012a8:	ec56                	sd	s5,24(sp)
    800012aa:	e85a                	sd	s6,16(sp)
    800012ac:	e45e                	sd	s7,8(sp)
    800012ae:	0880                	addi	s0,sp,80
  uint64 a;
  pte_t *pte;

  if((va % PGSIZE) != 0)
    800012b0:	03459793          	slli	a5,a1,0x34
    800012b4:	e795                	bnez	a5,800012e0 <uvmunmap+0x46>
    800012b6:	8a2a                	mv	s4,a0
    800012b8:	892e                	mv	s2,a1
    800012ba:	8ab6                	mv	s5,a3
    panic("uvmunmap: not aligned");

  for(a = va; a < va + npages*PGSIZE; a += PGSIZE){
    800012bc:	0632                	slli	a2,a2,0xc
    800012be:	00b609b3          	add	s3,a2,a1
    if((pte = walk(pagetable, a, 0)) == 0)
      panic("uvmunmap: walk");
    if((*pte & PTE_V) == 0)
      panic("uvmunmap: not mapped");
    if(PTE_FLAGS(*pte) == PTE_V)
    800012c2:	4b85                	li	s7,1
  for(a = va; a < va + npages*PGSIZE; a += PGSIZE){
    800012c4:	6b05                	lui	s6,0x1
    800012c6:	0735e263          	bltu	a1,s3,8000132a <uvmunmap+0x90>
      uint64 pa = PTE2PA(*pte);
      kfree((void*)pa);
    }
    *pte = 0;
  }
}
    800012ca:	60a6                	ld	ra,72(sp)
    800012cc:	6406                	ld	s0,64(sp)
    800012ce:	74e2                	ld	s1,56(sp)
    800012d0:	7942                	ld	s2,48(sp)
    800012d2:	79a2                	ld	s3,40(sp)
    800012d4:	7a02                	ld	s4,32(sp)
    800012d6:	6ae2                	ld	s5,24(sp)
    800012d8:	6b42                	ld	s6,16(sp)
    800012da:	6ba2                	ld	s7,8(sp)
    800012dc:	6161                	addi	sp,sp,80
    800012de:	8082                	ret
    panic("uvmunmap: not aligned");
    800012e0:	00007517          	auipc	a0,0x7
    800012e4:	e3050513          	addi	a0,a0,-464 # 80008110 <digits+0xd0>
    800012e8:	fffff097          	auipc	ra,0xfffff
    800012ec:	256080e7          	jalr	598(ra) # 8000053e <panic>
      panic("uvmunmap: walk");
    800012f0:	00007517          	auipc	a0,0x7
    800012f4:	e3850513          	addi	a0,a0,-456 # 80008128 <digits+0xe8>
    800012f8:	fffff097          	auipc	ra,0xfffff
    800012fc:	246080e7          	jalr	582(ra) # 8000053e <panic>
      panic("uvmunmap: not mapped");
    80001300:	00007517          	auipc	a0,0x7
    80001304:	e3850513          	addi	a0,a0,-456 # 80008138 <digits+0xf8>
    80001308:	fffff097          	auipc	ra,0xfffff
    8000130c:	236080e7          	jalr	566(ra) # 8000053e <panic>
      panic("uvmunmap: not a leaf");
    80001310:	00007517          	auipc	a0,0x7
    80001314:	e4050513          	addi	a0,a0,-448 # 80008150 <digits+0x110>
    80001318:	fffff097          	auipc	ra,0xfffff
    8000131c:	226080e7          	jalr	550(ra) # 8000053e <panic>
    *pte = 0;
    80001320:	0004b023          	sd	zero,0(s1)
  for(a = va; a < va + npages*PGSIZE; a += PGSIZE){
    80001324:	995a                	add	s2,s2,s6
    80001326:	fb3972e3          	bgeu	s2,s3,800012ca <uvmunmap+0x30>
    if((pte = walk(pagetable, a, 0)) == 0)
    8000132a:	4601                	li	a2,0
    8000132c:	85ca                	mv	a1,s2
    8000132e:	8552                	mv	a0,s4
    80001330:	00000097          	auipc	ra,0x0
    80001334:	ca6080e7          	jalr	-858(ra) # 80000fd6 <walk>
    80001338:	84aa                	mv	s1,a0
    8000133a:	d95d                	beqz	a0,800012f0 <uvmunmap+0x56>
    if((*pte & PTE_V) == 0)
    8000133c:	6108                	ld	a0,0(a0)
    8000133e:	00157793          	andi	a5,a0,1
    80001342:	dfdd                	beqz	a5,80001300 <uvmunmap+0x66>
    if(PTE_FLAGS(*pte) == PTE_V)
    80001344:	3ff57793          	andi	a5,a0,1023
    80001348:	fd7784e3          	beq	a5,s7,80001310 <uvmunmap+0x76>
    if(do_free){
    8000134c:	fc0a8ae3          	beqz	s5,80001320 <uvmunmap+0x86>
      uint64 pa = PTE2PA(*pte);
    80001350:	8129                	srli	a0,a0,0xa
      kfree((void*)pa);
    80001352:	0532                	slli	a0,a0,0xc
    80001354:	fffff097          	auipc	ra,0xfffff
    80001358:	696080e7          	jalr	1686(ra) # 800009ea <kfree>
    8000135c:	b7d1                	j	80001320 <uvmunmap+0x86>

000000008000135e <uvmcreate>:

// create an empty user page table.
// returns 0 if out of memory.
pagetable_t
uvmcreate()
{
    8000135e:	1101                	addi	sp,sp,-32
    80001360:	ec06                	sd	ra,24(sp)
    80001362:	e822                	sd	s0,16(sp)
    80001364:	e426                	sd	s1,8(sp)
    80001366:	1000                	addi	s0,sp,32
  pagetable_t pagetable;
  pagetable = (pagetable_t) kalloc();
    80001368:	fffff097          	auipc	ra,0xfffff
    8000136c:	77e080e7          	jalr	1918(ra) # 80000ae6 <kalloc>
    80001370:	84aa                	mv	s1,a0
  if(pagetable == 0)
    80001372:	c519                	beqz	a0,80001380 <uvmcreate+0x22>
    return 0;
  memset(pagetable, 0, PGSIZE);
    80001374:	6605                	lui	a2,0x1
    80001376:	4581                	li	a1,0
    80001378:	00000097          	auipc	ra,0x0
    8000137c:	95a080e7          	jalr	-1702(ra) # 80000cd2 <memset>
  return pagetable;
}
    80001380:	8526                	mv	a0,s1
    80001382:	60e2                	ld	ra,24(sp)
    80001384:	6442                	ld	s0,16(sp)
    80001386:	64a2                	ld	s1,8(sp)
    80001388:	6105                	addi	sp,sp,32
    8000138a:	8082                	ret

000000008000138c <uvmfirst>:
// Load the user initcode into address 0 of pagetable,
// for the very first process.
// sz must be less than a page.
void
uvmfirst(pagetable_t pagetable, uchar *src, uint sz)
{
    8000138c:	7179                	addi	sp,sp,-48
    8000138e:	f406                	sd	ra,40(sp)
    80001390:	f022                	sd	s0,32(sp)
    80001392:	ec26                	sd	s1,24(sp)
    80001394:	e84a                	sd	s2,16(sp)
    80001396:	e44e                	sd	s3,8(sp)
    80001398:	e052                	sd	s4,0(sp)
    8000139a:	1800                	addi	s0,sp,48
  char *mem;

  if(sz >= PGSIZE)
    8000139c:	6785                	lui	a5,0x1
    8000139e:	04f67863          	bgeu	a2,a5,800013ee <uvmfirst+0x62>
    800013a2:	8a2a                	mv	s4,a0
    800013a4:	89ae                	mv	s3,a1
    800013a6:	84b2                	mv	s1,a2
    panic("uvmfirst: more than a page");
  mem = kalloc();
    800013a8:	fffff097          	auipc	ra,0xfffff
    800013ac:	73e080e7          	jalr	1854(ra) # 80000ae6 <kalloc>
    800013b0:	892a                	mv	s2,a0
  memset(mem, 0, PGSIZE);
    800013b2:	6605                	lui	a2,0x1
    800013b4:	4581                	li	a1,0
    800013b6:	00000097          	auipc	ra,0x0
    800013ba:	91c080e7          	jalr	-1764(ra) # 80000cd2 <memset>
  mappages(pagetable, 0, PGSIZE, (uint64)mem, PTE_W|PTE_R|PTE_X|PTE_U);
    800013be:	4779                	li	a4,30
    800013c0:	86ca                	mv	a3,s2
    800013c2:	6605                	lui	a2,0x1
    800013c4:	4581                	li	a1,0
    800013c6:	8552                	mv	a0,s4
    800013c8:	00000097          	auipc	ra,0x0
    800013cc:	cf6080e7          	jalr	-778(ra) # 800010be <mappages>
  memmove(mem, src, sz);
    800013d0:	8626                	mv	a2,s1
    800013d2:	85ce                	mv	a1,s3
    800013d4:	854a                	mv	a0,s2
    800013d6:	00000097          	auipc	ra,0x0
    800013da:	958080e7          	jalr	-1704(ra) # 80000d2e <memmove>
}
    800013de:	70a2                	ld	ra,40(sp)
    800013e0:	7402                	ld	s0,32(sp)
    800013e2:	64e2                	ld	s1,24(sp)
    800013e4:	6942                	ld	s2,16(sp)
    800013e6:	69a2                	ld	s3,8(sp)
    800013e8:	6a02                	ld	s4,0(sp)
    800013ea:	6145                	addi	sp,sp,48
    800013ec:	8082                	ret
    panic("uvmfirst: more than a page");
    800013ee:	00007517          	auipc	a0,0x7
    800013f2:	d7a50513          	addi	a0,a0,-646 # 80008168 <digits+0x128>
    800013f6:	fffff097          	auipc	ra,0xfffff
    800013fa:	148080e7          	jalr	328(ra) # 8000053e <panic>

00000000800013fe <uvmdealloc>:
// newsz.  oldsz and newsz need not be page-aligned, nor does newsz
// need to be less than oldsz.  oldsz can be larger than the actual
// process size.  Returns the new process size.
uint64
uvmdealloc(pagetable_t pagetable, uint64 oldsz, uint64 newsz)
{
    800013fe:	1101                	addi	sp,sp,-32
    80001400:	ec06                	sd	ra,24(sp)
    80001402:	e822                	sd	s0,16(sp)
    80001404:	e426                	sd	s1,8(sp)
    80001406:	1000                	addi	s0,sp,32
  if(newsz >= oldsz)
    return oldsz;
    80001408:	84ae                	mv	s1,a1
  if(newsz >= oldsz)
    8000140a:	00b67d63          	bgeu	a2,a1,80001424 <uvmdealloc+0x26>
    8000140e:	84b2                	mv	s1,a2

  if(PGROUNDUP(newsz) < PGROUNDUP(oldsz)){
    80001410:	6785                	lui	a5,0x1
    80001412:	17fd                	addi	a5,a5,-1
    80001414:	00f60733          	add	a4,a2,a5
    80001418:	767d                	lui	a2,0xfffff
    8000141a:	8f71                	and	a4,a4,a2
    8000141c:	97ae                	add	a5,a5,a1
    8000141e:	8ff1                	and	a5,a5,a2
    80001420:	00f76863          	bltu	a4,a5,80001430 <uvmdealloc+0x32>
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
  }

  return newsz;
}
    80001424:	8526                	mv	a0,s1
    80001426:	60e2                	ld	ra,24(sp)
    80001428:	6442                	ld	s0,16(sp)
    8000142a:	64a2                	ld	s1,8(sp)
    8000142c:	6105                	addi	sp,sp,32
    8000142e:	8082                	ret
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    80001430:	8f99                	sub	a5,a5,a4
    80001432:	83b1                	srli	a5,a5,0xc
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
    80001434:	4685                	li	a3,1
    80001436:	0007861b          	sext.w	a2,a5
    8000143a:	85ba                	mv	a1,a4
    8000143c:	00000097          	auipc	ra,0x0
    80001440:	e5e080e7          	jalr	-418(ra) # 8000129a <uvmunmap>
    80001444:	b7c5                	j	80001424 <uvmdealloc+0x26>

0000000080001446 <uvmalloc>:
  if(newsz < oldsz)
    80001446:	0ab66563          	bltu	a2,a1,800014f0 <uvmalloc+0xaa>
{
    8000144a:	7139                	addi	sp,sp,-64
    8000144c:	fc06                	sd	ra,56(sp)
    8000144e:	f822                	sd	s0,48(sp)
    80001450:	f426                	sd	s1,40(sp)
    80001452:	f04a                	sd	s2,32(sp)
    80001454:	ec4e                	sd	s3,24(sp)
    80001456:	e852                	sd	s4,16(sp)
    80001458:	e456                	sd	s5,8(sp)
    8000145a:	e05a                	sd	s6,0(sp)
    8000145c:	0080                	addi	s0,sp,64
    8000145e:	8aaa                	mv	s5,a0
    80001460:	8a32                	mv	s4,a2
  oldsz = PGROUNDUP(oldsz);
    80001462:	6985                	lui	s3,0x1
    80001464:	19fd                	addi	s3,s3,-1
    80001466:	95ce                	add	a1,a1,s3
    80001468:	79fd                	lui	s3,0xfffff
    8000146a:	0135f9b3          	and	s3,a1,s3
  for(a = oldsz; a < newsz; a += PGSIZE){
    8000146e:	08c9f363          	bgeu	s3,a2,800014f4 <uvmalloc+0xae>
    80001472:	894e                	mv	s2,s3
    if(mappages(pagetable, a, PGSIZE, (uint64)mem, PTE_R|PTE_U|xperm) != 0){
    80001474:	0126eb13          	ori	s6,a3,18
    mem = kalloc();
    80001478:	fffff097          	auipc	ra,0xfffff
    8000147c:	66e080e7          	jalr	1646(ra) # 80000ae6 <kalloc>
    80001480:	84aa                	mv	s1,a0
    if(mem == 0){
    80001482:	c51d                	beqz	a0,800014b0 <uvmalloc+0x6a>
    memset(mem, 0, PGSIZE);
    80001484:	6605                	lui	a2,0x1
    80001486:	4581                	li	a1,0
    80001488:	00000097          	auipc	ra,0x0
    8000148c:	84a080e7          	jalr	-1974(ra) # 80000cd2 <memset>
    if(mappages(pagetable, a, PGSIZE, (uint64)mem, PTE_R|PTE_U|xperm) != 0){
    80001490:	875a                	mv	a4,s6
    80001492:	86a6                	mv	a3,s1
    80001494:	6605                	lui	a2,0x1
    80001496:	85ca                	mv	a1,s2
    80001498:	8556                	mv	a0,s5
    8000149a:	00000097          	auipc	ra,0x0
    8000149e:	c24080e7          	jalr	-988(ra) # 800010be <mappages>
    800014a2:	e90d                	bnez	a0,800014d4 <uvmalloc+0x8e>
  for(a = oldsz; a < newsz; a += PGSIZE){
    800014a4:	6785                	lui	a5,0x1
    800014a6:	993e                	add	s2,s2,a5
    800014a8:	fd4968e3          	bltu	s2,s4,80001478 <uvmalloc+0x32>
  return newsz;
    800014ac:	8552                	mv	a0,s4
    800014ae:	a809                	j	800014c0 <uvmalloc+0x7a>
      uvmdealloc(pagetable, a, oldsz);
    800014b0:	864e                	mv	a2,s3
    800014b2:	85ca                	mv	a1,s2
    800014b4:	8556                	mv	a0,s5
    800014b6:	00000097          	auipc	ra,0x0
    800014ba:	f48080e7          	jalr	-184(ra) # 800013fe <uvmdealloc>
      return 0;
    800014be:	4501                	li	a0,0
}
    800014c0:	70e2                	ld	ra,56(sp)
    800014c2:	7442                	ld	s0,48(sp)
    800014c4:	74a2                	ld	s1,40(sp)
    800014c6:	7902                	ld	s2,32(sp)
    800014c8:	69e2                	ld	s3,24(sp)
    800014ca:	6a42                	ld	s4,16(sp)
    800014cc:	6aa2                	ld	s5,8(sp)
    800014ce:	6b02                	ld	s6,0(sp)
    800014d0:	6121                	addi	sp,sp,64
    800014d2:	8082                	ret
      kfree(mem);
    800014d4:	8526                	mv	a0,s1
    800014d6:	fffff097          	auipc	ra,0xfffff
    800014da:	514080e7          	jalr	1300(ra) # 800009ea <kfree>
      uvmdealloc(pagetable, a, oldsz);
    800014de:	864e                	mv	a2,s3
    800014e0:	85ca                	mv	a1,s2
    800014e2:	8556                	mv	a0,s5
    800014e4:	00000097          	auipc	ra,0x0
    800014e8:	f1a080e7          	jalr	-230(ra) # 800013fe <uvmdealloc>
      return 0;
    800014ec:	4501                	li	a0,0
    800014ee:	bfc9                	j	800014c0 <uvmalloc+0x7a>
    return oldsz;
    800014f0:	852e                	mv	a0,a1
}
    800014f2:	8082                	ret
  return newsz;
    800014f4:	8532                	mv	a0,a2
    800014f6:	b7e9                	j	800014c0 <uvmalloc+0x7a>

00000000800014f8 <freewalk>:

// Recursively free page-table pages.
// All leaf mappings must already have been removed.
void
freewalk(pagetable_t pagetable)
{
    800014f8:	7179                	addi	sp,sp,-48
    800014fa:	f406                	sd	ra,40(sp)
    800014fc:	f022                	sd	s0,32(sp)
    800014fe:	ec26                	sd	s1,24(sp)
    80001500:	e84a                	sd	s2,16(sp)
    80001502:	e44e                	sd	s3,8(sp)
    80001504:	e052                	sd	s4,0(sp)
    80001506:	1800                	addi	s0,sp,48
    80001508:	8a2a                	mv	s4,a0
  // there are 2^9 = 512 PTEs in a page table.
  for(int i = 0; i < 512; i++){
    8000150a:	84aa                	mv	s1,a0
    8000150c:	6905                	lui	s2,0x1
    8000150e:	992a                	add	s2,s2,a0
    pte_t pte = pagetable[i];
    if((pte & PTE_V) && (pte & (PTE_R|PTE_W|PTE_X)) == 0){
    80001510:	4985                	li	s3,1
    80001512:	a821                	j	8000152a <freewalk+0x32>
      // this PTE points to a lower-level page table.
      uint64 child = PTE2PA(pte);
    80001514:	8129                	srli	a0,a0,0xa
      freewalk((pagetable_t)child);
    80001516:	0532                	slli	a0,a0,0xc
    80001518:	00000097          	auipc	ra,0x0
    8000151c:	fe0080e7          	jalr	-32(ra) # 800014f8 <freewalk>
      pagetable[i] = 0;
    80001520:	0004b023          	sd	zero,0(s1)
  for(int i = 0; i < 512; i++){
    80001524:	04a1                	addi	s1,s1,8
    80001526:	03248163          	beq	s1,s2,80001548 <freewalk+0x50>
    pte_t pte = pagetable[i];
    8000152a:	6088                	ld	a0,0(s1)
    if((pte & PTE_V) && (pte & (PTE_R|PTE_W|PTE_X)) == 0){
    8000152c:	00f57793          	andi	a5,a0,15
    80001530:	ff3782e3          	beq	a5,s3,80001514 <freewalk+0x1c>
    } else if(pte & PTE_V){
    80001534:	8905                	andi	a0,a0,1
    80001536:	d57d                	beqz	a0,80001524 <freewalk+0x2c>
      panic("freewalk: leaf");
    80001538:	00007517          	auipc	a0,0x7
    8000153c:	c5050513          	addi	a0,a0,-944 # 80008188 <digits+0x148>
    80001540:	fffff097          	auipc	ra,0xfffff
    80001544:	ffe080e7          	jalr	-2(ra) # 8000053e <panic>
    }
  }
  kfree((void*)pagetable);
    80001548:	8552                	mv	a0,s4
    8000154a:	fffff097          	auipc	ra,0xfffff
    8000154e:	4a0080e7          	jalr	1184(ra) # 800009ea <kfree>
}
    80001552:	70a2                	ld	ra,40(sp)
    80001554:	7402                	ld	s0,32(sp)
    80001556:	64e2                	ld	s1,24(sp)
    80001558:	6942                	ld	s2,16(sp)
    8000155a:	69a2                	ld	s3,8(sp)
    8000155c:	6a02                	ld	s4,0(sp)
    8000155e:	6145                	addi	sp,sp,48
    80001560:	8082                	ret

0000000080001562 <uvmfree>:

// Free user memory pages,
// then free page-table pages.
void
uvmfree(pagetable_t pagetable, uint64 sz)
{
    80001562:	1101                	addi	sp,sp,-32
    80001564:	ec06                	sd	ra,24(sp)
    80001566:	e822                	sd	s0,16(sp)
    80001568:	e426                	sd	s1,8(sp)
    8000156a:	1000                	addi	s0,sp,32
    8000156c:	84aa                	mv	s1,a0
  if(sz > 0)
    8000156e:	e999                	bnez	a1,80001584 <uvmfree+0x22>
    uvmunmap(pagetable, 0, PGROUNDUP(sz)/PGSIZE, 1);
  freewalk(pagetable);
    80001570:	8526                	mv	a0,s1
    80001572:	00000097          	auipc	ra,0x0
    80001576:	f86080e7          	jalr	-122(ra) # 800014f8 <freewalk>
}
    8000157a:	60e2                	ld	ra,24(sp)
    8000157c:	6442                	ld	s0,16(sp)
    8000157e:	64a2                	ld	s1,8(sp)
    80001580:	6105                	addi	sp,sp,32
    80001582:	8082                	ret
    uvmunmap(pagetable, 0, PGROUNDUP(sz)/PGSIZE, 1);
    80001584:	6605                	lui	a2,0x1
    80001586:	167d                	addi	a2,a2,-1
    80001588:	962e                	add	a2,a2,a1
    8000158a:	4685                	li	a3,1
    8000158c:	8231                	srli	a2,a2,0xc
    8000158e:	4581                	li	a1,0
    80001590:	00000097          	auipc	ra,0x0
    80001594:	d0a080e7          	jalr	-758(ra) # 8000129a <uvmunmap>
    80001598:	bfe1                	j	80001570 <uvmfree+0xe>

000000008000159a <uvmcopy>:
  pte_t *pte;
  uint64 pa, i;
  uint flags;
  char *mem;

  for(i = 0; i < sz; i += PGSIZE){
    8000159a:	c679                	beqz	a2,80001668 <uvmcopy+0xce>
{
    8000159c:	715d                	addi	sp,sp,-80
    8000159e:	e486                	sd	ra,72(sp)
    800015a0:	e0a2                	sd	s0,64(sp)
    800015a2:	fc26                	sd	s1,56(sp)
    800015a4:	f84a                	sd	s2,48(sp)
    800015a6:	f44e                	sd	s3,40(sp)
    800015a8:	f052                	sd	s4,32(sp)
    800015aa:	ec56                	sd	s5,24(sp)
    800015ac:	e85a                	sd	s6,16(sp)
    800015ae:	e45e                	sd	s7,8(sp)
    800015b0:	0880                	addi	s0,sp,80
    800015b2:	8b2a                	mv	s6,a0
    800015b4:	8aae                	mv	s5,a1
    800015b6:	8a32                	mv	s4,a2
  for(i = 0; i < sz; i += PGSIZE){
    800015b8:	4981                	li	s3,0
    if((pte = walk(old, i, 0)) == 0)
    800015ba:	4601                	li	a2,0
    800015bc:	85ce                	mv	a1,s3
    800015be:	855a                	mv	a0,s6
    800015c0:	00000097          	auipc	ra,0x0
    800015c4:	a16080e7          	jalr	-1514(ra) # 80000fd6 <walk>
    800015c8:	c531                	beqz	a0,80001614 <uvmcopy+0x7a>
      panic("uvmcopy: pte should exist");
    if((*pte & PTE_V) == 0)
    800015ca:	6118                	ld	a4,0(a0)
    800015cc:	00177793          	andi	a5,a4,1
    800015d0:	cbb1                	beqz	a5,80001624 <uvmcopy+0x8a>
      panic("uvmcopy: page not present");
    pa = PTE2PA(*pte);
    800015d2:	00a75593          	srli	a1,a4,0xa
    800015d6:	00c59b93          	slli	s7,a1,0xc
    flags = PTE_FLAGS(*pte);
    800015da:	3ff77493          	andi	s1,a4,1023
    if((mem = kalloc()) == 0)
    800015de:	fffff097          	auipc	ra,0xfffff
    800015e2:	508080e7          	jalr	1288(ra) # 80000ae6 <kalloc>
    800015e6:	892a                	mv	s2,a0
    800015e8:	c939                	beqz	a0,8000163e <uvmcopy+0xa4>
      goto err;
    memmove(mem, (char*)pa, PGSIZE);
    800015ea:	6605                	lui	a2,0x1
    800015ec:	85de                	mv	a1,s7
    800015ee:	fffff097          	auipc	ra,0xfffff
    800015f2:	740080e7          	jalr	1856(ra) # 80000d2e <memmove>
    if(mappages(new, i, PGSIZE, (uint64)mem, flags) != 0){
    800015f6:	8726                	mv	a4,s1
    800015f8:	86ca                	mv	a3,s2
    800015fa:	6605                	lui	a2,0x1
    800015fc:	85ce                	mv	a1,s3
    800015fe:	8556                	mv	a0,s5
    80001600:	00000097          	auipc	ra,0x0
    80001604:	abe080e7          	jalr	-1346(ra) # 800010be <mappages>
    80001608:	e515                	bnez	a0,80001634 <uvmcopy+0x9a>
  for(i = 0; i < sz; i += PGSIZE){
    8000160a:	6785                	lui	a5,0x1
    8000160c:	99be                	add	s3,s3,a5
    8000160e:	fb49e6e3          	bltu	s3,s4,800015ba <uvmcopy+0x20>
    80001612:	a081                	j	80001652 <uvmcopy+0xb8>
      panic("uvmcopy: pte should exist");
    80001614:	00007517          	auipc	a0,0x7
    80001618:	b8450513          	addi	a0,a0,-1148 # 80008198 <digits+0x158>
    8000161c:	fffff097          	auipc	ra,0xfffff
    80001620:	f22080e7          	jalr	-222(ra) # 8000053e <panic>
      panic("uvmcopy: page not present");
    80001624:	00007517          	auipc	a0,0x7
    80001628:	b9450513          	addi	a0,a0,-1132 # 800081b8 <digits+0x178>
    8000162c:	fffff097          	auipc	ra,0xfffff
    80001630:	f12080e7          	jalr	-238(ra) # 8000053e <panic>
      kfree(mem);
    80001634:	854a                	mv	a0,s2
    80001636:	fffff097          	auipc	ra,0xfffff
    8000163a:	3b4080e7          	jalr	948(ra) # 800009ea <kfree>
    }
  }
  return 0;

 err:
  uvmunmap(new, 0, i / PGSIZE, 1);
    8000163e:	4685                	li	a3,1
    80001640:	00c9d613          	srli	a2,s3,0xc
    80001644:	4581                	li	a1,0
    80001646:	8556                	mv	a0,s5
    80001648:	00000097          	auipc	ra,0x0
    8000164c:	c52080e7          	jalr	-942(ra) # 8000129a <uvmunmap>
  return -1;
    80001650:	557d                	li	a0,-1
}
    80001652:	60a6                	ld	ra,72(sp)
    80001654:	6406                	ld	s0,64(sp)
    80001656:	74e2                	ld	s1,56(sp)
    80001658:	7942                	ld	s2,48(sp)
    8000165a:	79a2                	ld	s3,40(sp)
    8000165c:	7a02                	ld	s4,32(sp)
    8000165e:	6ae2                	ld	s5,24(sp)
    80001660:	6b42                	ld	s6,16(sp)
    80001662:	6ba2                	ld	s7,8(sp)
    80001664:	6161                	addi	sp,sp,80
    80001666:	8082                	ret
  return 0;
    80001668:	4501                	li	a0,0
}
    8000166a:	8082                	ret

000000008000166c <uvmclear>:

// mark a PTE invalid for user access.
// used by exec for the user stack guard page.
void
uvmclear(pagetable_t pagetable, uint64 va)
{
    8000166c:	1141                	addi	sp,sp,-16
    8000166e:	e406                	sd	ra,8(sp)
    80001670:	e022                	sd	s0,0(sp)
    80001672:	0800                	addi	s0,sp,16
  pte_t *pte;
  
  pte = walk(pagetable, va, 0);
    80001674:	4601                	li	a2,0
    80001676:	00000097          	auipc	ra,0x0
    8000167a:	960080e7          	jalr	-1696(ra) # 80000fd6 <walk>
  if(pte == 0)
    8000167e:	c901                	beqz	a0,8000168e <uvmclear+0x22>
    panic("uvmclear");
  *pte &= ~PTE_U;
    80001680:	611c                	ld	a5,0(a0)
    80001682:	9bbd                	andi	a5,a5,-17
    80001684:	e11c                	sd	a5,0(a0)
}
    80001686:	60a2                	ld	ra,8(sp)
    80001688:	6402                	ld	s0,0(sp)
    8000168a:	0141                	addi	sp,sp,16
    8000168c:	8082                	ret
    panic("uvmclear");
    8000168e:	00007517          	auipc	a0,0x7
    80001692:	b4a50513          	addi	a0,a0,-1206 # 800081d8 <digits+0x198>
    80001696:	fffff097          	auipc	ra,0xfffff
    8000169a:	ea8080e7          	jalr	-344(ra) # 8000053e <panic>

000000008000169e <copyout>:
int
copyout(pagetable_t pagetable, uint64 dstva, char *src, uint64 len)
{
  uint64 n, va0, pa0;

  while(len > 0){
    8000169e:	c6bd                	beqz	a3,8000170c <copyout+0x6e>
{
    800016a0:	715d                	addi	sp,sp,-80
    800016a2:	e486                	sd	ra,72(sp)
    800016a4:	e0a2                	sd	s0,64(sp)
    800016a6:	fc26                	sd	s1,56(sp)
    800016a8:	f84a                	sd	s2,48(sp)
    800016aa:	f44e                	sd	s3,40(sp)
    800016ac:	f052                	sd	s4,32(sp)
    800016ae:	ec56                	sd	s5,24(sp)
    800016b0:	e85a                	sd	s6,16(sp)
    800016b2:	e45e                	sd	s7,8(sp)
    800016b4:	e062                	sd	s8,0(sp)
    800016b6:	0880                	addi	s0,sp,80
    800016b8:	8b2a                	mv	s6,a0
    800016ba:	8c2e                	mv	s8,a1
    800016bc:	8a32                	mv	s4,a2
    800016be:	89b6                	mv	s3,a3
    va0 = PGROUNDDOWN(dstva);
    800016c0:	7bfd                	lui	s7,0xfffff
    pa0 = walkaddr(pagetable, va0);
    if(pa0 == 0)
      return -1;
    n = PGSIZE - (dstva - va0);
    800016c2:	6a85                	lui	s5,0x1
    800016c4:	a015                	j	800016e8 <copyout+0x4a>
    if(n > len)
      n = len;
    memmove((void *)(pa0 + (dstva - va0)), src, n);
    800016c6:	9562                	add	a0,a0,s8
    800016c8:	0004861b          	sext.w	a2,s1
    800016cc:	85d2                	mv	a1,s4
    800016ce:	41250533          	sub	a0,a0,s2
    800016d2:	fffff097          	auipc	ra,0xfffff
    800016d6:	65c080e7          	jalr	1628(ra) # 80000d2e <memmove>

    len -= n;
    800016da:	409989b3          	sub	s3,s3,s1
    src += n;
    800016de:	9a26                	add	s4,s4,s1
    dstva = va0 + PGSIZE;
    800016e0:	01590c33          	add	s8,s2,s5
  while(len > 0){
    800016e4:	02098263          	beqz	s3,80001708 <copyout+0x6a>
    va0 = PGROUNDDOWN(dstva);
    800016e8:	017c7933          	and	s2,s8,s7
    pa0 = walkaddr(pagetable, va0);
    800016ec:	85ca                	mv	a1,s2
    800016ee:	855a                	mv	a0,s6
    800016f0:	00000097          	auipc	ra,0x0
    800016f4:	98c080e7          	jalr	-1652(ra) # 8000107c <walkaddr>
    if(pa0 == 0)
    800016f8:	cd01                	beqz	a0,80001710 <copyout+0x72>
    n = PGSIZE - (dstva - va0);
    800016fa:	418904b3          	sub	s1,s2,s8
    800016fe:	94d6                	add	s1,s1,s5
    if(n > len)
    80001700:	fc99f3e3          	bgeu	s3,s1,800016c6 <copyout+0x28>
    80001704:	84ce                	mv	s1,s3
    80001706:	b7c1                	j	800016c6 <copyout+0x28>
  }
  return 0;
    80001708:	4501                	li	a0,0
    8000170a:	a021                	j	80001712 <copyout+0x74>
    8000170c:	4501                	li	a0,0
}
    8000170e:	8082                	ret
      return -1;
    80001710:	557d                	li	a0,-1
}
    80001712:	60a6                	ld	ra,72(sp)
    80001714:	6406                	ld	s0,64(sp)
    80001716:	74e2                	ld	s1,56(sp)
    80001718:	7942                	ld	s2,48(sp)
    8000171a:	79a2                	ld	s3,40(sp)
    8000171c:	7a02                	ld	s4,32(sp)
    8000171e:	6ae2                	ld	s5,24(sp)
    80001720:	6b42                	ld	s6,16(sp)
    80001722:	6ba2                	ld	s7,8(sp)
    80001724:	6c02                	ld	s8,0(sp)
    80001726:	6161                	addi	sp,sp,80
    80001728:	8082                	ret

000000008000172a <copyin>:
int
copyin(pagetable_t pagetable, char *dst, uint64 srcva, uint64 len)
{
  uint64 n, va0, pa0;

  while(len > 0){
    8000172a:	caa5                	beqz	a3,8000179a <copyin+0x70>
{
    8000172c:	715d                	addi	sp,sp,-80
    8000172e:	e486                	sd	ra,72(sp)
    80001730:	e0a2                	sd	s0,64(sp)
    80001732:	fc26                	sd	s1,56(sp)
    80001734:	f84a                	sd	s2,48(sp)
    80001736:	f44e                	sd	s3,40(sp)
    80001738:	f052                	sd	s4,32(sp)
    8000173a:	ec56                	sd	s5,24(sp)
    8000173c:	e85a                	sd	s6,16(sp)
    8000173e:	e45e                	sd	s7,8(sp)
    80001740:	e062                	sd	s8,0(sp)
    80001742:	0880                	addi	s0,sp,80
    80001744:	8b2a                	mv	s6,a0
    80001746:	8a2e                	mv	s4,a1
    80001748:	8c32                	mv	s8,a2
    8000174a:	89b6                	mv	s3,a3
    va0 = PGROUNDDOWN(srcva);
    8000174c:	7bfd                	lui	s7,0xfffff
    pa0 = walkaddr(pagetable, va0);
    if(pa0 == 0)
      return -1;
    n = PGSIZE - (srcva - va0);
    8000174e:	6a85                	lui	s5,0x1
    80001750:	a01d                	j	80001776 <copyin+0x4c>
    if(n > len)
      n = len;
    memmove(dst, (void *)(pa0 + (srcva - va0)), n);
    80001752:	018505b3          	add	a1,a0,s8
    80001756:	0004861b          	sext.w	a2,s1
    8000175a:	412585b3          	sub	a1,a1,s2
    8000175e:	8552                	mv	a0,s4
    80001760:	fffff097          	auipc	ra,0xfffff
    80001764:	5ce080e7          	jalr	1486(ra) # 80000d2e <memmove>

    len -= n;
    80001768:	409989b3          	sub	s3,s3,s1
    dst += n;
    8000176c:	9a26                	add	s4,s4,s1
    srcva = va0 + PGSIZE;
    8000176e:	01590c33          	add	s8,s2,s5
  while(len > 0){
    80001772:	02098263          	beqz	s3,80001796 <copyin+0x6c>
    va0 = PGROUNDDOWN(srcva);
    80001776:	017c7933          	and	s2,s8,s7
    pa0 = walkaddr(pagetable, va0);
    8000177a:	85ca                	mv	a1,s2
    8000177c:	855a                	mv	a0,s6
    8000177e:	00000097          	auipc	ra,0x0
    80001782:	8fe080e7          	jalr	-1794(ra) # 8000107c <walkaddr>
    if(pa0 == 0)
    80001786:	cd01                	beqz	a0,8000179e <copyin+0x74>
    n = PGSIZE - (srcva - va0);
    80001788:	418904b3          	sub	s1,s2,s8
    8000178c:	94d6                	add	s1,s1,s5
    if(n > len)
    8000178e:	fc99f2e3          	bgeu	s3,s1,80001752 <copyin+0x28>
    80001792:	84ce                	mv	s1,s3
    80001794:	bf7d                	j	80001752 <copyin+0x28>
  }
  return 0;
    80001796:	4501                	li	a0,0
    80001798:	a021                	j	800017a0 <copyin+0x76>
    8000179a:	4501                	li	a0,0
}
    8000179c:	8082                	ret
      return -1;
    8000179e:	557d                	li	a0,-1
}
    800017a0:	60a6                	ld	ra,72(sp)
    800017a2:	6406                	ld	s0,64(sp)
    800017a4:	74e2                	ld	s1,56(sp)
    800017a6:	7942                	ld	s2,48(sp)
    800017a8:	79a2                	ld	s3,40(sp)
    800017aa:	7a02                	ld	s4,32(sp)
    800017ac:	6ae2                	ld	s5,24(sp)
    800017ae:	6b42                	ld	s6,16(sp)
    800017b0:	6ba2                	ld	s7,8(sp)
    800017b2:	6c02                	ld	s8,0(sp)
    800017b4:	6161                	addi	sp,sp,80
    800017b6:	8082                	ret

00000000800017b8 <copyinstr>:
copyinstr(pagetable_t pagetable, char *dst, uint64 srcva, uint64 max)
{
  uint64 n, va0, pa0;
  int got_null = 0;

  while(got_null == 0 && max > 0){
    800017b8:	c6c5                	beqz	a3,80001860 <copyinstr+0xa8>
{
    800017ba:	715d                	addi	sp,sp,-80
    800017bc:	e486                	sd	ra,72(sp)
    800017be:	e0a2                	sd	s0,64(sp)
    800017c0:	fc26                	sd	s1,56(sp)
    800017c2:	f84a                	sd	s2,48(sp)
    800017c4:	f44e                	sd	s3,40(sp)
    800017c6:	f052                	sd	s4,32(sp)
    800017c8:	ec56                	sd	s5,24(sp)
    800017ca:	e85a                	sd	s6,16(sp)
    800017cc:	e45e                	sd	s7,8(sp)
    800017ce:	0880                	addi	s0,sp,80
    800017d0:	8a2a                	mv	s4,a0
    800017d2:	8b2e                	mv	s6,a1
    800017d4:	8bb2                	mv	s7,a2
    800017d6:	84b6                	mv	s1,a3
    va0 = PGROUNDDOWN(srcva);
    800017d8:	7afd                	lui	s5,0xfffff
    pa0 = walkaddr(pagetable, va0);
    if(pa0 == 0)
      return -1;
    n = PGSIZE - (srcva - va0);
    800017da:	6985                	lui	s3,0x1
    800017dc:	a035                	j	80001808 <copyinstr+0x50>
      n = max;

    char *p = (char *) (pa0 + (srcva - va0));
    while(n > 0){
      if(*p == '\0'){
        *dst = '\0';
    800017de:	00078023          	sb	zero,0(a5) # 1000 <_entry-0x7ffff000>
    800017e2:	4785                	li	a5,1
      dst++;
    }

    srcva = va0 + PGSIZE;
  }
  if(got_null){
    800017e4:	0017b793          	seqz	a5,a5
    800017e8:	40f00533          	neg	a0,a5
    return 0;
  } else {
    return -1;
  }
}
    800017ec:	60a6                	ld	ra,72(sp)
    800017ee:	6406                	ld	s0,64(sp)
    800017f0:	74e2                	ld	s1,56(sp)
    800017f2:	7942                	ld	s2,48(sp)
    800017f4:	79a2                	ld	s3,40(sp)
    800017f6:	7a02                	ld	s4,32(sp)
    800017f8:	6ae2                	ld	s5,24(sp)
    800017fa:	6b42                	ld	s6,16(sp)
    800017fc:	6ba2                	ld	s7,8(sp)
    800017fe:	6161                	addi	sp,sp,80
    80001800:	8082                	ret
    srcva = va0 + PGSIZE;
    80001802:	01390bb3          	add	s7,s2,s3
  while(got_null == 0 && max > 0){
    80001806:	c8a9                	beqz	s1,80001858 <copyinstr+0xa0>
    va0 = PGROUNDDOWN(srcva);
    80001808:	015bf933          	and	s2,s7,s5
    pa0 = walkaddr(pagetable, va0);
    8000180c:	85ca                	mv	a1,s2
    8000180e:	8552                	mv	a0,s4
    80001810:	00000097          	auipc	ra,0x0
    80001814:	86c080e7          	jalr	-1940(ra) # 8000107c <walkaddr>
    if(pa0 == 0)
    80001818:	c131                	beqz	a0,8000185c <copyinstr+0xa4>
    n = PGSIZE - (srcva - va0);
    8000181a:	41790833          	sub	a6,s2,s7
    8000181e:	984e                	add	a6,a6,s3
    if(n > max)
    80001820:	0104f363          	bgeu	s1,a6,80001826 <copyinstr+0x6e>
    80001824:	8826                	mv	a6,s1
    char *p = (char *) (pa0 + (srcva - va0));
    80001826:	955e                	add	a0,a0,s7
    80001828:	41250533          	sub	a0,a0,s2
    while(n > 0){
    8000182c:	fc080be3          	beqz	a6,80001802 <copyinstr+0x4a>
    80001830:	985a                	add	a6,a6,s6
    80001832:	87da                	mv	a5,s6
      if(*p == '\0'){
    80001834:	41650633          	sub	a2,a0,s6
    80001838:	14fd                	addi	s1,s1,-1
    8000183a:	9b26                	add	s6,s6,s1
    8000183c:	00f60733          	add	a4,a2,a5
    80001840:	00074703          	lbu	a4,0(a4)
    80001844:	df49                	beqz	a4,800017de <copyinstr+0x26>
        *dst = *p;
    80001846:	00e78023          	sb	a4,0(a5)
      --max;
    8000184a:	40fb04b3          	sub	s1,s6,a5
      dst++;
    8000184e:	0785                	addi	a5,a5,1
    while(n > 0){
    80001850:	ff0796e3          	bne	a5,a6,8000183c <copyinstr+0x84>
      dst++;
    80001854:	8b42                	mv	s6,a6
    80001856:	b775                	j	80001802 <copyinstr+0x4a>
    80001858:	4781                	li	a5,0
    8000185a:	b769                	j	800017e4 <copyinstr+0x2c>
      return -1;
    8000185c:	557d                	li	a0,-1
    8000185e:	b779                	j	800017ec <copyinstr+0x34>
  int got_null = 0;
    80001860:	4781                	li	a5,0
  if(got_null){
    80001862:	0017b793          	seqz	a5,a5
    80001866:	40f00533          	neg	a0,a5
}
    8000186a:	8082                	ret

000000008000186c <proc_mapstacks>:
// Allocate a page for each process's kernel stack.
// Map it high in memory, followed by an invalid
// guard page.
void
proc_mapstacks(pagetable_t kpgtbl)
{
    8000186c:	7139                	addi	sp,sp,-64
    8000186e:	fc06                	sd	ra,56(sp)
    80001870:	f822                	sd	s0,48(sp)
    80001872:	f426                	sd	s1,40(sp)
    80001874:	f04a                	sd	s2,32(sp)
    80001876:	ec4e                	sd	s3,24(sp)
    80001878:	e852                	sd	s4,16(sp)
    8000187a:	e456                	sd	s5,8(sp)
    8000187c:	e05a                	sd	s6,0(sp)
    8000187e:	0080                	addi	s0,sp,64
    80001880:	89aa                	mv	s3,a0
  struct proc *p;
  
  for(p = proc; p < &proc[NPROC]; p++) {
    80001882:	00010497          	auipc	s1,0x10
    80001886:	07e48493          	addi	s1,s1,126 # 80011900 <proc>
    char *pa = kalloc();
    if(pa == 0)
      panic("kalloc");
    uint64 va = KSTACK((int) (p - proc));
    8000188a:	8b26                	mv	s6,s1
    8000188c:	00006a97          	auipc	s5,0x6
    80001890:	774a8a93          	addi	s5,s5,1908 # 80008000 <etext>
    80001894:	04000937          	lui	s2,0x4000
    80001898:	197d                	addi	s2,s2,-1
    8000189a:	0932                	slli	s2,s2,0xc
  for(p = proc; p < &proc[NPROC]; p++) {
    8000189c:	00016a17          	auipc	s4,0x16
    800018a0:	c64a0a13          	addi	s4,s4,-924 # 80017500 <tickslock>
    char *pa = kalloc();
    800018a4:	fffff097          	auipc	ra,0xfffff
    800018a8:	242080e7          	jalr	578(ra) # 80000ae6 <kalloc>
    800018ac:	862a                	mv	a2,a0
    if(pa == 0)
    800018ae:	c131                	beqz	a0,800018f2 <proc_mapstacks+0x86>
    uint64 va = KSTACK((int) (p - proc));
    800018b0:	416485b3          	sub	a1,s1,s6
    800018b4:	8591                	srai	a1,a1,0x4
    800018b6:	000ab783          	ld	a5,0(s5)
    800018ba:	02f585b3          	mul	a1,a1,a5
    800018be:	2585                	addiw	a1,a1,1
    800018c0:	00d5959b          	slliw	a1,a1,0xd
    kvmmap(kpgtbl, va, (uint64)pa, PGSIZE, PTE_R | PTE_W);
    800018c4:	4719                	li	a4,6
    800018c6:	6685                	lui	a3,0x1
    800018c8:	40b905b3          	sub	a1,s2,a1
    800018cc:	854e                	mv	a0,s3
    800018ce:	00000097          	auipc	ra,0x0
    800018d2:	890080e7          	jalr	-1904(ra) # 8000115e <kvmmap>
  for(p = proc; p < &proc[NPROC]; p++) {
    800018d6:	17048493          	addi	s1,s1,368
    800018da:	fd4495e3          	bne	s1,s4,800018a4 <proc_mapstacks+0x38>
  }
}
    800018de:	70e2                	ld	ra,56(sp)
    800018e0:	7442                	ld	s0,48(sp)
    800018e2:	74a2                	ld	s1,40(sp)
    800018e4:	7902                	ld	s2,32(sp)
    800018e6:	69e2                	ld	s3,24(sp)
    800018e8:	6a42                	ld	s4,16(sp)
    800018ea:	6aa2                	ld	s5,8(sp)
    800018ec:	6b02                	ld	s6,0(sp)
    800018ee:	6121                	addi	sp,sp,64
    800018f0:	8082                	ret
      panic("kalloc");
    800018f2:	00007517          	auipc	a0,0x7
    800018f6:	8f650513          	addi	a0,a0,-1802 # 800081e8 <digits+0x1a8>
    800018fa:	fffff097          	auipc	ra,0xfffff
    800018fe:	c44080e7          	jalr	-956(ra) # 8000053e <panic>

0000000080001902 <procinit>:

// initialize the proc table.
void
procinit(void)
{
    80001902:	7139                	addi	sp,sp,-64
    80001904:	fc06                	sd	ra,56(sp)
    80001906:	f822                	sd	s0,48(sp)
    80001908:	f426                	sd	s1,40(sp)
    8000190a:	f04a                	sd	s2,32(sp)
    8000190c:	ec4e                	sd	s3,24(sp)
    8000190e:	e852                	sd	s4,16(sp)
    80001910:	e456                	sd	s5,8(sp)
    80001912:	e05a                	sd	s6,0(sp)
    80001914:	0080                	addi	s0,sp,64
  struct proc *p;
  
  initlock(&pid_lock, "nextpid");
    80001916:	00007597          	auipc	a1,0x7
    8000191a:	8da58593          	addi	a1,a1,-1830 # 800081f0 <digits+0x1b0>
    8000191e:	00010517          	auipc	a0,0x10
    80001922:	bb250513          	addi	a0,a0,-1102 # 800114d0 <pid_lock>
    80001926:	fffff097          	auipc	ra,0xfffff
    8000192a:	220080e7          	jalr	544(ra) # 80000b46 <initlock>
  initlock(&wait_lock, "wait_lock");
    8000192e:	00007597          	auipc	a1,0x7
    80001932:	8ca58593          	addi	a1,a1,-1846 # 800081f8 <digits+0x1b8>
    80001936:	00010517          	auipc	a0,0x10
    8000193a:	bb250513          	addi	a0,a0,-1102 # 800114e8 <wait_lock>
    8000193e:	fffff097          	auipc	ra,0xfffff
    80001942:	208080e7          	jalr	520(ra) # 80000b46 <initlock>
  for(p = proc; p < &proc[NPROC]; p++) {
    80001946:	00010497          	auipc	s1,0x10
    8000194a:	fba48493          	addi	s1,s1,-70 # 80011900 <proc>
      initlock(&p->lock, "proc");
    8000194e:	00007b17          	auipc	s6,0x7
    80001952:	8bab0b13          	addi	s6,s6,-1862 # 80008208 <digits+0x1c8>
      p->state = UNUSED;
      p->kstack = KSTACK((int) (p - proc));
    80001956:	8aa6                	mv	s5,s1
    80001958:	00006a17          	auipc	s4,0x6
    8000195c:	6a8a0a13          	addi	s4,s4,1704 # 80008000 <etext>
    80001960:	04000937          	lui	s2,0x4000
    80001964:	197d                	addi	s2,s2,-1
    80001966:	0932                	slli	s2,s2,0xc
  for(p = proc; p < &proc[NPROC]; p++) {
    80001968:	00016997          	auipc	s3,0x16
    8000196c:	b9898993          	addi	s3,s3,-1128 # 80017500 <tickslock>
      initlock(&p->lock, "proc");
    80001970:	85da                	mv	a1,s6
    80001972:	8526                	mv	a0,s1
    80001974:	fffff097          	auipc	ra,0xfffff
    80001978:	1d2080e7          	jalr	466(ra) # 80000b46 <initlock>
      p->state = UNUSED;
    8000197c:	0004ac23          	sw	zero,24(s1)
      p->kstack = KSTACK((int) (p - proc));
    80001980:	415487b3          	sub	a5,s1,s5
    80001984:	8791                	srai	a5,a5,0x4
    80001986:	000a3703          	ld	a4,0(s4)
    8000198a:	02e787b3          	mul	a5,a5,a4
    8000198e:	2785                	addiw	a5,a5,1
    80001990:	00d7979b          	slliw	a5,a5,0xd
    80001994:	40f907b3          	sub	a5,s2,a5
    80001998:	e0bc                	sd	a5,64(s1)
  for(p = proc; p < &proc[NPROC]; p++) {
    8000199a:	17048493          	addi	s1,s1,368
    8000199e:	fd3499e3          	bne	s1,s3,80001970 <procinit+0x6e>
  }
}
    800019a2:	70e2                	ld	ra,56(sp)
    800019a4:	7442                	ld	s0,48(sp)
    800019a6:	74a2                	ld	s1,40(sp)
    800019a8:	7902                	ld	s2,32(sp)
    800019aa:	69e2                	ld	s3,24(sp)
    800019ac:	6a42                	ld	s4,16(sp)
    800019ae:	6aa2                	ld	s5,8(sp)
    800019b0:	6b02                	ld	s6,0(sp)
    800019b2:	6121                	addi	sp,sp,64
    800019b4:	8082                	ret

00000000800019b6 <cpuid>:
// Must be called with interrupts disabled,
// to prevent race with process being moved
// to a different CPU.
int
cpuid()
{
    800019b6:	1141                	addi	sp,sp,-16
    800019b8:	e422                	sd	s0,8(sp)
    800019ba:	0800                	addi	s0,sp,16
  asm volatile("mv %0, tp" : "=r" (x) );
    800019bc:	8512                	mv	a0,tp
  int id = r_tp();
  return id;
}
    800019be:	2501                	sext.w	a0,a0
    800019c0:	6422                	ld	s0,8(sp)
    800019c2:	0141                	addi	sp,sp,16
    800019c4:	8082                	ret

00000000800019c6 <mycpu>:

// Return this CPU's cpu struct.
// Interrupts must be disabled.
struct cpu*
mycpu(void)
{
    800019c6:	1141                	addi	sp,sp,-16
    800019c8:	e422                	sd	s0,8(sp)
    800019ca:	0800                	addi	s0,sp,16
    800019cc:	8792                	mv	a5,tp
  int id = cpuid();
  struct cpu *c = &cpus[id];
    800019ce:	2781                	sext.w	a5,a5
    800019d0:	079e                	slli	a5,a5,0x7
  return c;
}
    800019d2:	00010517          	auipc	a0,0x10
    800019d6:	b2e50513          	addi	a0,a0,-1234 # 80011500 <cpus>
    800019da:	953e                	add	a0,a0,a5
    800019dc:	6422                	ld	s0,8(sp)
    800019de:	0141                	addi	sp,sp,16
    800019e0:	8082                	ret

00000000800019e2 <myproc>:

// Return the current struct proc *, or zero if none.
struct proc*
myproc(void)
{
    800019e2:	1101                	addi	sp,sp,-32
    800019e4:	ec06                	sd	ra,24(sp)
    800019e6:	e822                	sd	s0,16(sp)
    800019e8:	e426                	sd	s1,8(sp)
    800019ea:	1000                	addi	s0,sp,32
  push_off();
    800019ec:	fffff097          	auipc	ra,0xfffff
    800019f0:	19e080e7          	jalr	414(ra) # 80000b8a <push_off>
    800019f4:	8792                	mv	a5,tp
  struct cpu *c = mycpu();
  struct proc *p = c->proc;
    800019f6:	2781                	sext.w	a5,a5
    800019f8:	079e                	slli	a5,a5,0x7
    800019fa:	00010717          	auipc	a4,0x10
    800019fe:	ad670713          	addi	a4,a4,-1322 # 800114d0 <pid_lock>
    80001a02:	97ba                	add	a5,a5,a4
    80001a04:	7b84                	ld	s1,48(a5)
  pop_off();
    80001a06:	fffff097          	auipc	ra,0xfffff
    80001a0a:	224080e7          	jalr	548(ra) # 80000c2a <pop_off>
  return p;
}
    80001a0e:	8526                	mv	a0,s1
    80001a10:	60e2                	ld	ra,24(sp)
    80001a12:	6442                	ld	s0,16(sp)
    80001a14:	64a2                	ld	s1,8(sp)
    80001a16:	6105                	addi	sp,sp,32
    80001a18:	8082                	ret

0000000080001a1a <forkret>:

// A fork child's very first scheduling by scheduler()
// will swtch to forkret.
void
forkret(void)
{
    80001a1a:	1141                	addi	sp,sp,-16
    80001a1c:	e406                	sd	ra,8(sp)
    80001a1e:	e022                	sd	s0,0(sp)
    80001a20:	0800                	addi	s0,sp,16
  static int first = 1;

  // Still holding p->lock from scheduler.
  release(&myproc()->lock);
    80001a22:	00000097          	auipc	ra,0x0
    80001a26:	fc0080e7          	jalr	-64(ra) # 800019e2 <myproc>
    80001a2a:	fffff097          	auipc	ra,0xfffff
    80001a2e:	260080e7          	jalr	608(ra) # 80000c8a <release>

  if (first) {
    80001a32:	00007797          	auipc	a5,0x7
    80001a36:	78e7a783          	lw	a5,1934(a5) # 800091c0 <first.1>
    80001a3a:	eb89                	bnez	a5,80001a4c <forkret+0x32>
    // be run from main().
    first = 0;
    fsinit(ROOTDEV);
  }

  usertrapret();
    80001a3c:	00001097          	auipc	ra,0x1
    80001a40:	ce4080e7          	jalr	-796(ra) # 80002720 <usertrapret>
}
    80001a44:	60a2                	ld	ra,8(sp)
    80001a46:	6402                	ld	s0,0(sp)
    80001a48:	0141                	addi	sp,sp,16
    80001a4a:	8082                	ret
    first = 0;
    80001a4c:	00007797          	auipc	a5,0x7
    80001a50:	7607aa23          	sw	zero,1908(a5) # 800091c0 <first.1>
    fsinit(ROOTDEV);
    80001a54:	4505                	li	a0,1
    80001a56:	00002097          	auipc	ra,0x2
    80001a5a:	ad0080e7          	jalr	-1328(ra) # 80003526 <fsinit>
    80001a5e:	bff9                	j	80001a3c <forkret+0x22>

0000000080001a60 <allocpid>:
{
    80001a60:	1101                	addi	sp,sp,-32
    80001a62:	ec06                	sd	ra,24(sp)
    80001a64:	e822                	sd	s0,16(sp)
    80001a66:	e426                	sd	s1,8(sp)
    80001a68:	e04a                	sd	s2,0(sp)
    80001a6a:	1000                	addi	s0,sp,32
  acquire(&pid_lock);
    80001a6c:	00010917          	auipc	s2,0x10
    80001a70:	a6490913          	addi	s2,s2,-1436 # 800114d0 <pid_lock>
    80001a74:	854a                	mv	a0,s2
    80001a76:	fffff097          	auipc	ra,0xfffff
    80001a7a:	160080e7          	jalr	352(ra) # 80000bd6 <acquire>
  pid = nextpid;
    80001a7e:	00007797          	auipc	a5,0x7
    80001a82:	74678793          	addi	a5,a5,1862 # 800091c4 <nextpid>
    80001a86:	4384                	lw	s1,0(a5)
  nextpid = nextpid + 1;
    80001a88:	0014871b          	addiw	a4,s1,1
    80001a8c:	c398                	sw	a4,0(a5)
  release(&pid_lock);
    80001a8e:	854a                	mv	a0,s2
    80001a90:	fffff097          	auipc	ra,0xfffff
    80001a94:	1fa080e7          	jalr	506(ra) # 80000c8a <release>
}
    80001a98:	8526                	mv	a0,s1
    80001a9a:	60e2                	ld	ra,24(sp)
    80001a9c:	6442                	ld	s0,16(sp)
    80001a9e:	64a2                	ld	s1,8(sp)
    80001aa0:	6902                	ld	s2,0(sp)
    80001aa2:	6105                	addi	sp,sp,32
    80001aa4:	8082                	ret

0000000080001aa6 <proc_pagetable>:
{
    80001aa6:	1101                	addi	sp,sp,-32
    80001aa8:	ec06                	sd	ra,24(sp)
    80001aaa:	e822                	sd	s0,16(sp)
    80001aac:	e426                	sd	s1,8(sp)
    80001aae:	e04a                	sd	s2,0(sp)
    80001ab0:	1000                	addi	s0,sp,32
    80001ab2:	892a                	mv	s2,a0
  pagetable = uvmcreate();
    80001ab4:	00000097          	auipc	ra,0x0
    80001ab8:	8aa080e7          	jalr	-1878(ra) # 8000135e <uvmcreate>
    80001abc:	84aa                	mv	s1,a0
  if(pagetable == 0)
    80001abe:	c121                	beqz	a0,80001afe <proc_pagetable+0x58>
  if(mappages(pagetable, TRAMPOLINE, PGSIZE,
    80001ac0:	4729                	li	a4,10
    80001ac2:	00005697          	auipc	a3,0x5
    80001ac6:	53e68693          	addi	a3,a3,1342 # 80007000 <_trampoline>
    80001aca:	6605                	lui	a2,0x1
    80001acc:	040005b7          	lui	a1,0x4000
    80001ad0:	15fd                	addi	a1,a1,-1
    80001ad2:	05b2                	slli	a1,a1,0xc
    80001ad4:	fffff097          	auipc	ra,0xfffff
    80001ad8:	5ea080e7          	jalr	1514(ra) # 800010be <mappages>
    80001adc:	02054863          	bltz	a0,80001b0c <proc_pagetable+0x66>
  if(mappages(pagetable, TRAPFRAME, PGSIZE,
    80001ae0:	4719                	li	a4,6
    80001ae2:	05893683          	ld	a3,88(s2)
    80001ae6:	6605                	lui	a2,0x1
    80001ae8:	020005b7          	lui	a1,0x2000
    80001aec:	15fd                	addi	a1,a1,-1
    80001aee:	05b6                	slli	a1,a1,0xd
    80001af0:	8526                	mv	a0,s1
    80001af2:	fffff097          	auipc	ra,0xfffff
    80001af6:	5cc080e7          	jalr	1484(ra) # 800010be <mappages>
    80001afa:	02054163          	bltz	a0,80001b1c <proc_pagetable+0x76>
}
    80001afe:	8526                	mv	a0,s1
    80001b00:	60e2                	ld	ra,24(sp)
    80001b02:	6442                	ld	s0,16(sp)
    80001b04:	64a2                	ld	s1,8(sp)
    80001b06:	6902                	ld	s2,0(sp)
    80001b08:	6105                	addi	sp,sp,32
    80001b0a:	8082                	ret
    uvmfree(pagetable, 0);
    80001b0c:	4581                	li	a1,0
    80001b0e:	8526                	mv	a0,s1
    80001b10:	00000097          	auipc	ra,0x0
    80001b14:	a52080e7          	jalr	-1454(ra) # 80001562 <uvmfree>
    return 0;
    80001b18:	4481                	li	s1,0
    80001b1a:	b7d5                	j	80001afe <proc_pagetable+0x58>
    uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    80001b1c:	4681                	li	a3,0
    80001b1e:	4605                	li	a2,1
    80001b20:	040005b7          	lui	a1,0x4000
    80001b24:	15fd                	addi	a1,a1,-1
    80001b26:	05b2                	slli	a1,a1,0xc
    80001b28:	8526                	mv	a0,s1
    80001b2a:	fffff097          	auipc	ra,0xfffff
    80001b2e:	770080e7          	jalr	1904(ra) # 8000129a <uvmunmap>
    uvmfree(pagetable, 0);
    80001b32:	4581                	li	a1,0
    80001b34:	8526                	mv	a0,s1
    80001b36:	00000097          	auipc	ra,0x0
    80001b3a:	a2c080e7          	jalr	-1492(ra) # 80001562 <uvmfree>
    return 0;
    80001b3e:	4481                	li	s1,0
    80001b40:	bf7d                	j	80001afe <proc_pagetable+0x58>

0000000080001b42 <proc_freepagetable>:
{
    80001b42:	1101                	addi	sp,sp,-32
    80001b44:	ec06                	sd	ra,24(sp)
    80001b46:	e822                	sd	s0,16(sp)
    80001b48:	e426                	sd	s1,8(sp)
    80001b4a:	e04a                	sd	s2,0(sp)
    80001b4c:	1000                	addi	s0,sp,32
    80001b4e:	84aa                	mv	s1,a0
    80001b50:	892e                	mv	s2,a1
  uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    80001b52:	4681                	li	a3,0
    80001b54:	4605                	li	a2,1
    80001b56:	040005b7          	lui	a1,0x4000
    80001b5a:	15fd                	addi	a1,a1,-1
    80001b5c:	05b2                	slli	a1,a1,0xc
    80001b5e:	fffff097          	auipc	ra,0xfffff
    80001b62:	73c080e7          	jalr	1852(ra) # 8000129a <uvmunmap>
  uvmunmap(pagetable, TRAPFRAME, 1, 0);
    80001b66:	4681                	li	a3,0
    80001b68:	4605                	li	a2,1
    80001b6a:	020005b7          	lui	a1,0x2000
    80001b6e:	15fd                	addi	a1,a1,-1
    80001b70:	05b6                	slli	a1,a1,0xd
    80001b72:	8526                	mv	a0,s1
    80001b74:	fffff097          	auipc	ra,0xfffff
    80001b78:	726080e7          	jalr	1830(ra) # 8000129a <uvmunmap>
  uvmfree(pagetable, sz);
    80001b7c:	85ca                	mv	a1,s2
    80001b7e:	8526                	mv	a0,s1
    80001b80:	00000097          	auipc	ra,0x0
    80001b84:	9e2080e7          	jalr	-1566(ra) # 80001562 <uvmfree>
}
    80001b88:	60e2                	ld	ra,24(sp)
    80001b8a:	6442                	ld	s0,16(sp)
    80001b8c:	64a2                	ld	s1,8(sp)
    80001b8e:	6902                	ld	s2,0(sp)
    80001b90:	6105                	addi	sp,sp,32
    80001b92:	8082                	ret

0000000080001b94 <freeproc>:
{
    80001b94:	1101                	addi	sp,sp,-32
    80001b96:	ec06                	sd	ra,24(sp)
    80001b98:	e822                	sd	s0,16(sp)
    80001b9a:	e426                	sd	s1,8(sp)
    80001b9c:	1000                	addi	s0,sp,32
    80001b9e:	84aa                	mv	s1,a0
  if(p->trapframe)
    80001ba0:	6d28                	ld	a0,88(a0)
    80001ba2:	c509                	beqz	a0,80001bac <freeproc+0x18>
    kfree((void*)p->trapframe);
    80001ba4:	fffff097          	auipc	ra,0xfffff
    80001ba8:	e46080e7          	jalr	-442(ra) # 800009ea <kfree>
  p->trapframe = 0;
    80001bac:	0404bc23          	sd	zero,88(s1)
  if(p->fb_va != 0 && p->pagetable){
    80001bb0:	1684b583          	ld	a1,360(s1)
    80001bb4:	c989                	beqz	a1,80001bc6 <freeproc+0x32>
    80001bb6:	68a8                	ld	a0,80(s1)
    80001bb8:	c50d                	beqz	a0,80001be2 <freeproc+0x4e>
    virtio_gpu_unmap_user(p->pagetable, p->fb_va);
    80001bba:	00005097          	auipc	ra,0x5
    80001bbe:	fee080e7          	jalr	-18(ra) # 80006ba8 <virtio_gpu_unmap_user>
    p->fb_va = 0;
    80001bc2:	1604b423          	sd	zero,360(s1)
  if(p->pagetable)
    80001bc6:	68bc                	ld	a5,80(s1)
    80001bc8:	cf89                	beqz	a5,80001be2 <freeproc+0x4e>
    virtio_gpu_release(p);
    80001bca:	8526                	mv	a0,s1
    80001bcc:	00005097          	auipc	ra,0x5
    80001bd0:	0ca080e7          	jalr	202(ra) # 80006c96 <virtio_gpu_release>
  if(p->pagetable)
    80001bd4:	68a8                	ld	a0,80(s1)
    80001bd6:	c511                	beqz	a0,80001be2 <freeproc+0x4e>
    proc_freepagetable(p->pagetable, p->sz);
    80001bd8:	64ac                	ld	a1,72(s1)
    80001bda:	00000097          	auipc	ra,0x0
    80001bde:	f68080e7          	jalr	-152(ra) # 80001b42 <proc_freepagetable>
  p->pagetable = 0;
    80001be2:	0404b823          	sd	zero,80(s1)
  p->sz = 0;
    80001be6:	0404b423          	sd	zero,72(s1)
  p->pid = 0;
    80001bea:	0204a823          	sw	zero,48(s1)
  p->parent = 0;
    80001bee:	0204bc23          	sd	zero,56(s1)
  p->name[0] = 0;
    80001bf2:	14048c23          	sb	zero,344(s1)
  p->chan = 0;
    80001bf6:	0204b023          	sd	zero,32(s1)
  p->killed = 0;
    80001bfa:	0204a423          	sw	zero,40(s1)
  p->xstate = 0;
    80001bfe:	0204a623          	sw	zero,44(s1)
  p->state = UNUSED;
    80001c02:	0004ac23          	sw	zero,24(s1)
}
    80001c06:	60e2                	ld	ra,24(sp)
    80001c08:	6442                	ld	s0,16(sp)
    80001c0a:	64a2                	ld	s1,8(sp)
    80001c0c:	6105                	addi	sp,sp,32
    80001c0e:	8082                	ret

0000000080001c10 <allocproc>:
{
    80001c10:	1101                	addi	sp,sp,-32
    80001c12:	ec06                	sd	ra,24(sp)
    80001c14:	e822                	sd	s0,16(sp)
    80001c16:	e426                	sd	s1,8(sp)
    80001c18:	e04a                	sd	s2,0(sp)
    80001c1a:	1000                	addi	s0,sp,32
  for(p = proc; p < &proc[NPROC]; p++) {
    80001c1c:	00010497          	auipc	s1,0x10
    80001c20:	ce448493          	addi	s1,s1,-796 # 80011900 <proc>
    80001c24:	00016917          	auipc	s2,0x16
    80001c28:	8dc90913          	addi	s2,s2,-1828 # 80017500 <tickslock>
    acquire(&p->lock);
    80001c2c:	8526                	mv	a0,s1
    80001c2e:	fffff097          	auipc	ra,0xfffff
    80001c32:	fa8080e7          	jalr	-88(ra) # 80000bd6 <acquire>
    if(p->state == UNUSED) {
    80001c36:	4c9c                	lw	a5,24(s1)
    80001c38:	cf81                	beqz	a5,80001c50 <allocproc+0x40>
      release(&p->lock);
    80001c3a:	8526                	mv	a0,s1
    80001c3c:	fffff097          	auipc	ra,0xfffff
    80001c40:	04e080e7          	jalr	78(ra) # 80000c8a <release>
  for(p = proc; p < &proc[NPROC]; p++) {
    80001c44:	17048493          	addi	s1,s1,368
    80001c48:	ff2492e3          	bne	s1,s2,80001c2c <allocproc+0x1c>
  return 0;
    80001c4c:	4481                	li	s1,0
    80001c4e:	a889                	j	80001ca0 <allocproc+0x90>
  p->pid = allocpid();
    80001c50:	00000097          	auipc	ra,0x0
    80001c54:	e10080e7          	jalr	-496(ra) # 80001a60 <allocpid>
    80001c58:	d888                	sw	a0,48(s1)
  p->state = USED;
    80001c5a:	4785                	li	a5,1
    80001c5c:	cc9c                	sw	a5,24(s1)
  if((p->trapframe = (struct trapframe *)kalloc()) == 0){
    80001c5e:	fffff097          	auipc	ra,0xfffff
    80001c62:	e88080e7          	jalr	-376(ra) # 80000ae6 <kalloc>
    80001c66:	892a                	mv	s2,a0
    80001c68:	eca8                	sd	a0,88(s1)
    80001c6a:	c131                	beqz	a0,80001cae <allocproc+0x9e>
  p->pagetable = proc_pagetable(p);
    80001c6c:	8526                	mv	a0,s1
    80001c6e:	00000097          	auipc	ra,0x0
    80001c72:	e38080e7          	jalr	-456(ra) # 80001aa6 <proc_pagetable>
    80001c76:	892a                	mv	s2,a0
    80001c78:	e8a8                	sd	a0,80(s1)
  if(p->pagetable == 0){
    80001c7a:	c531                	beqz	a0,80001cc6 <allocproc+0xb6>
  memset(&p->context, 0, sizeof(p->context));
    80001c7c:	07000613          	li	a2,112
    80001c80:	4581                	li	a1,0
    80001c82:	06048513          	addi	a0,s1,96
    80001c86:	fffff097          	auipc	ra,0xfffff
    80001c8a:	04c080e7          	jalr	76(ra) # 80000cd2 <memset>
  p->context.ra = (uint64)forkret;
    80001c8e:	00000797          	auipc	a5,0x0
    80001c92:	d8c78793          	addi	a5,a5,-628 # 80001a1a <forkret>
    80001c96:	f0bc                	sd	a5,96(s1)
  p->context.sp = p->kstack + PGSIZE;
    80001c98:	60bc                	ld	a5,64(s1)
    80001c9a:	6705                	lui	a4,0x1
    80001c9c:	97ba                	add	a5,a5,a4
    80001c9e:	f4bc                	sd	a5,104(s1)
}
    80001ca0:	8526                	mv	a0,s1
    80001ca2:	60e2                	ld	ra,24(sp)
    80001ca4:	6442                	ld	s0,16(sp)
    80001ca6:	64a2                	ld	s1,8(sp)
    80001ca8:	6902                	ld	s2,0(sp)
    80001caa:	6105                	addi	sp,sp,32
    80001cac:	8082                	ret
    freeproc(p);
    80001cae:	8526                	mv	a0,s1
    80001cb0:	00000097          	auipc	ra,0x0
    80001cb4:	ee4080e7          	jalr	-284(ra) # 80001b94 <freeproc>
    release(&p->lock);
    80001cb8:	8526                	mv	a0,s1
    80001cba:	fffff097          	auipc	ra,0xfffff
    80001cbe:	fd0080e7          	jalr	-48(ra) # 80000c8a <release>
    return 0;
    80001cc2:	84ca                	mv	s1,s2
    80001cc4:	bff1                	j	80001ca0 <allocproc+0x90>
    freeproc(p);
    80001cc6:	8526                	mv	a0,s1
    80001cc8:	00000097          	auipc	ra,0x0
    80001ccc:	ecc080e7          	jalr	-308(ra) # 80001b94 <freeproc>
    release(&p->lock);
    80001cd0:	8526                	mv	a0,s1
    80001cd2:	fffff097          	auipc	ra,0xfffff
    80001cd6:	fb8080e7          	jalr	-72(ra) # 80000c8a <release>
    return 0;
    80001cda:	84ca                	mv	s1,s2
    80001cdc:	b7d1                	j	80001ca0 <allocproc+0x90>

0000000080001cde <userinit>:
{
    80001cde:	1101                	addi	sp,sp,-32
    80001ce0:	ec06                	sd	ra,24(sp)
    80001ce2:	e822                	sd	s0,16(sp)
    80001ce4:	e426                	sd	s1,8(sp)
    80001ce6:	1000                	addi	s0,sp,32
  p = allocproc();
    80001ce8:	00000097          	auipc	ra,0x0
    80001cec:	f28080e7          	jalr	-216(ra) # 80001c10 <allocproc>
    80001cf0:	84aa                	mv	s1,a0
  initproc = p;
    80001cf2:	00007797          	auipc	a5,0x7
    80001cf6:	56a7b323          	sd	a0,1382(a5) # 80009258 <initproc>
  uvmfirst(p->pagetable, initcode, sizeof(initcode));
    80001cfa:	03400613          	li	a2,52
    80001cfe:	00007597          	auipc	a1,0x7
    80001d02:	4d258593          	addi	a1,a1,1234 # 800091d0 <initcode>
    80001d06:	6928                	ld	a0,80(a0)
    80001d08:	fffff097          	auipc	ra,0xfffff
    80001d0c:	684080e7          	jalr	1668(ra) # 8000138c <uvmfirst>
  p->sz = PGSIZE;
    80001d10:	6785                	lui	a5,0x1
    80001d12:	e4bc                	sd	a5,72(s1)
  p->trapframe->epc = 0;      // user program counter
    80001d14:	6cb8                	ld	a4,88(s1)
    80001d16:	00073c23          	sd	zero,24(a4) # 1018 <_entry-0x7fffefe8>
  p->trapframe->sp = PGSIZE;  // user stack pointer
    80001d1a:	6cb8                	ld	a4,88(s1)
    80001d1c:	fb1c                	sd	a5,48(a4)
  safestrcpy(p->name, "initcode", sizeof(p->name));
    80001d1e:	4641                	li	a2,16
    80001d20:	00006597          	auipc	a1,0x6
    80001d24:	4f058593          	addi	a1,a1,1264 # 80008210 <digits+0x1d0>
    80001d28:	15848513          	addi	a0,s1,344
    80001d2c:	fffff097          	auipc	ra,0xfffff
    80001d30:	0f0080e7          	jalr	240(ra) # 80000e1c <safestrcpy>
  p->cwd = namei("/");
    80001d34:	00006517          	auipc	a0,0x6
    80001d38:	4ec50513          	addi	a0,a0,1260 # 80008220 <digits+0x1e0>
    80001d3c:	00002097          	auipc	ra,0x2
    80001d40:	20c080e7          	jalr	524(ra) # 80003f48 <namei>
    80001d44:	14a4b823          	sd	a0,336(s1)
  p->state = RUNNABLE;
    80001d48:	478d                	li	a5,3
    80001d4a:	cc9c                	sw	a5,24(s1)
  release(&p->lock);
    80001d4c:	8526                	mv	a0,s1
    80001d4e:	fffff097          	auipc	ra,0xfffff
    80001d52:	f3c080e7          	jalr	-196(ra) # 80000c8a <release>
}
    80001d56:	60e2                	ld	ra,24(sp)
    80001d58:	6442                	ld	s0,16(sp)
    80001d5a:	64a2                	ld	s1,8(sp)
    80001d5c:	6105                	addi	sp,sp,32
    80001d5e:	8082                	ret

0000000080001d60 <kproc_create>:
{
    80001d60:	7179                	addi	sp,sp,-48
    80001d62:	f406                	sd	ra,40(sp)
    80001d64:	f022                	sd	s0,32(sp)
    80001d66:	ec26                	sd	s1,24(sp)
    80001d68:	e84a                	sd	s2,16(sp)
    80001d6a:	e44e                	sd	s3,8(sp)
    80001d6c:	1800                	addi	s0,sp,48
    80001d6e:	89aa                	mv	s3,a0
    80001d70:	892e                	mv	s2,a1
  struct proc *p = allocproc();
    80001d72:	00000097          	auipc	ra,0x0
    80001d76:	e9e080e7          	jalr	-354(ra) # 80001c10 <allocproc>
  if(p == 0)
    80001d7a:	cd15                	beqz	a0,80001db6 <kproc_create+0x56>
    80001d7c:	84aa                	mv	s1,a0
  p->context.ra = (uint64)fn;
    80001d7e:	07353023          	sd	s3,96(a0)
  p->context.sp = p->kstack + PGSIZE;
    80001d82:	613c                	ld	a5,64(a0)
    80001d84:	6705                	lui	a4,0x1
    80001d86:	97ba                	add	a5,a5,a4
    80001d88:	f53c                	sd	a5,104(a0)
  safestrcpy(p->name, name, sizeof(p->name));
    80001d8a:	4641                	li	a2,16
    80001d8c:	85ca                	mv	a1,s2
    80001d8e:	15850513          	addi	a0,a0,344
    80001d92:	fffff097          	auipc	ra,0xfffff
    80001d96:	08a080e7          	jalr	138(ra) # 80000e1c <safestrcpy>
  p->state = RUNNABLE;
    80001d9a:	478d                	li	a5,3
    80001d9c:	cc9c                	sw	a5,24(s1)
  release(&p->lock);
    80001d9e:	8526                	mv	a0,s1
    80001da0:	fffff097          	auipc	ra,0xfffff
    80001da4:	eea080e7          	jalr	-278(ra) # 80000c8a <release>
}
    80001da8:	70a2                	ld	ra,40(sp)
    80001daa:	7402                	ld	s0,32(sp)
    80001dac:	64e2                	ld	s1,24(sp)
    80001dae:	6942                	ld	s2,16(sp)
    80001db0:	69a2                	ld	s3,8(sp)
    80001db2:	6145                	addi	sp,sp,48
    80001db4:	8082                	ret
    panic("kproc_create");
    80001db6:	00006517          	auipc	a0,0x6
    80001dba:	47250513          	addi	a0,a0,1138 # 80008228 <digits+0x1e8>
    80001dbe:	ffffe097          	auipc	ra,0xffffe
    80001dc2:	780080e7          	jalr	1920(ra) # 8000053e <panic>

0000000080001dc6 <growproc>:
{
    80001dc6:	1101                	addi	sp,sp,-32
    80001dc8:	ec06                	sd	ra,24(sp)
    80001dca:	e822                	sd	s0,16(sp)
    80001dcc:	e426                	sd	s1,8(sp)
    80001dce:	e04a                	sd	s2,0(sp)
    80001dd0:	1000                	addi	s0,sp,32
    80001dd2:	892a                	mv	s2,a0
  struct proc *p = myproc();
    80001dd4:	00000097          	auipc	ra,0x0
    80001dd8:	c0e080e7          	jalr	-1010(ra) # 800019e2 <myproc>
    80001ddc:	84aa                	mv	s1,a0
  sz = p->sz;
    80001dde:	652c                	ld	a1,72(a0)
  if(n > 0){
    80001de0:	01204c63          	bgtz	s2,80001df8 <growproc+0x32>
  } else if(n < 0){
    80001de4:	02094663          	bltz	s2,80001e10 <growproc+0x4a>
  p->sz = sz;
    80001de8:	e4ac                	sd	a1,72(s1)
  return 0;
    80001dea:	4501                	li	a0,0
}
    80001dec:	60e2                	ld	ra,24(sp)
    80001dee:	6442                	ld	s0,16(sp)
    80001df0:	64a2                	ld	s1,8(sp)
    80001df2:	6902                	ld	s2,0(sp)
    80001df4:	6105                	addi	sp,sp,32
    80001df6:	8082                	ret
    if((sz = uvmalloc(p->pagetable, sz, sz + n, PTE_W)) == 0) {
    80001df8:	4691                	li	a3,4
    80001dfa:	00b90633          	add	a2,s2,a1
    80001dfe:	6928                	ld	a0,80(a0)
    80001e00:	fffff097          	auipc	ra,0xfffff
    80001e04:	646080e7          	jalr	1606(ra) # 80001446 <uvmalloc>
    80001e08:	85aa                	mv	a1,a0
    80001e0a:	fd79                	bnez	a0,80001de8 <growproc+0x22>
      return -1;
    80001e0c:	557d                	li	a0,-1
    80001e0e:	bff9                	j	80001dec <growproc+0x26>
    sz = uvmdealloc(p->pagetable, sz, sz + n);
    80001e10:	00b90633          	add	a2,s2,a1
    80001e14:	6928                	ld	a0,80(a0)
    80001e16:	fffff097          	auipc	ra,0xfffff
    80001e1a:	5e8080e7          	jalr	1512(ra) # 800013fe <uvmdealloc>
    80001e1e:	85aa                	mv	a1,a0
    80001e20:	b7e1                	j	80001de8 <growproc+0x22>

0000000080001e22 <fork>:
{
    80001e22:	7139                	addi	sp,sp,-64
    80001e24:	fc06                	sd	ra,56(sp)
    80001e26:	f822                	sd	s0,48(sp)
    80001e28:	f426                	sd	s1,40(sp)
    80001e2a:	f04a                	sd	s2,32(sp)
    80001e2c:	ec4e                	sd	s3,24(sp)
    80001e2e:	e852                	sd	s4,16(sp)
    80001e30:	e456                	sd	s5,8(sp)
    80001e32:	0080                	addi	s0,sp,64
  struct proc *p = myproc();
    80001e34:	00000097          	auipc	ra,0x0
    80001e38:	bae080e7          	jalr	-1106(ra) # 800019e2 <myproc>
    80001e3c:	8aaa                	mv	s5,a0
  if((np = allocproc()) == 0){
    80001e3e:	00000097          	auipc	ra,0x0
    80001e42:	dd2080e7          	jalr	-558(ra) # 80001c10 <allocproc>
    80001e46:	10050c63          	beqz	a0,80001f5e <fork+0x13c>
    80001e4a:	8a2a                	mv	s4,a0
  if(uvmcopy(p->pagetable, np->pagetable, p->sz) < 0){
    80001e4c:	048ab603          	ld	a2,72(s5)
    80001e50:	692c                	ld	a1,80(a0)
    80001e52:	050ab503          	ld	a0,80(s5)
    80001e56:	fffff097          	auipc	ra,0xfffff
    80001e5a:	744080e7          	jalr	1860(ra) # 8000159a <uvmcopy>
    80001e5e:	04054863          	bltz	a0,80001eae <fork+0x8c>
  np->sz = p->sz;
    80001e62:	048ab783          	ld	a5,72(s5)
    80001e66:	04fa3423          	sd	a5,72(s4)
  *(np->trapframe) = *(p->trapframe);
    80001e6a:	058ab683          	ld	a3,88(s5)
    80001e6e:	87b6                	mv	a5,a3
    80001e70:	058a3703          	ld	a4,88(s4)
    80001e74:	12068693          	addi	a3,a3,288
    80001e78:	0007b803          	ld	a6,0(a5) # 1000 <_entry-0x7ffff000>
    80001e7c:	6788                	ld	a0,8(a5)
    80001e7e:	6b8c                	ld	a1,16(a5)
    80001e80:	6f90                	ld	a2,24(a5)
    80001e82:	01073023          	sd	a6,0(a4) # 1000 <_entry-0x7ffff000>
    80001e86:	e708                	sd	a0,8(a4)
    80001e88:	eb0c                	sd	a1,16(a4)
    80001e8a:	ef10                	sd	a2,24(a4)
    80001e8c:	02078793          	addi	a5,a5,32
    80001e90:	02070713          	addi	a4,a4,32
    80001e94:	fed792e3          	bne	a5,a3,80001e78 <fork+0x56>
  np->trapframe->a0 = 0;
    80001e98:	058a3783          	ld	a5,88(s4)
    80001e9c:	0607b823          	sd	zero,112(a5)
  for(i = 0; i < NOFILE; i++)
    80001ea0:	0d0a8493          	addi	s1,s5,208
    80001ea4:	0d0a0913          	addi	s2,s4,208
    80001ea8:	150a8993          	addi	s3,s5,336
    80001eac:	a00d                	j	80001ece <fork+0xac>
    freeproc(np);
    80001eae:	8552                	mv	a0,s4
    80001eb0:	00000097          	auipc	ra,0x0
    80001eb4:	ce4080e7          	jalr	-796(ra) # 80001b94 <freeproc>
    release(&np->lock);
    80001eb8:	8552                	mv	a0,s4
    80001eba:	fffff097          	auipc	ra,0xfffff
    80001ebe:	dd0080e7          	jalr	-560(ra) # 80000c8a <release>
    return -1;
    80001ec2:	597d                	li	s2,-1
    80001ec4:	a059                	j	80001f4a <fork+0x128>
  for(i = 0; i < NOFILE; i++)
    80001ec6:	04a1                	addi	s1,s1,8
    80001ec8:	0921                	addi	s2,s2,8
    80001eca:	01348b63          	beq	s1,s3,80001ee0 <fork+0xbe>
    if(p->ofile[i])
    80001ece:	6088                	ld	a0,0(s1)
    80001ed0:	d97d                	beqz	a0,80001ec6 <fork+0xa4>
      np->ofile[i] = filedup(p->ofile[i]);
    80001ed2:	00002097          	auipc	ra,0x2
    80001ed6:	70c080e7          	jalr	1804(ra) # 800045de <filedup>
    80001eda:	00a93023          	sd	a0,0(s2)
    80001ede:	b7e5                	j	80001ec6 <fork+0xa4>
  np->cwd = idup(p->cwd);
    80001ee0:	150ab503          	ld	a0,336(s5)
    80001ee4:	00002097          	auipc	ra,0x2
    80001ee8:	880080e7          	jalr	-1920(ra) # 80003764 <idup>
    80001eec:	14aa3823          	sd	a0,336(s4)
  safestrcpy(np->name, p->name, sizeof(p->name));
    80001ef0:	4641                	li	a2,16
    80001ef2:	158a8593          	addi	a1,s5,344
    80001ef6:	158a0513          	addi	a0,s4,344
    80001efa:	fffff097          	auipc	ra,0xfffff
    80001efe:	f22080e7          	jalr	-222(ra) # 80000e1c <safestrcpy>
  pid = np->pid;
    80001f02:	030a2903          	lw	s2,48(s4)
  release(&np->lock);
    80001f06:	8552                	mv	a0,s4
    80001f08:	fffff097          	auipc	ra,0xfffff
    80001f0c:	d82080e7          	jalr	-638(ra) # 80000c8a <release>
  acquire(&wait_lock);
    80001f10:	0000f497          	auipc	s1,0xf
    80001f14:	5d848493          	addi	s1,s1,1496 # 800114e8 <wait_lock>
    80001f18:	8526                	mv	a0,s1
    80001f1a:	fffff097          	auipc	ra,0xfffff
    80001f1e:	cbc080e7          	jalr	-836(ra) # 80000bd6 <acquire>
  np->parent = p;
    80001f22:	035a3c23          	sd	s5,56(s4)
  release(&wait_lock);
    80001f26:	8526                	mv	a0,s1
    80001f28:	fffff097          	auipc	ra,0xfffff
    80001f2c:	d62080e7          	jalr	-670(ra) # 80000c8a <release>
  acquire(&np->lock);
    80001f30:	8552                	mv	a0,s4
    80001f32:	fffff097          	auipc	ra,0xfffff
    80001f36:	ca4080e7          	jalr	-860(ra) # 80000bd6 <acquire>
  np->state = RUNNABLE;
    80001f3a:	478d                	li	a5,3
    80001f3c:	00fa2c23          	sw	a5,24(s4)
  release(&np->lock);
    80001f40:	8552                	mv	a0,s4
    80001f42:	fffff097          	auipc	ra,0xfffff
    80001f46:	d48080e7          	jalr	-696(ra) # 80000c8a <release>
}
    80001f4a:	854a                	mv	a0,s2
    80001f4c:	70e2                	ld	ra,56(sp)
    80001f4e:	7442                	ld	s0,48(sp)
    80001f50:	74a2                	ld	s1,40(sp)
    80001f52:	7902                	ld	s2,32(sp)
    80001f54:	69e2                	ld	s3,24(sp)
    80001f56:	6a42                	ld	s4,16(sp)
    80001f58:	6aa2                	ld	s5,8(sp)
    80001f5a:	6121                	addi	sp,sp,64
    80001f5c:	8082                	ret
    return -1;
    80001f5e:	597d                	li	s2,-1
    80001f60:	b7ed                	j	80001f4a <fork+0x128>

0000000080001f62 <scheduler>:
{
    80001f62:	7139                	addi	sp,sp,-64
    80001f64:	fc06                	sd	ra,56(sp)
    80001f66:	f822                	sd	s0,48(sp)
    80001f68:	f426                	sd	s1,40(sp)
    80001f6a:	f04a                	sd	s2,32(sp)
    80001f6c:	ec4e                	sd	s3,24(sp)
    80001f6e:	e852                	sd	s4,16(sp)
    80001f70:	e456                	sd	s5,8(sp)
    80001f72:	e05a                	sd	s6,0(sp)
    80001f74:	0080                	addi	s0,sp,64
    80001f76:	8792                	mv	a5,tp
  int id = r_tp();
    80001f78:	2781                	sext.w	a5,a5
  c->proc = 0;
    80001f7a:	00779a93          	slli	s5,a5,0x7
    80001f7e:	0000f717          	auipc	a4,0xf
    80001f82:	55270713          	addi	a4,a4,1362 # 800114d0 <pid_lock>
    80001f86:	9756                	add	a4,a4,s5
    80001f88:	02073823          	sd	zero,48(a4)
        swtch(&c->context, &p->context);
    80001f8c:	0000f717          	auipc	a4,0xf
    80001f90:	57c70713          	addi	a4,a4,1404 # 80011508 <cpus+0x8>
    80001f94:	9aba                	add	s5,s5,a4
      if(p->state == RUNNABLE) {
    80001f96:	498d                	li	s3,3
        p->state = RUNNING;
    80001f98:	4b11                	li	s6,4
        c->proc = p;
    80001f9a:	079e                	slli	a5,a5,0x7
    80001f9c:	0000fa17          	auipc	s4,0xf
    80001fa0:	534a0a13          	addi	s4,s4,1332 # 800114d0 <pid_lock>
    80001fa4:	9a3e                	add	s4,s4,a5
    for(p = proc; p < &proc[NPROC]; p++) {
    80001fa6:	00015917          	auipc	s2,0x15
    80001faa:	55a90913          	addi	s2,s2,1370 # 80017500 <tickslock>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001fae:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    80001fb2:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80001fb6:	10079073          	csrw	sstatus,a5
    80001fba:	00010497          	auipc	s1,0x10
    80001fbe:	94648493          	addi	s1,s1,-1722 # 80011900 <proc>
    80001fc2:	a811                	j	80001fd6 <scheduler+0x74>
      release(&p->lock);
    80001fc4:	8526                	mv	a0,s1
    80001fc6:	fffff097          	auipc	ra,0xfffff
    80001fca:	cc4080e7          	jalr	-828(ra) # 80000c8a <release>
    for(p = proc; p < &proc[NPROC]; p++) {
    80001fce:	17048493          	addi	s1,s1,368
    80001fd2:	fd248ee3          	beq	s1,s2,80001fae <scheduler+0x4c>
      acquire(&p->lock);
    80001fd6:	8526                	mv	a0,s1
    80001fd8:	fffff097          	auipc	ra,0xfffff
    80001fdc:	bfe080e7          	jalr	-1026(ra) # 80000bd6 <acquire>
      if(p->state == RUNNABLE) {
    80001fe0:	4c9c                	lw	a5,24(s1)
    80001fe2:	ff3791e3          	bne	a5,s3,80001fc4 <scheduler+0x62>
        p->state = RUNNING;
    80001fe6:	0164ac23          	sw	s6,24(s1)
        c->proc = p;
    80001fea:	029a3823          	sd	s1,48(s4)
        swtch(&c->context, &p->context);
    80001fee:	06048593          	addi	a1,s1,96
    80001ff2:	8556                	mv	a0,s5
    80001ff4:	00000097          	auipc	ra,0x0
    80001ff8:	682080e7          	jalr	1666(ra) # 80002676 <swtch>
        c->proc = 0;
    80001ffc:	020a3823          	sd	zero,48(s4)
    80002000:	b7d1                	j	80001fc4 <scheduler+0x62>

0000000080002002 <sched>:
{
    80002002:	7179                	addi	sp,sp,-48
    80002004:	f406                	sd	ra,40(sp)
    80002006:	f022                	sd	s0,32(sp)
    80002008:	ec26                	sd	s1,24(sp)
    8000200a:	e84a                	sd	s2,16(sp)
    8000200c:	e44e                	sd	s3,8(sp)
    8000200e:	1800                	addi	s0,sp,48
  struct proc *p = myproc();
    80002010:	00000097          	auipc	ra,0x0
    80002014:	9d2080e7          	jalr	-1582(ra) # 800019e2 <myproc>
    80002018:	84aa                	mv	s1,a0
  if(!holding(&p->lock))
    8000201a:	fffff097          	auipc	ra,0xfffff
    8000201e:	b42080e7          	jalr	-1214(ra) # 80000b5c <holding>
    80002022:	c93d                	beqz	a0,80002098 <sched+0x96>
  asm volatile("mv %0, tp" : "=r" (x) );
    80002024:	8792                	mv	a5,tp
  if(mycpu()->noff != 1)
    80002026:	2781                	sext.w	a5,a5
    80002028:	079e                	slli	a5,a5,0x7
    8000202a:	0000f717          	auipc	a4,0xf
    8000202e:	4a670713          	addi	a4,a4,1190 # 800114d0 <pid_lock>
    80002032:	97ba                	add	a5,a5,a4
    80002034:	0a87a703          	lw	a4,168(a5)
    80002038:	4785                	li	a5,1
    8000203a:	06f71763          	bne	a4,a5,800020a8 <sched+0xa6>
  if(p->state == RUNNING)
    8000203e:	4c98                	lw	a4,24(s1)
    80002040:	4791                	li	a5,4
    80002042:	06f70b63          	beq	a4,a5,800020b8 <sched+0xb6>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80002046:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    8000204a:	8b89                	andi	a5,a5,2
  if(intr_get())
    8000204c:	efb5                	bnez	a5,800020c8 <sched+0xc6>
  asm volatile("mv %0, tp" : "=r" (x) );
    8000204e:	8792                	mv	a5,tp
  intena = mycpu()->intena;
    80002050:	0000f917          	auipc	s2,0xf
    80002054:	48090913          	addi	s2,s2,1152 # 800114d0 <pid_lock>
    80002058:	2781                	sext.w	a5,a5
    8000205a:	079e                	slli	a5,a5,0x7
    8000205c:	97ca                	add	a5,a5,s2
    8000205e:	0ac7a983          	lw	s3,172(a5)
    80002062:	8792                	mv	a5,tp
  swtch(&p->context, &mycpu()->context);
    80002064:	2781                	sext.w	a5,a5
    80002066:	079e                	slli	a5,a5,0x7
    80002068:	0000f597          	auipc	a1,0xf
    8000206c:	4a058593          	addi	a1,a1,1184 # 80011508 <cpus+0x8>
    80002070:	95be                	add	a1,a1,a5
    80002072:	06048513          	addi	a0,s1,96
    80002076:	00000097          	auipc	ra,0x0
    8000207a:	600080e7          	jalr	1536(ra) # 80002676 <swtch>
    8000207e:	8792                	mv	a5,tp
  mycpu()->intena = intena;
    80002080:	2781                	sext.w	a5,a5
    80002082:	079e                	slli	a5,a5,0x7
    80002084:	97ca                	add	a5,a5,s2
    80002086:	0b37a623          	sw	s3,172(a5)
}
    8000208a:	70a2                	ld	ra,40(sp)
    8000208c:	7402                	ld	s0,32(sp)
    8000208e:	64e2                	ld	s1,24(sp)
    80002090:	6942                	ld	s2,16(sp)
    80002092:	69a2                	ld	s3,8(sp)
    80002094:	6145                	addi	sp,sp,48
    80002096:	8082                	ret
    panic("sched p->lock");
    80002098:	00006517          	auipc	a0,0x6
    8000209c:	1a050513          	addi	a0,a0,416 # 80008238 <digits+0x1f8>
    800020a0:	ffffe097          	auipc	ra,0xffffe
    800020a4:	49e080e7          	jalr	1182(ra) # 8000053e <panic>
    panic("sched locks");
    800020a8:	00006517          	auipc	a0,0x6
    800020ac:	1a050513          	addi	a0,a0,416 # 80008248 <digits+0x208>
    800020b0:	ffffe097          	auipc	ra,0xffffe
    800020b4:	48e080e7          	jalr	1166(ra) # 8000053e <panic>
    panic("sched running");
    800020b8:	00006517          	auipc	a0,0x6
    800020bc:	1a050513          	addi	a0,a0,416 # 80008258 <digits+0x218>
    800020c0:	ffffe097          	auipc	ra,0xffffe
    800020c4:	47e080e7          	jalr	1150(ra) # 8000053e <panic>
    panic("sched interruptible");
    800020c8:	00006517          	auipc	a0,0x6
    800020cc:	1a050513          	addi	a0,a0,416 # 80008268 <digits+0x228>
    800020d0:	ffffe097          	auipc	ra,0xffffe
    800020d4:	46e080e7          	jalr	1134(ra) # 8000053e <panic>

00000000800020d8 <yield>:
{
    800020d8:	1101                	addi	sp,sp,-32
    800020da:	ec06                	sd	ra,24(sp)
    800020dc:	e822                	sd	s0,16(sp)
    800020de:	e426                	sd	s1,8(sp)
    800020e0:	1000                	addi	s0,sp,32
  struct proc *p = myproc();
    800020e2:	00000097          	auipc	ra,0x0
    800020e6:	900080e7          	jalr	-1792(ra) # 800019e2 <myproc>
    800020ea:	84aa                	mv	s1,a0
  acquire(&p->lock);
    800020ec:	fffff097          	auipc	ra,0xfffff
    800020f0:	aea080e7          	jalr	-1302(ra) # 80000bd6 <acquire>
  p->state = RUNNABLE;
    800020f4:	478d                	li	a5,3
    800020f6:	cc9c                	sw	a5,24(s1)
  sched();
    800020f8:	00000097          	auipc	ra,0x0
    800020fc:	f0a080e7          	jalr	-246(ra) # 80002002 <sched>
  release(&p->lock);
    80002100:	8526                	mv	a0,s1
    80002102:	fffff097          	auipc	ra,0xfffff
    80002106:	b88080e7          	jalr	-1144(ra) # 80000c8a <release>
}
    8000210a:	60e2                	ld	ra,24(sp)
    8000210c:	6442                	ld	s0,16(sp)
    8000210e:	64a2                	ld	s1,8(sp)
    80002110:	6105                	addi	sp,sp,32
    80002112:	8082                	ret

0000000080002114 <sleep>:

// Atomically release lock and sleep on chan.
// Reacquires lock when awakened.
void
sleep(void *chan, struct spinlock *lk)
{
    80002114:	7179                	addi	sp,sp,-48
    80002116:	f406                	sd	ra,40(sp)
    80002118:	f022                	sd	s0,32(sp)
    8000211a:	ec26                	sd	s1,24(sp)
    8000211c:	e84a                	sd	s2,16(sp)
    8000211e:	e44e                	sd	s3,8(sp)
    80002120:	1800                	addi	s0,sp,48
    80002122:	89aa                	mv	s3,a0
    80002124:	892e                	mv	s2,a1
  struct proc *p = myproc();
    80002126:	00000097          	auipc	ra,0x0
    8000212a:	8bc080e7          	jalr	-1860(ra) # 800019e2 <myproc>
    8000212e:	84aa                	mv	s1,a0
  // Once we hold p->lock, we can be
  // guaranteed that we won't miss any wakeup
  // (wakeup locks p->lock),
  // so it's okay to release lk.

  acquire(&p->lock);  //DOC: sleeplock1
    80002130:	fffff097          	auipc	ra,0xfffff
    80002134:	aa6080e7          	jalr	-1370(ra) # 80000bd6 <acquire>
  release(lk);
    80002138:	854a                	mv	a0,s2
    8000213a:	fffff097          	auipc	ra,0xfffff
    8000213e:	b50080e7          	jalr	-1200(ra) # 80000c8a <release>

  // Go to sleep.
  p->chan = chan;
    80002142:	0334b023          	sd	s3,32(s1)
  p->state = SLEEPING;
    80002146:	4789                	li	a5,2
    80002148:	cc9c                	sw	a5,24(s1)

  sched();
    8000214a:	00000097          	auipc	ra,0x0
    8000214e:	eb8080e7          	jalr	-328(ra) # 80002002 <sched>

  // Tidy up.
  p->chan = 0;
    80002152:	0204b023          	sd	zero,32(s1)

  // Reacquire original lock.
  release(&p->lock);
    80002156:	8526                	mv	a0,s1
    80002158:	fffff097          	auipc	ra,0xfffff
    8000215c:	b32080e7          	jalr	-1230(ra) # 80000c8a <release>
  acquire(lk);
    80002160:	854a                	mv	a0,s2
    80002162:	fffff097          	auipc	ra,0xfffff
    80002166:	a74080e7          	jalr	-1420(ra) # 80000bd6 <acquire>
}
    8000216a:	70a2                	ld	ra,40(sp)
    8000216c:	7402                	ld	s0,32(sp)
    8000216e:	64e2                	ld	s1,24(sp)
    80002170:	6942                	ld	s2,16(sp)
    80002172:	69a2                	ld	s3,8(sp)
    80002174:	6145                	addi	sp,sp,48
    80002176:	8082                	ret

0000000080002178 <wakeup>:

// Wake up all processes sleeping on chan.
// Must be called without any p->lock.
void
wakeup(void *chan)
{
    80002178:	7139                	addi	sp,sp,-64
    8000217a:	fc06                	sd	ra,56(sp)
    8000217c:	f822                	sd	s0,48(sp)
    8000217e:	f426                	sd	s1,40(sp)
    80002180:	f04a                	sd	s2,32(sp)
    80002182:	ec4e                	sd	s3,24(sp)
    80002184:	e852                	sd	s4,16(sp)
    80002186:	e456                	sd	s5,8(sp)
    80002188:	0080                	addi	s0,sp,64
    8000218a:	8a2a                	mv	s4,a0
  struct proc *p;

  for(p = proc; p < &proc[NPROC]; p++) {
    8000218c:	0000f497          	auipc	s1,0xf
    80002190:	77448493          	addi	s1,s1,1908 # 80011900 <proc>
    if(p != myproc()){
      acquire(&p->lock);
      if(p->state == SLEEPING && p->chan == chan) {
    80002194:	4989                	li	s3,2
        p->state = RUNNABLE;
    80002196:	4a8d                	li	s5,3
  for(p = proc; p < &proc[NPROC]; p++) {
    80002198:	00015917          	auipc	s2,0x15
    8000219c:	36890913          	addi	s2,s2,872 # 80017500 <tickslock>
    800021a0:	a811                	j	800021b4 <wakeup+0x3c>
      }
      release(&p->lock);
    800021a2:	8526                	mv	a0,s1
    800021a4:	fffff097          	auipc	ra,0xfffff
    800021a8:	ae6080e7          	jalr	-1306(ra) # 80000c8a <release>
  for(p = proc; p < &proc[NPROC]; p++) {
    800021ac:	17048493          	addi	s1,s1,368
    800021b0:	03248663          	beq	s1,s2,800021dc <wakeup+0x64>
    if(p != myproc()){
    800021b4:	00000097          	auipc	ra,0x0
    800021b8:	82e080e7          	jalr	-2002(ra) # 800019e2 <myproc>
    800021bc:	fea488e3          	beq	s1,a0,800021ac <wakeup+0x34>
      acquire(&p->lock);
    800021c0:	8526                	mv	a0,s1
    800021c2:	fffff097          	auipc	ra,0xfffff
    800021c6:	a14080e7          	jalr	-1516(ra) # 80000bd6 <acquire>
      if(p->state == SLEEPING && p->chan == chan) {
    800021ca:	4c9c                	lw	a5,24(s1)
    800021cc:	fd379be3          	bne	a5,s3,800021a2 <wakeup+0x2a>
    800021d0:	709c                	ld	a5,32(s1)
    800021d2:	fd4798e3          	bne	a5,s4,800021a2 <wakeup+0x2a>
        p->state = RUNNABLE;
    800021d6:	0154ac23          	sw	s5,24(s1)
    800021da:	b7e1                	j	800021a2 <wakeup+0x2a>
    }
  }
}
    800021dc:	70e2                	ld	ra,56(sp)
    800021de:	7442                	ld	s0,48(sp)
    800021e0:	74a2                	ld	s1,40(sp)
    800021e2:	7902                	ld	s2,32(sp)
    800021e4:	69e2                	ld	s3,24(sp)
    800021e6:	6a42                	ld	s4,16(sp)
    800021e8:	6aa2                	ld	s5,8(sp)
    800021ea:	6121                	addi	sp,sp,64
    800021ec:	8082                	ret

00000000800021ee <reparent>:
{
    800021ee:	7179                	addi	sp,sp,-48
    800021f0:	f406                	sd	ra,40(sp)
    800021f2:	f022                	sd	s0,32(sp)
    800021f4:	ec26                	sd	s1,24(sp)
    800021f6:	e84a                	sd	s2,16(sp)
    800021f8:	e44e                	sd	s3,8(sp)
    800021fa:	e052                	sd	s4,0(sp)
    800021fc:	1800                	addi	s0,sp,48
    800021fe:	892a                	mv	s2,a0
  for(pp = proc; pp < &proc[NPROC]; pp++){
    80002200:	0000f497          	auipc	s1,0xf
    80002204:	70048493          	addi	s1,s1,1792 # 80011900 <proc>
      pp->parent = initproc;
    80002208:	00007a17          	auipc	s4,0x7
    8000220c:	050a0a13          	addi	s4,s4,80 # 80009258 <initproc>
  for(pp = proc; pp < &proc[NPROC]; pp++){
    80002210:	00015997          	auipc	s3,0x15
    80002214:	2f098993          	addi	s3,s3,752 # 80017500 <tickslock>
    80002218:	a029                	j	80002222 <reparent+0x34>
    8000221a:	17048493          	addi	s1,s1,368
    8000221e:	01348d63          	beq	s1,s3,80002238 <reparent+0x4a>
    if(pp->parent == p){
    80002222:	7c9c                	ld	a5,56(s1)
    80002224:	ff279be3          	bne	a5,s2,8000221a <reparent+0x2c>
      pp->parent = initproc;
    80002228:	000a3503          	ld	a0,0(s4)
    8000222c:	fc88                	sd	a0,56(s1)
      wakeup(initproc);
    8000222e:	00000097          	auipc	ra,0x0
    80002232:	f4a080e7          	jalr	-182(ra) # 80002178 <wakeup>
    80002236:	b7d5                	j	8000221a <reparent+0x2c>
}
    80002238:	70a2                	ld	ra,40(sp)
    8000223a:	7402                	ld	s0,32(sp)
    8000223c:	64e2                	ld	s1,24(sp)
    8000223e:	6942                	ld	s2,16(sp)
    80002240:	69a2                	ld	s3,8(sp)
    80002242:	6a02                	ld	s4,0(sp)
    80002244:	6145                	addi	sp,sp,48
    80002246:	8082                	ret

0000000080002248 <exit>:
{
    80002248:	7179                	addi	sp,sp,-48
    8000224a:	f406                	sd	ra,40(sp)
    8000224c:	f022                	sd	s0,32(sp)
    8000224e:	ec26                	sd	s1,24(sp)
    80002250:	e84a                	sd	s2,16(sp)
    80002252:	e44e                	sd	s3,8(sp)
    80002254:	e052                	sd	s4,0(sp)
    80002256:	1800                	addi	s0,sp,48
    80002258:	8a2a                	mv	s4,a0
  struct proc *p = myproc();
    8000225a:	fffff097          	auipc	ra,0xfffff
    8000225e:	788080e7          	jalr	1928(ra) # 800019e2 <myproc>
    80002262:	89aa                	mv	s3,a0
  if(p == initproc)
    80002264:	00007797          	auipc	a5,0x7
    80002268:	ff47b783          	ld	a5,-12(a5) # 80009258 <initproc>
    8000226c:	0d050493          	addi	s1,a0,208
    80002270:	15050913          	addi	s2,a0,336
    80002274:	02a79363          	bne	a5,a0,8000229a <exit+0x52>
    panic("init exiting");
    80002278:	00006517          	auipc	a0,0x6
    8000227c:	00850513          	addi	a0,a0,8 # 80008280 <digits+0x240>
    80002280:	ffffe097          	auipc	ra,0xffffe
    80002284:	2be080e7          	jalr	702(ra) # 8000053e <panic>
      fileclose(f);
    80002288:	00002097          	auipc	ra,0x2
    8000228c:	3a8080e7          	jalr	936(ra) # 80004630 <fileclose>
      p->ofile[fd] = 0;
    80002290:	0004b023          	sd	zero,0(s1)
  for(int fd = 0; fd < NOFILE; fd++){
    80002294:	04a1                	addi	s1,s1,8
    80002296:	01248563          	beq	s1,s2,800022a0 <exit+0x58>
    if(p->ofile[fd]){
    8000229a:	6088                	ld	a0,0(s1)
    8000229c:	f575                	bnez	a0,80002288 <exit+0x40>
    8000229e:	bfdd                	j	80002294 <exit+0x4c>
  begin_op();
    800022a0:	00002097          	auipc	ra,0x2
    800022a4:	ec4080e7          	jalr	-316(ra) # 80004164 <begin_op>
  iput(p->cwd);
    800022a8:	1509b503          	ld	a0,336(s3)
    800022ac:	00001097          	auipc	ra,0x1
    800022b0:	6b0080e7          	jalr	1712(ra) # 8000395c <iput>
  end_op();
    800022b4:	00002097          	auipc	ra,0x2
    800022b8:	f30080e7          	jalr	-208(ra) # 800041e4 <end_op>
  p->cwd = 0;
    800022bc:	1409b823          	sd	zero,336(s3)
  acquire(&wait_lock);
    800022c0:	0000f497          	auipc	s1,0xf
    800022c4:	22848493          	addi	s1,s1,552 # 800114e8 <wait_lock>
    800022c8:	8526                	mv	a0,s1
    800022ca:	fffff097          	auipc	ra,0xfffff
    800022ce:	90c080e7          	jalr	-1780(ra) # 80000bd6 <acquire>
  reparent(p);
    800022d2:	854e                	mv	a0,s3
    800022d4:	00000097          	auipc	ra,0x0
    800022d8:	f1a080e7          	jalr	-230(ra) # 800021ee <reparent>
  wakeup(p->parent);
    800022dc:	0389b503          	ld	a0,56(s3)
    800022e0:	00000097          	auipc	ra,0x0
    800022e4:	e98080e7          	jalr	-360(ra) # 80002178 <wakeup>
  acquire(&p->lock);
    800022e8:	854e                	mv	a0,s3
    800022ea:	fffff097          	auipc	ra,0xfffff
    800022ee:	8ec080e7          	jalr	-1812(ra) # 80000bd6 <acquire>
  p->xstate = status;
    800022f2:	0349a623          	sw	s4,44(s3)
  p->state = ZOMBIE;
    800022f6:	4795                	li	a5,5
    800022f8:	00f9ac23          	sw	a5,24(s3)
  release(&wait_lock);
    800022fc:	8526                	mv	a0,s1
    800022fe:	fffff097          	auipc	ra,0xfffff
    80002302:	98c080e7          	jalr	-1652(ra) # 80000c8a <release>
  sched();
    80002306:	00000097          	auipc	ra,0x0
    8000230a:	cfc080e7          	jalr	-772(ra) # 80002002 <sched>
  panic("zombie exit");
    8000230e:	00006517          	auipc	a0,0x6
    80002312:	f8250513          	addi	a0,a0,-126 # 80008290 <digits+0x250>
    80002316:	ffffe097          	auipc	ra,0xffffe
    8000231a:	228080e7          	jalr	552(ra) # 8000053e <panic>

000000008000231e <kill>:
// Kill the process with the given pid.
// The victim won't exit until it tries to return
// to user space (see usertrap() in trap.c).
int
kill(int pid)
{
    8000231e:	7179                	addi	sp,sp,-48
    80002320:	f406                	sd	ra,40(sp)
    80002322:	f022                	sd	s0,32(sp)
    80002324:	ec26                	sd	s1,24(sp)
    80002326:	e84a                	sd	s2,16(sp)
    80002328:	e44e                	sd	s3,8(sp)
    8000232a:	1800                	addi	s0,sp,48
    8000232c:	892a                	mv	s2,a0
  struct proc *p;

  for(p = proc; p < &proc[NPROC]; p++){
    8000232e:	0000f497          	auipc	s1,0xf
    80002332:	5d248493          	addi	s1,s1,1490 # 80011900 <proc>
    80002336:	00015997          	auipc	s3,0x15
    8000233a:	1ca98993          	addi	s3,s3,458 # 80017500 <tickslock>
    acquire(&p->lock);
    8000233e:	8526                	mv	a0,s1
    80002340:	fffff097          	auipc	ra,0xfffff
    80002344:	896080e7          	jalr	-1898(ra) # 80000bd6 <acquire>
    if(p->pid == pid){
    80002348:	589c                	lw	a5,48(s1)
    8000234a:	01278d63          	beq	a5,s2,80002364 <kill+0x46>
        p->state = RUNNABLE;
      }
      release(&p->lock);
      return 0;
    }
    release(&p->lock);
    8000234e:	8526                	mv	a0,s1
    80002350:	fffff097          	auipc	ra,0xfffff
    80002354:	93a080e7          	jalr	-1734(ra) # 80000c8a <release>
  for(p = proc; p < &proc[NPROC]; p++){
    80002358:	17048493          	addi	s1,s1,368
    8000235c:	ff3491e3          	bne	s1,s3,8000233e <kill+0x20>
  }
  return -1;
    80002360:	557d                	li	a0,-1
    80002362:	a829                	j	8000237c <kill+0x5e>
      p->killed = 1;
    80002364:	4785                	li	a5,1
    80002366:	d49c                	sw	a5,40(s1)
      if(p->state == SLEEPING){
    80002368:	4c98                	lw	a4,24(s1)
    8000236a:	4789                	li	a5,2
    8000236c:	00f70f63          	beq	a4,a5,8000238a <kill+0x6c>
      release(&p->lock);
    80002370:	8526                	mv	a0,s1
    80002372:	fffff097          	auipc	ra,0xfffff
    80002376:	918080e7          	jalr	-1768(ra) # 80000c8a <release>
      return 0;
    8000237a:	4501                	li	a0,0
}
    8000237c:	70a2                	ld	ra,40(sp)
    8000237e:	7402                	ld	s0,32(sp)
    80002380:	64e2                	ld	s1,24(sp)
    80002382:	6942                	ld	s2,16(sp)
    80002384:	69a2                	ld	s3,8(sp)
    80002386:	6145                	addi	sp,sp,48
    80002388:	8082                	ret
        p->state = RUNNABLE;
    8000238a:	478d                	li	a5,3
    8000238c:	cc9c                	sw	a5,24(s1)
    8000238e:	b7cd                	j	80002370 <kill+0x52>

0000000080002390 <setkilled>:

void
setkilled(struct proc *p)
{
    80002390:	1101                	addi	sp,sp,-32
    80002392:	ec06                	sd	ra,24(sp)
    80002394:	e822                	sd	s0,16(sp)
    80002396:	e426                	sd	s1,8(sp)
    80002398:	1000                	addi	s0,sp,32
    8000239a:	84aa                	mv	s1,a0
  acquire(&p->lock);
    8000239c:	fffff097          	auipc	ra,0xfffff
    800023a0:	83a080e7          	jalr	-1990(ra) # 80000bd6 <acquire>
  p->killed = 1;
    800023a4:	4785                	li	a5,1
    800023a6:	d49c                	sw	a5,40(s1)
  release(&p->lock);
    800023a8:	8526                	mv	a0,s1
    800023aa:	fffff097          	auipc	ra,0xfffff
    800023ae:	8e0080e7          	jalr	-1824(ra) # 80000c8a <release>
}
    800023b2:	60e2                	ld	ra,24(sp)
    800023b4:	6442                	ld	s0,16(sp)
    800023b6:	64a2                	ld	s1,8(sp)
    800023b8:	6105                	addi	sp,sp,32
    800023ba:	8082                	ret

00000000800023bc <killed>:

int
killed(struct proc *p)
{
    800023bc:	1101                	addi	sp,sp,-32
    800023be:	ec06                	sd	ra,24(sp)
    800023c0:	e822                	sd	s0,16(sp)
    800023c2:	e426                	sd	s1,8(sp)
    800023c4:	e04a                	sd	s2,0(sp)
    800023c6:	1000                	addi	s0,sp,32
    800023c8:	84aa                	mv	s1,a0
  int k;
  
  acquire(&p->lock);
    800023ca:	fffff097          	auipc	ra,0xfffff
    800023ce:	80c080e7          	jalr	-2036(ra) # 80000bd6 <acquire>
  k = p->killed;
    800023d2:	0284a903          	lw	s2,40(s1)
  release(&p->lock);
    800023d6:	8526                	mv	a0,s1
    800023d8:	fffff097          	auipc	ra,0xfffff
    800023dc:	8b2080e7          	jalr	-1870(ra) # 80000c8a <release>
  return k;
}
    800023e0:	854a                	mv	a0,s2
    800023e2:	60e2                	ld	ra,24(sp)
    800023e4:	6442                	ld	s0,16(sp)
    800023e6:	64a2                	ld	s1,8(sp)
    800023e8:	6902                	ld	s2,0(sp)
    800023ea:	6105                	addi	sp,sp,32
    800023ec:	8082                	ret

00000000800023ee <wait>:
{
    800023ee:	715d                	addi	sp,sp,-80
    800023f0:	e486                	sd	ra,72(sp)
    800023f2:	e0a2                	sd	s0,64(sp)
    800023f4:	fc26                	sd	s1,56(sp)
    800023f6:	f84a                	sd	s2,48(sp)
    800023f8:	f44e                	sd	s3,40(sp)
    800023fa:	f052                	sd	s4,32(sp)
    800023fc:	ec56                	sd	s5,24(sp)
    800023fe:	e85a                	sd	s6,16(sp)
    80002400:	e45e                	sd	s7,8(sp)
    80002402:	e062                	sd	s8,0(sp)
    80002404:	0880                	addi	s0,sp,80
    80002406:	8b2a                	mv	s6,a0
  struct proc *p = myproc();
    80002408:	fffff097          	auipc	ra,0xfffff
    8000240c:	5da080e7          	jalr	1498(ra) # 800019e2 <myproc>
    80002410:	892a                	mv	s2,a0
  acquire(&wait_lock);
    80002412:	0000f517          	auipc	a0,0xf
    80002416:	0d650513          	addi	a0,a0,214 # 800114e8 <wait_lock>
    8000241a:	ffffe097          	auipc	ra,0xffffe
    8000241e:	7bc080e7          	jalr	1980(ra) # 80000bd6 <acquire>
    havekids = 0;
    80002422:	4b81                	li	s7,0
        if(pp->state == ZOMBIE){
    80002424:	4a15                	li	s4,5
        havekids = 1;
    80002426:	4a85                	li	s5,1
    for(pp = proc; pp < &proc[NPROC]; pp++){
    80002428:	00015997          	auipc	s3,0x15
    8000242c:	0d898993          	addi	s3,s3,216 # 80017500 <tickslock>
    sleep(p, &wait_lock);  //DOC: wait-sleep
    80002430:	0000fc17          	auipc	s8,0xf
    80002434:	0b8c0c13          	addi	s8,s8,184 # 800114e8 <wait_lock>
    havekids = 0;
    80002438:	875e                	mv	a4,s7
    for(pp = proc; pp < &proc[NPROC]; pp++){
    8000243a:	0000f497          	auipc	s1,0xf
    8000243e:	4c648493          	addi	s1,s1,1222 # 80011900 <proc>
    80002442:	a0bd                	j	800024b0 <wait+0xc2>
          pid = pp->pid;
    80002444:	0304a983          	lw	s3,48(s1)
          if(addr != 0 && copyout(p->pagetable, addr, (char *)&pp->xstate,
    80002448:	000b0e63          	beqz	s6,80002464 <wait+0x76>
    8000244c:	4691                	li	a3,4
    8000244e:	02c48613          	addi	a2,s1,44
    80002452:	85da                	mv	a1,s6
    80002454:	05093503          	ld	a0,80(s2)
    80002458:	fffff097          	auipc	ra,0xfffff
    8000245c:	246080e7          	jalr	582(ra) # 8000169e <copyout>
    80002460:	02054563          	bltz	a0,8000248a <wait+0x9c>
          freeproc(pp);
    80002464:	8526                	mv	a0,s1
    80002466:	fffff097          	auipc	ra,0xfffff
    8000246a:	72e080e7          	jalr	1838(ra) # 80001b94 <freeproc>
          release(&pp->lock);
    8000246e:	8526                	mv	a0,s1
    80002470:	fffff097          	auipc	ra,0xfffff
    80002474:	81a080e7          	jalr	-2022(ra) # 80000c8a <release>
          release(&wait_lock);
    80002478:	0000f517          	auipc	a0,0xf
    8000247c:	07050513          	addi	a0,a0,112 # 800114e8 <wait_lock>
    80002480:	fffff097          	auipc	ra,0xfffff
    80002484:	80a080e7          	jalr	-2038(ra) # 80000c8a <release>
          return pid;
    80002488:	a0b5                	j	800024f4 <wait+0x106>
            release(&pp->lock);
    8000248a:	8526                	mv	a0,s1
    8000248c:	ffffe097          	auipc	ra,0xffffe
    80002490:	7fe080e7          	jalr	2046(ra) # 80000c8a <release>
            release(&wait_lock);
    80002494:	0000f517          	auipc	a0,0xf
    80002498:	05450513          	addi	a0,a0,84 # 800114e8 <wait_lock>
    8000249c:	ffffe097          	auipc	ra,0xffffe
    800024a0:	7ee080e7          	jalr	2030(ra) # 80000c8a <release>
            return -1;
    800024a4:	59fd                	li	s3,-1
    800024a6:	a0b9                	j	800024f4 <wait+0x106>
    for(pp = proc; pp < &proc[NPROC]; pp++){
    800024a8:	17048493          	addi	s1,s1,368
    800024ac:	03348463          	beq	s1,s3,800024d4 <wait+0xe6>
      if(pp->parent == p){
    800024b0:	7c9c                	ld	a5,56(s1)
    800024b2:	ff279be3          	bne	a5,s2,800024a8 <wait+0xba>
        acquire(&pp->lock);
    800024b6:	8526                	mv	a0,s1
    800024b8:	ffffe097          	auipc	ra,0xffffe
    800024bc:	71e080e7          	jalr	1822(ra) # 80000bd6 <acquire>
        if(pp->state == ZOMBIE){
    800024c0:	4c9c                	lw	a5,24(s1)
    800024c2:	f94781e3          	beq	a5,s4,80002444 <wait+0x56>
        release(&pp->lock);
    800024c6:	8526                	mv	a0,s1
    800024c8:	ffffe097          	auipc	ra,0xffffe
    800024cc:	7c2080e7          	jalr	1986(ra) # 80000c8a <release>
        havekids = 1;
    800024d0:	8756                	mv	a4,s5
    800024d2:	bfd9                	j	800024a8 <wait+0xba>
    if(!havekids || killed(p)){
    800024d4:	c719                	beqz	a4,800024e2 <wait+0xf4>
    800024d6:	854a                	mv	a0,s2
    800024d8:	00000097          	auipc	ra,0x0
    800024dc:	ee4080e7          	jalr	-284(ra) # 800023bc <killed>
    800024e0:	c51d                	beqz	a0,8000250e <wait+0x120>
      release(&wait_lock);
    800024e2:	0000f517          	auipc	a0,0xf
    800024e6:	00650513          	addi	a0,a0,6 # 800114e8 <wait_lock>
    800024ea:	ffffe097          	auipc	ra,0xffffe
    800024ee:	7a0080e7          	jalr	1952(ra) # 80000c8a <release>
      return -1;
    800024f2:	59fd                	li	s3,-1
}
    800024f4:	854e                	mv	a0,s3
    800024f6:	60a6                	ld	ra,72(sp)
    800024f8:	6406                	ld	s0,64(sp)
    800024fa:	74e2                	ld	s1,56(sp)
    800024fc:	7942                	ld	s2,48(sp)
    800024fe:	79a2                	ld	s3,40(sp)
    80002500:	7a02                	ld	s4,32(sp)
    80002502:	6ae2                	ld	s5,24(sp)
    80002504:	6b42                	ld	s6,16(sp)
    80002506:	6ba2                	ld	s7,8(sp)
    80002508:	6c02                	ld	s8,0(sp)
    8000250a:	6161                	addi	sp,sp,80
    8000250c:	8082                	ret
    sleep(p, &wait_lock);  //DOC: wait-sleep
    8000250e:	85e2                	mv	a1,s8
    80002510:	854a                	mv	a0,s2
    80002512:	00000097          	auipc	ra,0x0
    80002516:	c02080e7          	jalr	-1022(ra) # 80002114 <sleep>
    havekids = 0;
    8000251a:	bf39                	j	80002438 <wait+0x4a>

000000008000251c <either_copyout>:
// Copy to either a user address, or kernel address,
// depending on usr_dst.
// Returns 0 on success, -1 on error.
int
either_copyout(int user_dst, uint64 dst, void *src, uint64 len)
{
    8000251c:	7179                	addi	sp,sp,-48
    8000251e:	f406                	sd	ra,40(sp)
    80002520:	f022                	sd	s0,32(sp)
    80002522:	ec26                	sd	s1,24(sp)
    80002524:	e84a                	sd	s2,16(sp)
    80002526:	e44e                	sd	s3,8(sp)
    80002528:	e052                	sd	s4,0(sp)
    8000252a:	1800                	addi	s0,sp,48
    8000252c:	84aa                	mv	s1,a0
    8000252e:	892e                	mv	s2,a1
    80002530:	89b2                	mv	s3,a2
    80002532:	8a36                	mv	s4,a3
  struct proc *p = myproc();
    80002534:	fffff097          	auipc	ra,0xfffff
    80002538:	4ae080e7          	jalr	1198(ra) # 800019e2 <myproc>
  if(user_dst){
    8000253c:	c08d                	beqz	s1,8000255e <either_copyout+0x42>
    return copyout(p->pagetable, dst, src, len);
    8000253e:	86d2                	mv	a3,s4
    80002540:	864e                	mv	a2,s3
    80002542:	85ca                	mv	a1,s2
    80002544:	6928                	ld	a0,80(a0)
    80002546:	fffff097          	auipc	ra,0xfffff
    8000254a:	158080e7          	jalr	344(ra) # 8000169e <copyout>
  } else {
    memmove((char *)dst, src, len);
    return 0;
  }
}
    8000254e:	70a2                	ld	ra,40(sp)
    80002550:	7402                	ld	s0,32(sp)
    80002552:	64e2                	ld	s1,24(sp)
    80002554:	6942                	ld	s2,16(sp)
    80002556:	69a2                	ld	s3,8(sp)
    80002558:	6a02                	ld	s4,0(sp)
    8000255a:	6145                	addi	sp,sp,48
    8000255c:	8082                	ret
    memmove((char *)dst, src, len);
    8000255e:	000a061b          	sext.w	a2,s4
    80002562:	85ce                	mv	a1,s3
    80002564:	854a                	mv	a0,s2
    80002566:	ffffe097          	auipc	ra,0xffffe
    8000256a:	7c8080e7          	jalr	1992(ra) # 80000d2e <memmove>
    return 0;
    8000256e:	8526                	mv	a0,s1
    80002570:	bff9                	j	8000254e <either_copyout+0x32>

0000000080002572 <either_copyin>:
// Copy from either a user address, or kernel address,
// depending on usr_src.
// Returns 0 on success, -1 on error.
int
either_copyin(void *dst, int user_src, uint64 src, uint64 len)
{
    80002572:	7179                	addi	sp,sp,-48
    80002574:	f406                	sd	ra,40(sp)
    80002576:	f022                	sd	s0,32(sp)
    80002578:	ec26                	sd	s1,24(sp)
    8000257a:	e84a                	sd	s2,16(sp)
    8000257c:	e44e                	sd	s3,8(sp)
    8000257e:	e052                	sd	s4,0(sp)
    80002580:	1800                	addi	s0,sp,48
    80002582:	892a                	mv	s2,a0
    80002584:	84ae                	mv	s1,a1
    80002586:	89b2                	mv	s3,a2
    80002588:	8a36                	mv	s4,a3
  struct proc *p = myproc();
    8000258a:	fffff097          	auipc	ra,0xfffff
    8000258e:	458080e7          	jalr	1112(ra) # 800019e2 <myproc>
  if(user_src){
    80002592:	c08d                	beqz	s1,800025b4 <either_copyin+0x42>
    return copyin(p->pagetable, dst, src, len);
    80002594:	86d2                	mv	a3,s4
    80002596:	864e                	mv	a2,s3
    80002598:	85ca                	mv	a1,s2
    8000259a:	6928                	ld	a0,80(a0)
    8000259c:	fffff097          	auipc	ra,0xfffff
    800025a0:	18e080e7          	jalr	398(ra) # 8000172a <copyin>
  } else {
    memmove(dst, (char*)src, len);
    return 0;
  }
}
    800025a4:	70a2                	ld	ra,40(sp)
    800025a6:	7402                	ld	s0,32(sp)
    800025a8:	64e2                	ld	s1,24(sp)
    800025aa:	6942                	ld	s2,16(sp)
    800025ac:	69a2                	ld	s3,8(sp)
    800025ae:	6a02                	ld	s4,0(sp)
    800025b0:	6145                	addi	sp,sp,48
    800025b2:	8082                	ret
    memmove(dst, (char*)src, len);
    800025b4:	000a061b          	sext.w	a2,s4
    800025b8:	85ce                	mv	a1,s3
    800025ba:	854a                	mv	a0,s2
    800025bc:	ffffe097          	auipc	ra,0xffffe
    800025c0:	772080e7          	jalr	1906(ra) # 80000d2e <memmove>
    return 0;
    800025c4:	8526                	mv	a0,s1
    800025c6:	bff9                	j	800025a4 <either_copyin+0x32>

00000000800025c8 <procdump>:
// Print a process listing to console.  For debugging.
// Runs when user types ^P on console.
// No lock to avoid wedging a stuck machine further.
void
procdump(void)
{
    800025c8:	715d                	addi	sp,sp,-80
    800025ca:	e486                	sd	ra,72(sp)
    800025cc:	e0a2                	sd	s0,64(sp)
    800025ce:	fc26                	sd	s1,56(sp)
    800025d0:	f84a                	sd	s2,48(sp)
    800025d2:	f44e                	sd	s3,40(sp)
    800025d4:	f052                	sd	s4,32(sp)
    800025d6:	ec56                	sd	s5,24(sp)
    800025d8:	e85a                	sd	s6,16(sp)
    800025da:	e45e                	sd	s7,8(sp)
    800025dc:	0880                	addi	s0,sp,80
  [ZOMBIE]    "zombie"
  };
  struct proc *p;
  char *state;

  printf("\n");
    800025de:	00006517          	auipc	a0,0x6
    800025e2:	afa50513          	addi	a0,a0,-1286 # 800080d8 <digits+0x98>
    800025e6:	ffffe097          	auipc	ra,0xffffe
    800025ea:	fa2080e7          	jalr	-94(ra) # 80000588 <printf>
  for(p = proc; p < &proc[NPROC]; p++){
    800025ee:	0000f497          	auipc	s1,0xf
    800025f2:	46a48493          	addi	s1,s1,1130 # 80011a58 <proc+0x158>
    800025f6:	00015917          	auipc	s2,0x15
    800025fa:	06290913          	addi	s2,s2,98 # 80017658 <bcache+0x140>
    if(p->state == UNUSED)
      continue;
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    800025fe:	4b15                	li	s6,5
      state = states[p->state];
    else
      state = "???";
    80002600:	00006997          	auipc	s3,0x6
    80002604:	ca098993          	addi	s3,s3,-864 # 800082a0 <digits+0x260>
    printf("%d %s %s", p->pid, state, p->name);
    80002608:	00006a97          	auipc	s5,0x6
    8000260c:	ca0a8a93          	addi	s5,s5,-864 # 800082a8 <digits+0x268>
    printf("\n");
    80002610:	00006a17          	auipc	s4,0x6
    80002614:	ac8a0a13          	addi	s4,s4,-1336 # 800080d8 <digits+0x98>
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    80002618:	00006b97          	auipc	s7,0x6
    8000261c:	cd0b8b93          	addi	s7,s7,-816 # 800082e8 <states.0>
    80002620:	a00d                	j	80002642 <procdump+0x7a>
    printf("%d %s %s", p->pid, state, p->name);
    80002622:	ed86a583          	lw	a1,-296(a3)
    80002626:	8556                	mv	a0,s5
    80002628:	ffffe097          	auipc	ra,0xffffe
    8000262c:	f60080e7          	jalr	-160(ra) # 80000588 <printf>
    printf("\n");
    80002630:	8552                	mv	a0,s4
    80002632:	ffffe097          	auipc	ra,0xffffe
    80002636:	f56080e7          	jalr	-170(ra) # 80000588 <printf>
  for(p = proc; p < &proc[NPROC]; p++){
    8000263a:	17048493          	addi	s1,s1,368
    8000263e:	03248163          	beq	s1,s2,80002660 <procdump+0x98>
    if(p->state == UNUSED)
    80002642:	86a6                	mv	a3,s1
    80002644:	ec04a783          	lw	a5,-320(s1)
    80002648:	dbed                	beqz	a5,8000263a <procdump+0x72>
      state = "???";
    8000264a:	864e                	mv	a2,s3
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    8000264c:	fcfb6be3          	bltu	s6,a5,80002622 <procdump+0x5a>
    80002650:	1782                	slli	a5,a5,0x20
    80002652:	9381                	srli	a5,a5,0x20
    80002654:	078e                	slli	a5,a5,0x3
    80002656:	97de                	add	a5,a5,s7
    80002658:	6390                	ld	a2,0(a5)
    8000265a:	f661                	bnez	a2,80002622 <procdump+0x5a>
      state = "???";
    8000265c:	864e                	mv	a2,s3
    8000265e:	b7d1                	j	80002622 <procdump+0x5a>
  }
}
    80002660:	60a6                	ld	ra,72(sp)
    80002662:	6406                	ld	s0,64(sp)
    80002664:	74e2                	ld	s1,56(sp)
    80002666:	7942                	ld	s2,48(sp)
    80002668:	79a2                	ld	s3,40(sp)
    8000266a:	7a02                	ld	s4,32(sp)
    8000266c:	6ae2                	ld	s5,24(sp)
    8000266e:	6b42                	ld	s6,16(sp)
    80002670:	6ba2                	ld	s7,8(sp)
    80002672:	6161                	addi	sp,sp,80
    80002674:	8082                	ret

0000000080002676 <swtch>:
    80002676:	00153023          	sd	ra,0(a0)
    8000267a:	00253423          	sd	sp,8(a0)
    8000267e:	e900                	sd	s0,16(a0)
    80002680:	ed04                	sd	s1,24(a0)
    80002682:	03253023          	sd	s2,32(a0)
    80002686:	03353423          	sd	s3,40(a0)
    8000268a:	03453823          	sd	s4,48(a0)
    8000268e:	03553c23          	sd	s5,56(a0)
    80002692:	05653023          	sd	s6,64(a0)
    80002696:	05753423          	sd	s7,72(a0)
    8000269a:	05853823          	sd	s8,80(a0)
    8000269e:	05953c23          	sd	s9,88(a0)
    800026a2:	07a53023          	sd	s10,96(a0)
    800026a6:	07b53423          	sd	s11,104(a0)
    800026aa:	0005b083          	ld	ra,0(a1)
    800026ae:	0085b103          	ld	sp,8(a1)
    800026b2:	6980                	ld	s0,16(a1)
    800026b4:	6d84                	ld	s1,24(a1)
    800026b6:	0205b903          	ld	s2,32(a1)
    800026ba:	0285b983          	ld	s3,40(a1)
    800026be:	0305ba03          	ld	s4,48(a1)
    800026c2:	0385ba83          	ld	s5,56(a1)
    800026c6:	0405bb03          	ld	s6,64(a1)
    800026ca:	0485bb83          	ld	s7,72(a1)
    800026ce:	0505bc03          	ld	s8,80(a1)
    800026d2:	0585bc83          	ld	s9,88(a1)
    800026d6:	0605bd03          	ld	s10,96(a1)
    800026da:	0685bd83          	ld	s11,104(a1)
    800026de:	8082                	ret

00000000800026e0 <trapinit>:

extern int devintr();

void
trapinit(void)
{
    800026e0:	1141                	addi	sp,sp,-16
    800026e2:	e406                	sd	ra,8(sp)
    800026e4:	e022                	sd	s0,0(sp)
    800026e6:	0800                	addi	s0,sp,16
  initlock(&tickslock, "time");
    800026e8:	00006597          	auipc	a1,0x6
    800026ec:	c3058593          	addi	a1,a1,-976 # 80008318 <states.0+0x30>
    800026f0:	00015517          	auipc	a0,0x15
    800026f4:	e1050513          	addi	a0,a0,-496 # 80017500 <tickslock>
    800026f8:	ffffe097          	auipc	ra,0xffffe
    800026fc:	44e080e7          	jalr	1102(ra) # 80000b46 <initlock>
}
    80002700:	60a2                	ld	ra,8(sp)
    80002702:	6402                	ld	s0,0(sp)
    80002704:	0141                	addi	sp,sp,16
    80002706:	8082                	ret

0000000080002708 <trapinithart>:

// set up to take exceptions and traps while in the kernel.
void
trapinithart(void)
{
    80002708:	1141                	addi	sp,sp,-16
    8000270a:	e422                	sd	s0,8(sp)
    8000270c:	0800                	addi	s0,sp,16
  asm volatile("csrw stvec, %0" : : "r" (x));
    8000270e:	00003797          	auipc	a5,0x3
    80002712:	59278793          	addi	a5,a5,1426 # 80005ca0 <kernelvec>
    80002716:	10579073          	csrw	stvec,a5
  w_stvec((uint64)kernelvec);
}
    8000271a:	6422                	ld	s0,8(sp)
    8000271c:	0141                	addi	sp,sp,16
    8000271e:	8082                	ret

0000000080002720 <usertrapret>:
//
// return to user space
//
void
usertrapret(void)
{
    80002720:	1141                	addi	sp,sp,-16
    80002722:	e406                	sd	ra,8(sp)
    80002724:	e022                	sd	s0,0(sp)
    80002726:	0800                	addi	s0,sp,16
  struct proc *p = myproc();
    80002728:	fffff097          	auipc	ra,0xfffff
    8000272c:	2ba080e7          	jalr	698(ra) # 800019e2 <myproc>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80002730:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() & ~SSTATUS_SIE);
    80002734:	9bf5                	andi	a5,a5,-3
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80002736:	10079073          	csrw	sstatus,a5
  // kerneltrap() to usertrap(), so turn off interrupts until
  // we're back in user space, where usertrap() is correct.
  intr_off();

  // send syscalls, interrupts, and exceptions to uservec in trampoline.S
  uint64 trampoline_uservec = TRAMPOLINE + (uservec - trampoline);
    8000273a:	00005617          	auipc	a2,0x5
    8000273e:	8c660613          	addi	a2,a2,-1850 # 80007000 <_trampoline>
    80002742:	00005697          	auipc	a3,0x5
    80002746:	8be68693          	addi	a3,a3,-1858 # 80007000 <_trampoline>
    8000274a:	8e91                	sub	a3,a3,a2
    8000274c:	040007b7          	lui	a5,0x4000
    80002750:	17fd                	addi	a5,a5,-1
    80002752:	07b2                	slli	a5,a5,0xc
    80002754:	96be                	add	a3,a3,a5
  asm volatile("csrw stvec, %0" : : "r" (x));
    80002756:	10569073          	csrw	stvec,a3
  w_stvec(trampoline_uservec);

  // set up trapframe values that uservec will need when
  // the process next traps into the kernel.
  p->trapframe->kernel_satp = r_satp();         // kernel page table
    8000275a:	6d38                	ld	a4,88(a0)
  asm volatile("csrr %0, satp" : "=r" (x) );
    8000275c:	180026f3          	csrr	a3,satp
    80002760:	e314                	sd	a3,0(a4)
  p->trapframe->kernel_sp = p->kstack + PGSIZE; // process's kernel stack
    80002762:	6d38                	ld	a4,88(a0)
    80002764:	6134                	ld	a3,64(a0)
    80002766:	6585                	lui	a1,0x1
    80002768:	96ae                	add	a3,a3,a1
    8000276a:	e714                	sd	a3,8(a4)
  p->trapframe->kernel_trap = (uint64)usertrap;
    8000276c:	6d38                	ld	a4,88(a0)
    8000276e:	00000697          	auipc	a3,0x0
    80002772:	13068693          	addi	a3,a3,304 # 8000289e <usertrap>
    80002776:	eb14                	sd	a3,16(a4)
  p->trapframe->kernel_hartid = r_tp();         // hartid for cpuid()
    80002778:	6d38                	ld	a4,88(a0)
  asm volatile("mv %0, tp" : "=r" (x) );
    8000277a:	8692                	mv	a3,tp
    8000277c:	f314                	sd	a3,32(a4)
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    8000277e:	100026f3          	csrr	a3,sstatus
  // set up the registers that trampoline.S's sret will use
  // to get to user space.
  
  // set S Previous Privilege mode to User.
  unsigned long x = r_sstatus();
  x &= ~SSTATUS_SPP; // clear SPP to 0 for user mode
    80002782:	eff6f693          	andi	a3,a3,-257
  x |= SSTATUS_SPIE; // enable interrupts in user mode
    80002786:	0206e693          	ori	a3,a3,32
  asm volatile("csrw sstatus, %0" : : "r" (x));
    8000278a:	10069073          	csrw	sstatus,a3
  w_sstatus(x);

  // set S Exception Program Counter to the saved user pc.
  w_sepc(p->trapframe->epc);
    8000278e:	6d38                	ld	a4,88(a0)
  asm volatile("csrw sepc, %0" : : "r" (x));
    80002790:	6f18                	ld	a4,24(a4)
    80002792:	14171073          	csrw	sepc,a4

  // tell trampoline.S the user page table to switch to.
  uint64 satp = MAKE_SATP(p->pagetable);
    80002796:	6928                	ld	a0,80(a0)
    80002798:	8131                	srli	a0,a0,0xc

  // jump to userret in trampoline.S at the top of memory, which 
  // switches to the user page table, restores user registers,
  // and switches to user mode with sret.
  uint64 trampoline_userret = TRAMPOLINE + (userret - trampoline);
    8000279a:	00005717          	auipc	a4,0x5
    8000279e:	90270713          	addi	a4,a4,-1790 # 8000709c <userret>
    800027a2:	8f11                	sub	a4,a4,a2
    800027a4:	97ba                	add	a5,a5,a4
  ((void (*)(uint64))trampoline_userret)(satp);
    800027a6:	577d                	li	a4,-1
    800027a8:	177e                	slli	a4,a4,0x3f
    800027aa:	8d59                	or	a0,a0,a4
    800027ac:	9782                	jalr	a5
}
    800027ae:	60a2                	ld	ra,8(sp)
    800027b0:	6402                	ld	s0,0(sp)
    800027b2:	0141                	addi	sp,sp,16
    800027b4:	8082                	ret

00000000800027b6 <clockintr>:
  w_sstatus(sstatus);
}

void
clockintr()
{
    800027b6:	1101                	addi	sp,sp,-32
    800027b8:	ec06                	sd	ra,24(sp)
    800027ba:	e822                	sd	s0,16(sp)
    800027bc:	e426                	sd	s1,8(sp)
    800027be:	1000                	addi	s0,sp,32
  acquire(&tickslock);
    800027c0:	00015497          	auipc	s1,0x15
    800027c4:	d4048493          	addi	s1,s1,-704 # 80017500 <tickslock>
    800027c8:	8526                	mv	a0,s1
    800027ca:	ffffe097          	auipc	ra,0xffffe
    800027ce:	40c080e7          	jalr	1036(ra) # 80000bd6 <acquire>
  ticks++;
    800027d2:	00007517          	auipc	a0,0x7
    800027d6:	a8e50513          	addi	a0,a0,-1394 # 80009260 <ticks>
    800027da:	411c                	lw	a5,0(a0)
    800027dc:	2785                	addiw	a5,a5,1
    800027de:	c11c                	sw	a5,0(a0)
  wakeup(&ticks);
    800027e0:	00000097          	auipc	ra,0x0
    800027e4:	998080e7          	jalr	-1640(ra) # 80002178 <wakeup>
  release(&tickslock);
    800027e8:	8526                	mv	a0,s1
    800027ea:	ffffe097          	auipc	ra,0xffffe
    800027ee:	4a0080e7          	jalr	1184(ra) # 80000c8a <release>
}
    800027f2:	60e2                	ld	ra,24(sp)
    800027f4:	6442                	ld	s0,16(sp)
    800027f6:	64a2                	ld	s1,8(sp)
    800027f8:	6105                	addi	sp,sp,32
    800027fa:	8082                	ret

00000000800027fc <devintr>:
// returns 2 if timer interrupt,
// 1 if other device,
// 0 if not recognized.
int
devintr()
{
    800027fc:	1101                	addi	sp,sp,-32
    800027fe:	ec06                	sd	ra,24(sp)
    80002800:	e822                	sd	s0,16(sp)
    80002802:	e426                	sd	s1,8(sp)
    80002804:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, scause" : "=r" (x) );
    80002806:	14202773          	csrr	a4,scause
  uint64 scause = r_scause();

  if((scause & 0x8000000000000000L) &&
    8000280a:	00074d63          	bltz	a4,80002824 <devintr+0x28>
    // now allowed to interrupt again.
    if(irq)
      plic_complete(irq);

    return 1;
  } else if(scause == 0x8000000000000001L){
    8000280e:	57fd                	li	a5,-1
    80002810:	17fe                	slli	a5,a5,0x3f
    80002812:	0785                	addi	a5,a5,1
    // the SSIP bit in sip.
    w_sip(r_sip() & ~2);

    return 2;
  } else {
    return 0;
    80002814:	4501                	li	a0,0
  } else if(scause == 0x8000000000000001L){
    80002816:	06f70363          	beq	a4,a5,8000287c <devintr+0x80>
  }
}
    8000281a:	60e2                	ld	ra,24(sp)
    8000281c:	6442                	ld	s0,16(sp)
    8000281e:	64a2                	ld	s1,8(sp)
    80002820:	6105                	addi	sp,sp,32
    80002822:	8082                	ret
     (scause & 0xff) == 9){
    80002824:	0ff77793          	andi	a5,a4,255
  if((scause & 0x8000000000000000L) &&
    80002828:	46a5                	li	a3,9
    8000282a:	fed792e3          	bne	a5,a3,8000280e <devintr+0x12>
    int irq = plic_claim();
    8000282e:	00003097          	auipc	ra,0x3
    80002832:	57a080e7          	jalr	1402(ra) # 80005da8 <plic_claim>
    80002836:	84aa                	mv	s1,a0
    if(irq == UART0_IRQ){
    80002838:	47a9                	li	a5,10
    8000283a:	02f50763          	beq	a0,a5,80002868 <devintr+0x6c>
    } else if(irq == VIRTIO0_IRQ){
    8000283e:	4785                	li	a5,1
    80002840:	02f50963          	beq	a0,a5,80002872 <devintr+0x76>
    return 1;
    80002844:	4505                	li	a0,1
    } else if(irq){
    80002846:	d8f1                	beqz	s1,8000281a <devintr+0x1e>
      printf("unexpected interrupt irq=%d\n", irq);
    80002848:	85a6                	mv	a1,s1
    8000284a:	00006517          	auipc	a0,0x6
    8000284e:	ad650513          	addi	a0,a0,-1322 # 80008320 <states.0+0x38>
    80002852:	ffffe097          	auipc	ra,0xffffe
    80002856:	d36080e7          	jalr	-714(ra) # 80000588 <printf>
      plic_complete(irq);
    8000285a:	8526                	mv	a0,s1
    8000285c:	00003097          	auipc	ra,0x3
    80002860:	570080e7          	jalr	1392(ra) # 80005dcc <plic_complete>
    return 1;
    80002864:	4505                	li	a0,1
    80002866:	bf55                	j	8000281a <devintr+0x1e>
      uartintr();
    80002868:	ffffe097          	auipc	ra,0xffffe
    8000286c:	132080e7          	jalr	306(ra) # 8000099a <uartintr>
    80002870:	b7ed                	j	8000285a <devintr+0x5e>
      virtio_disk_intr();
    80002872:	00004097          	auipc	ra,0x4
    80002876:	a26080e7          	jalr	-1498(ra) # 80006298 <virtio_disk_intr>
    8000287a:	b7c5                	j	8000285a <devintr+0x5e>
    if(cpuid() == 0){
    8000287c:	fffff097          	auipc	ra,0xfffff
    80002880:	13a080e7          	jalr	314(ra) # 800019b6 <cpuid>
    80002884:	c901                	beqz	a0,80002894 <devintr+0x98>
  asm volatile("csrr %0, sip" : "=r" (x) );
    80002886:	144027f3          	csrr	a5,sip
    w_sip(r_sip() & ~2);
    8000288a:	9bf5                	andi	a5,a5,-3
  asm volatile("csrw sip, %0" : : "r" (x));
    8000288c:	14479073          	csrw	sip,a5
    return 2;
    80002890:	4509                	li	a0,2
    80002892:	b761                	j	8000281a <devintr+0x1e>
      clockintr();
    80002894:	00000097          	auipc	ra,0x0
    80002898:	f22080e7          	jalr	-222(ra) # 800027b6 <clockintr>
    8000289c:	b7ed                	j	80002886 <devintr+0x8a>

000000008000289e <usertrap>:
{
    8000289e:	1101                	addi	sp,sp,-32
    800028a0:	ec06                	sd	ra,24(sp)
    800028a2:	e822                	sd	s0,16(sp)
    800028a4:	e426                	sd	s1,8(sp)
    800028a6:	e04a                	sd	s2,0(sp)
    800028a8:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    800028aa:	100027f3          	csrr	a5,sstatus
  if((r_sstatus() & SSTATUS_SPP) != 0)
    800028ae:	1007f793          	andi	a5,a5,256
    800028b2:	e3b1                	bnez	a5,800028f6 <usertrap+0x58>
  asm volatile("csrw stvec, %0" : : "r" (x));
    800028b4:	00003797          	auipc	a5,0x3
    800028b8:	3ec78793          	addi	a5,a5,1004 # 80005ca0 <kernelvec>
    800028bc:	10579073          	csrw	stvec,a5
  struct proc *p = myproc();
    800028c0:	fffff097          	auipc	ra,0xfffff
    800028c4:	122080e7          	jalr	290(ra) # 800019e2 <myproc>
    800028c8:	84aa                	mv	s1,a0
  p->trapframe->epc = r_sepc();
    800028ca:	6d3c                	ld	a5,88(a0)
  asm volatile("csrr %0, sepc" : "=r" (x) );
    800028cc:	14102773          	csrr	a4,sepc
    800028d0:	ef98                	sd	a4,24(a5)
  asm volatile("csrr %0, scause" : "=r" (x) );
    800028d2:	14202773          	csrr	a4,scause
  if(r_scause() == 8){
    800028d6:	47a1                	li	a5,8
    800028d8:	02f70763          	beq	a4,a5,80002906 <usertrap+0x68>
  } else if((which_dev = devintr()) != 0){
    800028dc:	00000097          	auipc	ra,0x0
    800028e0:	f20080e7          	jalr	-224(ra) # 800027fc <devintr>
    800028e4:	892a                	mv	s2,a0
    800028e6:	c151                	beqz	a0,8000296a <usertrap+0xcc>
  if(killed(p))
    800028e8:	8526                	mv	a0,s1
    800028ea:	00000097          	auipc	ra,0x0
    800028ee:	ad2080e7          	jalr	-1326(ra) # 800023bc <killed>
    800028f2:	c929                	beqz	a0,80002944 <usertrap+0xa6>
    800028f4:	a099                	j	8000293a <usertrap+0x9c>
    panic("usertrap: not from user mode");
    800028f6:	00006517          	auipc	a0,0x6
    800028fa:	a4a50513          	addi	a0,a0,-1462 # 80008340 <states.0+0x58>
    800028fe:	ffffe097          	auipc	ra,0xffffe
    80002902:	c40080e7          	jalr	-960(ra) # 8000053e <panic>
    if(killed(p))
    80002906:	00000097          	auipc	ra,0x0
    8000290a:	ab6080e7          	jalr	-1354(ra) # 800023bc <killed>
    8000290e:	e921                	bnez	a0,8000295e <usertrap+0xc0>
    p->trapframe->epc += 4;
    80002910:	6cb8                	ld	a4,88(s1)
    80002912:	6f1c                	ld	a5,24(a4)
    80002914:	0791                	addi	a5,a5,4
    80002916:	ef1c                	sd	a5,24(a4)
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80002918:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    8000291c:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80002920:	10079073          	csrw	sstatus,a5
    syscall();
    80002924:	00000097          	auipc	ra,0x0
    80002928:	2d4080e7          	jalr	724(ra) # 80002bf8 <syscall>
  if(killed(p))
    8000292c:	8526                	mv	a0,s1
    8000292e:	00000097          	auipc	ra,0x0
    80002932:	a8e080e7          	jalr	-1394(ra) # 800023bc <killed>
    80002936:	c911                	beqz	a0,8000294a <usertrap+0xac>
    80002938:	4901                	li	s2,0
    exit(-1);
    8000293a:	557d                	li	a0,-1
    8000293c:	00000097          	auipc	ra,0x0
    80002940:	90c080e7          	jalr	-1780(ra) # 80002248 <exit>
  if(which_dev == 2)
    80002944:	4789                	li	a5,2
    80002946:	04f90f63          	beq	s2,a5,800029a4 <usertrap+0x106>
  usertrapret();
    8000294a:	00000097          	auipc	ra,0x0
    8000294e:	dd6080e7          	jalr	-554(ra) # 80002720 <usertrapret>
}
    80002952:	60e2                	ld	ra,24(sp)
    80002954:	6442                	ld	s0,16(sp)
    80002956:	64a2                	ld	s1,8(sp)
    80002958:	6902                	ld	s2,0(sp)
    8000295a:	6105                	addi	sp,sp,32
    8000295c:	8082                	ret
      exit(-1);
    8000295e:	557d                	li	a0,-1
    80002960:	00000097          	auipc	ra,0x0
    80002964:	8e8080e7          	jalr	-1816(ra) # 80002248 <exit>
    80002968:	b765                	j	80002910 <usertrap+0x72>
  asm volatile("csrr %0, scause" : "=r" (x) );
    8000296a:	142025f3          	csrr	a1,scause
    printf("usertrap(): unexpected scause %p pid=%d\n", r_scause(), p->pid);
    8000296e:	5890                	lw	a2,48(s1)
    80002970:	00006517          	auipc	a0,0x6
    80002974:	9f050513          	addi	a0,a0,-1552 # 80008360 <states.0+0x78>
    80002978:	ffffe097          	auipc	ra,0xffffe
    8000297c:	c10080e7          	jalr	-1008(ra) # 80000588 <printf>
  asm volatile("csrr %0, sepc" : "=r" (x) );
    80002980:	141025f3          	csrr	a1,sepc
  asm volatile("csrr %0, stval" : "=r" (x) );
    80002984:	14302673          	csrr	a2,stval
    printf("            sepc=%p stval=%p\n", r_sepc(), r_stval());
    80002988:	00006517          	auipc	a0,0x6
    8000298c:	a0850513          	addi	a0,a0,-1528 # 80008390 <states.0+0xa8>
    80002990:	ffffe097          	auipc	ra,0xffffe
    80002994:	bf8080e7          	jalr	-1032(ra) # 80000588 <printf>
    setkilled(p);
    80002998:	8526                	mv	a0,s1
    8000299a:	00000097          	auipc	ra,0x0
    8000299e:	9f6080e7          	jalr	-1546(ra) # 80002390 <setkilled>
    800029a2:	b769                	j	8000292c <usertrap+0x8e>
    yield();
    800029a4:	fffff097          	auipc	ra,0xfffff
    800029a8:	734080e7          	jalr	1844(ra) # 800020d8 <yield>
    800029ac:	bf79                	j	8000294a <usertrap+0xac>

00000000800029ae <kerneltrap>:
{
    800029ae:	7179                	addi	sp,sp,-48
    800029b0:	f406                	sd	ra,40(sp)
    800029b2:	f022                	sd	s0,32(sp)
    800029b4:	ec26                	sd	s1,24(sp)
    800029b6:	e84a                	sd	s2,16(sp)
    800029b8:	e44e                	sd	s3,8(sp)
    800029ba:	1800                	addi	s0,sp,48
  asm volatile("csrr %0, sepc" : "=r" (x) );
    800029bc:	14102973          	csrr	s2,sepc
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    800029c0:	100024f3          	csrr	s1,sstatus
  asm volatile("csrr %0, scause" : "=r" (x) );
    800029c4:	142029f3          	csrr	s3,scause
  if((sstatus & SSTATUS_SPP) == 0)
    800029c8:	1004f793          	andi	a5,s1,256
    800029cc:	cb85                	beqz	a5,800029fc <kerneltrap+0x4e>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    800029ce:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    800029d2:	8b89                	andi	a5,a5,2
  if(intr_get() != 0)
    800029d4:	ef85                	bnez	a5,80002a0c <kerneltrap+0x5e>
  if((which_dev = devintr()) == 0){
    800029d6:	00000097          	auipc	ra,0x0
    800029da:	e26080e7          	jalr	-474(ra) # 800027fc <devintr>
    800029de:	cd1d                	beqz	a0,80002a1c <kerneltrap+0x6e>
  if(which_dev == 2 && myproc() != 0 && myproc()->state == RUNNING)
    800029e0:	4789                	li	a5,2
    800029e2:	06f50a63          	beq	a0,a5,80002a56 <kerneltrap+0xa8>
  asm volatile("csrw sepc, %0" : : "r" (x));
    800029e6:	14191073          	csrw	sepc,s2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    800029ea:	10049073          	csrw	sstatus,s1
}
    800029ee:	70a2                	ld	ra,40(sp)
    800029f0:	7402                	ld	s0,32(sp)
    800029f2:	64e2                	ld	s1,24(sp)
    800029f4:	6942                	ld	s2,16(sp)
    800029f6:	69a2                	ld	s3,8(sp)
    800029f8:	6145                	addi	sp,sp,48
    800029fa:	8082                	ret
    panic("kerneltrap: not from supervisor mode");
    800029fc:	00006517          	auipc	a0,0x6
    80002a00:	9b450513          	addi	a0,a0,-1612 # 800083b0 <states.0+0xc8>
    80002a04:	ffffe097          	auipc	ra,0xffffe
    80002a08:	b3a080e7          	jalr	-1222(ra) # 8000053e <panic>
    panic("kerneltrap: interrupts enabled");
    80002a0c:	00006517          	auipc	a0,0x6
    80002a10:	9cc50513          	addi	a0,a0,-1588 # 800083d8 <states.0+0xf0>
    80002a14:	ffffe097          	auipc	ra,0xffffe
    80002a18:	b2a080e7          	jalr	-1238(ra) # 8000053e <panic>
    printf("scause %p\n", scause);
    80002a1c:	85ce                	mv	a1,s3
    80002a1e:	00006517          	auipc	a0,0x6
    80002a22:	9da50513          	addi	a0,a0,-1574 # 800083f8 <states.0+0x110>
    80002a26:	ffffe097          	auipc	ra,0xffffe
    80002a2a:	b62080e7          	jalr	-1182(ra) # 80000588 <printf>
  asm volatile("csrr %0, sepc" : "=r" (x) );
    80002a2e:	141025f3          	csrr	a1,sepc
  asm volatile("csrr %0, stval" : "=r" (x) );
    80002a32:	14302673          	csrr	a2,stval
    printf("sepc=%p stval=%p\n", r_sepc(), r_stval());
    80002a36:	00006517          	auipc	a0,0x6
    80002a3a:	9d250513          	addi	a0,a0,-1582 # 80008408 <states.0+0x120>
    80002a3e:	ffffe097          	auipc	ra,0xffffe
    80002a42:	b4a080e7          	jalr	-1206(ra) # 80000588 <printf>
    panic("kerneltrap");
    80002a46:	00006517          	auipc	a0,0x6
    80002a4a:	9da50513          	addi	a0,a0,-1574 # 80008420 <states.0+0x138>
    80002a4e:	ffffe097          	auipc	ra,0xffffe
    80002a52:	af0080e7          	jalr	-1296(ra) # 8000053e <panic>
  if(which_dev == 2 && myproc() != 0 && myproc()->state == RUNNING)
    80002a56:	fffff097          	auipc	ra,0xfffff
    80002a5a:	f8c080e7          	jalr	-116(ra) # 800019e2 <myproc>
    80002a5e:	d541                	beqz	a0,800029e6 <kerneltrap+0x38>
    80002a60:	fffff097          	auipc	ra,0xfffff
    80002a64:	f82080e7          	jalr	-126(ra) # 800019e2 <myproc>
    80002a68:	4d18                	lw	a4,24(a0)
    80002a6a:	4791                	li	a5,4
    80002a6c:	f6f71de3          	bne	a4,a5,800029e6 <kerneltrap+0x38>
    yield();
    80002a70:	fffff097          	auipc	ra,0xfffff
    80002a74:	668080e7          	jalr	1640(ra) # 800020d8 <yield>
    80002a78:	b7bd                	j	800029e6 <kerneltrap+0x38>

0000000080002a7a <argraw>:
  return strlen(buf);
}

static uint64
argraw(int n)
{
    80002a7a:	1101                	addi	sp,sp,-32
    80002a7c:	ec06                	sd	ra,24(sp)
    80002a7e:	e822                	sd	s0,16(sp)
    80002a80:	e426                	sd	s1,8(sp)
    80002a82:	1000                	addi	s0,sp,32
    80002a84:	84aa                	mv	s1,a0
  struct proc *p = myproc();
    80002a86:	fffff097          	auipc	ra,0xfffff
    80002a8a:	f5c080e7          	jalr	-164(ra) # 800019e2 <myproc>
  switch (n) {
    80002a8e:	4795                	li	a5,5
    80002a90:	0497e163          	bltu	a5,s1,80002ad2 <argraw+0x58>
    80002a94:	048a                	slli	s1,s1,0x2
    80002a96:	00006717          	auipc	a4,0x6
    80002a9a:	9c270713          	addi	a4,a4,-1598 # 80008458 <states.0+0x170>
    80002a9e:	94ba                	add	s1,s1,a4
    80002aa0:	409c                	lw	a5,0(s1)
    80002aa2:	97ba                	add	a5,a5,a4
    80002aa4:	8782                	jr	a5
  case 0:
    return p->trapframe->a0;
    80002aa6:	6d3c                	ld	a5,88(a0)
    80002aa8:	7ba8                	ld	a0,112(a5)
  case 5:
    return p->trapframe->a5;
  }
  panic("argraw");
  return -1;
}
    80002aaa:	60e2                	ld	ra,24(sp)
    80002aac:	6442                	ld	s0,16(sp)
    80002aae:	64a2                	ld	s1,8(sp)
    80002ab0:	6105                	addi	sp,sp,32
    80002ab2:	8082                	ret
    return p->trapframe->a1;
    80002ab4:	6d3c                	ld	a5,88(a0)
    80002ab6:	7fa8                	ld	a0,120(a5)
    80002ab8:	bfcd                	j	80002aaa <argraw+0x30>
    return p->trapframe->a2;
    80002aba:	6d3c                	ld	a5,88(a0)
    80002abc:	63c8                	ld	a0,128(a5)
    80002abe:	b7f5                	j	80002aaa <argraw+0x30>
    return p->trapframe->a3;
    80002ac0:	6d3c                	ld	a5,88(a0)
    80002ac2:	67c8                	ld	a0,136(a5)
    80002ac4:	b7dd                	j	80002aaa <argraw+0x30>
    return p->trapframe->a4;
    80002ac6:	6d3c                	ld	a5,88(a0)
    80002ac8:	6bc8                	ld	a0,144(a5)
    80002aca:	b7c5                	j	80002aaa <argraw+0x30>
    return p->trapframe->a5;
    80002acc:	6d3c                	ld	a5,88(a0)
    80002ace:	6fc8                	ld	a0,152(a5)
    80002ad0:	bfe9                	j	80002aaa <argraw+0x30>
  panic("argraw");
    80002ad2:	00006517          	auipc	a0,0x6
    80002ad6:	95e50513          	addi	a0,a0,-1698 # 80008430 <states.0+0x148>
    80002ada:	ffffe097          	auipc	ra,0xffffe
    80002ade:	a64080e7          	jalr	-1436(ra) # 8000053e <panic>

0000000080002ae2 <fetchaddr>:
{
    80002ae2:	1101                	addi	sp,sp,-32
    80002ae4:	ec06                	sd	ra,24(sp)
    80002ae6:	e822                	sd	s0,16(sp)
    80002ae8:	e426                	sd	s1,8(sp)
    80002aea:	e04a                	sd	s2,0(sp)
    80002aec:	1000                	addi	s0,sp,32
    80002aee:	84aa                	mv	s1,a0
    80002af0:	892e                	mv	s2,a1
  struct proc *p = myproc();
    80002af2:	fffff097          	auipc	ra,0xfffff
    80002af6:	ef0080e7          	jalr	-272(ra) # 800019e2 <myproc>
  if(addr >= p->sz || addr+sizeof(uint64) > p->sz) // both tests needed, in case of overflow
    80002afa:	653c                	ld	a5,72(a0)
    80002afc:	02f4f863          	bgeu	s1,a5,80002b2c <fetchaddr+0x4a>
    80002b00:	00848713          	addi	a4,s1,8
    80002b04:	02e7e663          	bltu	a5,a4,80002b30 <fetchaddr+0x4e>
  if(copyin(p->pagetable, (char *)ip, addr, sizeof(*ip)) != 0)
    80002b08:	46a1                	li	a3,8
    80002b0a:	8626                	mv	a2,s1
    80002b0c:	85ca                	mv	a1,s2
    80002b0e:	6928                	ld	a0,80(a0)
    80002b10:	fffff097          	auipc	ra,0xfffff
    80002b14:	c1a080e7          	jalr	-998(ra) # 8000172a <copyin>
    80002b18:	00a03533          	snez	a0,a0
    80002b1c:	40a00533          	neg	a0,a0
}
    80002b20:	60e2                	ld	ra,24(sp)
    80002b22:	6442                	ld	s0,16(sp)
    80002b24:	64a2                	ld	s1,8(sp)
    80002b26:	6902                	ld	s2,0(sp)
    80002b28:	6105                	addi	sp,sp,32
    80002b2a:	8082                	ret
    return -1;
    80002b2c:	557d                	li	a0,-1
    80002b2e:	bfcd                	j	80002b20 <fetchaddr+0x3e>
    80002b30:	557d                	li	a0,-1
    80002b32:	b7fd                	j	80002b20 <fetchaddr+0x3e>

0000000080002b34 <fetchstr>:
{
    80002b34:	7179                	addi	sp,sp,-48
    80002b36:	f406                	sd	ra,40(sp)
    80002b38:	f022                	sd	s0,32(sp)
    80002b3a:	ec26                	sd	s1,24(sp)
    80002b3c:	e84a                	sd	s2,16(sp)
    80002b3e:	e44e                	sd	s3,8(sp)
    80002b40:	1800                	addi	s0,sp,48
    80002b42:	892a                	mv	s2,a0
    80002b44:	84ae                	mv	s1,a1
    80002b46:	89b2                	mv	s3,a2
  struct proc *p = myproc();
    80002b48:	fffff097          	auipc	ra,0xfffff
    80002b4c:	e9a080e7          	jalr	-358(ra) # 800019e2 <myproc>
  if(copyinstr(p->pagetable, buf, addr, max) < 0)
    80002b50:	86ce                	mv	a3,s3
    80002b52:	864a                	mv	a2,s2
    80002b54:	85a6                	mv	a1,s1
    80002b56:	6928                	ld	a0,80(a0)
    80002b58:	fffff097          	auipc	ra,0xfffff
    80002b5c:	c60080e7          	jalr	-928(ra) # 800017b8 <copyinstr>
    80002b60:	00054e63          	bltz	a0,80002b7c <fetchstr+0x48>
  return strlen(buf);
    80002b64:	8526                	mv	a0,s1
    80002b66:	ffffe097          	auipc	ra,0xffffe
    80002b6a:	2e8080e7          	jalr	744(ra) # 80000e4e <strlen>
}
    80002b6e:	70a2                	ld	ra,40(sp)
    80002b70:	7402                	ld	s0,32(sp)
    80002b72:	64e2                	ld	s1,24(sp)
    80002b74:	6942                	ld	s2,16(sp)
    80002b76:	69a2                	ld	s3,8(sp)
    80002b78:	6145                	addi	sp,sp,48
    80002b7a:	8082                	ret
    return -1;
    80002b7c:	557d                	li	a0,-1
    80002b7e:	bfc5                	j	80002b6e <fetchstr+0x3a>

0000000080002b80 <argint>:

// Fetch the nth 32-bit system call argument.
void
argint(int n, int *ip)
{
    80002b80:	1101                	addi	sp,sp,-32
    80002b82:	ec06                	sd	ra,24(sp)
    80002b84:	e822                	sd	s0,16(sp)
    80002b86:	e426                	sd	s1,8(sp)
    80002b88:	1000                	addi	s0,sp,32
    80002b8a:	84ae                	mv	s1,a1
  *ip = argraw(n);
    80002b8c:	00000097          	auipc	ra,0x0
    80002b90:	eee080e7          	jalr	-274(ra) # 80002a7a <argraw>
    80002b94:	c088                	sw	a0,0(s1)
}
    80002b96:	60e2                	ld	ra,24(sp)
    80002b98:	6442                	ld	s0,16(sp)
    80002b9a:	64a2                	ld	s1,8(sp)
    80002b9c:	6105                	addi	sp,sp,32
    80002b9e:	8082                	ret

0000000080002ba0 <argaddr>:
// Retrieve an argument as a pointer.
// Doesn't check for legality, since
// copyin/copyout will do that.
void
argaddr(int n, uint64 *ip)
{
    80002ba0:	1101                	addi	sp,sp,-32
    80002ba2:	ec06                	sd	ra,24(sp)
    80002ba4:	e822                	sd	s0,16(sp)
    80002ba6:	e426                	sd	s1,8(sp)
    80002ba8:	1000                	addi	s0,sp,32
    80002baa:	84ae                	mv	s1,a1
  *ip = argraw(n);
    80002bac:	00000097          	auipc	ra,0x0
    80002bb0:	ece080e7          	jalr	-306(ra) # 80002a7a <argraw>
    80002bb4:	e088                	sd	a0,0(s1)
}
    80002bb6:	60e2                	ld	ra,24(sp)
    80002bb8:	6442                	ld	s0,16(sp)
    80002bba:	64a2                	ld	s1,8(sp)
    80002bbc:	6105                	addi	sp,sp,32
    80002bbe:	8082                	ret

0000000080002bc0 <argstr>:
// Fetch the nth word-sized system call argument as a null-terminated string.
// Copies into buf, at most max.
// Returns string length if OK (including nul), -1 if error.
int
argstr(int n, char *buf, int max)
{
    80002bc0:	7179                	addi	sp,sp,-48
    80002bc2:	f406                	sd	ra,40(sp)
    80002bc4:	f022                	sd	s0,32(sp)
    80002bc6:	ec26                	sd	s1,24(sp)
    80002bc8:	e84a                	sd	s2,16(sp)
    80002bca:	1800                	addi	s0,sp,48
    80002bcc:	84ae                	mv	s1,a1
    80002bce:	8932                	mv	s2,a2
  uint64 addr;
  argaddr(n, &addr);
    80002bd0:	fd840593          	addi	a1,s0,-40
    80002bd4:	00000097          	auipc	ra,0x0
    80002bd8:	fcc080e7          	jalr	-52(ra) # 80002ba0 <argaddr>
  return fetchstr(addr, buf, max);
    80002bdc:	864a                	mv	a2,s2
    80002bde:	85a6                	mv	a1,s1
    80002be0:	fd843503          	ld	a0,-40(s0)
    80002be4:	00000097          	auipc	ra,0x0
    80002be8:	f50080e7          	jalr	-176(ra) # 80002b34 <fetchstr>
}
    80002bec:	70a2                	ld	ra,40(sp)
    80002bee:	7402                	ld	s0,32(sp)
    80002bf0:	64e2                	ld	s1,24(sp)
    80002bf2:	6942                	ld	s2,16(sp)
    80002bf4:	6145                	addi	sp,sp,48
    80002bf6:	8082                	ret

0000000080002bf8 <syscall>:
[SYS_map_display]    sys_map_display,
};

void
syscall(void)
{
    80002bf8:	1101                	addi	sp,sp,-32
    80002bfa:	ec06                	sd	ra,24(sp)
    80002bfc:	e822                	sd	s0,16(sp)
    80002bfe:	e426                	sd	s1,8(sp)
    80002c00:	e04a                	sd	s2,0(sp)
    80002c02:	1000                	addi	s0,sp,32
  int num;
  struct proc *p = myproc();
    80002c04:	fffff097          	auipc	ra,0xfffff
    80002c08:	dde080e7          	jalr	-546(ra) # 800019e2 <myproc>
    80002c0c:	84aa                	mv	s1,a0

  num = p->trapframe->a7;
    80002c0e:	05853903          	ld	s2,88(a0)
    80002c12:	0a893783          	ld	a5,168(s2)
    80002c16:	0007869b          	sext.w	a3,a5
  if(num > 0 && num < NELEM(syscalls) && syscalls[num]) {
    80002c1a:	37fd                	addiw	a5,a5,-1
    80002c1c:	4759                	li	a4,22
    80002c1e:	00f76f63          	bltu	a4,a5,80002c3c <syscall+0x44>
    80002c22:	00369713          	slli	a4,a3,0x3
    80002c26:	00006797          	auipc	a5,0x6
    80002c2a:	84a78793          	addi	a5,a5,-1974 # 80008470 <syscalls>
    80002c2e:	97ba                	add	a5,a5,a4
    80002c30:	639c                	ld	a5,0(a5)
    80002c32:	c789                	beqz	a5,80002c3c <syscall+0x44>
    // Use num to lookup the system call function for num, call it,
    // and store its return value in p->trapframe->a0
    p->trapframe->a0 = syscalls[num]();
    80002c34:	9782                	jalr	a5
    80002c36:	06a93823          	sd	a0,112(s2)
    80002c3a:	a839                	j	80002c58 <syscall+0x60>
  } else {
    printf("%d %s: unknown sys call %d\n",
    80002c3c:	15848613          	addi	a2,s1,344
    80002c40:	588c                	lw	a1,48(s1)
    80002c42:	00005517          	auipc	a0,0x5
    80002c46:	7f650513          	addi	a0,a0,2038 # 80008438 <states.0+0x150>
    80002c4a:	ffffe097          	auipc	ra,0xffffe
    80002c4e:	93e080e7          	jalr	-1730(ra) # 80000588 <printf>
            p->pid, p->name, num);
    p->trapframe->a0 = -1;
    80002c52:	6cbc                	ld	a5,88(s1)
    80002c54:	577d                	li	a4,-1
    80002c56:	fbb8                	sd	a4,112(a5)
  }
}
    80002c58:	60e2                	ld	ra,24(sp)
    80002c5a:	6442                	ld	s0,16(sp)
    80002c5c:	64a2                	ld	s1,8(sp)
    80002c5e:	6902                	ld	s2,0(sp)
    80002c60:	6105                	addi	sp,sp,32
    80002c62:	8082                	ret

0000000080002c64 <sys_exit>:
#include "spinlock.h"
#include "proc.h"

uint64
sys_exit(void)
{
    80002c64:	1101                	addi	sp,sp,-32
    80002c66:	ec06                	sd	ra,24(sp)
    80002c68:	e822                	sd	s0,16(sp)
    80002c6a:	1000                	addi	s0,sp,32
  int n;
  argint(0, &n);
    80002c6c:	fec40593          	addi	a1,s0,-20
    80002c70:	4501                	li	a0,0
    80002c72:	00000097          	auipc	ra,0x0
    80002c76:	f0e080e7          	jalr	-242(ra) # 80002b80 <argint>
  exit(n);
    80002c7a:	fec42503          	lw	a0,-20(s0)
    80002c7e:	fffff097          	auipc	ra,0xfffff
    80002c82:	5ca080e7          	jalr	1482(ra) # 80002248 <exit>
  return 0;  // not reached
}
    80002c86:	4501                	li	a0,0
    80002c88:	60e2                	ld	ra,24(sp)
    80002c8a:	6442                	ld	s0,16(sp)
    80002c8c:	6105                	addi	sp,sp,32
    80002c8e:	8082                	ret

0000000080002c90 <sys_getpid>:

uint64
sys_getpid(void)
{
    80002c90:	1141                	addi	sp,sp,-16
    80002c92:	e406                	sd	ra,8(sp)
    80002c94:	e022                	sd	s0,0(sp)
    80002c96:	0800                	addi	s0,sp,16
  return myproc()->pid;
    80002c98:	fffff097          	auipc	ra,0xfffff
    80002c9c:	d4a080e7          	jalr	-694(ra) # 800019e2 <myproc>
}
    80002ca0:	5908                	lw	a0,48(a0)
    80002ca2:	60a2                	ld	ra,8(sp)
    80002ca4:	6402                	ld	s0,0(sp)
    80002ca6:	0141                	addi	sp,sp,16
    80002ca8:	8082                	ret

0000000080002caa <sys_fork>:

uint64
sys_fork(void)
{
    80002caa:	1141                	addi	sp,sp,-16
    80002cac:	e406                	sd	ra,8(sp)
    80002cae:	e022                	sd	s0,0(sp)
    80002cb0:	0800                	addi	s0,sp,16
  return fork();
    80002cb2:	fffff097          	auipc	ra,0xfffff
    80002cb6:	170080e7          	jalr	368(ra) # 80001e22 <fork>
}
    80002cba:	60a2                	ld	ra,8(sp)
    80002cbc:	6402                	ld	s0,0(sp)
    80002cbe:	0141                	addi	sp,sp,16
    80002cc0:	8082                	ret

0000000080002cc2 <sys_wait>:

uint64
sys_wait(void)
{
    80002cc2:	1101                	addi	sp,sp,-32
    80002cc4:	ec06                	sd	ra,24(sp)
    80002cc6:	e822                	sd	s0,16(sp)
    80002cc8:	1000                	addi	s0,sp,32
  uint64 p;
  argaddr(0, &p);
    80002cca:	fe840593          	addi	a1,s0,-24
    80002cce:	4501                	li	a0,0
    80002cd0:	00000097          	auipc	ra,0x0
    80002cd4:	ed0080e7          	jalr	-304(ra) # 80002ba0 <argaddr>
  return wait(p);
    80002cd8:	fe843503          	ld	a0,-24(s0)
    80002cdc:	fffff097          	auipc	ra,0xfffff
    80002ce0:	712080e7          	jalr	1810(ra) # 800023ee <wait>
}
    80002ce4:	60e2                	ld	ra,24(sp)
    80002ce6:	6442                	ld	s0,16(sp)
    80002ce8:	6105                	addi	sp,sp,32
    80002cea:	8082                	ret

0000000080002cec <sys_sbrk>:

uint64
sys_sbrk(void)
{
    80002cec:	7179                	addi	sp,sp,-48
    80002cee:	f406                	sd	ra,40(sp)
    80002cf0:	f022                	sd	s0,32(sp)
    80002cf2:	ec26                	sd	s1,24(sp)
    80002cf4:	1800                	addi	s0,sp,48
  uint64 addr;
  int n;

  argint(0, &n);
    80002cf6:	fdc40593          	addi	a1,s0,-36
    80002cfa:	4501                	li	a0,0
    80002cfc:	00000097          	auipc	ra,0x0
    80002d00:	e84080e7          	jalr	-380(ra) # 80002b80 <argint>
  addr = myproc()->sz;
    80002d04:	fffff097          	auipc	ra,0xfffff
    80002d08:	cde080e7          	jalr	-802(ra) # 800019e2 <myproc>
    80002d0c:	6524                	ld	s1,72(a0)
  if(growproc(n) < 0)
    80002d0e:	fdc42503          	lw	a0,-36(s0)
    80002d12:	fffff097          	auipc	ra,0xfffff
    80002d16:	0b4080e7          	jalr	180(ra) # 80001dc6 <growproc>
    80002d1a:	00054863          	bltz	a0,80002d2a <sys_sbrk+0x3e>
    return -1;
  return addr;
}
    80002d1e:	8526                	mv	a0,s1
    80002d20:	70a2                	ld	ra,40(sp)
    80002d22:	7402                	ld	s0,32(sp)
    80002d24:	64e2                	ld	s1,24(sp)
    80002d26:	6145                	addi	sp,sp,48
    80002d28:	8082                	ret
    return -1;
    80002d2a:	54fd                	li	s1,-1
    80002d2c:	bfcd                	j	80002d1e <sys_sbrk+0x32>

0000000080002d2e <sys_sleep>:

uint64
sys_sleep(void)
{
    80002d2e:	7139                	addi	sp,sp,-64
    80002d30:	fc06                	sd	ra,56(sp)
    80002d32:	f822                	sd	s0,48(sp)
    80002d34:	f426                	sd	s1,40(sp)
    80002d36:	f04a                	sd	s2,32(sp)
    80002d38:	ec4e                	sd	s3,24(sp)
    80002d3a:	0080                	addi	s0,sp,64
  int n;
  uint ticks0;

  argint(0, &n);
    80002d3c:	fcc40593          	addi	a1,s0,-52
    80002d40:	4501                	li	a0,0
    80002d42:	00000097          	auipc	ra,0x0
    80002d46:	e3e080e7          	jalr	-450(ra) # 80002b80 <argint>
  acquire(&tickslock);
    80002d4a:	00014517          	auipc	a0,0x14
    80002d4e:	7b650513          	addi	a0,a0,1974 # 80017500 <tickslock>
    80002d52:	ffffe097          	auipc	ra,0xffffe
    80002d56:	e84080e7          	jalr	-380(ra) # 80000bd6 <acquire>
  ticks0 = ticks;
    80002d5a:	00006917          	auipc	s2,0x6
    80002d5e:	50692903          	lw	s2,1286(s2) # 80009260 <ticks>
  while(ticks - ticks0 < n){
    80002d62:	fcc42783          	lw	a5,-52(s0)
    80002d66:	cf9d                	beqz	a5,80002da4 <sys_sleep+0x76>
    if(killed(myproc())){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
    80002d68:	00014997          	auipc	s3,0x14
    80002d6c:	79898993          	addi	s3,s3,1944 # 80017500 <tickslock>
    80002d70:	00006497          	auipc	s1,0x6
    80002d74:	4f048493          	addi	s1,s1,1264 # 80009260 <ticks>
    if(killed(myproc())){
    80002d78:	fffff097          	auipc	ra,0xfffff
    80002d7c:	c6a080e7          	jalr	-918(ra) # 800019e2 <myproc>
    80002d80:	fffff097          	auipc	ra,0xfffff
    80002d84:	63c080e7          	jalr	1596(ra) # 800023bc <killed>
    80002d88:	ed15                	bnez	a0,80002dc4 <sys_sleep+0x96>
    sleep(&ticks, &tickslock);
    80002d8a:	85ce                	mv	a1,s3
    80002d8c:	8526                	mv	a0,s1
    80002d8e:	fffff097          	auipc	ra,0xfffff
    80002d92:	386080e7          	jalr	902(ra) # 80002114 <sleep>
  while(ticks - ticks0 < n){
    80002d96:	409c                	lw	a5,0(s1)
    80002d98:	412787bb          	subw	a5,a5,s2
    80002d9c:	fcc42703          	lw	a4,-52(s0)
    80002da0:	fce7ece3          	bltu	a5,a4,80002d78 <sys_sleep+0x4a>
  }
  release(&tickslock);
    80002da4:	00014517          	auipc	a0,0x14
    80002da8:	75c50513          	addi	a0,a0,1884 # 80017500 <tickslock>
    80002dac:	ffffe097          	auipc	ra,0xffffe
    80002db0:	ede080e7          	jalr	-290(ra) # 80000c8a <release>
  return 0;
    80002db4:	4501                	li	a0,0
}
    80002db6:	70e2                	ld	ra,56(sp)
    80002db8:	7442                	ld	s0,48(sp)
    80002dba:	74a2                	ld	s1,40(sp)
    80002dbc:	7902                	ld	s2,32(sp)
    80002dbe:	69e2                	ld	s3,24(sp)
    80002dc0:	6121                	addi	sp,sp,64
    80002dc2:	8082                	ret
      release(&tickslock);
    80002dc4:	00014517          	auipc	a0,0x14
    80002dc8:	73c50513          	addi	a0,a0,1852 # 80017500 <tickslock>
    80002dcc:	ffffe097          	auipc	ra,0xffffe
    80002dd0:	ebe080e7          	jalr	-322(ra) # 80000c8a <release>
      return -1;
    80002dd4:	557d                	li	a0,-1
    80002dd6:	b7c5                	j	80002db6 <sys_sleep+0x88>

0000000080002dd8 <sys_kill>:

uint64
sys_kill(void)
{
    80002dd8:	1101                	addi	sp,sp,-32
    80002dda:	ec06                	sd	ra,24(sp)
    80002ddc:	e822                	sd	s0,16(sp)
    80002dde:	1000                	addi	s0,sp,32
  int pid;

  argint(0, &pid);
    80002de0:	fec40593          	addi	a1,s0,-20
    80002de4:	4501                	li	a0,0
    80002de6:	00000097          	auipc	ra,0x0
    80002dea:	d9a080e7          	jalr	-614(ra) # 80002b80 <argint>
  return kill(pid);
    80002dee:	fec42503          	lw	a0,-20(s0)
    80002df2:	fffff097          	auipc	ra,0xfffff
    80002df6:	52c080e7          	jalr	1324(ra) # 8000231e <kill>
}
    80002dfa:	60e2                	ld	ra,24(sp)
    80002dfc:	6442                	ld	s0,16(sp)
    80002dfe:	6105                	addi	sp,sp,32
    80002e00:	8082                	ret

0000000080002e02 <sys_uptime>:

// return how many clock tick interrupts have occurred
// since start.
uint64
sys_uptime(void)
{
    80002e02:	1101                	addi	sp,sp,-32
    80002e04:	ec06                	sd	ra,24(sp)
    80002e06:	e822                	sd	s0,16(sp)
    80002e08:	e426                	sd	s1,8(sp)
    80002e0a:	1000                	addi	s0,sp,32
  uint xticks;

  acquire(&tickslock);
    80002e0c:	00014517          	auipc	a0,0x14
    80002e10:	6f450513          	addi	a0,a0,1780 # 80017500 <tickslock>
    80002e14:	ffffe097          	auipc	ra,0xffffe
    80002e18:	dc2080e7          	jalr	-574(ra) # 80000bd6 <acquire>
  xticks = ticks;
    80002e1c:	00006497          	auipc	s1,0x6
    80002e20:	4444a483          	lw	s1,1092(s1) # 80009260 <ticks>
  release(&tickslock);
    80002e24:	00014517          	auipc	a0,0x14
    80002e28:	6dc50513          	addi	a0,a0,1756 # 80017500 <tickslock>
    80002e2c:	ffffe097          	auipc	ra,0xffffe
    80002e30:	e5e080e7          	jalr	-418(ra) # 80000c8a <release>
  return xticks;
}
    80002e34:	02049513          	slli	a0,s1,0x20
    80002e38:	9101                	srli	a0,a0,0x20
    80002e3a:	60e2                	ld	ra,24(sp)
    80002e3c:	6442                	ld	s0,16(sp)
    80002e3e:	64a2                	ld	s1,8(sp)
    80002e40:	6105                	addi	sp,sp,32
    80002e42:	8082                	ret

0000000080002e44 <sys_flip_display>:
//
// Returns 0 on success, (uint64)-1 on failure (bad alignment, page not
// mapped, missing user permission, etc.).
uint64
sys_flip_display(void)
{
    80002e44:	1101                	addi	sp,sp,-32
    80002e46:	ec06                	sd	ra,24(sp)
    80002e48:	e822                	sd	s0,16(sp)
    80002e4a:	1000                	addi	s0,sp,32
  uint64 addr;
  argaddr(0, &addr);
    80002e4c:	fe840593          	addi	a1,s0,-24
    80002e50:	4501                	li	a0,0
    80002e52:	00000097          	auipc	ra,0x0
    80002e56:	d4e080e7          	jalr	-690(ra) # 80002ba0 <argaddr>

  // NULL is meaningless here — the user must provide a real buffer.
  // Page alignment is also validated again inside virtio_gpu_flip,
  // but checking here lets us fail fast without acquiring gpu_lock.
  if (addr == 0 || addr % PGSIZE != 0)
    80002e5a:	fe843783          	ld	a5,-24(s0)
    return -1;
    80002e5e:	557d                	li	a0,-1
  if (addr == 0 || addr % PGSIZE != 0)
    80002e60:	c395                	beqz	a5,80002e84 <sys_flip_display+0x40>
    80002e62:	17d2                	slli	a5,a5,0x34
    80002e64:	e385                	bnez	a5,80002e84 <sys_flip_display+0x40>

  struct proc *p = myproc();
    80002e66:	fffff097          	auipc	ra,0xfffff
    80002e6a:	b7c080e7          	jalr	-1156(ra) # 800019e2 <myproc>

  // virtio_gpu_flip does the per-page walk, permission check, and the
  // actual DETACH/ATTACH commands.  On failure it leaves the device's
  // current backing untouched.
  if (virtio_gpu_flip(p->pagetable, addr) != 0)
    80002e6e:	fe843583          	ld	a1,-24(s0)
    80002e72:	6928                	ld	a0,80(a0)
    80002e74:	00004097          	auipc	ra,0x4
    80002e78:	d52080e7          	jalr	-686(ra) # 80006bc6 <virtio_gpu_flip>
    80002e7c:	00a03533          	snez	a0,a0
    80002e80:	40a00533          	neg	a0,a0
    return -1;

  return 0;
}
    80002e84:	60e2                	ld	ra,24(sp)
    80002e86:	6442                	ld	s0,16(sp)
    80002e88:	6105                	addi	sp,sp,32
    80002e8a:	8082                	ret

0000000080002e8c <sys_map_display>:
//   Pass 0 to let the kernel auto-select the next available VA above p->sz.
//
// Returns the mapped virtual address on success, (uint64)-1 on failure.
uint64
sys_map_display(void)
{
    80002e8c:	7179                	addi	sp,sp,-48
    80002e8e:	f406                	sd	ra,40(sp)
    80002e90:	f022                	sd	s0,32(sp)
    80002e92:	ec26                	sd	s1,24(sp)
    80002e94:	e84a                	sd	s2,16(sp)
    80002e96:	1800                	addi	s0,sp,48
  uint64 addr;
  argaddr(0, &addr);
    80002e98:	fd840593          	addi	a1,s0,-40
    80002e9c:	4501                	li	a0,0
    80002e9e:	00000097          	auipc	ra,0x0
    80002ea2:	d02080e7          	jalr	-766(ra) # 80002ba0 <argaddr>

  struct proc *p = myproc();
    80002ea6:	fffff097          	auipc	ra,0xfffff
    80002eaa:	b3c080e7          	jalr	-1220(ra) # 800019e2 <myproc>

  // One mapping per process.  If this process already has the FB mapped,
  // refuse — the caller can keep using its previous pointer.  (Re-mapping
  // would either leak the old mapping or surprise other code holding the
  // old pointer.)
  if (p->fb_va != 0)
    80002eae:	16853783          	ld	a5,360(a0)
    return -1;
    80002eb2:	54fd                	li	s1,-1
  if (p->fb_va != 0)
    80002eb4:	e78d                	bnez	a5,80002ede <sys_map_display+0x52>
    80002eb6:	892a                	mv	s2,a0

  uint64 va;
  if (addr == 0) {
    80002eb8:	fd843483          	ld	s1,-40(s0)
    80002ebc:	e885                	bnez	s1,80002eec <sys_map_display+0x60>
    // Auto-pick: first page-aligned VA at or above p->sz.
    va = PGROUNDUP(p->sz);
    80002ebe:	6524                	ld	s1,72(a0)
    80002ec0:	6785                	lui	a5,0x1
    80002ec2:	17fd                	addi	a5,a5,-1
    80002ec4:	94be                	add	s1,s1,a5
    80002ec6:	77fd                	lui	a5,0xfffff
    80002ec8:	8cfd                	and	s1,s1,a5
    va = addr;
  }

  // virtio_gpu_map_user does the collision check, the actual mapping,
  // and rolls back on partial failure.
  if (virtio_gpu_map_user(p->pagetable, va) != 0)
    80002eca:	85a6                	mv	a1,s1
    80002ecc:	05093503          	ld	a0,80(s2)
    80002ed0:	00004097          	auipc	ra,0x4
    80002ed4:	c10080e7          	jalr	-1008(ra) # 80006ae0 <virtio_gpu_map_user>
    80002ed8:	ed19                	bnez	a0,80002ef6 <sys_map_display+0x6a>
    return -1;

  // Remember where we mapped so freeproc()/exec() can tear it down
  // without freeing the (kernel-owned) physical pages.
  p->fb_va = va;
    80002eda:	16993423          	sd	s1,360(s2)
  return va;
}
    80002ede:	8526                	mv	a0,s1
    80002ee0:	70a2                	ld	ra,40(sp)
    80002ee2:	7402                	ld	s0,32(sp)
    80002ee4:	64e2                	ld	s1,24(sp)
    80002ee6:	6942                	ld	s2,16(sp)
    80002ee8:	6145                	addi	sp,sp,48
    80002eea:	8082                	ret
    if (addr % PGSIZE != 0)
    80002eec:	03449793          	slli	a5,s1,0x34
    80002ef0:	dfe9                	beqz	a5,80002eca <sys_map_display+0x3e>
      return -1;
    80002ef2:	54fd                	li	s1,-1
    80002ef4:	b7ed                	j	80002ede <sys_map_display+0x52>
    return -1;
    80002ef6:	54fd                	li	s1,-1
    80002ef8:	b7dd                	j	80002ede <sys_map_display+0x52>

0000000080002efa <binit>:
  struct buf head;
} bcache;

void
binit(void)
{
    80002efa:	7179                	addi	sp,sp,-48
    80002efc:	f406                	sd	ra,40(sp)
    80002efe:	f022                	sd	s0,32(sp)
    80002f00:	ec26                	sd	s1,24(sp)
    80002f02:	e84a                	sd	s2,16(sp)
    80002f04:	e44e                	sd	s3,8(sp)
    80002f06:	e052                	sd	s4,0(sp)
    80002f08:	1800                	addi	s0,sp,48
  struct buf *b;

  initlock(&bcache.lock, "bcache");
    80002f0a:	00005597          	auipc	a1,0x5
    80002f0e:	62658593          	addi	a1,a1,1574 # 80008530 <syscalls+0xc0>
    80002f12:	00014517          	auipc	a0,0x14
    80002f16:	60650513          	addi	a0,a0,1542 # 80017518 <bcache>
    80002f1a:	ffffe097          	auipc	ra,0xffffe
    80002f1e:	c2c080e7          	jalr	-980(ra) # 80000b46 <initlock>

  // Create linked list of buffers
  bcache.head.prev = &bcache.head;
    80002f22:	0001c797          	auipc	a5,0x1c
    80002f26:	5f678793          	addi	a5,a5,1526 # 8001f518 <bcache+0x8000>
    80002f2a:	0001d717          	auipc	a4,0x1d
    80002f2e:	85670713          	addi	a4,a4,-1962 # 8001f780 <bcache+0x8268>
    80002f32:	2ae7b823          	sd	a4,688(a5)
  bcache.head.next = &bcache.head;
    80002f36:	2ae7bc23          	sd	a4,696(a5)
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
    80002f3a:	00014497          	auipc	s1,0x14
    80002f3e:	5f648493          	addi	s1,s1,1526 # 80017530 <bcache+0x18>
    b->next = bcache.head.next;
    80002f42:	893e                	mv	s2,a5
    b->prev = &bcache.head;
    80002f44:	89ba                	mv	s3,a4
    initsleeplock(&b->lock, "buffer");
    80002f46:	00005a17          	auipc	s4,0x5
    80002f4a:	5f2a0a13          	addi	s4,s4,1522 # 80008538 <syscalls+0xc8>
    b->next = bcache.head.next;
    80002f4e:	2b893783          	ld	a5,696(s2)
    80002f52:	e8bc                	sd	a5,80(s1)
    b->prev = &bcache.head;
    80002f54:	0534b423          	sd	s3,72(s1)
    initsleeplock(&b->lock, "buffer");
    80002f58:	85d2                	mv	a1,s4
    80002f5a:	01048513          	addi	a0,s1,16
    80002f5e:	00001097          	auipc	ra,0x1
    80002f62:	4c4080e7          	jalr	1220(ra) # 80004422 <initsleeplock>
    bcache.head.next->prev = b;
    80002f66:	2b893783          	ld	a5,696(s2)
    80002f6a:	e7a4                	sd	s1,72(a5)
    bcache.head.next = b;
    80002f6c:	2a993c23          	sd	s1,696(s2)
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
    80002f70:	45848493          	addi	s1,s1,1112
    80002f74:	fd349de3          	bne	s1,s3,80002f4e <binit+0x54>
  }
}
    80002f78:	70a2                	ld	ra,40(sp)
    80002f7a:	7402                	ld	s0,32(sp)
    80002f7c:	64e2                	ld	s1,24(sp)
    80002f7e:	6942                	ld	s2,16(sp)
    80002f80:	69a2                	ld	s3,8(sp)
    80002f82:	6a02                	ld	s4,0(sp)
    80002f84:	6145                	addi	sp,sp,48
    80002f86:	8082                	ret

0000000080002f88 <bread>:
}

// Return a locked buf with the contents of the indicated block.
struct buf*
bread(uint dev, uint blockno)
{
    80002f88:	7179                	addi	sp,sp,-48
    80002f8a:	f406                	sd	ra,40(sp)
    80002f8c:	f022                	sd	s0,32(sp)
    80002f8e:	ec26                	sd	s1,24(sp)
    80002f90:	e84a                	sd	s2,16(sp)
    80002f92:	e44e                	sd	s3,8(sp)
    80002f94:	1800                	addi	s0,sp,48
    80002f96:	892a                	mv	s2,a0
    80002f98:	89ae                	mv	s3,a1
  acquire(&bcache.lock);
    80002f9a:	00014517          	auipc	a0,0x14
    80002f9e:	57e50513          	addi	a0,a0,1406 # 80017518 <bcache>
    80002fa2:	ffffe097          	auipc	ra,0xffffe
    80002fa6:	c34080e7          	jalr	-972(ra) # 80000bd6 <acquire>
  for(b = bcache.head.next; b != &bcache.head; b = b->next){
    80002faa:	0001d497          	auipc	s1,0x1d
    80002fae:	8264b483          	ld	s1,-2010(s1) # 8001f7d0 <bcache+0x82b8>
    80002fb2:	0001c797          	auipc	a5,0x1c
    80002fb6:	7ce78793          	addi	a5,a5,1998 # 8001f780 <bcache+0x8268>
    80002fba:	02f48f63          	beq	s1,a5,80002ff8 <bread+0x70>
    80002fbe:	873e                	mv	a4,a5
    80002fc0:	a021                	j	80002fc8 <bread+0x40>
    80002fc2:	68a4                	ld	s1,80(s1)
    80002fc4:	02e48a63          	beq	s1,a4,80002ff8 <bread+0x70>
    if(b->dev == dev && b->blockno == blockno){
    80002fc8:	449c                	lw	a5,8(s1)
    80002fca:	ff279ce3          	bne	a5,s2,80002fc2 <bread+0x3a>
    80002fce:	44dc                	lw	a5,12(s1)
    80002fd0:	ff3799e3          	bne	a5,s3,80002fc2 <bread+0x3a>
      b->refcnt++;
    80002fd4:	40bc                	lw	a5,64(s1)
    80002fd6:	2785                	addiw	a5,a5,1
    80002fd8:	c0bc                	sw	a5,64(s1)
      release(&bcache.lock);
    80002fda:	00014517          	auipc	a0,0x14
    80002fde:	53e50513          	addi	a0,a0,1342 # 80017518 <bcache>
    80002fe2:	ffffe097          	auipc	ra,0xffffe
    80002fe6:	ca8080e7          	jalr	-856(ra) # 80000c8a <release>
      acquiresleep(&b->lock);
    80002fea:	01048513          	addi	a0,s1,16
    80002fee:	00001097          	auipc	ra,0x1
    80002ff2:	46e080e7          	jalr	1134(ra) # 8000445c <acquiresleep>
      return b;
    80002ff6:	a8b9                	j	80003054 <bread+0xcc>
  for(b = bcache.head.prev; b != &bcache.head; b = b->prev){
    80002ff8:	0001c497          	auipc	s1,0x1c
    80002ffc:	7d04b483          	ld	s1,2000(s1) # 8001f7c8 <bcache+0x82b0>
    80003000:	0001c797          	auipc	a5,0x1c
    80003004:	78078793          	addi	a5,a5,1920 # 8001f780 <bcache+0x8268>
    80003008:	00f48863          	beq	s1,a5,80003018 <bread+0x90>
    8000300c:	873e                	mv	a4,a5
    if(b->refcnt == 0) {
    8000300e:	40bc                	lw	a5,64(s1)
    80003010:	cf81                	beqz	a5,80003028 <bread+0xa0>
  for(b = bcache.head.prev; b != &bcache.head; b = b->prev){
    80003012:	64a4                	ld	s1,72(s1)
    80003014:	fee49de3          	bne	s1,a4,8000300e <bread+0x86>
  panic("bget: no buffers");
    80003018:	00005517          	auipc	a0,0x5
    8000301c:	52850513          	addi	a0,a0,1320 # 80008540 <syscalls+0xd0>
    80003020:	ffffd097          	auipc	ra,0xffffd
    80003024:	51e080e7          	jalr	1310(ra) # 8000053e <panic>
      b->dev = dev;
    80003028:	0124a423          	sw	s2,8(s1)
      b->blockno = blockno;
    8000302c:	0134a623          	sw	s3,12(s1)
      b->valid = 0;
    80003030:	0004a023          	sw	zero,0(s1)
      b->refcnt = 1;
    80003034:	4785                	li	a5,1
    80003036:	c0bc                	sw	a5,64(s1)
      release(&bcache.lock);
    80003038:	00014517          	auipc	a0,0x14
    8000303c:	4e050513          	addi	a0,a0,1248 # 80017518 <bcache>
    80003040:	ffffe097          	auipc	ra,0xffffe
    80003044:	c4a080e7          	jalr	-950(ra) # 80000c8a <release>
      acquiresleep(&b->lock);
    80003048:	01048513          	addi	a0,s1,16
    8000304c:	00001097          	auipc	ra,0x1
    80003050:	410080e7          	jalr	1040(ra) # 8000445c <acquiresleep>
  struct buf *b;

  b = bget(dev, blockno);
  if(!b->valid) {
    80003054:	409c                	lw	a5,0(s1)
    80003056:	cb89                	beqz	a5,80003068 <bread+0xe0>
    virtio_disk_rw(b, 0);
    b->valid = 1;
  }
  return b;
}
    80003058:	8526                	mv	a0,s1
    8000305a:	70a2                	ld	ra,40(sp)
    8000305c:	7402                	ld	s0,32(sp)
    8000305e:	64e2                	ld	s1,24(sp)
    80003060:	6942                	ld	s2,16(sp)
    80003062:	69a2                	ld	s3,8(sp)
    80003064:	6145                	addi	sp,sp,48
    80003066:	8082                	ret
    virtio_disk_rw(b, 0);
    80003068:	4581                	li	a1,0
    8000306a:	8526                	mv	a0,s1
    8000306c:	00003097          	auipc	ra,0x3
    80003070:	ff8080e7          	jalr	-8(ra) # 80006064 <virtio_disk_rw>
    b->valid = 1;
    80003074:	4785                	li	a5,1
    80003076:	c09c                	sw	a5,0(s1)
  return b;
    80003078:	b7c5                	j	80003058 <bread+0xd0>

000000008000307a <bwrite>:

// Write b's contents to disk.  Must be locked.
void
bwrite(struct buf *b)
{
    8000307a:	1101                	addi	sp,sp,-32
    8000307c:	ec06                	sd	ra,24(sp)
    8000307e:	e822                	sd	s0,16(sp)
    80003080:	e426                	sd	s1,8(sp)
    80003082:	1000                	addi	s0,sp,32
    80003084:	84aa                	mv	s1,a0
  if(!holdingsleep(&b->lock))
    80003086:	0541                	addi	a0,a0,16
    80003088:	00001097          	auipc	ra,0x1
    8000308c:	46e080e7          	jalr	1134(ra) # 800044f6 <holdingsleep>
    80003090:	cd01                	beqz	a0,800030a8 <bwrite+0x2e>
    panic("bwrite");
  virtio_disk_rw(b, 1);
    80003092:	4585                	li	a1,1
    80003094:	8526                	mv	a0,s1
    80003096:	00003097          	auipc	ra,0x3
    8000309a:	fce080e7          	jalr	-50(ra) # 80006064 <virtio_disk_rw>
}
    8000309e:	60e2                	ld	ra,24(sp)
    800030a0:	6442                	ld	s0,16(sp)
    800030a2:	64a2                	ld	s1,8(sp)
    800030a4:	6105                	addi	sp,sp,32
    800030a6:	8082                	ret
    panic("bwrite");
    800030a8:	00005517          	auipc	a0,0x5
    800030ac:	4b050513          	addi	a0,a0,1200 # 80008558 <syscalls+0xe8>
    800030b0:	ffffd097          	auipc	ra,0xffffd
    800030b4:	48e080e7          	jalr	1166(ra) # 8000053e <panic>

00000000800030b8 <brelse>:

// Release a locked buffer.
// Move to the head of the most-recently-used list.
void
brelse(struct buf *b)
{
    800030b8:	1101                	addi	sp,sp,-32
    800030ba:	ec06                	sd	ra,24(sp)
    800030bc:	e822                	sd	s0,16(sp)
    800030be:	e426                	sd	s1,8(sp)
    800030c0:	e04a                	sd	s2,0(sp)
    800030c2:	1000                	addi	s0,sp,32
    800030c4:	84aa                	mv	s1,a0
  if(!holdingsleep(&b->lock))
    800030c6:	01050913          	addi	s2,a0,16
    800030ca:	854a                	mv	a0,s2
    800030cc:	00001097          	auipc	ra,0x1
    800030d0:	42a080e7          	jalr	1066(ra) # 800044f6 <holdingsleep>
    800030d4:	c92d                	beqz	a0,80003146 <brelse+0x8e>
    panic("brelse");

  releasesleep(&b->lock);
    800030d6:	854a                	mv	a0,s2
    800030d8:	00001097          	auipc	ra,0x1
    800030dc:	3da080e7          	jalr	986(ra) # 800044b2 <releasesleep>

  acquire(&bcache.lock);
    800030e0:	00014517          	auipc	a0,0x14
    800030e4:	43850513          	addi	a0,a0,1080 # 80017518 <bcache>
    800030e8:	ffffe097          	auipc	ra,0xffffe
    800030ec:	aee080e7          	jalr	-1298(ra) # 80000bd6 <acquire>
  b->refcnt--;
    800030f0:	40bc                	lw	a5,64(s1)
    800030f2:	37fd                	addiw	a5,a5,-1
    800030f4:	0007871b          	sext.w	a4,a5
    800030f8:	c0bc                	sw	a5,64(s1)
  if (b->refcnt == 0) {
    800030fa:	eb05                	bnez	a4,8000312a <brelse+0x72>
    // no one is waiting for it.
    b->next->prev = b->prev;
    800030fc:	68bc                	ld	a5,80(s1)
    800030fe:	64b8                	ld	a4,72(s1)
    80003100:	e7b8                	sd	a4,72(a5)
    b->prev->next = b->next;
    80003102:	64bc                	ld	a5,72(s1)
    80003104:	68b8                	ld	a4,80(s1)
    80003106:	ebb8                	sd	a4,80(a5)
    b->next = bcache.head.next;
    80003108:	0001c797          	auipc	a5,0x1c
    8000310c:	41078793          	addi	a5,a5,1040 # 8001f518 <bcache+0x8000>
    80003110:	2b87b703          	ld	a4,696(a5)
    80003114:	e8b8                	sd	a4,80(s1)
    b->prev = &bcache.head;
    80003116:	0001c717          	auipc	a4,0x1c
    8000311a:	66a70713          	addi	a4,a4,1642 # 8001f780 <bcache+0x8268>
    8000311e:	e4b8                	sd	a4,72(s1)
    bcache.head.next->prev = b;
    80003120:	2b87b703          	ld	a4,696(a5)
    80003124:	e724                	sd	s1,72(a4)
    bcache.head.next = b;
    80003126:	2a97bc23          	sd	s1,696(a5)
  }
  
  release(&bcache.lock);
    8000312a:	00014517          	auipc	a0,0x14
    8000312e:	3ee50513          	addi	a0,a0,1006 # 80017518 <bcache>
    80003132:	ffffe097          	auipc	ra,0xffffe
    80003136:	b58080e7          	jalr	-1192(ra) # 80000c8a <release>
}
    8000313a:	60e2                	ld	ra,24(sp)
    8000313c:	6442                	ld	s0,16(sp)
    8000313e:	64a2                	ld	s1,8(sp)
    80003140:	6902                	ld	s2,0(sp)
    80003142:	6105                	addi	sp,sp,32
    80003144:	8082                	ret
    panic("brelse");
    80003146:	00005517          	auipc	a0,0x5
    8000314a:	41a50513          	addi	a0,a0,1050 # 80008560 <syscalls+0xf0>
    8000314e:	ffffd097          	auipc	ra,0xffffd
    80003152:	3f0080e7          	jalr	1008(ra) # 8000053e <panic>

0000000080003156 <bpin>:

void
bpin(struct buf *b) {
    80003156:	1101                	addi	sp,sp,-32
    80003158:	ec06                	sd	ra,24(sp)
    8000315a:	e822                	sd	s0,16(sp)
    8000315c:	e426                	sd	s1,8(sp)
    8000315e:	1000                	addi	s0,sp,32
    80003160:	84aa                	mv	s1,a0
  acquire(&bcache.lock);
    80003162:	00014517          	auipc	a0,0x14
    80003166:	3b650513          	addi	a0,a0,950 # 80017518 <bcache>
    8000316a:	ffffe097          	auipc	ra,0xffffe
    8000316e:	a6c080e7          	jalr	-1428(ra) # 80000bd6 <acquire>
  b->refcnt++;
    80003172:	40bc                	lw	a5,64(s1)
    80003174:	2785                	addiw	a5,a5,1
    80003176:	c0bc                	sw	a5,64(s1)
  release(&bcache.lock);
    80003178:	00014517          	auipc	a0,0x14
    8000317c:	3a050513          	addi	a0,a0,928 # 80017518 <bcache>
    80003180:	ffffe097          	auipc	ra,0xffffe
    80003184:	b0a080e7          	jalr	-1270(ra) # 80000c8a <release>
}
    80003188:	60e2                	ld	ra,24(sp)
    8000318a:	6442                	ld	s0,16(sp)
    8000318c:	64a2                	ld	s1,8(sp)
    8000318e:	6105                	addi	sp,sp,32
    80003190:	8082                	ret

0000000080003192 <bunpin>:

void
bunpin(struct buf *b) {
    80003192:	1101                	addi	sp,sp,-32
    80003194:	ec06                	sd	ra,24(sp)
    80003196:	e822                	sd	s0,16(sp)
    80003198:	e426                	sd	s1,8(sp)
    8000319a:	1000                	addi	s0,sp,32
    8000319c:	84aa                	mv	s1,a0
  acquire(&bcache.lock);
    8000319e:	00014517          	auipc	a0,0x14
    800031a2:	37a50513          	addi	a0,a0,890 # 80017518 <bcache>
    800031a6:	ffffe097          	auipc	ra,0xffffe
    800031aa:	a30080e7          	jalr	-1488(ra) # 80000bd6 <acquire>
  b->refcnt--;
    800031ae:	40bc                	lw	a5,64(s1)
    800031b0:	37fd                	addiw	a5,a5,-1
    800031b2:	c0bc                	sw	a5,64(s1)
  release(&bcache.lock);
    800031b4:	00014517          	auipc	a0,0x14
    800031b8:	36450513          	addi	a0,a0,868 # 80017518 <bcache>
    800031bc:	ffffe097          	auipc	ra,0xffffe
    800031c0:	ace080e7          	jalr	-1330(ra) # 80000c8a <release>
}
    800031c4:	60e2                	ld	ra,24(sp)
    800031c6:	6442                	ld	s0,16(sp)
    800031c8:	64a2                	ld	s1,8(sp)
    800031ca:	6105                	addi	sp,sp,32
    800031cc:	8082                	ret

00000000800031ce <bfree>:
}

// Free a disk block.
static void
bfree(int dev, uint b)
{
    800031ce:	1101                	addi	sp,sp,-32
    800031d0:	ec06                	sd	ra,24(sp)
    800031d2:	e822                	sd	s0,16(sp)
    800031d4:	e426                	sd	s1,8(sp)
    800031d6:	e04a                	sd	s2,0(sp)
    800031d8:	1000                	addi	s0,sp,32
    800031da:	84ae                	mv	s1,a1
  struct buf *bp;
  int bi, m;

  bp = bread(dev, BBLOCK(b, sb));
    800031dc:	00d5d59b          	srliw	a1,a1,0xd
    800031e0:	0001d797          	auipc	a5,0x1d
    800031e4:	a147a783          	lw	a5,-1516(a5) # 8001fbf4 <sb+0x1c>
    800031e8:	9dbd                	addw	a1,a1,a5
    800031ea:	00000097          	auipc	ra,0x0
    800031ee:	d9e080e7          	jalr	-610(ra) # 80002f88 <bread>
  bi = b % BPB;
  m = 1 << (bi % 8);
    800031f2:	0074f713          	andi	a4,s1,7
    800031f6:	4785                	li	a5,1
    800031f8:	00e797bb          	sllw	a5,a5,a4
  if((bp->data[bi/8] & m) == 0)
    800031fc:	14ce                	slli	s1,s1,0x33
    800031fe:	90d9                	srli	s1,s1,0x36
    80003200:	00950733          	add	a4,a0,s1
    80003204:	05874703          	lbu	a4,88(a4)
    80003208:	00e7f6b3          	and	a3,a5,a4
    8000320c:	c69d                	beqz	a3,8000323a <bfree+0x6c>
    8000320e:	892a                	mv	s2,a0
    panic("freeing free block");
  bp->data[bi/8] &= ~m;
    80003210:	94aa                	add	s1,s1,a0
    80003212:	fff7c793          	not	a5,a5
    80003216:	8ff9                	and	a5,a5,a4
    80003218:	04f48c23          	sb	a5,88(s1)
  log_write(bp);
    8000321c:	00001097          	auipc	ra,0x1
    80003220:	120080e7          	jalr	288(ra) # 8000433c <log_write>
  brelse(bp);
    80003224:	854a                	mv	a0,s2
    80003226:	00000097          	auipc	ra,0x0
    8000322a:	e92080e7          	jalr	-366(ra) # 800030b8 <brelse>
}
    8000322e:	60e2                	ld	ra,24(sp)
    80003230:	6442                	ld	s0,16(sp)
    80003232:	64a2                	ld	s1,8(sp)
    80003234:	6902                	ld	s2,0(sp)
    80003236:	6105                	addi	sp,sp,32
    80003238:	8082                	ret
    panic("freeing free block");
    8000323a:	00005517          	auipc	a0,0x5
    8000323e:	32e50513          	addi	a0,a0,814 # 80008568 <syscalls+0xf8>
    80003242:	ffffd097          	auipc	ra,0xffffd
    80003246:	2fc080e7          	jalr	764(ra) # 8000053e <panic>

000000008000324a <balloc>:
{
    8000324a:	711d                	addi	sp,sp,-96
    8000324c:	ec86                	sd	ra,88(sp)
    8000324e:	e8a2                	sd	s0,80(sp)
    80003250:	e4a6                	sd	s1,72(sp)
    80003252:	e0ca                	sd	s2,64(sp)
    80003254:	fc4e                	sd	s3,56(sp)
    80003256:	f852                	sd	s4,48(sp)
    80003258:	f456                	sd	s5,40(sp)
    8000325a:	f05a                	sd	s6,32(sp)
    8000325c:	ec5e                	sd	s7,24(sp)
    8000325e:	e862                	sd	s8,16(sp)
    80003260:	e466                	sd	s9,8(sp)
    80003262:	1080                	addi	s0,sp,96
  for(b = 0; b < sb.size; b += BPB){
    80003264:	0001d797          	auipc	a5,0x1d
    80003268:	9787a783          	lw	a5,-1672(a5) # 8001fbdc <sb+0x4>
    8000326c:	10078163          	beqz	a5,8000336e <balloc+0x124>
    80003270:	8baa                	mv	s7,a0
    80003272:	4a81                	li	s5,0
    bp = bread(dev, BBLOCK(b, sb));
    80003274:	0001db17          	auipc	s6,0x1d
    80003278:	964b0b13          	addi	s6,s6,-1692 # 8001fbd8 <sb>
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    8000327c:	4c01                	li	s8,0
      m = 1 << (bi % 8);
    8000327e:	4985                	li	s3,1
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    80003280:	6a09                	lui	s4,0x2
  for(b = 0; b < sb.size; b += BPB){
    80003282:	6c89                	lui	s9,0x2
    80003284:	a061                	j	8000330c <balloc+0xc2>
        bp->data[bi/8] |= m;  // Mark block in use.
    80003286:	974a                	add	a4,a4,s2
    80003288:	8fd5                	or	a5,a5,a3
    8000328a:	04f70c23          	sb	a5,88(a4)
        log_write(bp);
    8000328e:	854a                	mv	a0,s2
    80003290:	00001097          	auipc	ra,0x1
    80003294:	0ac080e7          	jalr	172(ra) # 8000433c <log_write>
        brelse(bp);
    80003298:	854a                	mv	a0,s2
    8000329a:	00000097          	auipc	ra,0x0
    8000329e:	e1e080e7          	jalr	-482(ra) # 800030b8 <brelse>
  bp = bread(dev, bno);
    800032a2:	85a6                	mv	a1,s1
    800032a4:	855e                	mv	a0,s7
    800032a6:	00000097          	auipc	ra,0x0
    800032aa:	ce2080e7          	jalr	-798(ra) # 80002f88 <bread>
    800032ae:	892a                	mv	s2,a0
  memset(bp->data, 0, BSIZE);
    800032b0:	40000613          	li	a2,1024
    800032b4:	4581                	li	a1,0
    800032b6:	05850513          	addi	a0,a0,88
    800032ba:	ffffe097          	auipc	ra,0xffffe
    800032be:	a18080e7          	jalr	-1512(ra) # 80000cd2 <memset>
  log_write(bp);
    800032c2:	854a                	mv	a0,s2
    800032c4:	00001097          	auipc	ra,0x1
    800032c8:	078080e7          	jalr	120(ra) # 8000433c <log_write>
  brelse(bp);
    800032cc:	854a                	mv	a0,s2
    800032ce:	00000097          	auipc	ra,0x0
    800032d2:	dea080e7          	jalr	-534(ra) # 800030b8 <brelse>
}
    800032d6:	8526                	mv	a0,s1
    800032d8:	60e6                	ld	ra,88(sp)
    800032da:	6446                	ld	s0,80(sp)
    800032dc:	64a6                	ld	s1,72(sp)
    800032de:	6906                	ld	s2,64(sp)
    800032e0:	79e2                	ld	s3,56(sp)
    800032e2:	7a42                	ld	s4,48(sp)
    800032e4:	7aa2                	ld	s5,40(sp)
    800032e6:	7b02                	ld	s6,32(sp)
    800032e8:	6be2                	ld	s7,24(sp)
    800032ea:	6c42                	ld	s8,16(sp)
    800032ec:	6ca2                	ld	s9,8(sp)
    800032ee:	6125                	addi	sp,sp,96
    800032f0:	8082                	ret
    brelse(bp);
    800032f2:	854a                	mv	a0,s2
    800032f4:	00000097          	auipc	ra,0x0
    800032f8:	dc4080e7          	jalr	-572(ra) # 800030b8 <brelse>
  for(b = 0; b < sb.size; b += BPB){
    800032fc:	015c87bb          	addw	a5,s9,s5
    80003300:	00078a9b          	sext.w	s5,a5
    80003304:	004b2703          	lw	a4,4(s6)
    80003308:	06eaf363          	bgeu	s5,a4,8000336e <balloc+0x124>
    bp = bread(dev, BBLOCK(b, sb));
    8000330c:	41fad79b          	sraiw	a5,s5,0x1f
    80003310:	0137d79b          	srliw	a5,a5,0x13
    80003314:	015787bb          	addw	a5,a5,s5
    80003318:	40d7d79b          	sraiw	a5,a5,0xd
    8000331c:	01cb2583          	lw	a1,28(s6)
    80003320:	9dbd                	addw	a1,a1,a5
    80003322:	855e                	mv	a0,s7
    80003324:	00000097          	auipc	ra,0x0
    80003328:	c64080e7          	jalr	-924(ra) # 80002f88 <bread>
    8000332c:	892a                	mv	s2,a0
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    8000332e:	004b2503          	lw	a0,4(s6)
    80003332:	000a849b          	sext.w	s1,s5
    80003336:	8662                	mv	a2,s8
    80003338:	faa4fde3          	bgeu	s1,a0,800032f2 <balloc+0xa8>
      m = 1 << (bi % 8);
    8000333c:	41f6579b          	sraiw	a5,a2,0x1f
    80003340:	01d7d69b          	srliw	a3,a5,0x1d
    80003344:	00c6873b          	addw	a4,a3,a2
    80003348:	00777793          	andi	a5,a4,7
    8000334c:	9f95                	subw	a5,a5,a3
    8000334e:	00f997bb          	sllw	a5,s3,a5
      if((bp->data[bi/8] & m) == 0){  // Is block free?
    80003352:	4037571b          	sraiw	a4,a4,0x3
    80003356:	00e906b3          	add	a3,s2,a4
    8000335a:	0586c683          	lbu	a3,88(a3)
    8000335e:	00d7f5b3          	and	a1,a5,a3
    80003362:	d195                	beqz	a1,80003286 <balloc+0x3c>
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    80003364:	2605                	addiw	a2,a2,1
    80003366:	2485                	addiw	s1,s1,1
    80003368:	fd4618e3          	bne	a2,s4,80003338 <balloc+0xee>
    8000336c:	b759                	j	800032f2 <balloc+0xa8>
  printf("balloc: out of blocks\n");
    8000336e:	00005517          	auipc	a0,0x5
    80003372:	21250513          	addi	a0,a0,530 # 80008580 <syscalls+0x110>
    80003376:	ffffd097          	auipc	ra,0xffffd
    8000337a:	212080e7          	jalr	530(ra) # 80000588 <printf>
  return 0;
    8000337e:	4481                	li	s1,0
    80003380:	bf99                	j	800032d6 <balloc+0x8c>

0000000080003382 <bmap>:
// Return the disk block address of the nth block in inode ip.
// If there is no such block, bmap allocates one.
// returns 0 if out of disk space.
static uint
bmap(struct inode *ip, uint bn)
{
    80003382:	7179                	addi	sp,sp,-48
    80003384:	f406                	sd	ra,40(sp)
    80003386:	f022                	sd	s0,32(sp)
    80003388:	ec26                	sd	s1,24(sp)
    8000338a:	e84a                	sd	s2,16(sp)
    8000338c:	e44e                	sd	s3,8(sp)
    8000338e:	e052                	sd	s4,0(sp)
    80003390:	1800                	addi	s0,sp,48
    80003392:	89aa                	mv	s3,a0
  uint addr, *a;
  struct buf *bp;

  if(bn < NDIRECT){
    80003394:	47ad                	li	a5,11
    80003396:	02b7e763          	bltu	a5,a1,800033c4 <bmap+0x42>
    if((addr = ip->addrs[bn]) == 0){
    8000339a:	02059493          	slli	s1,a1,0x20
    8000339e:	9081                	srli	s1,s1,0x20
    800033a0:	048a                	slli	s1,s1,0x2
    800033a2:	94aa                	add	s1,s1,a0
    800033a4:	0504a903          	lw	s2,80(s1)
    800033a8:	06091e63          	bnez	s2,80003424 <bmap+0xa2>
      addr = balloc(ip->dev);
    800033ac:	4108                	lw	a0,0(a0)
    800033ae:	00000097          	auipc	ra,0x0
    800033b2:	e9c080e7          	jalr	-356(ra) # 8000324a <balloc>
    800033b6:	0005091b          	sext.w	s2,a0
      if(addr == 0)
    800033ba:	06090563          	beqz	s2,80003424 <bmap+0xa2>
        return 0;
      ip->addrs[bn] = addr;
    800033be:	0524a823          	sw	s2,80(s1)
    800033c2:	a08d                	j	80003424 <bmap+0xa2>
    }
    return addr;
  }
  bn -= NDIRECT;
    800033c4:	ff45849b          	addiw	s1,a1,-12
    800033c8:	0004871b          	sext.w	a4,s1

  if(bn < NINDIRECT){
    800033cc:	0ff00793          	li	a5,255
    800033d0:	08e7e563          	bltu	a5,a4,8000345a <bmap+0xd8>
    // Load indirect block, allocating if necessary.
    if((addr = ip->addrs[NDIRECT]) == 0){
    800033d4:	08052903          	lw	s2,128(a0)
    800033d8:	00091d63          	bnez	s2,800033f2 <bmap+0x70>
      addr = balloc(ip->dev);
    800033dc:	4108                	lw	a0,0(a0)
    800033de:	00000097          	auipc	ra,0x0
    800033e2:	e6c080e7          	jalr	-404(ra) # 8000324a <balloc>
    800033e6:	0005091b          	sext.w	s2,a0
      if(addr == 0)
    800033ea:	02090d63          	beqz	s2,80003424 <bmap+0xa2>
        return 0;
      ip->addrs[NDIRECT] = addr;
    800033ee:	0929a023          	sw	s2,128(s3)
    }
    bp = bread(ip->dev, addr);
    800033f2:	85ca                	mv	a1,s2
    800033f4:	0009a503          	lw	a0,0(s3)
    800033f8:	00000097          	auipc	ra,0x0
    800033fc:	b90080e7          	jalr	-1136(ra) # 80002f88 <bread>
    80003400:	8a2a                	mv	s4,a0
    a = (uint*)bp->data;
    80003402:	05850793          	addi	a5,a0,88
    if((addr = a[bn]) == 0){
    80003406:	02049593          	slli	a1,s1,0x20
    8000340a:	9181                	srli	a1,a1,0x20
    8000340c:	058a                	slli	a1,a1,0x2
    8000340e:	00b784b3          	add	s1,a5,a1
    80003412:	0004a903          	lw	s2,0(s1)
    80003416:	02090063          	beqz	s2,80003436 <bmap+0xb4>
      if(addr){
        a[bn] = addr;
        log_write(bp);
      }
    }
    brelse(bp);
    8000341a:	8552                	mv	a0,s4
    8000341c:	00000097          	auipc	ra,0x0
    80003420:	c9c080e7          	jalr	-868(ra) # 800030b8 <brelse>
    return addr;
  }

  panic("bmap: out of range");
}
    80003424:	854a                	mv	a0,s2
    80003426:	70a2                	ld	ra,40(sp)
    80003428:	7402                	ld	s0,32(sp)
    8000342a:	64e2                	ld	s1,24(sp)
    8000342c:	6942                	ld	s2,16(sp)
    8000342e:	69a2                	ld	s3,8(sp)
    80003430:	6a02                	ld	s4,0(sp)
    80003432:	6145                	addi	sp,sp,48
    80003434:	8082                	ret
      addr = balloc(ip->dev);
    80003436:	0009a503          	lw	a0,0(s3)
    8000343a:	00000097          	auipc	ra,0x0
    8000343e:	e10080e7          	jalr	-496(ra) # 8000324a <balloc>
    80003442:	0005091b          	sext.w	s2,a0
      if(addr){
    80003446:	fc090ae3          	beqz	s2,8000341a <bmap+0x98>
        a[bn] = addr;
    8000344a:	0124a023          	sw	s2,0(s1)
        log_write(bp);
    8000344e:	8552                	mv	a0,s4
    80003450:	00001097          	auipc	ra,0x1
    80003454:	eec080e7          	jalr	-276(ra) # 8000433c <log_write>
    80003458:	b7c9                	j	8000341a <bmap+0x98>
  panic("bmap: out of range");
    8000345a:	00005517          	auipc	a0,0x5
    8000345e:	13e50513          	addi	a0,a0,318 # 80008598 <syscalls+0x128>
    80003462:	ffffd097          	auipc	ra,0xffffd
    80003466:	0dc080e7          	jalr	220(ra) # 8000053e <panic>

000000008000346a <iget>:
{
    8000346a:	7179                	addi	sp,sp,-48
    8000346c:	f406                	sd	ra,40(sp)
    8000346e:	f022                	sd	s0,32(sp)
    80003470:	ec26                	sd	s1,24(sp)
    80003472:	e84a                	sd	s2,16(sp)
    80003474:	e44e                	sd	s3,8(sp)
    80003476:	e052                	sd	s4,0(sp)
    80003478:	1800                	addi	s0,sp,48
    8000347a:	89aa                	mv	s3,a0
    8000347c:	8a2e                	mv	s4,a1
  acquire(&itable.lock);
    8000347e:	0001c517          	auipc	a0,0x1c
    80003482:	77a50513          	addi	a0,a0,1914 # 8001fbf8 <itable>
    80003486:	ffffd097          	auipc	ra,0xffffd
    8000348a:	750080e7          	jalr	1872(ra) # 80000bd6 <acquire>
  empty = 0;
    8000348e:	4901                	li	s2,0
  for(ip = &itable.inode[0]; ip < &itable.inode[NINODE]; ip++){
    80003490:	0001c497          	auipc	s1,0x1c
    80003494:	78048493          	addi	s1,s1,1920 # 8001fc10 <itable+0x18>
    80003498:	0001e697          	auipc	a3,0x1e
    8000349c:	20868693          	addi	a3,a3,520 # 800216a0 <log>
    800034a0:	a039                	j	800034ae <iget+0x44>
    if(empty == 0 && ip->ref == 0)    // Remember empty slot.
    800034a2:	02090b63          	beqz	s2,800034d8 <iget+0x6e>
  for(ip = &itable.inode[0]; ip < &itable.inode[NINODE]; ip++){
    800034a6:	08848493          	addi	s1,s1,136
    800034aa:	02d48a63          	beq	s1,a3,800034de <iget+0x74>
    if(ip->ref > 0 && ip->dev == dev && ip->inum == inum){
    800034ae:	449c                	lw	a5,8(s1)
    800034b0:	fef059e3          	blez	a5,800034a2 <iget+0x38>
    800034b4:	4098                	lw	a4,0(s1)
    800034b6:	ff3716e3          	bne	a4,s3,800034a2 <iget+0x38>
    800034ba:	40d8                	lw	a4,4(s1)
    800034bc:	ff4713e3          	bne	a4,s4,800034a2 <iget+0x38>
      ip->ref++;
    800034c0:	2785                	addiw	a5,a5,1
    800034c2:	c49c                	sw	a5,8(s1)
      release(&itable.lock);
    800034c4:	0001c517          	auipc	a0,0x1c
    800034c8:	73450513          	addi	a0,a0,1844 # 8001fbf8 <itable>
    800034cc:	ffffd097          	auipc	ra,0xffffd
    800034d0:	7be080e7          	jalr	1982(ra) # 80000c8a <release>
      return ip;
    800034d4:	8926                	mv	s2,s1
    800034d6:	a03d                	j	80003504 <iget+0x9a>
    if(empty == 0 && ip->ref == 0)    // Remember empty slot.
    800034d8:	f7f9                	bnez	a5,800034a6 <iget+0x3c>
    800034da:	8926                	mv	s2,s1
    800034dc:	b7e9                	j	800034a6 <iget+0x3c>
  if(empty == 0)
    800034de:	02090c63          	beqz	s2,80003516 <iget+0xac>
  ip->dev = dev;
    800034e2:	01392023          	sw	s3,0(s2)
  ip->inum = inum;
    800034e6:	01492223          	sw	s4,4(s2)
  ip->ref = 1;
    800034ea:	4785                	li	a5,1
    800034ec:	00f92423          	sw	a5,8(s2)
  ip->valid = 0;
    800034f0:	04092023          	sw	zero,64(s2)
  release(&itable.lock);
    800034f4:	0001c517          	auipc	a0,0x1c
    800034f8:	70450513          	addi	a0,a0,1796 # 8001fbf8 <itable>
    800034fc:	ffffd097          	auipc	ra,0xffffd
    80003500:	78e080e7          	jalr	1934(ra) # 80000c8a <release>
}
    80003504:	854a                	mv	a0,s2
    80003506:	70a2                	ld	ra,40(sp)
    80003508:	7402                	ld	s0,32(sp)
    8000350a:	64e2                	ld	s1,24(sp)
    8000350c:	6942                	ld	s2,16(sp)
    8000350e:	69a2                	ld	s3,8(sp)
    80003510:	6a02                	ld	s4,0(sp)
    80003512:	6145                	addi	sp,sp,48
    80003514:	8082                	ret
    panic("iget: no inodes");
    80003516:	00005517          	auipc	a0,0x5
    8000351a:	09a50513          	addi	a0,a0,154 # 800085b0 <syscalls+0x140>
    8000351e:	ffffd097          	auipc	ra,0xffffd
    80003522:	020080e7          	jalr	32(ra) # 8000053e <panic>

0000000080003526 <fsinit>:
fsinit(int dev) {
    80003526:	7179                	addi	sp,sp,-48
    80003528:	f406                	sd	ra,40(sp)
    8000352a:	f022                	sd	s0,32(sp)
    8000352c:	ec26                	sd	s1,24(sp)
    8000352e:	e84a                	sd	s2,16(sp)
    80003530:	e44e                	sd	s3,8(sp)
    80003532:	1800                	addi	s0,sp,48
    80003534:	892a                	mv	s2,a0
  bp = bread(dev, 1);
    80003536:	4585                	li	a1,1
    80003538:	00000097          	auipc	ra,0x0
    8000353c:	a50080e7          	jalr	-1456(ra) # 80002f88 <bread>
    80003540:	84aa                	mv	s1,a0
  memmove(sb, bp->data, sizeof(*sb));
    80003542:	0001c997          	auipc	s3,0x1c
    80003546:	69698993          	addi	s3,s3,1686 # 8001fbd8 <sb>
    8000354a:	02000613          	li	a2,32
    8000354e:	05850593          	addi	a1,a0,88
    80003552:	854e                	mv	a0,s3
    80003554:	ffffd097          	auipc	ra,0xffffd
    80003558:	7da080e7          	jalr	2010(ra) # 80000d2e <memmove>
  brelse(bp);
    8000355c:	8526                	mv	a0,s1
    8000355e:	00000097          	auipc	ra,0x0
    80003562:	b5a080e7          	jalr	-1190(ra) # 800030b8 <brelse>
  if(sb.magic != FSMAGIC)
    80003566:	0009a703          	lw	a4,0(s3)
    8000356a:	102037b7          	lui	a5,0x10203
    8000356e:	04078793          	addi	a5,a5,64 # 10203040 <_entry-0x6fdfcfc0>
    80003572:	02f71263          	bne	a4,a5,80003596 <fsinit+0x70>
  initlog(dev, &sb);
    80003576:	0001c597          	auipc	a1,0x1c
    8000357a:	66258593          	addi	a1,a1,1634 # 8001fbd8 <sb>
    8000357e:	854a                	mv	a0,s2
    80003580:	00001097          	auipc	ra,0x1
    80003584:	b40080e7          	jalr	-1216(ra) # 800040c0 <initlog>
}
    80003588:	70a2                	ld	ra,40(sp)
    8000358a:	7402                	ld	s0,32(sp)
    8000358c:	64e2                	ld	s1,24(sp)
    8000358e:	6942                	ld	s2,16(sp)
    80003590:	69a2                	ld	s3,8(sp)
    80003592:	6145                	addi	sp,sp,48
    80003594:	8082                	ret
    panic("invalid file system");
    80003596:	00005517          	auipc	a0,0x5
    8000359a:	02a50513          	addi	a0,a0,42 # 800085c0 <syscalls+0x150>
    8000359e:	ffffd097          	auipc	ra,0xffffd
    800035a2:	fa0080e7          	jalr	-96(ra) # 8000053e <panic>

00000000800035a6 <iinit>:
{
    800035a6:	7179                	addi	sp,sp,-48
    800035a8:	f406                	sd	ra,40(sp)
    800035aa:	f022                	sd	s0,32(sp)
    800035ac:	ec26                	sd	s1,24(sp)
    800035ae:	e84a                	sd	s2,16(sp)
    800035b0:	e44e                	sd	s3,8(sp)
    800035b2:	1800                	addi	s0,sp,48
  initlock(&itable.lock, "itable");
    800035b4:	00005597          	auipc	a1,0x5
    800035b8:	02458593          	addi	a1,a1,36 # 800085d8 <syscalls+0x168>
    800035bc:	0001c517          	auipc	a0,0x1c
    800035c0:	63c50513          	addi	a0,a0,1596 # 8001fbf8 <itable>
    800035c4:	ffffd097          	auipc	ra,0xffffd
    800035c8:	582080e7          	jalr	1410(ra) # 80000b46 <initlock>
  for(i = 0; i < NINODE; i++) {
    800035cc:	0001c497          	auipc	s1,0x1c
    800035d0:	65448493          	addi	s1,s1,1620 # 8001fc20 <itable+0x28>
    800035d4:	0001e997          	auipc	s3,0x1e
    800035d8:	0dc98993          	addi	s3,s3,220 # 800216b0 <log+0x10>
    initsleeplock(&itable.inode[i].lock, "inode");
    800035dc:	00005917          	auipc	s2,0x5
    800035e0:	00490913          	addi	s2,s2,4 # 800085e0 <syscalls+0x170>
    800035e4:	85ca                	mv	a1,s2
    800035e6:	8526                	mv	a0,s1
    800035e8:	00001097          	auipc	ra,0x1
    800035ec:	e3a080e7          	jalr	-454(ra) # 80004422 <initsleeplock>
  for(i = 0; i < NINODE; i++) {
    800035f0:	08848493          	addi	s1,s1,136
    800035f4:	ff3498e3          	bne	s1,s3,800035e4 <iinit+0x3e>
}
    800035f8:	70a2                	ld	ra,40(sp)
    800035fa:	7402                	ld	s0,32(sp)
    800035fc:	64e2                	ld	s1,24(sp)
    800035fe:	6942                	ld	s2,16(sp)
    80003600:	69a2                	ld	s3,8(sp)
    80003602:	6145                	addi	sp,sp,48
    80003604:	8082                	ret

0000000080003606 <ialloc>:
{
    80003606:	715d                	addi	sp,sp,-80
    80003608:	e486                	sd	ra,72(sp)
    8000360a:	e0a2                	sd	s0,64(sp)
    8000360c:	fc26                	sd	s1,56(sp)
    8000360e:	f84a                	sd	s2,48(sp)
    80003610:	f44e                	sd	s3,40(sp)
    80003612:	f052                	sd	s4,32(sp)
    80003614:	ec56                	sd	s5,24(sp)
    80003616:	e85a                	sd	s6,16(sp)
    80003618:	e45e                	sd	s7,8(sp)
    8000361a:	0880                	addi	s0,sp,80
  for(inum = 1; inum < sb.ninodes; inum++){
    8000361c:	0001c717          	auipc	a4,0x1c
    80003620:	5c872703          	lw	a4,1480(a4) # 8001fbe4 <sb+0xc>
    80003624:	4785                	li	a5,1
    80003626:	04e7fa63          	bgeu	a5,a4,8000367a <ialloc+0x74>
    8000362a:	8aaa                	mv	s5,a0
    8000362c:	8bae                	mv	s7,a1
    8000362e:	4485                	li	s1,1
    bp = bread(dev, IBLOCK(inum, sb));
    80003630:	0001ca17          	auipc	s4,0x1c
    80003634:	5a8a0a13          	addi	s4,s4,1448 # 8001fbd8 <sb>
    80003638:	00048b1b          	sext.w	s6,s1
    8000363c:	0044d793          	srli	a5,s1,0x4
    80003640:	018a2583          	lw	a1,24(s4)
    80003644:	9dbd                	addw	a1,a1,a5
    80003646:	8556                	mv	a0,s5
    80003648:	00000097          	auipc	ra,0x0
    8000364c:	940080e7          	jalr	-1728(ra) # 80002f88 <bread>
    80003650:	892a                	mv	s2,a0
    dip = (struct dinode*)bp->data + inum%IPB;
    80003652:	05850993          	addi	s3,a0,88
    80003656:	00f4f793          	andi	a5,s1,15
    8000365a:	079a                	slli	a5,a5,0x6
    8000365c:	99be                	add	s3,s3,a5
    if(dip->type == 0){  // a free inode
    8000365e:	00099783          	lh	a5,0(s3)
    80003662:	c3a1                	beqz	a5,800036a2 <ialloc+0x9c>
    brelse(bp);
    80003664:	00000097          	auipc	ra,0x0
    80003668:	a54080e7          	jalr	-1452(ra) # 800030b8 <brelse>
  for(inum = 1; inum < sb.ninodes; inum++){
    8000366c:	0485                	addi	s1,s1,1
    8000366e:	00ca2703          	lw	a4,12(s4)
    80003672:	0004879b          	sext.w	a5,s1
    80003676:	fce7e1e3          	bltu	a5,a4,80003638 <ialloc+0x32>
  printf("ialloc: no inodes\n");
    8000367a:	00005517          	auipc	a0,0x5
    8000367e:	f6e50513          	addi	a0,a0,-146 # 800085e8 <syscalls+0x178>
    80003682:	ffffd097          	auipc	ra,0xffffd
    80003686:	f06080e7          	jalr	-250(ra) # 80000588 <printf>
  return 0;
    8000368a:	4501                	li	a0,0
}
    8000368c:	60a6                	ld	ra,72(sp)
    8000368e:	6406                	ld	s0,64(sp)
    80003690:	74e2                	ld	s1,56(sp)
    80003692:	7942                	ld	s2,48(sp)
    80003694:	79a2                	ld	s3,40(sp)
    80003696:	7a02                	ld	s4,32(sp)
    80003698:	6ae2                	ld	s5,24(sp)
    8000369a:	6b42                	ld	s6,16(sp)
    8000369c:	6ba2                	ld	s7,8(sp)
    8000369e:	6161                	addi	sp,sp,80
    800036a0:	8082                	ret
      memset(dip, 0, sizeof(*dip));
    800036a2:	04000613          	li	a2,64
    800036a6:	4581                	li	a1,0
    800036a8:	854e                	mv	a0,s3
    800036aa:	ffffd097          	auipc	ra,0xffffd
    800036ae:	628080e7          	jalr	1576(ra) # 80000cd2 <memset>
      dip->type = type;
    800036b2:	01799023          	sh	s7,0(s3)
      log_write(bp);   // mark it allocated on the disk
    800036b6:	854a                	mv	a0,s2
    800036b8:	00001097          	auipc	ra,0x1
    800036bc:	c84080e7          	jalr	-892(ra) # 8000433c <log_write>
      brelse(bp);
    800036c0:	854a                	mv	a0,s2
    800036c2:	00000097          	auipc	ra,0x0
    800036c6:	9f6080e7          	jalr	-1546(ra) # 800030b8 <brelse>
      return iget(dev, inum);
    800036ca:	85da                	mv	a1,s6
    800036cc:	8556                	mv	a0,s5
    800036ce:	00000097          	auipc	ra,0x0
    800036d2:	d9c080e7          	jalr	-612(ra) # 8000346a <iget>
    800036d6:	bf5d                	j	8000368c <ialloc+0x86>

00000000800036d8 <iupdate>:
{
    800036d8:	1101                	addi	sp,sp,-32
    800036da:	ec06                	sd	ra,24(sp)
    800036dc:	e822                	sd	s0,16(sp)
    800036de:	e426                	sd	s1,8(sp)
    800036e0:	e04a                	sd	s2,0(sp)
    800036e2:	1000                	addi	s0,sp,32
    800036e4:	84aa                	mv	s1,a0
  bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    800036e6:	415c                	lw	a5,4(a0)
    800036e8:	0047d79b          	srliw	a5,a5,0x4
    800036ec:	0001c597          	auipc	a1,0x1c
    800036f0:	5045a583          	lw	a1,1284(a1) # 8001fbf0 <sb+0x18>
    800036f4:	9dbd                	addw	a1,a1,a5
    800036f6:	4108                	lw	a0,0(a0)
    800036f8:	00000097          	auipc	ra,0x0
    800036fc:	890080e7          	jalr	-1904(ra) # 80002f88 <bread>
    80003700:	892a                	mv	s2,a0
  dip = (struct dinode*)bp->data + ip->inum%IPB;
    80003702:	05850793          	addi	a5,a0,88
    80003706:	40c8                	lw	a0,4(s1)
    80003708:	893d                	andi	a0,a0,15
    8000370a:	051a                	slli	a0,a0,0x6
    8000370c:	953e                	add	a0,a0,a5
  dip->type = ip->type;
    8000370e:	04449703          	lh	a4,68(s1)
    80003712:	00e51023          	sh	a4,0(a0)
  dip->major = ip->major;
    80003716:	04649703          	lh	a4,70(s1)
    8000371a:	00e51123          	sh	a4,2(a0)
  dip->minor = ip->minor;
    8000371e:	04849703          	lh	a4,72(s1)
    80003722:	00e51223          	sh	a4,4(a0)
  dip->nlink = ip->nlink;
    80003726:	04a49703          	lh	a4,74(s1)
    8000372a:	00e51323          	sh	a4,6(a0)
  dip->size = ip->size;
    8000372e:	44f8                	lw	a4,76(s1)
    80003730:	c518                	sw	a4,8(a0)
  memmove(dip->addrs, ip->addrs, sizeof(ip->addrs));
    80003732:	03400613          	li	a2,52
    80003736:	05048593          	addi	a1,s1,80
    8000373a:	0531                	addi	a0,a0,12
    8000373c:	ffffd097          	auipc	ra,0xffffd
    80003740:	5f2080e7          	jalr	1522(ra) # 80000d2e <memmove>
  log_write(bp);
    80003744:	854a                	mv	a0,s2
    80003746:	00001097          	auipc	ra,0x1
    8000374a:	bf6080e7          	jalr	-1034(ra) # 8000433c <log_write>
  brelse(bp);
    8000374e:	854a                	mv	a0,s2
    80003750:	00000097          	auipc	ra,0x0
    80003754:	968080e7          	jalr	-1688(ra) # 800030b8 <brelse>
}
    80003758:	60e2                	ld	ra,24(sp)
    8000375a:	6442                	ld	s0,16(sp)
    8000375c:	64a2                	ld	s1,8(sp)
    8000375e:	6902                	ld	s2,0(sp)
    80003760:	6105                	addi	sp,sp,32
    80003762:	8082                	ret

0000000080003764 <idup>:
{
    80003764:	1101                	addi	sp,sp,-32
    80003766:	ec06                	sd	ra,24(sp)
    80003768:	e822                	sd	s0,16(sp)
    8000376a:	e426                	sd	s1,8(sp)
    8000376c:	1000                	addi	s0,sp,32
    8000376e:	84aa                	mv	s1,a0
  acquire(&itable.lock);
    80003770:	0001c517          	auipc	a0,0x1c
    80003774:	48850513          	addi	a0,a0,1160 # 8001fbf8 <itable>
    80003778:	ffffd097          	auipc	ra,0xffffd
    8000377c:	45e080e7          	jalr	1118(ra) # 80000bd6 <acquire>
  ip->ref++;
    80003780:	449c                	lw	a5,8(s1)
    80003782:	2785                	addiw	a5,a5,1
    80003784:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    80003786:	0001c517          	auipc	a0,0x1c
    8000378a:	47250513          	addi	a0,a0,1138 # 8001fbf8 <itable>
    8000378e:	ffffd097          	auipc	ra,0xffffd
    80003792:	4fc080e7          	jalr	1276(ra) # 80000c8a <release>
}
    80003796:	8526                	mv	a0,s1
    80003798:	60e2                	ld	ra,24(sp)
    8000379a:	6442                	ld	s0,16(sp)
    8000379c:	64a2                	ld	s1,8(sp)
    8000379e:	6105                	addi	sp,sp,32
    800037a0:	8082                	ret

00000000800037a2 <ilock>:
{
    800037a2:	1101                	addi	sp,sp,-32
    800037a4:	ec06                	sd	ra,24(sp)
    800037a6:	e822                	sd	s0,16(sp)
    800037a8:	e426                	sd	s1,8(sp)
    800037aa:	e04a                	sd	s2,0(sp)
    800037ac:	1000                	addi	s0,sp,32
  if(ip == 0 || ip->ref < 1)
    800037ae:	c115                	beqz	a0,800037d2 <ilock+0x30>
    800037b0:	84aa                	mv	s1,a0
    800037b2:	451c                	lw	a5,8(a0)
    800037b4:	00f05f63          	blez	a5,800037d2 <ilock+0x30>
  acquiresleep(&ip->lock);
    800037b8:	0541                	addi	a0,a0,16
    800037ba:	00001097          	auipc	ra,0x1
    800037be:	ca2080e7          	jalr	-862(ra) # 8000445c <acquiresleep>
  if(ip->valid == 0){
    800037c2:	40bc                	lw	a5,64(s1)
    800037c4:	cf99                	beqz	a5,800037e2 <ilock+0x40>
}
    800037c6:	60e2                	ld	ra,24(sp)
    800037c8:	6442                	ld	s0,16(sp)
    800037ca:	64a2                	ld	s1,8(sp)
    800037cc:	6902                	ld	s2,0(sp)
    800037ce:	6105                	addi	sp,sp,32
    800037d0:	8082                	ret
    panic("ilock");
    800037d2:	00005517          	auipc	a0,0x5
    800037d6:	e2e50513          	addi	a0,a0,-466 # 80008600 <syscalls+0x190>
    800037da:	ffffd097          	auipc	ra,0xffffd
    800037de:	d64080e7          	jalr	-668(ra) # 8000053e <panic>
    bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    800037e2:	40dc                	lw	a5,4(s1)
    800037e4:	0047d79b          	srliw	a5,a5,0x4
    800037e8:	0001c597          	auipc	a1,0x1c
    800037ec:	4085a583          	lw	a1,1032(a1) # 8001fbf0 <sb+0x18>
    800037f0:	9dbd                	addw	a1,a1,a5
    800037f2:	4088                	lw	a0,0(s1)
    800037f4:	fffff097          	auipc	ra,0xfffff
    800037f8:	794080e7          	jalr	1940(ra) # 80002f88 <bread>
    800037fc:	892a                	mv	s2,a0
    dip = (struct dinode*)bp->data + ip->inum%IPB;
    800037fe:	05850593          	addi	a1,a0,88
    80003802:	40dc                	lw	a5,4(s1)
    80003804:	8bbd                	andi	a5,a5,15
    80003806:	079a                	slli	a5,a5,0x6
    80003808:	95be                	add	a1,a1,a5
    ip->type = dip->type;
    8000380a:	00059783          	lh	a5,0(a1)
    8000380e:	04f49223          	sh	a5,68(s1)
    ip->major = dip->major;
    80003812:	00259783          	lh	a5,2(a1)
    80003816:	04f49323          	sh	a5,70(s1)
    ip->minor = dip->minor;
    8000381a:	00459783          	lh	a5,4(a1)
    8000381e:	04f49423          	sh	a5,72(s1)
    ip->nlink = dip->nlink;
    80003822:	00659783          	lh	a5,6(a1)
    80003826:	04f49523          	sh	a5,74(s1)
    ip->size = dip->size;
    8000382a:	459c                	lw	a5,8(a1)
    8000382c:	c4fc                	sw	a5,76(s1)
    memmove(ip->addrs, dip->addrs, sizeof(ip->addrs));
    8000382e:	03400613          	li	a2,52
    80003832:	05b1                	addi	a1,a1,12
    80003834:	05048513          	addi	a0,s1,80
    80003838:	ffffd097          	auipc	ra,0xffffd
    8000383c:	4f6080e7          	jalr	1270(ra) # 80000d2e <memmove>
    brelse(bp);
    80003840:	854a                	mv	a0,s2
    80003842:	00000097          	auipc	ra,0x0
    80003846:	876080e7          	jalr	-1930(ra) # 800030b8 <brelse>
    ip->valid = 1;
    8000384a:	4785                	li	a5,1
    8000384c:	c0bc                	sw	a5,64(s1)
    if(ip->type == 0)
    8000384e:	04449783          	lh	a5,68(s1)
    80003852:	fbb5                	bnez	a5,800037c6 <ilock+0x24>
      panic("ilock: no type");
    80003854:	00005517          	auipc	a0,0x5
    80003858:	db450513          	addi	a0,a0,-588 # 80008608 <syscalls+0x198>
    8000385c:	ffffd097          	auipc	ra,0xffffd
    80003860:	ce2080e7          	jalr	-798(ra) # 8000053e <panic>

0000000080003864 <iunlock>:
{
    80003864:	1101                	addi	sp,sp,-32
    80003866:	ec06                	sd	ra,24(sp)
    80003868:	e822                	sd	s0,16(sp)
    8000386a:	e426                	sd	s1,8(sp)
    8000386c:	e04a                	sd	s2,0(sp)
    8000386e:	1000                	addi	s0,sp,32
  if(ip == 0 || !holdingsleep(&ip->lock) || ip->ref < 1)
    80003870:	c905                	beqz	a0,800038a0 <iunlock+0x3c>
    80003872:	84aa                	mv	s1,a0
    80003874:	01050913          	addi	s2,a0,16
    80003878:	854a                	mv	a0,s2
    8000387a:	00001097          	auipc	ra,0x1
    8000387e:	c7c080e7          	jalr	-900(ra) # 800044f6 <holdingsleep>
    80003882:	cd19                	beqz	a0,800038a0 <iunlock+0x3c>
    80003884:	449c                	lw	a5,8(s1)
    80003886:	00f05d63          	blez	a5,800038a0 <iunlock+0x3c>
  releasesleep(&ip->lock);
    8000388a:	854a                	mv	a0,s2
    8000388c:	00001097          	auipc	ra,0x1
    80003890:	c26080e7          	jalr	-986(ra) # 800044b2 <releasesleep>
}
    80003894:	60e2                	ld	ra,24(sp)
    80003896:	6442                	ld	s0,16(sp)
    80003898:	64a2                	ld	s1,8(sp)
    8000389a:	6902                	ld	s2,0(sp)
    8000389c:	6105                	addi	sp,sp,32
    8000389e:	8082                	ret
    panic("iunlock");
    800038a0:	00005517          	auipc	a0,0x5
    800038a4:	d7850513          	addi	a0,a0,-648 # 80008618 <syscalls+0x1a8>
    800038a8:	ffffd097          	auipc	ra,0xffffd
    800038ac:	c96080e7          	jalr	-874(ra) # 8000053e <panic>

00000000800038b0 <itrunc>:

// Truncate inode (discard contents).
// Caller must hold ip->lock.
void
itrunc(struct inode *ip)
{
    800038b0:	7179                	addi	sp,sp,-48
    800038b2:	f406                	sd	ra,40(sp)
    800038b4:	f022                	sd	s0,32(sp)
    800038b6:	ec26                	sd	s1,24(sp)
    800038b8:	e84a                	sd	s2,16(sp)
    800038ba:	e44e                	sd	s3,8(sp)
    800038bc:	e052                	sd	s4,0(sp)
    800038be:	1800                	addi	s0,sp,48
    800038c0:	89aa                	mv	s3,a0
  int i, j;
  struct buf *bp;
  uint *a;

  for(i = 0; i < NDIRECT; i++){
    800038c2:	05050493          	addi	s1,a0,80
    800038c6:	08050913          	addi	s2,a0,128
    800038ca:	a021                	j	800038d2 <itrunc+0x22>
    800038cc:	0491                	addi	s1,s1,4
    800038ce:	01248d63          	beq	s1,s2,800038e8 <itrunc+0x38>
    if(ip->addrs[i]){
    800038d2:	408c                	lw	a1,0(s1)
    800038d4:	dde5                	beqz	a1,800038cc <itrunc+0x1c>
      bfree(ip->dev, ip->addrs[i]);
    800038d6:	0009a503          	lw	a0,0(s3)
    800038da:	00000097          	auipc	ra,0x0
    800038de:	8f4080e7          	jalr	-1804(ra) # 800031ce <bfree>
      ip->addrs[i] = 0;
    800038e2:	0004a023          	sw	zero,0(s1)
    800038e6:	b7dd                	j	800038cc <itrunc+0x1c>
    }
  }

  if(ip->addrs[NDIRECT]){
    800038e8:	0809a583          	lw	a1,128(s3)
    800038ec:	e185                	bnez	a1,8000390c <itrunc+0x5c>
    brelse(bp);
    bfree(ip->dev, ip->addrs[NDIRECT]);
    ip->addrs[NDIRECT] = 0;
  }

  ip->size = 0;
    800038ee:	0409a623          	sw	zero,76(s3)
  iupdate(ip);
    800038f2:	854e                	mv	a0,s3
    800038f4:	00000097          	auipc	ra,0x0
    800038f8:	de4080e7          	jalr	-540(ra) # 800036d8 <iupdate>
}
    800038fc:	70a2                	ld	ra,40(sp)
    800038fe:	7402                	ld	s0,32(sp)
    80003900:	64e2                	ld	s1,24(sp)
    80003902:	6942                	ld	s2,16(sp)
    80003904:	69a2                	ld	s3,8(sp)
    80003906:	6a02                	ld	s4,0(sp)
    80003908:	6145                	addi	sp,sp,48
    8000390a:	8082                	ret
    bp = bread(ip->dev, ip->addrs[NDIRECT]);
    8000390c:	0009a503          	lw	a0,0(s3)
    80003910:	fffff097          	auipc	ra,0xfffff
    80003914:	678080e7          	jalr	1656(ra) # 80002f88 <bread>
    80003918:	8a2a                	mv	s4,a0
    for(j = 0; j < NINDIRECT; j++){
    8000391a:	05850493          	addi	s1,a0,88
    8000391e:	45850913          	addi	s2,a0,1112
    80003922:	a021                	j	8000392a <itrunc+0x7a>
    80003924:	0491                	addi	s1,s1,4
    80003926:	01248b63          	beq	s1,s2,8000393c <itrunc+0x8c>
      if(a[j])
    8000392a:	408c                	lw	a1,0(s1)
    8000392c:	dde5                	beqz	a1,80003924 <itrunc+0x74>
        bfree(ip->dev, a[j]);
    8000392e:	0009a503          	lw	a0,0(s3)
    80003932:	00000097          	auipc	ra,0x0
    80003936:	89c080e7          	jalr	-1892(ra) # 800031ce <bfree>
    8000393a:	b7ed                	j	80003924 <itrunc+0x74>
    brelse(bp);
    8000393c:	8552                	mv	a0,s4
    8000393e:	fffff097          	auipc	ra,0xfffff
    80003942:	77a080e7          	jalr	1914(ra) # 800030b8 <brelse>
    bfree(ip->dev, ip->addrs[NDIRECT]);
    80003946:	0809a583          	lw	a1,128(s3)
    8000394a:	0009a503          	lw	a0,0(s3)
    8000394e:	00000097          	auipc	ra,0x0
    80003952:	880080e7          	jalr	-1920(ra) # 800031ce <bfree>
    ip->addrs[NDIRECT] = 0;
    80003956:	0809a023          	sw	zero,128(s3)
    8000395a:	bf51                	j	800038ee <itrunc+0x3e>

000000008000395c <iput>:
{
    8000395c:	1101                	addi	sp,sp,-32
    8000395e:	ec06                	sd	ra,24(sp)
    80003960:	e822                	sd	s0,16(sp)
    80003962:	e426                	sd	s1,8(sp)
    80003964:	e04a                	sd	s2,0(sp)
    80003966:	1000                	addi	s0,sp,32
    80003968:	84aa                	mv	s1,a0
  acquire(&itable.lock);
    8000396a:	0001c517          	auipc	a0,0x1c
    8000396e:	28e50513          	addi	a0,a0,654 # 8001fbf8 <itable>
    80003972:	ffffd097          	auipc	ra,0xffffd
    80003976:	264080e7          	jalr	612(ra) # 80000bd6 <acquire>
  if(ip->ref == 1 && ip->valid && ip->nlink == 0){
    8000397a:	4498                	lw	a4,8(s1)
    8000397c:	4785                	li	a5,1
    8000397e:	02f70363          	beq	a4,a5,800039a4 <iput+0x48>
  ip->ref--;
    80003982:	449c                	lw	a5,8(s1)
    80003984:	37fd                	addiw	a5,a5,-1
    80003986:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    80003988:	0001c517          	auipc	a0,0x1c
    8000398c:	27050513          	addi	a0,a0,624 # 8001fbf8 <itable>
    80003990:	ffffd097          	auipc	ra,0xffffd
    80003994:	2fa080e7          	jalr	762(ra) # 80000c8a <release>
}
    80003998:	60e2                	ld	ra,24(sp)
    8000399a:	6442                	ld	s0,16(sp)
    8000399c:	64a2                	ld	s1,8(sp)
    8000399e:	6902                	ld	s2,0(sp)
    800039a0:	6105                	addi	sp,sp,32
    800039a2:	8082                	ret
  if(ip->ref == 1 && ip->valid && ip->nlink == 0){
    800039a4:	40bc                	lw	a5,64(s1)
    800039a6:	dff1                	beqz	a5,80003982 <iput+0x26>
    800039a8:	04a49783          	lh	a5,74(s1)
    800039ac:	fbf9                	bnez	a5,80003982 <iput+0x26>
    acquiresleep(&ip->lock);
    800039ae:	01048913          	addi	s2,s1,16
    800039b2:	854a                	mv	a0,s2
    800039b4:	00001097          	auipc	ra,0x1
    800039b8:	aa8080e7          	jalr	-1368(ra) # 8000445c <acquiresleep>
    release(&itable.lock);
    800039bc:	0001c517          	auipc	a0,0x1c
    800039c0:	23c50513          	addi	a0,a0,572 # 8001fbf8 <itable>
    800039c4:	ffffd097          	auipc	ra,0xffffd
    800039c8:	2c6080e7          	jalr	710(ra) # 80000c8a <release>
    itrunc(ip);
    800039cc:	8526                	mv	a0,s1
    800039ce:	00000097          	auipc	ra,0x0
    800039d2:	ee2080e7          	jalr	-286(ra) # 800038b0 <itrunc>
    ip->type = 0;
    800039d6:	04049223          	sh	zero,68(s1)
    iupdate(ip);
    800039da:	8526                	mv	a0,s1
    800039dc:	00000097          	auipc	ra,0x0
    800039e0:	cfc080e7          	jalr	-772(ra) # 800036d8 <iupdate>
    ip->valid = 0;
    800039e4:	0404a023          	sw	zero,64(s1)
    releasesleep(&ip->lock);
    800039e8:	854a                	mv	a0,s2
    800039ea:	00001097          	auipc	ra,0x1
    800039ee:	ac8080e7          	jalr	-1336(ra) # 800044b2 <releasesleep>
    acquire(&itable.lock);
    800039f2:	0001c517          	auipc	a0,0x1c
    800039f6:	20650513          	addi	a0,a0,518 # 8001fbf8 <itable>
    800039fa:	ffffd097          	auipc	ra,0xffffd
    800039fe:	1dc080e7          	jalr	476(ra) # 80000bd6 <acquire>
    80003a02:	b741                	j	80003982 <iput+0x26>

0000000080003a04 <iunlockput>:
{
    80003a04:	1101                	addi	sp,sp,-32
    80003a06:	ec06                	sd	ra,24(sp)
    80003a08:	e822                	sd	s0,16(sp)
    80003a0a:	e426                	sd	s1,8(sp)
    80003a0c:	1000                	addi	s0,sp,32
    80003a0e:	84aa                	mv	s1,a0
  iunlock(ip);
    80003a10:	00000097          	auipc	ra,0x0
    80003a14:	e54080e7          	jalr	-428(ra) # 80003864 <iunlock>
  iput(ip);
    80003a18:	8526                	mv	a0,s1
    80003a1a:	00000097          	auipc	ra,0x0
    80003a1e:	f42080e7          	jalr	-190(ra) # 8000395c <iput>
}
    80003a22:	60e2                	ld	ra,24(sp)
    80003a24:	6442                	ld	s0,16(sp)
    80003a26:	64a2                	ld	s1,8(sp)
    80003a28:	6105                	addi	sp,sp,32
    80003a2a:	8082                	ret

0000000080003a2c <stati>:

// Copy stat information from inode.
// Caller must hold ip->lock.
void
stati(struct inode *ip, struct stat *st)
{
    80003a2c:	1141                	addi	sp,sp,-16
    80003a2e:	e422                	sd	s0,8(sp)
    80003a30:	0800                	addi	s0,sp,16
  st->dev = ip->dev;
    80003a32:	411c                	lw	a5,0(a0)
    80003a34:	c19c                	sw	a5,0(a1)
  st->ino = ip->inum;
    80003a36:	415c                	lw	a5,4(a0)
    80003a38:	c1dc                	sw	a5,4(a1)
  st->type = ip->type;
    80003a3a:	04451783          	lh	a5,68(a0)
    80003a3e:	00f59423          	sh	a5,8(a1)
  st->nlink = ip->nlink;
    80003a42:	04a51783          	lh	a5,74(a0)
    80003a46:	00f59523          	sh	a5,10(a1)
  st->size = ip->size;
    80003a4a:	04c56783          	lwu	a5,76(a0)
    80003a4e:	e99c                	sd	a5,16(a1)
}
    80003a50:	6422                	ld	s0,8(sp)
    80003a52:	0141                	addi	sp,sp,16
    80003a54:	8082                	ret

0000000080003a56 <readi>:
readi(struct inode *ip, int user_dst, uint64 dst, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if(off > ip->size || off + n < off)
    80003a56:	457c                	lw	a5,76(a0)
    80003a58:	0ed7e963          	bltu	a5,a3,80003b4a <readi+0xf4>
{
    80003a5c:	7159                	addi	sp,sp,-112
    80003a5e:	f486                	sd	ra,104(sp)
    80003a60:	f0a2                	sd	s0,96(sp)
    80003a62:	eca6                	sd	s1,88(sp)
    80003a64:	e8ca                	sd	s2,80(sp)
    80003a66:	e4ce                	sd	s3,72(sp)
    80003a68:	e0d2                	sd	s4,64(sp)
    80003a6a:	fc56                	sd	s5,56(sp)
    80003a6c:	f85a                	sd	s6,48(sp)
    80003a6e:	f45e                	sd	s7,40(sp)
    80003a70:	f062                	sd	s8,32(sp)
    80003a72:	ec66                	sd	s9,24(sp)
    80003a74:	e86a                	sd	s10,16(sp)
    80003a76:	e46e                	sd	s11,8(sp)
    80003a78:	1880                	addi	s0,sp,112
    80003a7a:	8b2a                	mv	s6,a0
    80003a7c:	8bae                	mv	s7,a1
    80003a7e:	8a32                	mv	s4,a2
    80003a80:	84b6                	mv	s1,a3
    80003a82:	8aba                	mv	s5,a4
  if(off > ip->size || off + n < off)
    80003a84:	9f35                	addw	a4,a4,a3
    return 0;
    80003a86:	4501                	li	a0,0
  if(off > ip->size || off + n < off)
    80003a88:	0ad76063          	bltu	a4,a3,80003b28 <readi+0xd2>
  if(off + n > ip->size)
    80003a8c:	00e7f463          	bgeu	a5,a4,80003a94 <readi+0x3e>
    n = ip->size - off;
    80003a90:	40d78abb          	subw	s5,a5,a3

  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    80003a94:	0a0a8963          	beqz	s5,80003b46 <readi+0xf0>
    80003a98:	4981                	li	s3,0
    uint addr = bmap(ip, off/BSIZE);
    if(addr == 0)
      break;
    bp = bread(ip->dev, addr);
    m = min(n - tot, BSIZE - off%BSIZE);
    80003a9a:	40000c93          	li	s9,1024
    if(either_copyout(user_dst, dst, bp->data + (off % BSIZE), m) == -1) {
    80003a9e:	5c7d                	li	s8,-1
    80003aa0:	a82d                	j	80003ada <readi+0x84>
    80003aa2:	020d1d93          	slli	s11,s10,0x20
    80003aa6:	020ddd93          	srli	s11,s11,0x20
    80003aaa:	05890793          	addi	a5,s2,88
    80003aae:	86ee                	mv	a3,s11
    80003ab0:	963e                	add	a2,a2,a5
    80003ab2:	85d2                	mv	a1,s4
    80003ab4:	855e                	mv	a0,s7
    80003ab6:	fffff097          	auipc	ra,0xfffff
    80003aba:	a66080e7          	jalr	-1434(ra) # 8000251c <either_copyout>
    80003abe:	05850d63          	beq	a0,s8,80003b18 <readi+0xc2>
      brelse(bp);
      tot = -1;
      break;
    }
    brelse(bp);
    80003ac2:	854a                	mv	a0,s2
    80003ac4:	fffff097          	auipc	ra,0xfffff
    80003ac8:	5f4080e7          	jalr	1524(ra) # 800030b8 <brelse>
  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    80003acc:	013d09bb          	addw	s3,s10,s3
    80003ad0:	009d04bb          	addw	s1,s10,s1
    80003ad4:	9a6e                	add	s4,s4,s11
    80003ad6:	0559f763          	bgeu	s3,s5,80003b24 <readi+0xce>
    uint addr = bmap(ip, off/BSIZE);
    80003ada:	00a4d59b          	srliw	a1,s1,0xa
    80003ade:	855a                	mv	a0,s6
    80003ae0:	00000097          	auipc	ra,0x0
    80003ae4:	8a2080e7          	jalr	-1886(ra) # 80003382 <bmap>
    80003ae8:	0005059b          	sext.w	a1,a0
    if(addr == 0)
    80003aec:	cd85                	beqz	a1,80003b24 <readi+0xce>
    bp = bread(ip->dev, addr);
    80003aee:	000b2503          	lw	a0,0(s6)
    80003af2:	fffff097          	auipc	ra,0xfffff
    80003af6:	496080e7          	jalr	1174(ra) # 80002f88 <bread>
    80003afa:	892a                	mv	s2,a0
    m = min(n - tot, BSIZE - off%BSIZE);
    80003afc:	3ff4f613          	andi	a2,s1,1023
    80003b00:	40cc87bb          	subw	a5,s9,a2
    80003b04:	413a873b          	subw	a4,s5,s3
    80003b08:	8d3e                	mv	s10,a5
    80003b0a:	2781                	sext.w	a5,a5
    80003b0c:	0007069b          	sext.w	a3,a4
    80003b10:	f8f6f9e3          	bgeu	a3,a5,80003aa2 <readi+0x4c>
    80003b14:	8d3a                	mv	s10,a4
    80003b16:	b771                	j	80003aa2 <readi+0x4c>
      brelse(bp);
    80003b18:	854a                	mv	a0,s2
    80003b1a:	fffff097          	auipc	ra,0xfffff
    80003b1e:	59e080e7          	jalr	1438(ra) # 800030b8 <brelse>
      tot = -1;
    80003b22:	59fd                	li	s3,-1
  }
  return tot;
    80003b24:	0009851b          	sext.w	a0,s3
}
    80003b28:	70a6                	ld	ra,104(sp)
    80003b2a:	7406                	ld	s0,96(sp)
    80003b2c:	64e6                	ld	s1,88(sp)
    80003b2e:	6946                	ld	s2,80(sp)
    80003b30:	69a6                	ld	s3,72(sp)
    80003b32:	6a06                	ld	s4,64(sp)
    80003b34:	7ae2                	ld	s5,56(sp)
    80003b36:	7b42                	ld	s6,48(sp)
    80003b38:	7ba2                	ld	s7,40(sp)
    80003b3a:	7c02                	ld	s8,32(sp)
    80003b3c:	6ce2                	ld	s9,24(sp)
    80003b3e:	6d42                	ld	s10,16(sp)
    80003b40:	6da2                	ld	s11,8(sp)
    80003b42:	6165                	addi	sp,sp,112
    80003b44:	8082                	ret
  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    80003b46:	89d6                	mv	s3,s5
    80003b48:	bff1                	j	80003b24 <readi+0xce>
    return 0;
    80003b4a:	4501                	li	a0,0
}
    80003b4c:	8082                	ret

0000000080003b4e <writei>:
writei(struct inode *ip, int user_src, uint64 src, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if(off > ip->size || off + n < off)
    80003b4e:	457c                	lw	a5,76(a0)
    80003b50:	10d7e863          	bltu	a5,a3,80003c60 <writei+0x112>
{
    80003b54:	7159                	addi	sp,sp,-112
    80003b56:	f486                	sd	ra,104(sp)
    80003b58:	f0a2                	sd	s0,96(sp)
    80003b5a:	eca6                	sd	s1,88(sp)
    80003b5c:	e8ca                	sd	s2,80(sp)
    80003b5e:	e4ce                	sd	s3,72(sp)
    80003b60:	e0d2                	sd	s4,64(sp)
    80003b62:	fc56                	sd	s5,56(sp)
    80003b64:	f85a                	sd	s6,48(sp)
    80003b66:	f45e                	sd	s7,40(sp)
    80003b68:	f062                	sd	s8,32(sp)
    80003b6a:	ec66                	sd	s9,24(sp)
    80003b6c:	e86a                	sd	s10,16(sp)
    80003b6e:	e46e                	sd	s11,8(sp)
    80003b70:	1880                	addi	s0,sp,112
    80003b72:	8aaa                	mv	s5,a0
    80003b74:	8bae                	mv	s7,a1
    80003b76:	8a32                	mv	s4,a2
    80003b78:	8936                	mv	s2,a3
    80003b7a:	8b3a                	mv	s6,a4
  if(off > ip->size || off + n < off)
    80003b7c:	00e687bb          	addw	a5,a3,a4
    80003b80:	0ed7e263          	bltu	a5,a3,80003c64 <writei+0x116>
    return -1;
  if(off + n > MAXFILE*BSIZE)
    80003b84:	00043737          	lui	a4,0x43
    80003b88:	0ef76063          	bltu	a4,a5,80003c68 <writei+0x11a>
    return -1;

  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    80003b8c:	0c0b0863          	beqz	s6,80003c5c <writei+0x10e>
    80003b90:	4981                	li	s3,0
    uint addr = bmap(ip, off/BSIZE);
    if(addr == 0)
      break;
    bp = bread(ip->dev, addr);
    m = min(n - tot, BSIZE - off%BSIZE);
    80003b92:	40000c93          	li	s9,1024
    if(either_copyin(bp->data + (off % BSIZE), user_src, src, m) == -1) {
    80003b96:	5c7d                	li	s8,-1
    80003b98:	a091                	j	80003bdc <writei+0x8e>
    80003b9a:	020d1d93          	slli	s11,s10,0x20
    80003b9e:	020ddd93          	srli	s11,s11,0x20
    80003ba2:	05848793          	addi	a5,s1,88
    80003ba6:	86ee                	mv	a3,s11
    80003ba8:	8652                	mv	a2,s4
    80003baa:	85de                	mv	a1,s7
    80003bac:	953e                	add	a0,a0,a5
    80003bae:	fffff097          	auipc	ra,0xfffff
    80003bb2:	9c4080e7          	jalr	-1596(ra) # 80002572 <either_copyin>
    80003bb6:	07850263          	beq	a0,s8,80003c1a <writei+0xcc>
      brelse(bp);
      break;
    }
    log_write(bp);
    80003bba:	8526                	mv	a0,s1
    80003bbc:	00000097          	auipc	ra,0x0
    80003bc0:	780080e7          	jalr	1920(ra) # 8000433c <log_write>
    brelse(bp);
    80003bc4:	8526                	mv	a0,s1
    80003bc6:	fffff097          	auipc	ra,0xfffff
    80003bca:	4f2080e7          	jalr	1266(ra) # 800030b8 <brelse>
  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    80003bce:	013d09bb          	addw	s3,s10,s3
    80003bd2:	012d093b          	addw	s2,s10,s2
    80003bd6:	9a6e                	add	s4,s4,s11
    80003bd8:	0569f663          	bgeu	s3,s6,80003c24 <writei+0xd6>
    uint addr = bmap(ip, off/BSIZE);
    80003bdc:	00a9559b          	srliw	a1,s2,0xa
    80003be0:	8556                	mv	a0,s5
    80003be2:	fffff097          	auipc	ra,0xfffff
    80003be6:	7a0080e7          	jalr	1952(ra) # 80003382 <bmap>
    80003bea:	0005059b          	sext.w	a1,a0
    if(addr == 0)
    80003bee:	c99d                	beqz	a1,80003c24 <writei+0xd6>
    bp = bread(ip->dev, addr);
    80003bf0:	000aa503          	lw	a0,0(s5)
    80003bf4:	fffff097          	auipc	ra,0xfffff
    80003bf8:	394080e7          	jalr	916(ra) # 80002f88 <bread>
    80003bfc:	84aa                	mv	s1,a0
    m = min(n - tot, BSIZE - off%BSIZE);
    80003bfe:	3ff97513          	andi	a0,s2,1023
    80003c02:	40ac87bb          	subw	a5,s9,a0
    80003c06:	413b073b          	subw	a4,s6,s3
    80003c0a:	8d3e                	mv	s10,a5
    80003c0c:	2781                	sext.w	a5,a5
    80003c0e:	0007069b          	sext.w	a3,a4
    80003c12:	f8f6f4e3          	bgeu	a3,a5,80003b9a <writei+0x4c>
    80003c16:	8d3a                	mv	s10,a4
    80003c18:	b749                	j	80003b9a <writei+0x4c>
      brelse(bp);
    80003c1a:	8526                	mv	a0,s1
    80003c1c:	fffff097          	auipc	ra,0xfffff
    80003c20:	49c080e7          	jalr	1180(ra) # 800030b8 <brelse>
  }

  if(off > ip->size)
    80003c24:	04caa783          	lw	a5,76(s5)
    80003c28:	0127f463          	bgeu	a5,s2,80003c30 <writei+0xe2>
    ip->size = off;
    80003c2c:	052aa623          	sw	s2,76(s5)

  // write the i-node back to disk even if the size didn't change
  // because the loop above might have called bmap() and added a new
  // block to ip->addrs[].
  iupdate(ip);
    80003c30:	8556                	mv	a0,s5
    80003c32:	00000097          	auipc	ra,0x0
    80003c36:	aa6080e7          	jalr	-1370(ra) # 800036d8 <iupdate>

  return tot;
    80003c3a:	0009851b          	sext.w	a0,s3
}
    80003c3e:	70a6                	ld	ra,104(sp)
    80003c40:	7406                	ld	s0,96(sp)
    80003c42:	64e6                	ld	s1,88(sp)
    80003c44:	6946                	ld	s2,80(sp)
    80003c46:	69a6                	ld	s3,72(sp)
    80003c48:	6a06                	ld	s4,64(sp)
    80003c4a:	7ae2                	ld	s5,56(sp)
    80003c4c:	7b42                	ld	s6,48(sp)
    80003c4e:	7ba2                	ld	s7,40(sp)
    80003c50:	7c02                	ld	s8,32(sp)
    80003c52:	6ce2                	ld	s9,24(sp)
    80003c54:	6d42                	ld	s10,16(sp)
    80003c56:	6da2                	ld	s11,8(sp)
    80003c58:	6165                	addi	sp,sp,112
    80003c5a:	8082                	ret
  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    80003c5c:	89da                	mv	s3,s6
    80003c5e:	bfc9                	j	80003c30 <writei+0xe2>
    return -1;
    80003c60:	557d                	li	a0,-1
}
    80003c62:	8082                	ret
    return -1;
    80003c64:	557d                	li	a0,-1
    80003c66:	bfe1                	j	80003c3e <writei+0xf0>
    return -1;
    80003c68:	557d                	li	a0,-1
    80003c6a:	bfd1                	j	80003c3e <writei+0xf0>

0000000080003c6c <namecmp>:

// Directories

int
namecmp(const char *s, const char *t)
{
    80003c6c:	1141                	addi	sp,sp,-16
    80003c6e:	e406                	sd	ra,8(sp)
    80003c70:	e022                	sd	s0,0(sp)
    80003c72:	0800                	addi	s0,sp,16
  return strncmp(s, t, DIRSIZ);
    80003c74:	4639                	li	a2,14
    80003c76:	ffffd097          	auipc	ra,0xffffd
    80003c7a:	12c080e7          	jalr	300(ra) # 80000da2 <strncmp>
}
    80003c7e:	60a2                	ld	ra,8(sp)
    80003c80:	6402                	ld	s0,0(sp)
    80003c82:	0141                	addi	sp,sp,16
    80003c84:	8082                	ret

0000000080003c86 <dirlookup>:

// Look for a directory entry in a directory.
// If found, set *poff to byte offset of entry.
struct inode*
dirlookup(struct inode *dp, char *name, uint *poff)
{
    80003c86:	7139                	addi	sp,sp,-64
    80003c88:	fc06                	sd	ra,56(sp)
    80003c8a:	f822                	sd	s0,48(sp)
    80003c8c:	f426                	sd	s1,40(sp)
    80003c8e:	f04a                	sd	s2,32(sp)
    80003c90:	ec4e                	sd	s3,24(sp)
    80003c92:	e852                	sd	s4,16(sp)
    80003c94:	0080                	addi	s0,sp,64
  uint off, inum;
  struct dirent de;

  if(dp->type != T_DIR)
    80003c96:	04451703          	lh	a4,68(a0)
    80003c9a:	4785                	li	a5,1
    80003c9c:	00f71a63          	bne	a4,a5,80003cb0 <dirlookup+0x2a>
    80003ca0:	892a                	mv	s2,a0
    80003ca2:	89ae                	mv	s3,a1
    80003ca4:	8a32                	mv	s4,a2
    panic("dirlookup not DIR");

  for(off = 0; off < dp->size; off += sizeof(de)){
    80003ca6:	457c                	lw	a5,76(a0)
    80003ca8:	4481                	li	s1,0
      inum = de.inum;
      return iget(dp->dev, inum);
    }
  }

  return 0;
    80003caa:	4501                	li	a0,0
  for(off = 0; off < dp->size; off += sizeof(de)){
    80003cac:	e79d                	bnez	a5,80003cda <dirlookup+0x54>
    80003cae:	a8a5                	j	80003d26 <dirlookup+0xa0>
    panic("dirlookup not DIR");
    80003cb0:	00005517          	auipc	a0,0x5
    80003cb4:	97050513          	addi	a0,a0,-1680 # 80008620 <syscalls+0x1b0>
    80003cb8:	ffffd097          	auipc	ra,0xffffd
    80003cbc:	886080e7          	jalr	-1914(ra) # 8000053e <panic>
      panic("dirlookup read");
    80003cc0:	00005517          	auipc	a0,0x5
    80003cc4:	97850513          	addi	a0,a0,-1672 # 80008638 <syscalls+0x1c8>
    80003cc8:	ffffd097          	auipc	ra,0xffffd
    80003ccc:	876080e7          	jalr	-1930(ra) # 8000053e <panic>
  for(off = 0; off < dp->size; off += sizeof(de)){
    80003cd0:	24c1                	addiw	s1,s1,16
    80003cd2:	04c92783          	lw	a5,76(s2)
    80003cd6:	04f4f763          	bgeu	s1,a5,80003d24 <dirlookup+0x9e>
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80003cda:	4741                	li	a4,16
    80003cdc:	86a6                	mv	a3,s1
    80003cde:	fc040613          	addi	a2,s0,-64
    80003ce2:	4581                	li	a1,0
    80003ce4:	854a                	mv	a0,s2
    80003ce6:	00000097          	auipc	ra,0x0
    80003cea:	d70080e7          	jalr	-656(ra) # 80003a56 <readi>
    80003cee:	47c1                	li	a5,16
    80003cf0:	fcf518e3          	bne	a0,a5,80003cc0 <dirlookup+0x3a>
    if(de.inum == 0)
    80003cf4:	fc045783          	lhu	a5,-64(s0)
    80003cf8:	dfe1                	beqz	a5,80003cd0 <dirlookup+0x4a>
    if(namecmp(name, de.name) == 0){
    80003cfa:	fc240593          	addi	a1,s0,-62
    80003cfe:	854e                	mv	a0,s3
    80003d00:	00000097          	auipc	ra,0x0
    80003d04:	f6c080e7          	jalr	-148(ra) # 80003c6c <namecmp>
    80003d08:	f561                	bnez	a0,80003cd0 <dirlookup+0x4a>
      if(poff)
    80003d0a:	000a0463          	beqz	s4,80003d12 <dirlookup+0x8c>
        *poff = off;
    80003d0e:	009a2023          	sw	s1,0(s4)
      return iget(dp->dev, inum);
    80003d12:	fc045583          	lhu	a1,-64(s0)
    80003d16:	00092503          	lw	a0,0(s2)
    80003d1a:	fffff097          	auipc	ra,0xfffff
    80003d1e:	750080e7          	jalr	1872(ra) # 8000346a <iget>
    80003d22:	a011                	j	80003d26 <dirlookup+0xa0>
  return 0;
    80003d24:	4501                	li	a0,0
}
    80003d26:	70e2                	ld	ra,56(sp)
    80003d28:	7442                	ld	s0,48(sp)
    80003d2a:	74a2                	ld	s1,40(sp)
    80003d2c:	7902                	ld	s2,32(sp)
    80003d2e:	69e2                	ld	s3,24(sp)
    80003d30:	6a42                	ld	s4,16(sp)
    80003d32:	6121                	addi	sp,sp,64
    80003d34:	8082                	ret

0000000080003d36 <namex>:
// If parent != 0, return the inode for the parent and copy the final
// path element into name, which must have room for DIRSIZ bytes.
// Must be called inside a transaction since it calls iput().
static struct inode*
namex(char *path, int nameiparent, char *name)
{
    80003d36:	711d                	addi	sp,sp,-96
    80003d38:	ec86                	sd	ra,88(sp)
    80003d3a:	e8a2                	sd	s0,80(sp)
    80003d3c:	e4a6                	sd	s1,72(sp)
    80003d3e:	e0ca                	sd	s2,64(sp)
    80003d40:	fc4e                	sd	s3,56(sp)
    80003d42:	f852                	sd	s4,48(sp)
    80003d44:	f456                	sd	s5,40(sp)
    80003d46:	f05a                	sd	s6,32(sp)
    80003d48:	ec5e                	sd	s7,24(sp)
    80003d4a:	e862                	sd	s8,16(sp)
    80003d4c:	e466                	sd	s9,8(sp)
    80003d4e:	1080                	addi	s0,sp,96
    80003d50:	84aa                	mv	s1,a0
    80003d52:	8aae                	mv	s5,a1
    80003d54:	8a32                	mv	s4,a2
  struct inode *ip, *next;

  if(*path == '/')
    80003d56:	00054703          	lbu	a4,0(a0)
    80003d5a:	02f00793          	li	a5,47
    80003d5e:	02f70363          	beq	a4,a5,80003d84 <namex+0x4e>
    ip = iget(ROOTDEV, ROOTINO);
  else
    ip = idup(myproc()->cwd);
    80003d62:	ffffe097          	auipc	ra,0xffffe
    80003d66:	c80080e7          	jalr	-896(ra) # 800019e2 <myproc>
    80003d6a:	15053503          	ld	a0,336(a0)
    80003d6e:	00000097          	auipc	ra,0x0
    80003d72:	9f6080e7          	jalr	-1546(ra) # 80003764 <idup>
    80003d76:	89aa                	mv	s3,a0
  while(*path == '/')
    80003d78:	02f00913          	li	s2,47
  len = path - s;
    80003d7c:	4b01                	li	s6,0
  if(len >= DIRSIZ)
    80003d7e:	4c35                	li	s8,13

  while((path = skipelem(path, name)) != 0){
    ilock(ip);
    if(ip->type != T_DIR){
    80003d80:	4b85                	li	s7,1
    80003d82:	a865                	j	80003e3a <namex+0x104>
    ip = iget(ROOTDEV, ROOTINO);
    80003d84:	4585                	li	a1,1
    80003d86:	4505                	li	a0,1
    80003d88:	fffff097          	auipc	ra,0xfffff
    80003d8c:	6e2080e7          	jalr	1762(ra) # 8000346a <iget>
    80003d90:	89aa                	mv	s3,a0
    80003d92:	b7dd                	j	80003d78 <namex+0x42>
      iunlockput(ip);
    80003d94:	854e                	mv	a0,s3
    80003d96:	00000097          	auipc	ra,0x0
    80003d9a:	c6e080e7          	jalr	-914(ra) # 80003a04 <iunlockput>
      return 0;
    80003d9e:	4981                	li	s3,0
  if(nameiparent){
    iput(ip);
    return 0;
  }
  return ip;
}
    80003da0:	854e                	mv	a0,s3
    80003da2:	60e6                	ld	ra,88(sp)
    80003da4:	6446                	ld	s0,80(sp)
    80003da6:	64a6                	ld	s1,72(sp)
    80003da8:	6906                	ld	s2,64(sp)
    80003daa:	79e2                	ld	s3,56(sp)
    80003dac:	7a42                	ld	s4,48(sp)
    80003dae:	7aa2                	ld	s5,40(sp)
    80003db0:	7b02                	ld	s6,32(sp)
    80003db2:	6be2                	ld	s7,24(sp)
    80003db4:	6c42                	ld	s8,16(sp)
    80003db6:	6ca2                	ld	s9,8(sp)
    80003db8:	6125                	addi	sp,sp,96
    80003dba:	8082                	ret
      iunlock(ip);
    80003dbc:	854e                	mv	a0,s3
    80003dbe:	00000097          	auipc	ra,0x0
    80003dc2:	aa6080e7          	jalr	-1370(ra) # 80003864 <iunlock>
      return ip;
    80003dc6:	bfe9                	j	80003da0 <namex+0x6a>
      iunlockput(ip);
    80003dc8:	854e                	mv	a0,s3
    80003dca:	00000097          	auipc	ra,0x0
    80003dce:	c3a080e7          	jalr	-966(ra) # 80003a04 <iunlockput>
      return 0;
    80003dd2:	89e6                	mv	s3,s9
    80003dd4:	b7f1                	j	80003da0 <namex+0x6a>
  len = path - s;
    80003dd6:	40b48633          	sub	a2,s1,a1
    80003dda:	00060c9b          	sext.w	s9,a2
  if(len >= DIRSIZ)
    80003dde:	099c5463          	bge	s8,s9,80003e66 <namex+0x130>
    memmove(name, s, DIRSIZ);
    80003de2:	4639                	li	a2,14
    80003de4:	8552                	mv	a0,s4
    80003de6:	ffffd097          	auipc	ra,0xffffd
    80003dea:	f48080e7          	jalr	-184(ra) # 80000d2e <memmove>
  while(*path == '/')
    80003dee:	0004c783          	lbu	a5,0(s1)
    80003df2:	01279763          	bne	a5,s2,80003e00 <namex+0xca>
    path++;
    80003df6:	0485                	addi	s1,s1,1
  while(*path == '/')
    80003df8:	0004c783          	lbu	a5,0(s1)
    80003dfc:	ff278de3          	beq	a5,s2,80003df6 <namex+0xc0>
    ilock(ip);
    80003e00:	854e                	mv	a0,s3
    80003e02:	00000097          	auipc	ra,0x0
    80003e06:	9a0080e7          	jalr	-1632(ra) # 800037a2 <ilock>
    if(ip->type != T_DIR){
    80003e0a:	04499783          	lh	a5,68(s3)
    80003e0e:	f97793e3          	bne	a5,s7,80003d94 <namex+0x5e>
    if(nameiparent && *path == '\0'){
    80003e12:	000a8563          	beqz	s5,80003e1c <namex+0xe6>
    80003e16:	0004c783          	lbu	a5,0(s1)
    80003e1a:	d3cd                	beqz	a5,80003dbc <namex+0x86>
    if((next = dirlookup(ip, name, 0)) == 0){
    80003e1c:	865a                	mv	a2,s6
    80003e1e:	85d2                	mv	a1,s4
    80003e20:	854e                	mv	a0,s3
    80003e22:	00000097          	auipc	ra,0x0
    80003e26:	e64080e7          	jalr	-412(ra) # 80003c86 <dirlookup>
    80003e2a:	8caa                	mv	s9,a0
    80003e2c:	dd51                	beqz	a0,80003dc8 <namex+0x92>
    iunlockput(ip);
    80003e2e:	854e                	mv	a0,s3
    80003e30:	00000097          	auipc	ra,0x0
    80003e34:	bd4080e7          	jalr	-1068(ra) # 80003a04 <iunlockput>
    ip = next;
    80003e38:	89e6                	mv	s3,s9
  while(*path == '/')
    80003e3a:	0004c783          	lbu	a5,0(s1)
    80003e3e:	05279763          	bne	a5,s2,80003e8c <namex+0x156>
    path++;
    80003e42:	0485                	addi	s1,s1,1
  while(*path == '/')
    80003e44:	0004c783          	lbu	a5,0(s1)
    80003e48:	ff278de3          	beq	a5,s2,80003e42 <namex+0x10c>
  if(*path == 0)
    80003e4c:	c79d                	beqz	a5,80003e7a <namex+0x144>
    path++;
    80003e4e:	85a6                	mv	a1,s1
  len = path - s;
    80003e50:	8cda                	mv	s9,s6
    80003e52:	865a                	mv	a2,s6
  while(*path != '/' && *path != 0)
    80003e54:	01278963          	beq	a5,s2,80003e66 <namex+0x130>
    80003e58:	dfbd                	beqz	a5,80003dd6 <namex+0xa0>
    path++;
    80003e5a:	0485                	addi	s1,s1,1
  while(*path != '/' && *path != 0)
    80003e5c:	0004c783          	lbu	a5,0(s1)
    80003e60:	ff279ce3          	bne	a5,s2,80003e58 <namex+0x122>
    80003e64:	bf8d                	j	80003dd6 <namex+0xa0>
    memmove(name, s, len);
    80003e66:	2601                	sext.w	a2,a2
    80003e68:	8552                	mv	a0,s4
    80003e6a:	ffffd097          	auipc	ra,0xffffd
    80003e6e:	ec4080e7          	jalr	-316(ra) # 80000d2e <memmove>
    name[len] = 0;
    80003e72:	9cd2                	add	s9,s9,s4
    80003e74:	000c8023          	sb	zero,0(s9) # 2000 <_entry-0x7fffe000>
    80003e78:	bf9d                	j	80003dee <namex+0xb8>
  if(nameiparent){
    80003e7a:	f20a83e3          	beqz	s5,80003da0 <namex+0x6a>
    iput(ip);
    80003e7e:	854e                	mv	a0,s3
    80003e80:	00000097          	auipc	ra,0x0
    80003e84:	adc080e7          	jalr	-1316(ra) # 8000395c <iput>
    return 0;
    80003e88:	4981                	li	s3,0
    80003e8a:	bf19                	j	80003da0 <namex+0x6a>
  if(*path == 0)
    80003e8c:	d7fd                	beqz	a5,80003e7a <namex+0x144>
  while(*path != '/' && *path != 0)
    80003e8e:	0004c783          	lbu	a5,0(s1)
    80003e92:	85a6                	mv	a1,s1
    80003e94:	b7d1                	j	80003e58 <namex+0x122>

0000000080003e96 <dirlink>:
{
    80003e96:	7139                	addi	sp,sp,-64
    80003e98:	fc06                	sd	ra,56(sp)
    80003e9a:	f822                	sd	s0,48(sp)
    80003e9c:	f426                	sd	s1,40(sp)
    80003e9e:	f04a                	sd	s2,32(sp)
    80003ea0:	ec4e                	sd	s3,24(sp)
    80003ea2:	e852                	sd	s4,16(sp)
    80003ea4:	0080                	addi	s0,sp,64
    80003ea6:	892a                	mv	s2,a0
    80003ea8:	8a2e                	mv	s4,a1
    80003eaa:	89b2                	mv	s3,a2
  if((ip = dirlookup(dp, name, 0)) != 0){
    80003eac:	4601                	li	a2,0
    80003eae:	00000097          	auipc	ra,0x0
    80003eb2:	dd8080e7          	jalr	-552(ra) # 80003c86 <dirlookup>
    80003eb6:	e93d                	bnez	a0,80003f2c <dirlink+0x96>
  for(off = 0; off < dp->size; off += sizeof(de)){
    80003eb8:	04c92483          	lw	s1,76(s2)
    80003ebc:	c49d                	beqz	s1,80003eea <dirlink+0x54>
    80003ebe:	4481                	li	s1,0
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80003ec0:	4741                	li	a4,16
    80003ec2:	86a6                	mv	a3,s1
    80003ec4:	fc040613          	addi	a2,s0,-64
    80003ec8:	4581                	li	a1,0
    80003eca:	854a                	mv	a0,s2
    80003ecc:	00000097          	auipc	ra,0x0
    80003ed0:	b8a080e7          	jalr	-1142(ra) # 80003a56 <readi>
    80003ed4:	47c1                	li	a5,16
    80003ed6:	06f51163          	bne	a0,a5,80003f38 <dirlink+0xa2>
    if(de.inum == 0)
    80003eda:	fc045783          	lhu	a5,-64(s0)
    80003ede:	c791                	beqz	a5,80003eea <dirlink+0x54>
  for(off = 0; off < dp->size; off += sizeof(de)){
    80003ee0:	24c1                	addiw	s1,s1,16
    80003ee2:	04c92783          	lw	a5,76(s2)
    80003ee6:	fcf4ede3          	bltu	s1,a5,80003ec0 <dirlink+0x2a>
  strncpy(de.name, name, DIRSIZ);
    80003eea:	4639                	li	a2,14
    80003eec:	85d2                	mv	a1,s4
    80003eee:	fc240513          	addi	a0,s0,-62
    80003ef2:	ffffd097          	auipc	ra,0xffffd
    80003ef6:	eec080e7          	jalr	-276(ra) # 80000dde <strncpy>
  de.inum = inum;
    80003efa:	fd341023          	sh	s3,-64(s0)
  if(writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80003efe:	4741                	li	a4,16
    80003f00:	86a6                	mv	a3,s1
    80003f02:	fc040613          	addi	a2,s0,-64
    80003f06:	4581                	li	a1,0
    80003f08:	854a                	mv	a0,s2
    80003f0a:	00000097          	auipc	ra,0x0
    80003f0e:	c44080e7          	jalr	-956(ra) # 80003b4e <writei>
    80003f12:	1541                	addi	a0,a0,-16
    80003f14:	00a03533          	snez	a0,a0
    80003f18:	40a00533          	neg	a0,a0
}
    80003f1c:	70e2                	ld	ra,56(sp)
    80003f1e:	7442                	ld	s0,48(sp)
    80003f20:	74a2                	ld	s1,40(sp)
    80003f22:	7902                	ld	s2,32(sp)
    80003f24:	69e2                	ld	s3,24(sp)
    80003f26:	6a42                	ld	s4,16(sp)
    80003f28:	6121                	addi	sp,sp,64
    80003f2a:	8082                	ret
    iput(ip);
    80003f2c:	00000097          	auipc	ra,0x0
    80003f30:	a30080e7          	jalr	-1488(ra) # 8000395c <iput>
    return -1;
    80003f34:	557d                	li	a0,-1
    80003f36:	b7dd                	j	80003f1c <dirlink+0x86>
      panic("dirlink read");
    80003f38:	00004517          	auipc	a0,0x4
    80003f3c:	71050513          	addi	a0,a0,1808 # 80008648 <syscalls+0x1d8>
    80003f40:	ffffc097          	auipc	ra,0xffffc
    80003f44:	5fe080e7          	jalr	1534(ra) # 8000053e <panic>

0000000080003f48 <namei>:

struct inode*
namei(char *path)
{
    80003f48:	1101                	addi	sp,sp,-32
    80003f4a:	ec06                	sd	ra,24(sp)
    80003f4c:	e822                	sd	s0,16(sp)
    80003f4e:	1000                	addi	s0,sp,32
  char name[DIRSIZ];
  return namex(path, 0, name);
    80003f50:	fe040613          	addi	a2,s0,-32
    80003f54:	4581                	li	a1,0
    80003f56:	00000097          	auipc	ra,0x0
    80003f5a:	de0080e7          	jalr	-544(ra) # 80003d36 <namex>
}
    80003f5e:	60e2                	ld	ra,24(sp)
    80003f60:	6442                	ld	s0,16(sp)
    80003f62:	6105                	addi	sp,sp,32
    80003f64:	8082                	ret

0000000080003f66 <nameiparent>:

struct inode*
nameiparent(char *path, char *name)
{
    80003f66:	1141                	addi	sp,sp,-16
    80003f68:	e406                	sd	ra,8(sp)
    80003f6a:	e022                	sd	s0,0(sp)
    80003f6c:	0800                	addi	s0,sp,16
    80003f6e:	862e                	mv	a2,a1
  return namex(path, 1, name);
    80003f70:	4585                	li	a1,1
    80003f72:	00000097          	auipc	ra,0x0
    80003f76:	dc4080e7          	jalr	-572(ra) # 80003d36 <namex>
}
    80003f7a:	60a2                	ld	ra,8(sp)
    80003f7c:	6402                	ld	s0,0(sp)
    80003f7e:	0141                	addi	sp,sp,16
    80003f80:	8082                	ret

0000000080003f82 <write_head>:
// Write in-memory log header to disk.
// This is the true point at which the
// current transaction commits.
static void
write_head(void)
{
    80003f82:	1101                	addi	sp,sp,-32
    80003f84:	ec06                	sd	ra,24(sp)
    80003f86:	e822                	sd	s0,16(sp)
    80003f88:	e426                	sd	s1,8(sp)
    80003f8a:	e04a                	sd	s2,0(sp)
    80003f8c:	1000                	addi	s0,sp,32
  struct buf *buf = bread(log.dev, log.start);
    80003f8e:	0001d917          	auipc	s2,0x1d
    80003f92:	71290913          	addi	s2,s2,1810 # 800216a0 <log>
    80003f96:	01892583          	lw	a1,24(s2)
    80003f9a:	02892503          	lw	a0,40(s2)
    80003f9e:	fffff097          	auipc	ra,0xfffff
    80003fa2:	fea080e7          	jalr	-22(ra) # 80002f88 <bread>
    80003fa6:	84aa                	mv	s1,a0
  struct logheader *hb = (struct logheader *) (buf->data);
  int i;
  hb->n = log.lh.n;
    80003fa8:	02c92683          	lw	a3,44(s2)
    80003fac:	cd34                	sw	a3,88(a0)
  for (i = 0; i < log.lh.n; i++) {
    80003fae:	02d05763          	blez	a3,80003fdc <write_head+0x5a>
    80003fb2:	0001d797          	auipc	a5,0x1d
    80003fb6:	71e78793          	addi	a5,a5,1822 # 800216d0 <log+0x30>
    80003fba:	05c50713          	addi	a4,a0,92
    80003fbe:	36fd                	addiw	a3,a3,-1
    80003fc0:	1682                	slli	a3,a3,0x20
    80003fc2:	9281                	srli	a3,a3,0x20
    80003fc4:	068a                	slli	a3,a3,0x2
    80003fc6:	0001d617          	auipc	a2,0x1d
    80003fca:	70e60613          	addi	a2,a2,1806 # 800216d4 <log+0x34>
    80003fce:	96b2                	add	a3,a3,a2
    hb->block[i] = log.lh.block[i];
    80003fd0:	4390                	lw	a2,0(a5)
    80003fd2:	c310                	sw	a2,0(a4)
  for (i = 0; i < log.lh.n; i++) {
    80003fd4:	0791                	addi	a5,a5,4
    80003fd6:	0711                	addi	a4,a4,4
    80003fd8:	fed79ce3          	bne	a5,a3,80003fd0 <write_head+0x4e>
  }
  bwrite(buf);
    80003fdc:	8526                	mv	a0,s1
    80003fde:	fffff097          	auipc	ra,0xfffff
    80003fe2:	09c080e7          	jalr	156(ra) # 8000307a <bwrite>
  brelse(buf);
    80003fe6:	8526                	mv	a0,s1
    80003fe8:	fffff097          	auipc	ra,0xfffff
    80003fec:	0d0080e7          	jalr	208(ra) # 800030b8 <brelse>
}
    80003ff0:	60e2                	ld	ra,24(sp)
    80003ff2:	6442                	ld	s0,16(sp)
    80003ff4:	64a2                	ld	s1,8(sp)
    80003ff6:	6902                	ld	s2,0(sp)
    80003ff8:	6105                	addi	sp,sp,32
    80003ffa:	8082                	ret

0000000080003ffc <install_trans>:
  for (tail = 0; tail < log.lh.n; tail++) {
    80003ffc:	0001d797          	auipc	a5,0x1d
    80004000:	6d07a783          	lw	a5,1744(a5) # 800216cc <log+0x2c>
    80004004:	0af05d63          	blez	a5,800040be <install_trans+0xc2>
{
    80004008:	7139                	addi	sp,sp,-64
    8000400a:	fc06                	sd	ra,56(sp)
    8000400c:	f822                	sd	s0,48(sp)
    8000400e:	f426                	sd	s1,40(sp)
    80004010:	f04a                	sd	s2,32(sp)
    80004012:	ec4e                	sd	s3,24(sp)
    80004014:	e852                	sd	s4,16(sp)
    80004016:	e456                	sd	s5,8(sp)
    80004018:	e05a                	sd	s6,0(sp)
    8000401a:	0080                	addi	s0,sp,64
    8000401c:	8b2a                	mv	s6,a0
    8000401e:	0001da97          	auipc	s5,0x1d
    80004022:	6b2a8a93          	addi	s5,s5,1714 # 800216d0 <log+0x30>
  for (tail = 0; tail < log.lh.n; tail++) {
    80004026:	4a01                	li	s4,0
    struct buf *lbuf = bread(log.dev, log.start+tail+1); // read log block
    80004028:	0001d997          	auipc	s3,0x1d
    8000402c:	67898993          	addi	s3,s3,1656 # 800216a0 <log>
    80004030:	a00d                	j	80004052 <install_trans+0x56>
    brelse(lbuf);
    80004032:	854a                	mv	a0,s2
    80004034:	fffff097          	auipc	ra,0xfffff
    80004038:	084080e7          	jalr	132(ra) # 800030b8 <brelse>
    brelse(dbuf);
    8000403c:	8526                	mv	a0,s1
    8000403e:	fffff097          	auipc	ra,0xfffff
    80004042:	07a080e7          	jalr	122(ra) # 800030b8 <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
    80004046:	2a05                	addiw	s4,s4,1
    80004048:	0a91                	addi	s5,s5,4
    8000404a:	02c9a783          	lw	a5,44(s3)
    8000404e:	04fa5e63          	bge	s4,a5,800040aa <install_trans+0xae>
    struct buf *lbuf = bread(log.dev, log.start+tail+1); // read log block
    80004052:	0189a583          	lw	a1,24(s3)
    80004056:	014585bb          	addw	a1,a1,s4
    8000405a:	2585                	addiw	a1,a1,1
    8000405c:	0289a503          	lw	a0,40(s3)
    80004060:	fffff097          	auipc	ra,0xfffff
    80004064:	f28080e7          	jalr	-216(ra) # 80002f88 <bread>
    80004068:	892a                	mv	s2,a0
    struct buf *dbuf = bread(log.dev, log.lh.block[tail]); // read dst
    8000406a:	000aa583          	lw	a1,0(s5)
    8000406e:	0289a503          	lw	a0,40(s3)
    80004072:	fffff097          	auipc	ra,0xfffff
    80004076:	f16080e7          	jalr	-234(ra) # 80002f88 <bread>
    8000407a:	84aa                	mv	s1,a0
    memmove(dbuf->data, lbuf->data, BSIZE);  // copy block to dst
    8000407c:	40000613          	li	a2,1024
    80004080:	05890593          	addi	a1,s2,88
    80004084:	05850513          	addi	a0,a0,88
    80004088:	ffffd097          	auipc	ra,0xffffd
    8000408c:	ca6080e7          	jalr	-858(ra) # 80000d2e <memmove>
    bwrite(dbuf);  // write dst to disk
    80004090:	8526                	mv	a0,s1
    80004092:	fffff097          	auipc	ra,0xfffff
    80004096:	fe8080e7          	jalr	-24(ra) # 8000307a <bwrite>
    if(recovering == 0)
    8000409a:	f80b1ce3          	bnez	s6,80004032 <install_trans+0x36>
      bunpin(dbuf);
    8000409e:	8526                	mv	a0,s1
    800040a0:	fffff097          	auipc	ra,0xfffff
    800040a4:	0f2080e7          	jalr	242(ra) # 80003192 <bunpin>
    800040a8:	b769                	j	80004032 <install_trans+0x36>
}
    800040aa:	70e2                	ld	ra,56(sp)
    800040ac:	7442                	ld	s0,48(sp)
    800040ae:	74a2                	ld	s1,40(sp)
    800040b0:	7902                	ld	s2,32(sp)
    800040b2:	69e2                	ld	s3,24(sp)
    800040b4:	6a42                	ld	s4,16(sp)
    800040b6:	6aa2                	ld	s5,8(sp)
    800040b8:	6b02                	ld	s6,0(sp)
    800040ba:	6121                	addi	sp,sp,64
    800040bc:	8082                	ret
    800040be:	8082                	ret

00000000800040c0 <initlog>:
{
    800040c0:	7179                	addi	sp,sp,-48
    800040c2:	f406                	sd	ra,40(sp)
    800040c4:	f022                	sd	s0,32(sp)
    800040c6:	ec26                	sd	s1,24(sp)
    800040c8:	e84a                	sd	s2,16(sp)
    800040ca:	e44e                	sd	s3,8(sp)
    800040cc:	1800                	addi	s0,sp,48
    800040ce:	892a                	mv	s2,a0
    800040d0:	89ae                	mv	s3,a1
  initlock(&log.lock, "log");
    800040d2:	0001d497          	auipc	s1,0x1d
    800040d6:	5ce48493          	addi	s1,s1,1486 # 800216a0 <log>
    800040da:	00004597          	auipc	a1,0x4
    800040de:	57e58593          	addi	a1,a1,1406 # 80008658 <syscalls+0x1e8>
    800040e2:	8526                	mv	a0,s1
    800040e4:	ffffd097          	auipc	ra,0xffffd
    800040e8:	a62080e7          	jalr	-1438(ra) # 80000b46 <initlock>
  log.start = sb->logstart;
    800040ec:	0149a583          	lw	a1,20(s3)
    800040f0:	cc8c                	sw	a1,24(s1)
  log.size = sb->nlog;
    800040f2:	0109a783          	lw	a5,16(s3)
    800040f6:	ccdc                	sw	a5,28(s1)
  log.dev = dev;
    800040f8:	0324a423          	sw	s2,40(s1)
  struct buf *buf = bread(log.dev, log.start);
    800040fc:	854a                	mv	a0,s2
    800040fe:	fffff097          	auipc	ra,0xfffff
    80004102:	e8a080e7          	jalr	-374(ra) # 80002f88 <bread>
  log.lh.n = lh->n;
    80004106:	4d34                	lw	a3,88(a0)
    80004108:	d4d4                	sw	a3,44(s1)
  for (i = 0; i < log.lh.n; i++) {
    8000410a:	02d05563          	blez	a3,80004134 <initlog+0x74>
    8000410e:	05c50793          	addi	a5,a0,92
    80004112:	0001d717          	auipc	a4,0x1d
    80004116:	5be70713          	addi	a4,a4,1470 # 800216d0 <log+0x30>
    8000411a:	36fd                	addiw	a3,a3,-1
    8000411c:	1682                	slli	a3,a3,0x20
    8000411e:	9281                	srli	a3,a3,0x20
    80004120:	068a                	slli	a3,a3,0x2
    80004122:	06050613          	addi	a2,a0,96
    80004126:	96b2                	add	a3,a3,a2
    log.lh.block[i] = lh->block[i];
    80004128:	4390                	lw	a2,0(a5)
    8000412a:	c310                	sw	a2,0(a4)
  for (i = 0; i < log.lh.n; i++) {
    8000412c:	0791                	addi	a5,a5,4
    8000412e:	0711                	addi	a4,a4,4
    80004130:	fed79ce3          	bne	a5,a3,80004128 <initlog+0x68>
  brelse(buf);
    80004134:	fffff097          	auipc	ra,0xfffff
    80004138:	f84080e7          	jalr	-124(ra) # 800030b8 <brelse>

static void
recover_from_log(void)
{
  read_head();
  install_trans(1); // if committed, copy from log to disk
    8000413c:	4505                	li	a0,1
    8000413e:	00000097          	auipc	ra,0x0
    80004142:	ebe080e7          	jalr	-322(ra) # 80003ffc <install_trans>
  log.lh.n = 0;
    80004146:	0001d797          	auipc	a5,0x1d
    8000414a:	5807a323          	sw	zero,1414(a5) # 800216cc <log+0x2c>
  write_head(); // clear the log
    8000414e:	00000097          	auipc	ra,0x0
    80004152:	e34080e7          	jalr	-460(ra) # 80003f82 <write_head>
}
    80004156:	70a2                	ld	ra,40(sp)
    80004158:	7402                	ld	s0,32(sp)
    8000415a:	64e2                	ld	s1,24(sp)
    8000415c:	6942                	ld	s2,16(sp)
    8000415e:	69a2                	ld	s3,8(sp)
    80004160:	6145                	addi	sp,sp,48
    80004162:	8082                	ret

0000000080004164 <begin_op>:
}

// called at the start of each FS system call.
void
begin_op(void)
{
    80004164:	1101                	addi	sp,sp,-32
    80004166:	ec06                	sd	ra,24(sp)
    80004168:	e822                	sd	s0,16(sp)
    8000416a:	e426                	sd	s1,8(sp)
    8000416c:	e04a                	sd	s2,0(sp)
    8000416e:	1000                	addi	s0,sp,32
  acquire(&log.lock);
    80004170:	0001d517          	auipc	a0,0x1d
    80004174:	53050513          	addi	a0,a0,1328 # 800216a0 <log>
    80004178:	ffffd097          	auipc	ra,0xffffd
    8000417c:	a5e080e7          	jalr	-1442(ra) # 80000bd6 <acquire>
  while(1){
    if(log.committing){
    80004180:	0001d497          	auipc	s1,0x1d
    80004184:	52048493          	addi	s1,s1,1312 # 800216a0 <log>
      sleep(&log, &log.lock);
    } else if(log.lh.n + (log.outstanding+1)*MAXOPBLOCKS > LOGSIZE){
    80004188:	4979                	li	s2,30
    8000418a:	a039                	j	80004198 <begin_op+0x34>
      sleep(&log, &log.lock);
    8000418c:	85a6                	mv	a1,s1
    8000418e:	8526                	mv	a0,s1
    80004190:	ffffe097          	auipc	ra,0xffffe
    80004194:	f84080e7          	jalr	-124(ra) # 80002114 <sleep>
    if(log.committing){
    80004198:	50dc                	lw	a5,36(s1)
    8000419a:	fbed                	bnez	a5,8000418c <begin_op+0x28>
    } else if(log.lh.n + (log.outstanding+1)*MAXOPBLOCKS > LOGSIZE){
    8000419c:	509c                	lw	a5,32(s1)
    8000419e:	0017871b          	addiw	a4,a5,1
    800041a2:	0007069b          	sext.w	a3,a4
    800041a6:	0027179b          	slliw	a5,a4,0x2
    800041aa:	9fb9                	addw	a5,a5,a4
    800041ac:	0017979b          	slliw	a5,a5,0x1
    800041b0:	54d8                	lw	a4,44(s1)
    800041b2:	9fb9                	addw	a5,a5,a4
    800041b4:	00f95963          	bge	s2,a5,800041c6 <begin_op+0x62>
      // this op might exhaust log space; wait for commit.
      sleep(&log, &log.lock);
    800041b8:	85a6                	mv	a1,s1
    800041ba:	8526                	mv	a0,s1
    800041bc:	ffffe097          	auipc	ra,0xffffe
    800041c0:	f58080e7          	jalr	-168(ra) # 80002114 <sleep>
    800041c4:	bfd1                	j	80004198 <begin_op+0x34>
    } else {
      log.outstanding += 1;
    800041c6:	0001d517          	auipc	a0,0x1d
    800041ca:	4da50513          	addi	a0,a0,1242 # 800216a0 <log>
    800041ce:	d114                	sw	a3,32(a0)
      release(&log.lock);
    800041d0:	ffffd097          	auipc	ra,0xffffd
    800041d4:	aba080e7          	jalr	-1350(ra) # 80000c8a <release>
      break;
    }
  }
}
    800041d8:	60e2                	ld	ra,24(sp)
    800041da:	6442                	ld	s0,16(sp)
    800041dc:	64a2                	ld	s1,8(sp)
    800041de:	6902                	ld	s2,0(sp)
    800041e0:	6105                	addi	sp,sp,32
    800041e2:	8082                	ret

00000000800041e4 <end_op>:

// called at the end of each FS system call.
// commits if this was the last outstanding operation.
void
end_op(void)
{
    800041e4:	7139                	addi	sp,sp,-64
    800041e6:	fc06                	sd	ra,56(sp)
    800041e8:	f822                	sd	s0,48(sp)
    800041ea:	f426                	sd	s1,40(sp)
    800041ec:	f04a                	sd	s2,32(sp)
    800041ee:	ec4e                	sd	s3,24(sp)
    800041f0:	e852                	sd	s4,16(sp)
    800041f2:	e456                	sd	s5,8(sp)
    800041f4:	0080                	addi	s0,sp,64
  int do_commit = 0;

  acquire(&log.lock);
    800041f6:	0001d497          	auipc	s1,0x1d
    800041fa:	4aa48493          	addi	s1,s1,1194 # 800216a0 <log>
    800041fe:	8526                	mv	a0,s1
    80004200:	ffffd097          	auipc	ra,0xffffd
    80004204:	9d6080e7          	jalr	-1578(ra) # 80000bd6 <acquire>
  log.outstanding -= 1;
    80004208:	509c                	lw	a5,32(s1)
    8000420a:	37fd                	addiw	a5,a5,-1
    8000420c:	0007891b          	sext.w	s2,a5
    80004210:	d09c                	sw	a5,32(s1)
  if(log.committing)
    80004212:	50dc                	lw	a5,36(s1)
    80004214:	e7b9                	bnez	a5,80004262 <end_op+0x7e>
    panic("log.committing");
  if(log.outstanding == 0){
    80004216:	04091e63          	bnez	s2,80004272 <end_op+0x8e>
    do_commit = 1;
    log.committing = 1;
    8000421a:	0001d497          	auipc	s1,0x1d
    8000421e:	48648493          	addi	s1,s1,1158 # 800216a0 <log>
    80004222:	4785                	li	a5,1
    80004224:	d0dc                	sw	a5,36(s1)
    // begin_op() may be waiting for log space,
    // and decrementing log.outstanding has decreased
    // the amount of reserved space.
    wakeup(&log);
  }
  release(&log.lock);
    80004226:	8526                	mv	a0,s1
    80004228:	ffffd097          	auipc	ra,0xffffd
    8000422c:	a62080e7          	jalr	-1438(ra) # 80000c8a <release>
}

static void
commit()
{
  if (log.lh.n > 0) {
    80004230:	54dc                	lw	a5,44(s1)
    80004232:	06f04763          	bgtz	a5,800042a0 <end_op+0xbc>
    acquire(&log.lock);
    80004236:	0001d497          	auipc	s1,0x1d
    8000423a:	46a48493          	addi	s1,s1,1130 # 800216a0 <log>
    8000423e:	8526                	mv	a0,s1
    80004240:	ffffd097          	auipc	ra,0xffffd
    80004244:	996080e7          	jalr	-1642(ra) # 80000bd6 <acquire>
    log.committing = 0;
    80004248:	0204a223          	sw	zero,36(s1)
    wakeup(&log);
    8000424c:	8526                	mv	a0,s1
    8000424e:	ffffe097          	auipc	ra,0xffffe
    80004252:	f2a080e7          	jalr	-214(ra) # 80002178 <wakeup>
    release(&log.lock);
    80004256:	8526                	mv	a0,s1
    80004258:	ffffd097          	auipc	ra,0xffffd
    8000425c:	a32080e7          	jalr	-1486(ra) # 80000c8a <release>
}
    80004260:	a03d                	j	8000428e <end_op+0xaa>
    panic("log.committing");
    80004262:	00004517          	auipc	a0,0x4
    80004266:	3fe50513          	addi	a0,a0,1022 # 80008660 <syscalls+0x1f0>
    8000426a:	ffffc097          	auipc	ra,0xffffc
    8000426e:	2d4080e7          	jalr	724(ra) # 8000053e <panic>
    wakeup(&log);
    80004272:	0001d497          	auipc	s1,0x1d
    80004276:	42e48493          	addi	s1,s1,1070 # 800216a0 <log>
    8000427a:	8526                	mv	a0,s1
    8000427c:	ffffe097          	auipc	ra,0xffffe
    80004280:	efc080e7          	jalr	-260(ra) # 80002178 <wakeup>
  release(&log.lock);
    80004284:	8526                	mv	a0,s1
    80004286:	ffffd097          	auipc	ra,0xffffd
    8000428a:	a04080e7          	jalr	-1532(ra) # 80000c8a <release>
}
    8000428e:	70e2                	ld	ra,56(sp)
    80004290:	7442                	ld	s0,48(sp)
    80004292:	74a2                	ld	s1,40(sp)
    80004294:	7902                	ld	s2,32(sp)
    80004296:	69e2                	ld	s3,24(sp)
    80004298:	6a42                	ld	s4,16(sp)
    8000429a:	6aa2                	ld	s5,8(sp)
    8000429c:	6121                	addi	sp,sp,64
    8000429e:	8082                	ret
  for (tail = 0; tail < log.lh.n; tail++) {
    800042a0:	0001da97          	auipc	s5,0x1d
    800042a4:	430a8a93          	addi	s5,s5,1072 # 800216d0 <log+0x30>
    struct buf *to = bread(log.dev, log.start+tail+1); // log block
    800042a8:	0001da17          	auipc	s4,0x1d
    800042ac:	3f8a0a13          	addi	s4,s4,1016 # 800216a0 <log>
    800042b0:	018a2583          	lw	a1,24(s4)
    800042b4:	012585bb          	addw	a1,a1,s2
    800042b8:	2585                	addiw	a1,a1,1
    800042ba:	028a2503          	lw	a0,40(s4)
    800042be:	fffff097          	auipc	ra,0xfffff
    800042c2:	cca080e7          	jalr	-822(ra) # 80002f88 <bread>
    800042c6:	84aa                	mv	s1,a0
    struct buf *from = bread(log.dev, log.lh.block[tail]); // cache block
    800042c8:	000aa583          	lw	a1,0(s5)
    800042cc:	028a2503          	lw	a0,40(s4)
    800042d0:	fffff097          	auipc	ra,0xfffff
    800042d4:	cb8080e7          	jalr	-840(ra) # 80002f88 <bread>
    800042d8:	89aa                	mv	s3,a0
    memmove(to->data, from->data, BSIZE);
    800042da:	40000613          	li	a2,1024
    800042de:	05850593          	addi	a1,a0,88
    800042e2:	05848513          	addi	a0,s1,88
    800042e6:	ffffd097          	auipc	ra,0xffffd
    800042ea:	a48080e7          	jalr	-1464(ra) # 80000d2e <memmove>
    bwrite(to);  // write the log
    800042ee:	8526                	mv	a0,s1
    800042f0:	fffff097          	auipc	ra,0xfffff
    800042f4:	d8a080e7          	jalr	-630(ra) # 8000307a <bwrite>
    brelse(from);
    800042f8:	854e                	mv	a0,s3
    800042fa:	fffff097          	auipc	ra,0xfffff
    800042fe:	dbe080e7          	jalr	-578(ra) # 800030b8 <brelse>
    brelse(to);
    80004302:	8526                	mv	a0,s1
    80004304:	fffff097          	auipc	ra,0xfffff
    80004308:	db4080e7          	jalr	-588(ra) # 800030b8 <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
    8000430c:	2905                	addiw	s2,s2,1
    8000430e:	0a91                	addi	s5,s5,4
    80004310:	02ca2783          	lw	a5,44(s4)
    80004314:	f8f94ee3          	blt	s2,a5,800042b0 <end_op+0xcc>
    write_log();     // Write modified blocks from cache to log
    write_head();    // Write header to disk -- the real commit
    80004318:	00000097          	auipc	ra,0x0
    8000431c:	c6a080e7          	jalr	-918(ra) # 80003f82 <write_head>
    install_trans(0); // Now install writes to home locations
    80004320:	4501                	li	a0,0
    80004322:	00000097          	auipc	ra,0x0
    80004326:	cda080e7          	jalr	-806(ra) # 80003ffc <install_trans>
    log.lh.n = 0;
    8000432a:	0001d797          	auipc	a5,0x1d
    8000432e:	3a07a123          	sw	zero,930(a5) # 800216cc <log+0x2c>
    write_head();    // Erase the transaction from the log
    80004332:	00000097          	auipc	ra,0x0
    80004336:	c50080e7          	jalr	-944(ra) # 80003f82 <write_head>
    8000433a:	bdf5                	j	80004236 <end_op+0x52>

000000008000433c <log_write>:
//   modify bp->data[]
//   log_write(bp)
//   brelse(bp)
void
log_write(struct buf *b)
{
    8000433c:	1101                	addi	sp,sp,-32
    8000433e:	ec06                	sd	ra,24(sp)
    80004340:	e822                	sd	s0,16(sp)
    80004342:	e426                	sd	s1,8(sp)
    80004344:	e04a                	sd	s2,0(sp)
    80004346:	1000                	addi	s0,sp,32
    80004348:	84aa                	mv	s1,a0
  int i;

  acquire(&log.lock);
    8000434a:	0001d917          	auipc	s2,0x1d
    8000434e:	35690913          	addi	s2,s2,854 # 800216a0 <log>
    80004352:	854a                	mv	a0,s2
    80004354:	ffffd097          	auipc	ra,0xffffd
    80004358:	882080e7          	jalr	-1918(ra) # 80000bd6 <acquire>
  if (log.lh.n >= LOGSIZE || log.lh.n >= log.size - 1)
    8000435c:	02c92603          	lw	a2,44(s2)
    80004360:	47f5                	li	a5,29
    80004362:	06c7c563          	blt	a5,a2,800043cc <log_write+0x90>
    80004366:	0001d797          	auipc	a5,0x1d
    8000436a:	3567a783          	lw	a5,854(a5) # 800216bc <log+0x1c>
    8000436e:	37fd                	addiw	a5,a5,-1
    80004370:	04f65e63          	bge	a2,a5,800043cc <log_write+0x90>
    panic("too big a transaction");
  if (log.outstanding < 1)
    80004374:	0001d797          	auipc	a5,0x1d
    80004378:	34c7a783          	lw	a5,844(a5) # 800216c0 <log+0x20>
    8000437c:	06f05063          	blez	a5,800043dc <log_write+0xa0>
    panic("log_write outside of trans");

  for (i = 0; i < log.lh.n; i++) {
    80004380:	4781                	li	a5,0
    80004382:	06c05563          	blez	a2,800043ec <log_write+0xb0>
    if (log.lh.block[i] == b->blockno)   // log absorption
    80004386:	44cc                	lw	a1,12(s1)
    80004388:	0001d717          	auipc	a4,0x1d
    8000438c:	34870713          	addi	a4,a4,840 # 800216d0 <log+0x30>
  for (i = 0; i < log.lh.n; i++) {
    80004390:	4781                	li	a5,0
    if (log.lh.block[i] == b->blockno)   // log absorption
    80004392:	4314                	lw	a3,0(a4)
    80004394:	04b68c63          	beq	a3,a1,800043ec <log_write+0xb0>
  for (i = 0; i < log.lh.n; i++) {
    80004398:	2785                	addiw	a5,a5,1
    8000439a:	0711                	addi	a4,a4,4
    8000439c:	fef61be3          	bne	a2,a5,80004392 <log_write+0x56>
      break;
  }
  log.lh.block[i] = b->blockno;
    800043a0:	0621                	addi	a2,a2,8
    800043a2:	060a                	slli	a2,a2,0x2
    800043a4:	0001d797          	auipc	a5,0x1d
    800043a8:	2fc78793          	addi	a5,a5,764 # 800216a0 <log>
    800043ac:	963e                	add	a2,a2,a5
    800043ae:	44dc                	lw	a5,12(s1)
    800043b0:	ca1c                	sw	a5,16(a2)
  if (i == log.lh.n) {  // Add new block to log?
    bpin(b);
    800043b2:	8526                	mv	a0,s1
    800043b4:	fffff097          	auipc	ra,0xfffff
    800043b8:	da2080e7          	jalr	-606(ra) # 80003156 <bpin>
    log.lh.n++;
    800043bc:	0001d717          	auipc	a4,0x1d
    800043c0:	2e470713          	addi	a4,a4,740 # 800216a0 <log>
    800043c4:	575c                	lw	a5,44(a4)
    800043c6:	2785                	addiw	a5,a5,1
    800043c8:	d75c                	sw	a5,44(a4)
    800043ca:	a835                	j	80004406 <log_write+0xca>
    panic("too big a transaction");
    800043cc:	00004517          	auipc	a0,0x4
    800043d0:	2a450513          	addi	a0,a0,676 # 80008670 <syscalls+0x200>
    800043d4:	ffffc097          	auipc	ra,0xffffc
    800043d8:	16a080e7          	jalr	362(ra) # 8000053e <panic>
    panic("log_write outside of trans");
    800043dc:	00004517          	auipc	a0,0x4
    800043e0:	2ac50513          	addi	a0,a0,684 # 80008688 <syscalls+0x218>
    800043e4:	ffffc097          	auipc	ra,0xffffc
    800043e8:	15a080e7          	jalr	346(ra) # 8000053e <panic>
  log.lh.block[i] = b->blockno;
    800043ec:	00878713          	addi	a4,a5,8
    800043f0:	00271693          	slli	a3,a4,0x2
    800043f4:	0001d717          	auipc	a4,0x1d
    800043f8:	2ac70713          	addi	a4,a4,684 # 800216a0 <log>
    800043fc:	9736                	add	a4,a4,a3
    800043fe:	44d4                	lw	a3,12(s1)
    80004400:	cb14                	sw	a3,16(a4)
  if (i == log.lh.n) {  // Add new block to log?
    80004402:	faf608e3          	beq	a2,a5,800043b2 <log_write+0x76>
  }
  release(&log.lock);
    80004406:	0001d517          	auipc	a0,0x1d
    8000440a:	29a50513          	addi	a0,a0,666 # 800216a0 <log>
    8000440e:	ffffd097          	auipc	ra,0xffffd
    80004412:	87c080e7          	jalr	-1924(ra) # 80000c8a <release>
}
    80004416:	60e2                	ld	ra,24(sp)
    80004418:	6442                	ld	s0,16(sp)
    8000441a:	64a2                	ld	s1,8(sp)
    8000441c:	6902                	ld	s2,0(sp)
    8000441e:	6105                	addi	sp,sp,32
    80004420:	8082                	ret

0000000080004422 <initsleeplock>:
#include "proc.h"
#include "sleeplock.h"

void
initsleeplock(struct sleeplock *lk, char *name)
{
    80004422:	1101                	addi	sp,sp,-32
    80004424:	ec06                	sd	ra,24(sp)
    80004426:	e822                	sd	s0,16(sp)
    80004428:	e426                	sd	s1,8(sp)
    8000442a:	e04a                	sd	s2,0(sp)
    8000442c:	1000                	addi	s0,sp,32
    8000442e:	84aa                	mv	s1,a0
    80004430:	892e                	mv	s2,a1
  initlock(&lk->lk, "sleep lock");
    80004432:	00004597          	auipc	a1,0x4
    80004436:	27658593          	addi	a1,a1,630 # 800086a8 <syscalls+0x238>
    8000443a:	0521                	addi	a0,a0,8
    8000443c:	ffffc097          	auipc	ra,0xffffc
    80004440:	70a080e7          	jalr	1802(ra) # 80000b46 <initlock>
  lk->name = name;
    80004444:	0324b023          	sd	s2,32(s1)
  lk->locked = 0;
    80004448:	0004a023          	sw	zero,0(s1)
  lk->pid = 0;
    8000444c:	0204a423          	sw	zero,40(s1)
}
    80004450:	60e2                	ld	ra,24(sp)
    80004452:	6442                	ld	s0,16(sp)
    80004454:	64a2                	ld	s1,8(sp)
    80004456:	6902                	ld	s2,0(sp)
    80004458:	6105                	addi	sp,sp,32
    8000445a:	8082                	ret

000000008000445c <acquiresleep>:

void
acquiresleep(struct sleeplock *lk)
{
    8000445c:	1101                	addi	sp,sp,-32
    8000445e:	ec06                	sd	ra,24(sp)
    80004460:	e822                	sd	s0,16(sp)
    80004462:	e426                	sd	s1,8(sp)
    80004464:	e04a                	sd	s2,0(sp)
    80004466:	1000                	addi	s0,sp,32
    80004468:	84aa                	mv	s1,a0
  acquire(&lk->lk);
    8000446a:	00850913          	addi	s2,a0,8
    8000446e:	854a                	mv	a0,s2
    80004470:	ffffc097          	auipc	ra,0xffffc
    80004474:	766080e7          	jalr	1894(ra) # 80000bd6 <acquire>
  while (lk->locked) {
    80004478:	409c                	lw	a5,0(s1)
    8000447a:	cb89                	beqz	a5,8000448c <acquiresleep+0x30>
    sleep(lk, &lk->lk);
    8000447c:	85ca                	mv	a1,s2
    8000447e:	8526                	mv	a0,s1
    80004480:	ffffe097          	auipc	ra,0xffffe
    80004484:	c94080e7          	jalr	-876(ra) # 80002114 <sleep>
  while (lk->locked) {
    80004488:	409c                	lw	a5,0(s1)
    8000448a:	fbed                	bnez	a5,8000447c <acquiresleep+0x20>
  }
  lk->locked = 1;
    8000448c:	4785                	li	a5,1
    8000448e:	c09c                	sw	a5,0(s1)
  lk->pid = myproc()->pid;
    80004490:	ffffd097          	auipc	ra,0xffffd
    80004494:	552080e7          	jalr	1362(ra) # 800019e2 <myproc>
    80004498:	591c                	lw	a5,48(a0)
    8000449a:	d49c                	sw	a5,40(s1)
  release(&lk->lk);
    8000449c:	854a                	mv	a0,s2
    8000449e:	ffffc097          	auipc	ra,0xffffc
    800044a2:	7ec080e7          	jalr	2028(ra) # 80000c8a <release>
}
    800044a6:	60e2                	ld	ra,24(sp)
    800044a8:	6442                	ld	s0,16(sp)
    800044aa:	64a2                	ld	s1,8(sp)
    800044ac:	6902                	ld	s2,0(sp)
    800044ae:	6105                	addi	sp,sp,32
    800044b0:	8082                	ret

00000000800044b2 <releasesleep>:

void
releasesleep(struct sleeplock *lk)
{
    800044b2:	1101                	addi	sp,sp,-32
    800044b4:	ec06                	sd	ra,24(sp)
    800044b6:	e822                	sd	s0,16(sp)
    800044b8:	e426                	sd	s1,8(sp)
    800044ba:	e04a                	sd	s2,0(sp)
    800044bc:	1000                	addi	s0,sp,32
    800044be:	84aa                	mv	s1,a0
  acquire(&lk->lk);
    800044c0:	00850913          	addi	s2,a0,8
    800044c4:	854a                	mv	a0,s2
    800044c6:	ffffc097          	auipc	ra,0xffffc
    800044ca:	710080e7          	jalr	1808(ra) # 80000bd6 <acquire>
  lk->locked = 0;
    800044ce:	0004a023          	sw	zero,0(s1)
  lk->pid = 0;
    800044d2:	0204a423          	sw	zero,40(s1)
  wakeup(lk);
    800044d6:	8526                	mv	a0,s1
    800044d8:	ffffe097          	auipc	ra,0xffffe
    800044dc:	ca0080e7          	jalr	-864(ra) # 80002178 <wakeup>
  release(&lk->lk);
    800044e0:	854a                	mv	a0,s2
    800044e2:	ffffc097          	auipc	ra,0xffffc
    800044e6:	7a8080e7          	jalr	1960(ra) # 80000c8a <release>
}
    800044ea:	60e2                	ld	ra,24(sp)
    800044ec:	6442                	ld	s0,16(sp)
    800044ee:	64a2                	ld	s1,8(sp)
    800044f0:	6902                	ld	s2,0(sp)
    800044f2:	6105                	addi	sp,sp,32
    800044f4:	8082                	ret

00000000800044f6 <holdingsleep>:

int
holdingsleep(struct sleeplock *lk)
{
    800044f6:	7179                	addi	sp,sp,-48
    800044f8:	f406                	sd	ra,40(sp)
    800044fa:	f022                	sd	s0,32(sp)
    800044fc:	ec26                	sd	s1,24(sp)
    800044fe:	e84a                	sd	s2,16(sp)
    80004500:	e44e                	sd	s3,8(sp)
    80004502:	1800                	addi	s0,sp,48
    80004504:	84aa                	mv	s1,a0
  int r;
  
  acquire(&lk->lk);
    80004506:	00850913          	addi	s2,a0,8
    8000450a:	854a                	mv	a0,s2
    8000450c:	ffffc097          	auipc	ra,0xffffc
    80004510:	6ca080e7          	jalr	1738(ra) # 80000bd6 <acquire>
  r = lk->locked && (lk->pid == myproc()->pid);
    80004514:	409c                	lw	a5,0(s1)
    80004516:	ef99                	bnez	a5,80004534 <holdingsleep+0x3e>
    80004518:	4481                	li	s1,0
  release(&lk->lk);
    8000451a:	854a                	mv	a0,s2
    8000451c:	ffffc097          	auipc	ra,0xffffc
    80004520:	76e080e7          	jalr	1902(ra) # 80000c8a <release>
  return r;
}
    80004524:	8526                	mv	a0,s1
    80004526:	70a2                	ld	ra,40(sp)
    80004528:	7402                	ld	s0,32(sp)
    8000452a:	64e2                	ld	s1,24(sp)
    8000452c:	6942                	ld	s2,16(sp)
    8000452e:	69a2                	ld	s3,8(sp)
    80004530:	6145                	addi	sp,sp,48
    80004532:	8082                	ret
  r = lk->locked && (lk->pid == myproc()->pid);
    80004534:	0284a983          	lw	s3,40(s1)
    80004538:	ffffd097          	auipc	ra,0xffffd
    8000453c:	4aa080e7          	jalr	1194(ra) # 800019e2 <myproc>
    80004540:	5904                	lw	s1,48(a0)
    80004542:	413484b3          	sub	s1,s1,s3
    80004546:	0014b493          	seqz	s1,s1
    8000454a:	bfc1                	j	8000451a <holdingsleep+0x24>

000000008000454c <fileinit>:
  struct file file[NFILE];
} ftable;

void
fileinit(void)
{
    8000454c:	1141                	addi	sp,sp,-16
    8000454e:	e406                	sd	ra,8(sp)
    80004550:	e022                	sd	s0,0(sp)
    80004552:	0800                	addi	s0,sp,16
  initlock(&ftable.lock, "ftable");
    80004554:	00004597          	auipc	a1,0x4
    80004558:	16458593          	addi	a1,a1,356 # 800086b8 <syscalls+0x248>
    8000455c:	0001d517          	auipc	a0,0x1d
    80004560:	28c50513          	addi	a0,a0,652 # 800217e8 <ftable>
    80004564:	ffffc097          	auipc	ra,0xffffc
    80004568:	5e2080e7          	jalr	1506(ra) # 80000b46 <initlock>
}
    8000456c:	60a2                	ld	ra,8(sp)
    8000456e:	6402                	ld	s0,0(sp)
    80004570:	0141                	addi	sp,sp,16
    80004572:	8082                	ret

0000000080004574 <filealloc>:

// Allocate a file structure.
struct file*
filealloc(void)
{
    80004574:	1101                	addi	sp,sp,-32
    80004576:	ec06                	sd	ra,24(sp)
    80004578:	e822                	sd	s0,16(sp)
    8000457a:	e426                	sd	s1,8(sp)
    8000457c:	1000                	addi	s0,sp,32
  struct file *f;

  acquire(&ftable.lock);
    8000457e:	0001d517          	auipc	a0,0x1d
    80004582:	26a50513          	addi	a0,a0,618 # 800217e8 <ftable>
    80004586:	ffffc097          	auipc	ra,0xffffc
    8000458a:	650080e7          	jalr	1616(ra) # 80000bd6 <acquire>
  for(f = ftable.file; f < ftable.file + NFILE; f++){
    8000458e:	0001d497          	auipc	s1,0x1d
    80004592:	27248493          	addi	s1,s1,626 # 80021800 <ftable+0x18>
    80004596:	0001e717          	auipc	a4,0x1e
    8000459a:	20a70713          	addi	a4,a4,522 # 800227a0 <disk>
    if(f->ref == 0){
    8000459e:	40dc                	lw	a5,4(s1)
    800045a0:	cf99                	beqz	a5,800045be <filealloc+0x4a>
  for(f = ftable.file; f < ftable.file + NFILE; f++){
    800045a2:	02848493          	addi	s1,s1,40
    800045a6:	fee49ce3          	bne	s1,a4,8000459e <filealloc+0x2a>
      f->ref = 1;
      release(&ftable.lock);
      return f;
    }
  }
  release(&ftable.lock);
    800045aa:	0001d517          	auipc	a0,0x1d
    800045ae:	23e50513          	addi	a0,a0,574 # 800217e8 <ftable>
    800045b2:	ffffc097          	auipc	ra,0xffffc
    800045b6:	6d8080e7          	jalr	1752(ra) # 80000c8a <release>
  return 0;
    800045ba:	4481                	li	s1,0
    800045bc:	a819                	j	800045d2 <filealloc+0x5e>
      f->ref = 1;
    800045be:	4785                	li	a5,1
    800045c0:	c0dc                	sw	a5,4(s1)
      release(&ftable.lock);
    800045c2:	0001d517          	auipc	a0,0x1d
    800045c6:	22650513          	addi	a0,a0,550 # 800217e8 <ftable>
    800045ca:	ffffc097          	auipc	ra,0xffffc
    800045ce:	6c0080e7          	jalr	1728(ra) # 80000c8a <release>
}
    800045d2:	8526                	mv	a0,s1
    800045d4:	60e2                	ld	ra,24(sp)
    800045d6:	6442                	ld	s0,16(sp)
    800045d8:	64a2                	ld	s1,8(sp)
    800045da:	6105                	addi	sp,sp,32
    800045dc:	8082                	ret

00000000800045de <filedup>:

// Increment ref count for file f.
struct file*
filedup(struct file *f)
{
    800045de:	1101                	addi	sp,sp,-32
    800045e0:	ec06                	sd	ra,24(sp)
    800045e2:	e822                	sd	s0,16(sp)
    800045e4:	e426                	sd	s1,8(sp)
    800045e6:	1000                	addi	s0,sp,32
    800045e8:	84aa                	mv	s1,a0
  acquire(&ftable.lock);
    800045ea:	0001d517          	auipc	a0,0x1d
    800045ee:	1fe50513          	addi	a0,a0,510 # 800217e8 <ftable>
    800045f2:	ffffc097          	auipc	ra,0xffffc
    800045f6:	5e4080e7          	jalr	1508(ra) # 80000bd6 <acquire>
  if(f->ref < 1)
    800045fa:	40dc                	lw	a5,4(s1)
    800045fc:	02f05263          	blez	a5,80004620 <filedup+0x42>
    panic("filedup");
  f->ref++;
    80004600:	2785                	addiw	a5,a5,1
    80004602:	c0dc                	sw	a5,4(s1)
  release(&ftable.lock);
    80004604:	0001d517          	auipc	a0,0x1d
    80004608:	1e450513          	addi	a0,a0,484 # 800217e8 <ftable>
    8000460c:	ffffc097          	auipc	ra,0xffffc
    80004610:	67e080e7          	jalr	1662(ra) # 80000c8a <release>
  return f;
}
    80004614:	8526                	mv	a0,s1
    80004616:	60e2                	ld	ra,24(sp)
    80004618:	6442                	ld	s0,16(sp)
    8000461a:	64a2                	ld	s1,8(sp)
    8000461c:	6105                	addi	sp,sp,32
    8000461e:	8082                	ret
    panic("filedup");
    80004620:	00004517          	auipc	a0,0x4
    80004624:	0a050513          	addi	a0,a0,160 # 800086c0 <syscalls+0x250>
    80004628:	ffffc097          	auipc	ra,0xffffc
    8000462c:	f16080e7          	jalr	-234(ra) # 8000053e <panic>

0000000080004630 <fileclose>:

// Close file f.  (Decrement ref count, close when reaches 0.)
void
fileclose(struct file *f)
{
    80004630:	7139                	addi	sp,sp,-64
    80004632:	fc06                	sd	ra,56(sp)
    80004634:	f822                	sd	s0,48(sp)
    80004636:	f426                	sd	s1,40(sp)
    80004638:	f04a                	sd	s2,32(sp)
    8000463a:	ec4e                	sd	s3,24(sp)
    8000463c:	e852                	sd	s4,16(sp)
    8000463e:	e456                	sd	s5,8(sp)
    80004640:	0080                	addi	s0,sp,64
    80004642:	84aa                	mv	s1,a0
  struct file ff;

  acquire(&ftable.lock);
    80004644:	0001d517          	auipc	a0,0x1d
    80004648:	1a450513          	addi	a0,a0,420 # 800217e8 <ftable>
    8000464c:	ffffc097          	auipc	ra,0xffffc
    80004650:	58a080e7          	jalr	1418(ra) # 80000bd6 <acquire>
  if(f->ref < 1)
    80004654:	40dc                	lw	a5,4(s1)
    80004656:	06f05163          	blez	a5,800046b8 <fileclose+0x88>
    panic("fileclose");
  if(--f->ref > 0){
    8000465a:	37fd                	addiw	a5,a5,-1
    8000465c:	0007871b          	sext.w	a4,a5
    80004660:	c0dc                	sw	a5,4(s1)
    80004662:	06e04363          	bgtz	a4,800046c8 <fileclose+0x98>
    release(&ftable.lock);
    return;
  }
  ff = *f;
    80004666:	0004a903          	lw	s2,0(s1)
    8000466a:	0094ca83          	lbu	s5,9(s1)
    8000466e:	0104ba03          	ld	s4,16(s1)
    80004672:	0184b983          	ld	s3,24(s1)
  f->ref = 0;
    80004676:	0004a223          	sw	zero,4(s1)
  f->type = FD_NONE;
    8000467a:	0004a023          	sw	zero,0(s1)
  release(&ftable.lock);
    8000467e:	0001d517          	auipc	a0,0x1d
    80004682:	16a50513          	addi	a0,a0,362 # 800217e8 <ftable>
    80004686:	ffffc097          	auipc	ra,0xffffc
    8000468a:	604080e7          	jalr	1540(ra) # 80000c8a <release>

  if(ff.type == FD_PIPE){
    8000468e:	4785                	li	a5,1
    80004690:	04f90d63          	beq	s2,a5,800046ea <fileclose+0xba>
    pipeclose(ff.pipe, ff.writable);
  } else if(ff.type == FD_INODE || ff.type == FD_DEVICE){
    80004694:	3979                	addiw	s2,s2,-2
    80004696:	4785                	li	a5,1
    80004698:	0527e063          	bltu	a5,s2,800046d8 <fileclose+0xa8>
    begin_op();
    8000469c:	00000097          	auipc	ra,0x0
    800046a0:	ac8080e7          	jalr	-1336(ra) # 80004164 <begin_op>
    iput(ff.ip);
    800046a4:	854e                	mv	a0,s3
    800046a6:	fffff097          	auipc	ra,0xfffff
    800046aa:	2b6080e7          	jalr	694(ra) # 8000395c <iput>
    end_op();
    800046ae:	00000097          	auipc	ra,0x0
    800046b2:	b36080e7          	jalr	-1226(ra) # 800041e4 <end_op>
    800046b6:	a00d                	j	800046d8 <fileclose+0xa8>
    panic("fileclose");
    800046b8:	00004517          	auipc	a0,0x4
    800046bc:	01050513          	addi	a0,a0,16 # 800086c8 <syscalls+0x258>
    800046c0:	ffffc097          	auipc	ra,0xffffc
    800046c4:	e7e080e7          	jalr	-386(ra) # 8000053e <panic>
    release(&ftable.lock);
    800046c8:	0001d517          	auipc	a0,0x1d
    800046cc:	12050513          	addi	a0,a0,288 # 800217e8 <ftable>
    800046d0:	ffffc097          	auipc	ra,0xffffc
    800046d4:	5ba080e7          	jalr	1466(ra) # 80000c8a <release>
  }
}
    800046d8:	70e2                	ld	ra,56(sp)
    800046da:	7442                	ld	s0,48(sp)
    800046dc:	74a2                	ld	s1,40(sp)
    800046de:	7902                	ld	s2,32(sp)
    800046e0:	69e2                	ld	s3,24(sp)
    800046e2:	6a42                	ld	s4,16(sp)
    800046e4:	6aa2                	ld	s5,8(sp)
    800046e6:	6121                	addi	sp,sp,64
    800046e8:	8082                	ret
    pipeclose(ff.pipe, ff.writable);
    800046ea:	85d6                	mv	a1,s5
    800046ec:	8552                	mv	a0,s4
    800046ee:	00000097          	auipc	ra,0x0
    800046f2:	34c080e7          	jalr	844(ra) # 80004a3a <pipeclose>
    800046f6:	b7cd                	j	800046d8 <fileclose+0xa8>

00000000800046f8 <filestat>:

// Get metadata about file f.
// addr is a user virtual address, pointing to a struct stat.
int
filestat(struct file *f, uint64 addr)
{
    800046f8:	715d                	addi	sp,sp,-80
    800046fa:	e486                	sd	ra,72(sp)
    800046fc:	e0a2                	sd	s0,64(sp)
    800046fe:	fc26                	sd	s1,56(sp)
    80004700:	f84a                	sd	s2,48(sp)
    80004702:	f44e                	sd	s3,40(sp)
    80004704:	0880                	addi	s0,sp,80
    80004706:	84aa                	mv	s1,a0
    80004708:	89ae                	mv	s3,a1
  struct proc *p = myproc();
    8000470a:	ffffd097          	auipc	ra,0xffffd
    8000470e:	2d8080e7          	jalr	728(ra) # 800019e2 <myproc>
  struct stat st;
  
  if(f->type == FD_INODE || f->type == FD_DEVICE){
    80004712:	409c                	lw	a5,0(s1)
    80004714:	37f9                	addiw	a5,a5,-2
    80004716:	4705                	li	a4,1
    80004718:	04f76763          	bltu	a4,a5,80004766 <filestat+0x6e>
    8000471c:	892a                	mv	s2,a0
    ilock(f->ip);
    8000471e:	6c88                	ld	a0,24(s1)
    80004720:	fffff097          	auipc	ra,0xfffff
    80004724:	082080e7          	jalr	130(ra) # 800037a2 <ilock>
    stati(f->ip, &st);
    80004728:	fb840593          	addi	a1,s0,-72
    8000472c:	6c88                	ld	a0,24(s1)
    8000472e:	fffff097          	auipc	ra,0xfffff
    80004732:	2fe080e7          	jalr	766(ra) # 80003a2c <stati>
    iunlock(f->ip);
    80004736:	6c88                	ld	a0,24(s1)
    80004738:	fffff097          	auipc	ra,0xfffff
    8000473c:	12c080e7          	jalr	300(ra) # 80003864 <iunlock>
    if(copyout(p->pagetable, addr, (char *)&st, sizeof(st)) < 0)
    80004740:	46e1                	li	a3,24
    80004742:	fb840613          	addi	a2,s0,-72
    80004746:	85ce                	mv	a1,s3
    80004748:	05093503          	ld	a0,80(s2)
    8000474c:	ffffd097          	auipc	ra,0xffffd
    80004750:	f52080e7          	jalr	-174(ra) # 8000169e <copyout>
    80004754:	41f5551b          	sraiw	a0,a0,0x1f
      return -1;
    return 0;
  }
  return -1;
}
    80004758:	60a6                	ld	ra,72(sp)
    8000475a:	6406                	ld	s0,64(sp)
    8000475c:	74e2                	ld	s1,56(sp)
    8000475e:	7942                	ld	s2,48(sp)
    80004760:	79a2                	ld	s3,40(sp)
    80004762:	6161                	addi	sp,sp,80
    80004764:	8082                	ret
  return -1;
    80004766:	557d                	li	a0,-1
    80004768:	bfc5                	j	80004758 <filestat+0x60>

000000008000476a <fileread>:

// Read from file f.
// addr is a user virtual address.
int
fileread(struct file *f, uint64 addr, int n)
{
    8000476a:	7179                	addi	sp,sp,-48
    8000476c:	f406                	sd	ra,40(sp)
    8000476e:	f022                	sd	s0,32(sp)
    80004770:	ec26                	sd	s1,24(sp)
    80004772:	e84a                	sd	s2,16(sp)
    80004774:	e44e                	sd	s3,8(sp)
    80004776:	1800                	addi	s0,sp,48
  int r = 0;

  if(f->readable == 0)
    80004778:	00854783          	lbu	a5,8(a0)
    8000477c:	c3d5                	beqz	a5,80004820 <fileread+0xb6>
    8000477e:	84aa                	mv	s1,a0
    80004780:	89ae                	mv	s3,a1
    80004782:	8932                	mv	s2,a2
    return -1;

  if(f->type == FD_PIPE){
    80004784:	411c                	lw	a5,0(a0)
    80004786:	4705                	li	a4,1
    80004788:	04e78963          	beq	a5,a4,800047da <fileread+0x70>
    r = piperead(f->pipe, addr, n);
  } else if(f->type == FD_DEVICE){
    8000478c:	470d                	li	a4,3
    8000478e:	04e78d63          	beq	a5,a4,800047e8 <fileread+0x7e>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].read)
      return -1;
    r = devsw[f->major].read(1, addr, n);
  } else if(f->type == FD_INODE){
    80004792:	4709                	li	a4,2
    80004794:	06e79e63          	bne	a5,a4,80004810 <fileread+0xa6>
    ilock(f->ip);
    80004798:	6d08                	ld	a0,24(a0)
    8000479a:	fffff097          	auipc	ra,0xfffff
    8000479e:	008080e7          	jalr	8(ra) # 800037a2 <ilock>
    if((r = readi(f->ip, 1, addr, f->off, n)) > 0)
    800047a2:	874a                	mv	a4,s2
    800047a4:	5094                	lw	a3,32(s1)
    800047a6:	864e                	mv	a2,s3
    800047a8:	4585                	li	a1,1
    800047aa:	6c88                	ld	a0,24(s1)
    800047ac:	fffff097          	auipc	ra,0xfffff
    800047b0:	2aa080e7          	jalr	682(ra) # 80003a56 <readi>
    800047b4:	892a                	mv	s2,a0
    800047b6:	00a05563          	blez	a0,800047c0 <fileread+0x56>
      f->off += r;
    800047ba:	509c                	lw	a5,32(s1)
    800047bc:	9fa9                	addw	a5,a5,a0
    800047be:	d09c                	sw	a5,32(s1)
    iunlock(f->ip);
    800047c0:	6c88                	ld	a0,24(s1)
    800047c2:	fffff097          	auipc	ra,0xfffff
    800047c6:	0a2080e7          	jalr	162(ra) # 80003864 <iunlock>
  } else {
    panic("fileread");
  }

  return r;
}
    800047ca:	854a                	mv	a0,s2
    800047cc:	70a2                	ld	ra,40(sp)
    800047ce:	7402                	ld	s0,32(sp)
    800047d0:	64e2                	ld	s1,24(sp)
    800047d2:	6942                	ld	s2,16(sp)
    800047d4:	69a2                	ld	s3,8(sp)
    800047d6:	6145                	addi	sp,sp,48
    800047d8:	8082                	ret
    r = piperead(f->pipe, addr, n);
    800047da:	6908                	ld	a0,16(a0)
    800047dc:	00000097          	auipc	ra,0x0
    800047e0:	3c6080e7          	jalr	966(ra) # 80004ba2 <piperead>
    800047e4:	892a                	mv	s2,a0
    800047e6:	b7d5                	j	800047ca <fileread+0x60>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].read)
    800047e8:	02451783          	lh	a5,36(a0)
    800047ec:	03079693          	slli	a3,a5,0x30
    800047f0:	92c1                	srli	a3,a3,0x30
    800047f2:	4725                	li	a4,9
    800047f4:	02d76863          	bltu	a4,a3,80004824 <fileread+0xba>
    800047f8:	0792                	slli	a5,a5,0x4
    800047fa:	0001d717          	auipc	a4,0x1d
    800047fe:	f4e70713          	addi	a4,a4,-178 # 80021748 <devsw>
    80004802:	97ba                	add	a5,a5,a4
    80004804:	639c                	ld	a5,0(a5)
    80004806:	c38d                	beqz	a5,80004828 <fileread+0xbe>
    r = devsw[f->major].read(1, addr, n);
    80004808:	4505                	li	a0,1
    8000480a:	9782                	jalr	a5
    8000480c:	892a                	mv	s2,a0
    8000480e:	bf75                	j	800047ca <fileread+0x60>
    panic("fileread");
    80004810:	00004517          	auipc	a0,0x4
    80004814:	ec850513          	addi	a0,a0,-312 # 800086d8 <syscalls+0x268>
    80004818:	ffffc097          	auipc	ra,0xffffc
    8000481c:	d26080e7          	jalr	-730(ra) # 8000053e <panic>
    return -1;
    80004820:	597d                	li	s2,-1
    80004822:	b765                	j	800047ca <fileread+0x60>
      return -1;
    80004824:	597d                	li	s2,-1
    80004826:	b755                	j	800047ca <fileread+0x60>
    80004828:	597d                	li	s2,-1
    8000482a:	b745                	j	800047ca <fileread+0x60>

000000008000482c <filewrite>:

// Write to file f.
// addr is a user virtual address.
int
filewrite(struct file *f, uint64 addr, int n)
{
    8000482c:	715d                	addi	sp,sp,-80
    8000482e:	e486                	sd	ra,72(sp)
    80004830:	e0a2                	sd	s0,64(sp)
    80004832:	fc26                	sd	s1,56(sp)
    80004834:	f84a                	sd	s2,48(sp)
    80004836:	f44e                	sd	s3,40(sp)
    80004838:	f052                	sd	s4,32(sp)
    8000483a:	ec56                	sd	s5,24(sp)
    8000483c:	e85a                	sd	s6,16(sp)
    8000483e:	e45e                	sd	s7,8(sp)
    80004840:	e062                	sd	s8,0(sp)
    80004842:	0880                	addi	s0,sp,80
  int r, ret = 0;

  if(f->writable == 0)
    80004844:	00954783          	lbu	a5,9(a0)
    80004848:	10078663          	beqz	a5,80004954 <filewrite+0x128>
    8000484c:	892a                	mv	s2,a0
    8000484e:	8aae                	mv	s5,a1
    80004850:	8a32                	mv	s4,a2
    return -1;

  if(f->type == FD_PIPE){
    80004852:	411c                	lw	a5,0(a0)
    80004854:	4705                	li	a4,1
    80004856:	02e78263          	beq	a5,a4,8000487a <filewrite+0x4e>
    ret = pipewrite(f->pipe, addr, n);
  } else if(f->type == FD_DEVICE){
    8000485a:	470d                	li	a4,3
    8000485c:	02e78663          	beq	a5,a4,80004888 <filewrite+0x5c>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].write)
      return -1;
    ret = devsw[f->major].write(1, addr, n);
  } else if(f->type == FD_INODE){
    80004860:	4709                	li	a4,2
    80004862:	0ee79163          	bne	a5,a4,80004944 <filewrite+0x118>
    // and 2 blocks of slop for non-aligned writes.
    // this really belongs lower down, since writei()
    // might be writing a device like the console.
    int max = ((MAXOPBLOCKS-1-1-2) / 2) * BSIZE;
    int i = 0;
    while(i < n){
    80004866:	0ac05d63          	blez	a2,80004920 <filewrite+0xf4>
    int i = 0;
    8000486a:	4981                	li	s3,0
    8000486c:	6b05                	lui	s6,0x1
    8000486e:	c00b0b13          	addi	s6,s6,-1024 # c00 <_entry-0x7ffff400>
    80004872:	6b85                	lui	s7,0x1
    80004874:	c00b8b9b          	addiw	s7,s7,-1024
    80004878:	a861                	j	80004910 <filewrite+0xe4>
    ret = pipewrite(f->pipe, addr, n);
    8000487a:	6908                	ld	a0,16(a0)
    8000487c:	00000097          	auipc	ra,0x0
    80004880:	22e080e7          	jalr	558(ra) # 80004aaa <pipewrite>
    80004884:	8a2a                	mv	s4,a0
    80004886:	a045                	j	80004926 <filewrite+0xfa>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].write)
    80004888:	02451783          	lh	a5,36(a0)
    8000488c:	03079693          	slli	a3,a5,0x30
    80004890:	92c1                	srli	a3,a3,0x30
    80004892:	4725                	li	a4,9
    80004894:	0cd76263          	bltu	a4,a3,80004958 <filewrite+0x12c>
    80004898:	0792                	slli	a5,a5,0x4
    8000489a:	0001d717          	auipc	a4,0x1d
    8000489e:	eae70713          	addi	a4,a4,-338 # 80021748 <devsw>
    800048a2:	97ba                	add	a5,a5,a4
    800048a4:	679c                	ld	a5,8(a5)
    800048a6:	cbdd                	beqz	a5,8000495c <filewrite+0x130>
    ret = devsw[f->major].write(1, addr, n);
    800048a8:	4505                	li	a0,1
    800048aa:	9782                	jalr	a5
    800048ac:	8a2a                	mv	s4,a0
    800048ae:	a8a5                	j	80004926 <filewrite+0xfa>
    800048b0:	00048c1b          	sext.w	s8,s1
      int n1 = n - i;
      if(n1 > max)
        n1 = max;

      begin_op();
    800048b4:	00000097          	auipc	ra,0x0
    800048b8:	8b0080e7          	jalr	-1872(ra) # 80004164 <begin_op>
      ilock(f->ip);
    800048bc:	01893503          	ld	a0,24(s2)
    800048c0:	fffff097          	auipc	ra,0xfffff
    800048c4:	ee2080e7          	jalr	-286(ra) # 800037a2 <ilock>
      if ((r = writei(f->ip, 1, addr + i, f->off, n1)) > 0)
    800048c8:	8762                	mv	a4,s8
    800048ca:	02092683          	lw	a3,32(s2)
    800048ce:	01598633          	add	a2,s3,s5
    800048d2:	4585                	li	a1,1
    800048d4:	01893503          	ld	a0,24(s2)
    800048d8:	fffff097          	auipc	ra,0xfffff
    800048dc:	276080e7          	jalr	630(ra) # 80003b4e <writei>
    800048e0:	84aa                	mv	s1,a0
    800048e2:	00a05763          	blez	a0,800048f0 <filewrite+0xc4>
        f->off += r;
    800048e6:	02092783          	lw	a5,32(s2)
    800048ea:	9fa9                	addw	a5,a5,a0
    800048ec:	02f92023          	sw	a5,32(s2)
      iunlock(f->ip);
    800048f0:	01893503          	ld	a0,24(s2)
    800048f4:	fffff097          	auipc	ra,0xfffff
    800048f8:	f70080e7          	jalr	-144(ra) # 80003864 <iunlock>
      end_op();
    800048fc:	00000097          	auipc	ra,0x0
    80004900:	8e8080e7          	jalr	-1816(ra) # 800041e4 <end_op>

      if(r != n1){
    80004904:	009c1f63          	bne	s8,s1,80004922 <filewrite+0xf6>
        // error from writei
        break;
      }
      i += r;
    80004908:	013489bb          	addw	s3,s1,s3
    while(i < n){
    8000490c:	0149db63          	bge	s3,s4,80004922 <filewrite+0xf6>
      int n1 = n - i;
    80004910:	413a07bb          	subw	a5,s4,s3
      if(n1 > max)
    80004914:	84be                	mv	s1,a5
    80004916:	2781                	sext.w	a5,a5
    80004918:	f8fb5ce3          	bge	s6,a5,800048b0 <filewrite+0x84>
    8000491c:	84de                	mv	s1,s7
    8000491e:	bf49                	j	800048b0 <filewrite+0x84>
    int i = 0;
    80004920:	4981                	li	s3,0
    }
    ret = (i == n ? n : -1);
    80004922:	013a1f63          	bne	s4,s3,80004940 <filewrite+0x114>
  } else {
    panic("filewrite");
  }

  return ret;
}
    80004926:	8552                	mv	a0,s4
    80004928:	60a6                	ld	ra,72(sp)
    8000492a:	6406                	ld	s0,64(sp)
    8000492c:	74e2                	ld	s1,56(sp)
    8000492e:	7942                	ld	s2,48(sp)
    80004930:	79a2                	ld	s3,40(sp)
    80004932:	7a02                	ld	s4,32(sp)
    80004934:	6ae2                	ld	s5,24(sp)
    80004936:	6b42                	ld	s6,16(sp)
    80004938:	6ba2                	ld	s7,8(sp)
    8000493a:	6c02                	ld	s8,0(sp)
    8000493c:	6161                	addi	sp,sp,80
    8000493e:	8082                	ret
    ret = (i == n ? n : -1);
    80004940:	5a7d                	li	s4,-1
    80004942:	b7d5                	j	80004926 <filewrite+0xfa>
    panic("filewrite");
    80004944:	00004517          	auipc	a0,0x4
    80004948:	da450513          	addi	a0,a0,-604 # 800086e8 <syscalls+0x278>
    8000494c:	ffffc097          	auipc	ra,0xffffc
    80004950:	bf2080e7          	jalr	-1038(ra) # 8000053e <panic>
    return -1;
    80004954:	5a7d                	li	s4,-1
    80004956:	bfc1                	j	80004926 <filewrite+0xfa>
      return -1;
    80004958:	5a7d                	li	s4,-1
    8000495a:	b7f1                	j	80004926 <filewrite+0xfa>
    8000495c:	5a7d                	li	s4,-1
    8000495e:	b7e1                	j	80004926 <filewrite+0xfa>

0000000080004960 <pipealloc>:
  int writeopen;  // write fd is still open
};

int
pipealloc(struct file **f0, struct file **f1)
{
    80004960:	7179                	addi	sp,sp,-48
    80004962:	f406                	sd	ra,40(sp)
    80004964:	f022                	sd	s0,32(sp)
    80004966:	ec26                	sd	s1,24(sp)
    80004968:	e84a                	sd	s2,16(sp)
    8000496a:	e44e                	sd	s3,8(sp)
    8000496c:	e052                	sd	s4,0(sp)
    8000496e:	1800                	addi	s0,sp,48
    80004970:	84aa                	mv	s1,a0
    80004972:	8a2e                	mv	s4,a1
  struct pipe *pi;

  pi = 0;
  *f0 = *f1 = 0;
    80004974:	0005b023          	sd	zero,0(a1)
    80004978:	00053023          	sd	zero,0(a0)
  if((*f0 = filealloc()) == 0 || (*f1 = filealloc()) == 0)
    8000497c:	00000097          	auipc	ra,0x0
    80004980:	bf8080e7          	jalr	-1032(ra) # 80004574 <filealloc>
    80004984:	e088                	sd	a0,0(s1)
    80004986:	c551                	beqz	a0,80004a12 <pipealloc+0xb2>
    80004988:	00000097          	auipc	ra,0x0
    8000498c:	bec080e7          	jalr	-1044(ra) # 80004574 <filealloc>
    80004990:	00aa3023          	sd	a0,0(s4)
    80004994:	c92d                	beqz	a0,80004a06 <pipealloc+0xa6>
    goto bad;
  if((pi = (struct pipe*)kalloc()) == 0)
    80004996:	ffffc097          	auipc	ra,0xffffc
    8000499a:	150080e7          	jalr	336(ra) # 80000ae6 <kalloc>
    8000499e:	892a                	mv	s2,a0
    800049a0:	c125                	beqz	a0,80004a00 <pipealloc+0xa0>
    goto bad;
  pi->readopen = 1;
    800049a2:	4985                	li	s3,1
    800049a4:	23352023          	sw	s3,544(a0)
  pi->writeopen = 1;
    800049a8:	23352223          	sw	s3,548(a0)
  pi->nwrite = 0;
    800049ac:	20052e23          	sw	zero,540(a0)
  pi->nread = 0;
    800049b0:	20052c23          	sw	zero,536(a0)
  initlock(&pi->lock, "pipe");
    800049b4:	00004597          	auipc	a1,0x4
    800049b8:	d4458593          	addi	a1,a1,-700 # 800086f8 <syscalls+0x288>
    800049bc:	ffffc097          	auipc	ra,0xffffc
    800049c0:	18a080e7          	jalr	394(ra) # 80000b46 <initlock>
  (*f0)->type = FD_PIPE;
    800049c4:	609c                	ld	a5,0(s1)
    800049c6:	0137a023          	sw	s3,0(a5)
  (*f0)->readable = 1;
    800049ca:	609c                	ld	a5,0(s1)
    800049cc:	01378423          	sb	s3,8(a5)
  (*f0)->writable = 0;
    800049d0:	609c                	ld	a5,0(s1)
    800049d2:	000784a3          	sb	zero,9(a5)
  (*f0)->pipe = pi;
    800049d6:	609c                	ld	a5,0(s1)
    800049d8:	0127b823          	sd	s2,16(a5)
  (*f1)->type = FD_PIPE;
    800049dc:	000a3783          	ld	a5,0(s4)
    800049e0:	0137a023          	sw	s3,0(a5)
  (*f1)->readable = 0;
    800049e4:	000a3783          	ld	a5,0(s4)
    800049e8:	00078423          	sb	zero,8(a5)
  (*f1)->writable = 1;
    800049ec:	000a3783          	ld	a5,0(s4)
    800049f0:	013784a3          	sb	s3,9(a5)
  (*f1)->pipe = pi;
    800049f4:	000a3783          	ld	a5,0(s4)
    800049f8:	0127b823          	sd	s2,16(a5)
  return 0;
    800049fc:	4501                	li	a0,0
    800049fe:	a025                	j	80004a26 <pipealloc+0xc6>

 bad:
  if(pi)
    kfree((char*)pi);
  if(*f0)
    80004a00:	6088                	ld	a0,0(s1)
    80004a02:	e501                	bnez	a0,80004a0a <pipealloc+0xaa>
    80004a04:	a039                	j	80004a12 <pipealloc+0xb2>
    80004a06:	6088                	ld	a0,0(s1)
    80004a08:	c51d                	beqz	a0,80004a36 <pipealloc+0xd6>
    fileclose(*f0);
    80004a0a:	00000097          	auipc	ra,0x0
    80004a0e:	c26080e7          	jalr	-986(ra) # 80004630 <fileclose>
  if(*f1)
    80004a12:	000a3783          	ld	a5,0(s4)
    fileclose(*f1);
  return -1;
    80004a16:	557d                	li	a0,-1
  if(*f1)
    80004a18:	c799                	beqz	a5,80004a26 <pipealloc+0xc6>
    fileclose(*f1);
    80004a1a:	853e                	mv	a0,a5
    80004a1c:	00000097          	auipc	ra,0x0
    80004a20:	c14080e7          	jalr	-1004(ra) # 80004630 <fileclose>
  return -1;
    80004a24:	557d                	li	a0,-1
}
    80004a26:	70a2                	ld	ra,40(sp)
    80004a28:	7402                	ld	s0,32(sp)
    80004a2a:	64e2                	ld	s1,24(sp)
    80004a2c:	6942                	ld	s2,16(sp)
    80004a2e:	69a2                	ld	s3,8(sp)
    80004a30:	6a02                	ld	s4,0(sp)
    80004a32:	6145                	addi	sp,sp,48
    80004a34:	8082                	ret
  return -1;
    80004a36:	557d                	li	a0,-1
    80004a38:	b7fd                	j	80004a26 <pipealloc+0xc6>

0000000080004a3a <pipeclose>:

void
pipeclose(struct pipe *pi, int writable)
{
    80004a3a:	1101                	addi	sp,sp,-32
    80004a3c:	ec06                	sd	ra,24(sp)
    80004a3e:	e822                	sd	s0,16(sp)
    80004a40:	e426                	sd	s1,8(sp)
    80004a42:	e04a                	sd	s2,0(sp)
    80004a44:	1000                	addi	s0,sp,32
    80004a46:	84aa                	mv	s1,a0
    80004a48:	892e                	mv	s2,a1
  acquire(&pi->lock);
    80004a4a:	ffffc097          	auipc	ra,0xffffc
    80004a4e:	18c080e7          	jalr	396(ra) # 80000bd6 <acquire>
  if(writable){
    80004a52:	02090d63          	beqz	s2,80004a8c <pipeclose+0x52>
    pi->writeopen = 0;
    80004a56:	2204a223          	sw	zero,548(s1)
    wakeup(&pi->nread);
    80004a5a:	21848513          	addi	a0,s1,536
    80004a5e:	ffffd097          	auipc	ra,0xffffd
    80004a62:	71a080e7          	jalr	1818(ra) # 80002178 <wakeup>
  } else {
    pi->readopen = 0;
    wakeup(&pi->nwrite);
  }
  if(pi->readopen == 0 && pi->writeopen == 0){
    80004a66:	2204b783          	ld	a5,544(s1)
    80004a6a:	eb95                	bnez	a5,80004a9e <pipeclose+0x64>
    release(&pi->lock);
    80004a6c:	8526                	mv	a0,s1
    80004a6e:	ffffc097          	auipc	ra,0xffffc
    80004a72:	21c080e7          	jalr	540(ra) # 80000c8a <release>
    kfree((char*)pi);
    80004a76:	8526                	mv	a0,s1
    80004a78:	ffffc097          	auipc	ra,0xffffc
    80004a7c:	f72080e7          	jalr	-142(ra) # 800009ea <kfree>
  } else
    release(&pi->lock);
}
    80004a80:	60e2                	ld	ra,24(sp)
    80004a82:	6442                	ld	s0,16(sp)
    80004a84:	64a2                	ld	s1,8(sp)
    80004a86:	6902                	ld	s2,0(sp)
    80004a88:	6105                	addi	sp,sp,32
    80004a8a:	8082                	ret
    pi->readopen = 0;
    80004a8c:	2204a023          	sw	zero,544(s1)
    wakeup(&pi->nwrite);
    80004a90:	21c48513          	addi	a0,s1,540
    80004a94:	ffffd097          	auipc	ra,0xffffd
    80004a98:	6e4080e7          	jalr	1764(ra) # 80002178 <wakeup>
    80004a9c:	b7e9                	j	80004a66 <pipeclose+0x2c>
    release(&pi->lock);
    80004a9e:	8526                	mv	a0,s1
    80004aa0:	ffffc097          	auipc	ra,0xffffc
    80004aa4:	1ea080e7          	jalr	490(ra) # 80000c8a <release>
}
    80004aa8:	bfe1                	j	80004a80 <pipeclose+0x46>

0000000080004aaa <pipewrite>:

int
pipewrite(struct pipe *pi, uint64 addr, int n)
{
    80004aaa:	711d                	addi	sp,sp,-96
    80004aac:	ec86                	sd	ra,88(sp)
    80004aae:	e8a2                	sd	s0,80(sp)
    80004ab0:	e4a6                	sd	s1,72(sp)
    80004ab2:	e0ca                	sd	s2,64(sp)
    80004ab4:	fc4e                	sd	s3,56(sp)
    80004ab6:	f852                	sd	s4,48(sp)
    80004ab8:	f456                	sd	s5,40(sp)
    80004aba:	f05a                	sd	s6,32(sp)
    80004abc:	ec5e                	sd	s7,24(sp)
    80004abe:	e862                	sd	s8,16(sp)
    80004ac0:	1080                	addi	s0,sp,96
    80004ac2:	84aa                	mv	s1,a0
    80004ac4:	8aae                	mv	s5,a1
    80004ac6:	8a32                	mv	s4,a2
  int i = 0;
  struct proc *pr = myproc();
    80004ac8:	ffffd097          	auipc	ra,0xffffd
    80004acc:	f1a080e7          	jalr	-230(ra) # 800019e2 <myproc>
    80004ad0:	89aa                	mv	s3,a0

  acquire(&pi->lock);
    80004ad2:	8526                	mv	a0,s1
    80004ad4:	ffffc097          	auipc	ra,0xffffc
    80004ad8:	102080e7          	jalr	258(ra) # 80000bd6 <acquire>
  while(i < n){
    80004adc:	0b405663          	blez	s4,80004b88 <pipewrite+0xde>
  int i = 0;
    80004ae0:	4901                	li	s2,0
    if(pi->nwrite == pi->nread + PIPESIZE){ //DOC: pipewrite-full
      wakeup(&pi->nread);
      sleep(&pi->nwrite, &pi->lock);
    } else {
      char ch;
      if(copyin(pr->pagetable, &ch, addr + i, 1) == -1)
    80004ae2:	5b7d                	li	s6,-1
      wakeup(&pi->nread);
    80004ae4:	21848c13          	addi	s8,s1,536
      sleep(&pi->nwrite, &pi->lock);
    80004ae8:	21c48b93          	addi	s7,s1,540
    80004aec:	a089                	j	80004b2e <pipewrite+0x84>
      release(&pi->lock);
    80004aee:	8526                	mv	a0,s1
    80004af0:	ffffc097          	auipc	ra,0xffffc
    80004af4:	19a080e7          	jalr	410(ra) # 80000c8a <release>
      return -1;
    80004af8:	597d                	li	s2,-1
  }
  wakeup(&pi->nread);
  release(&pi->lock);

  return i;
}
    80004afa:	854a                	mv	a0,s2
    80004afc:	60e6                	ld	ra,88(sp)
    80004afe:	6446                	ld	s0,80(sp)
    80004b00:	64a6                	ld	s1,72(sp)
    80004b02:	6906                	ld	s2,64(sp)
    80004b04:	79e2                	ld	s3,56(sp)
    80004b06:	7a42                	ld	s4,48(sp)
    80004b08:	7aa2                	ld	s5,40(sp)
    80004b0a:	7b02                	ld	s6,32(sp)
    80004b0c:	6be2                	ld	s7,24(sp)
    80004b0e:	6c42                	ld	s8,16(sp)
    80004b10:	6125                	addi	sp,sp,96
    80004b12:	8082                	ret
      wakeup(&pi->nread);
    80004b14:	8562                	mv	a0,s8
    80004b16:	ffffd097          	auipc	ra,0xffffd
    80004b1a:	662080e7          	jalr	1634(ra) # 80002178 <wakeup>
      sleep(&pi->nwrite, &pi->lock);
    80004b1e:	85a6                	mv	a1,s1
    80004b20:	855e                	mv	a0,s7
    80004b22:	ffffd097          	auipc	ra,0xffffd
    80004b26:	5f2080e7          	jalr	1522(ra) # 80002114 <sleep>
  while(i < n){
    80004b2a:	07495063          	bge	s2,s4,80004b8a <pipewrite+0xe0>
    if(pi->readopen == 0 || killed(pr)){
    80004b2e:	2204a783          	lw	a5,544(s1)
    80004b32:	dfd5                	beqz	a5,80004aee <pipewrite+0x44>
    80004b34:	854e                	mv	a0,s3
    80004b36:	ffffe097          	auipc	ra,0xffffe
    80004b3a:	886080e7          	jalr	-1914(ra) # 800023bc <killed>
    80004b3e:	f945                	bnez	a0,80004aee <pipewrite+0x44>
    if(pi->nwrite == pi->nread + PIPESIZE){ //DOC: pipewrite-full
    80004b40:	2184a783          	lw	a5,536(s1)
    80004b44:	21c4a703          	lw	a4,540(s1)
    80004b48:	2007879b          	addiw	a5,a5,512
    80004b4c:	fcf704e3          	beq	a4,a5,80004b14 <pipewrite+0x6a>
      if(copyin(pr->pagetable, &ch, addr + i, 1) == -1)
    80004b50:	4685                	li	a3,1
    80004b52:	01590633          	add	a2,s2,s5
    80004b56:	faf40593          	addi	a1,s0,-81
    80004b5a:	0509b503          	ld	a0,80(s3)
    80004b5e:	ffffd097          	auipc	ra,0xffffd
    80004b62:	bcc080e7          	jalr	-1076(ra) # 8000172a <copyin>
    80004b66:	03650263          	beq	a0,s6,80004b8a <pipewrite+0xe0>
      pi->data[pi->nwrite++ % PIPESIZE] = ch;
    80004b6a:	21c4a783          	lw	a5,540(s1)
    80004b6e:	0017871b          	addiw	a4,a5,1
    80004b72:	20e4ae23          	sw	a4,540(s1)
    80004b76:	1ff7f793          	andi	a5,a5,511
    80004b7a:	97a6                	add	a5,a5,s1
    80004b7c:	faf44703          	lbu	a4,-81(s0)
    80004b80:	00e78c23          	sb	a4,24(a5)
      i++;
    80004b84:	2905                	addiw	s2,s2,1
    80004b86:	b755                	j	80004b2a <pipewrite+0x80>
  int i = 0;
    80004b88:	4901                	li	s2,0
  wakeup(&pi->nread);
    80004b8a:	21848513          	addi	a0,s1,536
    80004b8e:	ffffd097          	auipc	ra,0xffffd
    80004b92:	5ea080e7          	jalr	1514(ra) # 80002178 <wakeup>
  release(&pi->lock);
    80004b96:	8526                	mv	a0,s1
    80004b98:	ffffc097          	auipc	ra,0xffffc
    80004b9c:	0f2080e7          	jalr	242(ra) # 80000c8a <release>
  return i;
    80004ba0:	bfa9                	j	80004afa <pipewrite+0x50>

0000000080004ba2 <piperead>:

int
piperead(struct pipe *pi, uint64 addr, int n)
{
    80004ba2:	715d                	addi	sp,sp,-80
    80004ba4:	e486                	sd	ra,72(sp)
    80004ba6:	e0a2                	sd	s0,64(sp)
    80004ba8:	fc26                	sd	s1,56(sp)
    80004baa:	f84a                	sd	s2,48(sp)
    80004bac:	f44e                	sd	s3,40(sp)
    80004bae:	f052                	sd	s4,32(sp)
    80004bb0:	ec56                	sd	s5,24(sp)
    80004bb2:	e85a                	sd	s6,16(sp)
    80004bb4:	0880                	addi	s0,sp,80
    80004bb6:	84aa                	mv	s1,a0
    80004bb8:	892e                	mv	s2,a1
    80004bba:	8ab2                	mv	s5,a2
  int i;
  struct proc *pr = myproc();
    80004bbc:	ffffd097          	auipc	ra,0xffffd
    80004bc0:	e26080e7          	jalr	-474(ra) # 800019e2 <myproc>
    80004bc4:	8a2a                	mv	s4,a0
  char ch;

  acquire(&pi->lock);
    80004bc6:	8526                	mv	a0,s1
    80004bc8:	ffffc097          	auipc	ra,0xffffc
    80004bcc:	00e080e7          	jalr	14(ra) # 80000bd6 <acquire>
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    80004bd0:	2184a703          	lw	a4,536(s1)
    80004bd4:	21c4a783          	lw	a5,540(s1)
    if(killed(pr)){
      release(&pi->lock);
      return -1;
    }
    sleep(&pi->nread, &pi->lock); //DOC: piperead-sleep
    80004bd8:	21848993          	addi	s3,s1,536
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    80004bdc:	02f71763          	bne	a4,a5,80004c0a <piperead+0x68>
    80004be0:	2244a783          	lw	a5,548(s1)
    80004be4:	c39d                	beqz	a5,80004c0a <piperead+0x68>
    if(killed(pr)){
    80004be6:	8552                	mv	a0,s4
    80004be8:	ffffd097          	auipc	ra,0xffffd
    80004bec:	7d4080e7          	jalr	2004(ra) # 800023bc <killed>
    80004bf0:	e941                	bnez	a0,80004c80 <piperead+0xde>
    sleep(&pi->nread, &pi->lock); //DOC: piperead-sleep
    80004bf2:	85a6                	mv	a1,s1
    80004bf4:	854e                	mv	a0,s3
    80004bf6:	ffffd097          	auipc	ra,0xffffd
    80004bfa:	51e080e7          	jalr	1310(ra) # 80002114 <sleep>
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    80004bfe:	2184a703          	lw	a4,536(s1)
    80004c02:	21c4a783          	lw	a5,540(s1)
    80004c06:	fcf70de3          	beq	a4,a5,80004be0 <piperead+0x3e>
  }
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    80004c0a:	4981                	li	s3,0
    if(pi->nread == pi->nwrite)
      break;
    ch = pi->data[pi->nread++ % PIPESIZE];
    if(copyout(pr->pagetable, addr + i, &ch, 1) == -1)
    80004c0c:	5b7d                	li	s6,-1
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    80004c0e:	05505363          	blez	s5,80004c54 <piperead+0xb2>
    if(pi->nread == pi->nwrite)
    80004c12:	2184a783          	lw	a5,536(s1)
    80004c16:	21c4a703          	lw	a4,540(s1)
    80004c1a:	02f70d63          	beq	a4,a5,80004c54 <piperead+0xb2>
    ch = pi->data[pi->nread++ % PIPESIZE];
    80004c1e:	0017871b          	addiw	a4,a5,1
    80004c22:	20e4ac23          	sw	a4,536(s1)
    80004c26:	1ff7f793          	andi	a5,a5,511
    80004c2a:	97a6                	add	a5,a5,s1
    80004c2c:	0187c783          	lbu	a5,24(a5)
    80004c30:	faf40fa3          	sb	a5,-65(s0)
    if(copyout(pr->pagetable, addr + i, &ch, 1) == -1)
    80004c34:	4685                	li	a3,1
    80004c36:	fbf40613          	addi	a2,s0,-65
    80004c3a:	85ca                	mv	a1,s2
    80004c3c:	050a3503          	ld	a0,80(s4)
    80004c40:	ffffd097          	auipc	ra,0xffffd
    80004c44:	a5e080e7          	jalr	-1442(ra) # 8000169e <copyout>
    80004c48:	01650663          	beq	a0,s6,80004c54 <piperead+0xb2>
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    80004c4c:	2985                	addiw	s3,s3,1
    80004c4e:	0905                	addi	s2,s2,1
    80004c50:	fd3a91e3          	bne	s5,s3,80004c12 <piperead+0x70>
      break;
  }
  wakeup(&pi->nwrite);  //DOC: piperead-wakeup
    80004c54:	21c48513          	addi	a0,s1,540
    80004c58:	ffffd097          	auipc	ra,0xffffd
    80004c5c:	520080e7          	jalr	1312(ra) # 80002178 <wakeup>
  release(&pi->lock);
    80004c60:	8526                	mv	a0,s1
    80004c62:	ffffc097          	auipc	ra,0xffffc
    80004c66:	028080e7          	jalr	40(ra) # 80000c8a <release>
  return i;
}
    80004c6a:	854e                	mv	a0,s3
    80004c6c:	60a6                	ld	ra,72(sp)
    80004c6e:	6406                	ld	s0,64(sp)
    80004c70:	74e2                	ld	s1,56(sp)
    80004c72:	7942                	ld	s2,48(sp)
    80004c74:	79a2                	ld	s3,40(sp)
    80004c76:	7a02                	ld	s4,32(sp)
    80004c78:	6ae2                	ld	s5,24(sp)
    80004c7a:	6b42                	ld	s6,16(sp)
    80004c7c:	6161                	addi	sp,sp,80
    80004c7e:	8082                	ret
      release(&pi->lock);
    80004c80:	8526                	mv	a0,s1
    80004c82:	ffffc097          	auipc	ra,0xffffc
    80004c86:	008080e7          	jalr	8(ra) # 80000c8a <release>
      return -1;
    80004c8a:	59fd                	li	s3,-1
    80004c8c:	bff9                	j	80004c6a <piperead+0xc8>

0000000080004c8e <flags2perm>:
#include "elf.h"

static int loadseg(pde_t *, uint64, struct inode *, uint, uint);

int flags2perm(int flags)
{
    80004c8e:	1141                	addi	sp,sp,-16
    80004c90:	e422                	sd	s0,8(sp)
    80004c92:	0800                	addi	s0,sp,16
    80004c94:	87aa                	mv	a5,a0
    int perm = 0;
    if(flags & 0x1)
    80004c96:	8905                	andi	a0,a0,1
    80004c98:	c111                	beqz	a0,80004c9c <flags2perm+0xe>
      perm = PTE_X;
    80004c9a:	4521                	li	a0,8
    if(flags & 0x2)
    80004c9c:	8b89                	andi	a5,a5,2
    80004c9e:	c399                	beqz	a5,80004ca4 <flags2perm+0x16>
      perm |= PTE_W;
    80004ca0:	00456513          	ori	a0,a0,4
    return perm;
}
    80004ca4:	6422                	ld	s0,8(sp)
    80004ca6:	0141                	addi	sp,sp,16
    80004ca8:	8082                	ret

0000000080004caa <exec>:

int
exec(char *path, char **argv)
{
    80004caa:	de010113          	addi	sp,sp,-544
    80004cae:	20113c23          	sd	ra,536(sp)
    80004cb2:	20813823          	sd	s0,528(sp)
    80004cb6:	20913423          	sd	s1,520(sp)
    80004cba:	21213023          	sd	s2,512(sp)
    80004cbe:	ffce                	sd	s3,504(sp)
    80004cc0:	fbd2                	sd	s4,496(sp)
    80004cc2:	f7d6                	sd	s5,488(sp)
    80004cc4:	f3da                	sd	s6,480(sp)
    80004cc6:	efde                	sd	s7,472(sp)
    80004cc8:	ebe2                	sd	s8,464(sp)
    80004cca:	e7e6                	sd	s9,456(sp)
    80004ccc:	e3ea                	sd	s10,448(sp)
    80004cce:	ff6e                	sd	s11,440(sp)
    80004cd0:	1400                	addi	s0,sp,544
    80004cd2:	892a                	mv	s2,a0
    80004cd4:	dea43423          	sd	a0,-536(s0)
    80004cd8:	deb43823          	sd	a1,-528(s0)
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
  struct elfhdr elf;
  struct inode *ip;
  struct proghdr ph;
  pagetable_t pagetable = 0, oldpagetable;
  struct proc *p = myproc();
    80004cdc:	ffffd097          	auipc	ra,0xffffd
    80004ce0:	d06080e7          	jalr	-762(ra) # 800019e2 <myproc>
    80004ce4:	84aa                	mv	s1,a0

  begin_op();
    80004ce6:	fffff097          	auipc	ra,0xfffff
    80004cea:	47e080e7          	jalr	1150(ra) # 80004164 <begin_op>

  if((ip = namei(path)) == 0){
    80004cee:	854a                	mv	a0,s2
    80004cf0:	fffff097          	auipc	ra,0xfffff
    80004cf4:	258080e7          	jalr	600(ra) # 80003f48 <namei>
    80004cf8:	c93d                	beqz	a0,80004d6e <exec+0xc4>
    80004cfa:	8aaa                	mv	s5,a0
    end_op();
    return -1;
  }
  ilock(ip);
    80004cfc:	fffff097          	auipc	ra,0xfffff
    80004d00:	aa6080e7          	jalr	-1370(ra) # 800037a2 <ilock>

  // Check ELF header
  if(readi(ip, 0, (uint64)&elf, 0, sizeof(elf)) != sizeof(elf))
    80004d04:	04000713          	li	a4,64
    80004d08:	4681                	li	a3,0
    80004d0a:	e5040613          	addi	a2,s0,-432
    80004d0e:	4581                	li	a1,0
    80004d10:	8556                	mv	a0,s5
    80004d12:	fffff097          	auipc	ra,0xfffff
    80004d16:	d44080e7          	jalr	-700(ra) # 80003a56 <readi>
    80004d1a:	04000793          	li	a5,64
    80004d1e:	00f51a63          	bne	a0,a5,80004d32 <exec+0x88>
    goto bad;

  if(elf.magic != ELF_MAGIC)
    80004d22:	e5042703          	lw	a4,-432(s0)
    80004d26:	464c47b7          	lui	a5,0x464c4
    80004d2a:	57f78793          	addi	a5,a5,1407 # 464c457f <_entry-0x39b3ba81>
    80004d2e:	04f70663          	beq	a4,a5,80004d7a <exec+0xd0>

 bad:
  if(pagetable)
    proc_freepagetable(pagetable, sz);
  if(ip){
    iunlockput(ip);
    80004d32:	8556                	mv	a0,s5
    80004d34:	fffff097          	auipc	ra,0xfffff
    80004d38:	cd0080e7          	jalr	-816(ra) # 80003a04 <iunlockput>
    end_op();
    80004d3c:	fffff097          	auipc	ra,0xfffff
    80004d40:	4a8080e7          	jalr	1192(ra) # 800041e4 <end_op>
  }
  return -1;
    80004d44:	557d                	li	a0,-1
}
    80004d46:	21813083          	ld	ra,536(sp)
    80004d4a:	21013403          	ld	s0,528(sp)
    80004d4e:	20813483          	ld	s1,520(sp)
    80004d52:	20013903          	ld	s2,512(sp)
    80004d56:	79fe                	ld	s3,504(sp)
    80004d58:	7a5e                	ld	s4,496(sp)
    80004d5a:	7abe                	ld	s5,488(sp)
    80004d5c:	7b1e                	ld	s6,480(sp)
    80004d5e:	6bfe                	ld	s7,472(sp)
    80004d60:	6c5e                	ld	s8,464(sp)
    80004d62:	6cbe                	ld	s9,456(sp)
    80004d64:	6d1e                	ld	s10,448(sp)
    80004d66:	7dfa                	ld	s11,440(sp)
    80004d68:	22010113          	addi	sp,sp,544
    80004d6c:	8082                	ret
    end_op();
    80004d6e:	fffff097          	auipc	ra,0xfffff
    80004d72:	476080e7          	jalr	1142(ra) # 800041e4 <end_op>
    return -1;
    80004d76:	557d                	li	a0,-1
    80004d78:	b7f9                	j	80004d46 <exec+0x9c>
  if((pagetable = proc_pagetable(p)) == 0)
    80004d7a:	8526                	mv	a0,s1
    80004d7c:	ffffd097          	auipc	ra,0xffffd
    80004d80:	d2a080e7          	jalr	-726(ra) # 80001aa6 <proc_pagetable>
    80004d84:	8b2a                	mv	s6,a0
    80004d86:	d555                	beqz	a0,80004d32 <exec+0x88>
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    80004d88:	e7042783          	lw	a5,-400(s0)
    80004d8c:	e8845703          	lhu	a4,-376(s0)
    80004d90:	c735                	beqz	a4,80004dfc <exec+0x152>
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
    80004d92:	4901                	li	s2,0
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    80004d94:	e0043423          	sd	zero,-504(s0)
    if(ph.vaddr % PGSIZE != 0)
    80004d98:	6a05                	lui	s4,0x1
    80004d9a:	fffa0713          	addi	a4,s4,-1 # fff <_entry-0x7ffff001>
    80004d9e:	dee43023          	sd	a4,-544(s0)
loadseg(pagetable_t pagetable, uint64 va, struct inode *ip, uint offset, uint sz)
{
  uint i, n;
  uint64 pa;

  for(i = 0; i < sz; i += PGSIZE){
    80004da2:	6d85                	lui	s11,0x1
    80004da4:	7d7d                	lui	s10,0xfffff
    80004da6:	a48d                	j	80005008 <exec+0x35e>
    pa = walkaddr(pagetable, va + i);
    if(pa == 0)
      panic("loadseg: address should exist");
    80004da8:	00004517          	auipc	a0,0x4
    80004dac:	95850513          	addi	a0,a0,-1704 # 80008700 <syscalls+0x290>
    80004db0:	ffffb097          	auipc	ra,0xffffb
    80004db4:	78e080e7          	jalr	1934(ra) # 8000053e <panic>
    if(sz - i < PGSIZE)
      n = sz - i;
    else
      n = PGSIZE;
    if(readi(ip, 0, (uint64)pa, offset+i, n) != n)
    80004db8:	874a                	mv	a4,s2
    80004dba:	009c86bb          	addw	a3,s9,s1
    80004dbe:	4581                	li	a1,0
    80004dc0:	8556                	mv	a0,s5
    80004dc2:	fffff097          	auipc	ra,0xfffff
    80004dc6:	c94080e7          	jalr	-876(ra) # 80003a56 <readi>
    80004dca:	2501                	sext.w	a0,a0
    80004dcc:	1ca91b63          	bne	s2,a0,80004fa2 <exec+0x2f8>
  for(i = 0; i < sz; i += PGSIZE){
    80004dd0:	009d84bb          	addw	s1,s11,s1
    80004dd4:	013d09bb          	addw	s3,s10,s3
    80004dd8:	2174f863          	bgeu	s1,s7,80004fe8 <exec+0x33e>
    pa = walkaddr(pagetable, va + i);
    80004ddc:	02049593          	slli	a1,s1,0x20
    80004de0:	9181                	srli	a1,a1,0x20
    80004de2:	95e2                	add	a1,a1,s8
    80004de4:	855a                	mv	a0,s6
    80004de6:	ffffc097          	auipc	ra,0xffffc
    80004dea:	296080e7          	jalr	662(ra) # 8000107c <walkaddr>
    80004dee:	862a                	mv	a2,a0
    if(pa == 0)
    80004df0:	dd45                	beqz	a0,80004da8 <exec+0xfe>
      n = PGSIZE;
    80004df2:	8952                	mv	s2,s4
    if(sz - i < PGSIZE)
    80004df4:	fd49f2e3          	bgeu	s3,s4,80004db8 <exec+0x10e>
      n = sz - i;
    80004df8:	894e                	mv	s2,s3
    80004dfa:	bf7d                	j	80004db8 <exec+0x10e>
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
    80004dfc:	4901                	li	s2,0
  iunlockput(ip);
    80004dfe:	8556                	mv	a0,s5
    80004e00:	fffff097          	auipc	ra,0xfffff
    80004e04:	c04080e7          	jalr	-1020(ra) # 80003a04 <iunlockput>
  end_op();
    80004e08:	fffff097          	auipc	ra,0xfffff
    80004e0c:	3dc080e7          	jalr	988(ra) # 800041e4 <end_op>
  p = myproc();
    80004e10:	ffffd097          	auipc	ra,0xffffd
    80004e14:	bd2080e7          	jalr	-1070(ra) # 800019e2 <myproc>
    80004e18:	8baa                	mv	s7,a0
  uint64 oldsz = p->sz;
    80004e1a:	04853d03          	ld	s10,72(a0)
  sz = PGROUNDUP(sz);
    80004e1e:	6785                	lui	a5,0x1
    80004e20:	17fd                	addi	a5,a5,-1
    80004e22:	993e                	add	s2,s2,a5
    80004e24:	77fd                	lui	a5,0xfffff
    80004e26:	00f977b3          	and	a5,s2,a5
    80004e2a:	def43c23          	sd	a5,-520(s0)
  if((sz1 = uvmalloc(pagetable, sz, sz + 2*PGSIZE, PTE_W)) == 0)
    80004e2e:	4691                	li	a3,4
    80004e30:	6609                	lui	a2,0x2
    80004e32:	963e                	add	a2,a2,a5
    80004e34:	85be                	mv	a1,a5
    80004e36:	855a                	mv	a0,s6
    80004e38:	ffffc097          	auipc	ra,0xffffc
    80004e3c:	60e080e7          	jalr	1550(ra) # 80001446 <uvmalloc>
    80004e40:	8c2a                	mv	s8,a0
  ip = 0;
    80004e42:	4a81                	li	s5,0
  if((sz1 = uvmalloc(pagetable, sz, sz + 2*PGSIZE, PTE_W)) == 0)
    80004e44:	14050f63          	beqz	a0,80004fa2 <exec+0x2f8>
  uvmclear(pagetable, sz-2*PGSIZE);
    80004e48:	75f9                	lui	a1,0xffffe
    80004e4a:	95aa                	add	a1,a1,a0
    80004e4c:	855a                	mv	a0,s6
    80004e4e:	ffffd097          	auipc	ra,0xffffd
    80004e52:	81e080e7          	jalr	-2018(ra) # 8000166c <uvmclear>
  stackbase = sp - PGSIZE;
    80004e56:	7afd                	lui	s5,0xfffff
    80004e58:	9ae2                	add	s5,s5,s8
  for(argc = 0; argv[argc]; argc++) {
    80004e5a:	df043783          	ld	a5,-528(s0)
    80004e5e:	6388                	ld	a0,0(a5)
    80004e60:	c925                	beqz	a0,80004ed0 <exec+0x226>
    80004e62:	e9040993          	addi	s3,s0,-368
    80004e66:	f9040c93          	addi	s9,s0,-112
  sp = sz;
    80004e6a:	8962                	mv	s2,s8
  for(argc = 0; argv[argc]; argc++) {
    80004e6c:	4481                	li	s1,0
    sp -= strlen(argv[argc]) + 1;
    80004e6e:	ffffc097          	auipc	ra,0xffffc
    80004e72:	fe0080e7          	jalr	-32(ra) # 80000e4e <strlen>
    80004e76:	0015079b          	addiw	a5,a0,1
    80004e7a:	40f90933          	sub	s2,s2,a5
    sp -= sp % 16; // riscv sp must be 16-byte aligned
    80004e7e:	ff097913          	andi	s2,s2,-16
    if(sp < stackbase)
    80004e82:	15596763          	bltu	s2,s5,80004fd0 <exec+0x326>
    if(copyout(pagetable, sp, argv[argc], strlen(argv[argc]) + 1) < 0)
    80004e86:	df043d83          	ld	s11,-528(s0)
    80004e8a:	000dba03          	ld	s4,0(s11) # 1000 <_entry-0x7ffff000>
    80004e8e:	8552                	mv	a0,s4
    80004e90:	ffffc097          	auipc	ra,0xffffc
    80004e94:	fbe080e7          	jalr	-66(ra) # 80000e4e <strlen>
    80004e98:	0015069b          	addiw	a3,a0,1
    80004e9c:	8652                	mv	a2,s4
    80004e9e:	85ca                	mv	a1,s2
    80004ea0:	855a                	mv	a0,s6
    80004ea2:	ffffc097          	auipc	ra,0xffffc
    80004ea6:	7fc080e7          	jalr	2044(ra) # 8000169e <copyout>
    80004eaa:	12054763          	bltz	a0,80004fd8 <exec+0x32e>
    ustack[argc] = sp;
    80004eae:	0129b023          	sd	s2,0(s3)
  for(argc = 0; argv[argc]; argc++) {
    80004eb2:	0485                	addi	s1,s1,1
    80004eb4:	008d8793          	addi	a5,s11,8
    80004eb8:	def43823          	sd	a5,-528(s0)
    80004ebc:	008db503          	ld	a0,8(s11)
    80004ec0:	c911                	beqz	a0,80004ed4 <exec+0x22a>
    if(argc >= MAXARG)
    80004ec2:	09a1                	addi	s3,s3,8
    80004ec4:	fb3c95e3          	bne	s9,s3,80004e6e <exec+0x1c4>
  sz = sz1;
    80004ec8:	df843c23          	sd	s8,-520(s0)
  ip = 0;
    80004ecc:	4a81                	li	s5,0
    80004ece:	a8d1                	j	80004fa2 <exec+0x2f8>
  sp = sz;
    80004ed0:	8962                	mv	s2,s8
  for(argc = 0; argv[argc]; argc++) {
    80004ed2:	4481                	li	s1,0
  ustack[argc] = 0;
    80004ed4:	00349793          	slli	a5,s1,0x3
    80004ed8:	f9040713          	addi	a4,s0,-112
    80004edc:	97ba                	add	a5,a5,a4
    80004ede:	f007b023          	sd	zero,-256(a5) # ffffffffffffef00 <end+0xffffffff7ffd7068>
  sp -= (argc+1) * sizeof(uint64);
    80004ee2:	00148693          	addi	a3,s1,1
    80004ee6:	068e                	slli	a3,a3,0x3
    80004ee8:	40d90933          	sub	s2,s2,a3
  sp -= sp % 16;
    80004eec:	ff097913          	andi	s2,s2,-16
  if(sp < stackbase)
    80004ef0:	01597663          	bgeu	s2,s5,80004efc <exec+0x252>
  sz = sz1;
    80004ef4:	df843c23          	sd	s8,-520(s0)
  ip = 0;
    80004ef8:	4a81                	li	s5,0
    80004efa:	a065                	j	80004fa2 <exec+0x2f8>
  if(copyout(pagetable, sp, (char *)ustack, (argc+1)*sizeof(uint64)) < 0)
    80004efc:	e9040613          	addi	a2,s0,-368
    80004f00:	85ca                	mv	a1,s2
    80004f02:	855a                	mv	a0,s6
    80004f04:	ffffc097          	auipc	ra,0xffffc
    80004f08:	79a080e7          	jalr	1946(ra) # 8000169e <copyout>
    80004f0c:	0c054a63          	bltz	a0,80004fe0 <exec+0x336>
  p->trapframe->a1 = sp;
    80004f10:	058bb783          	ld	a5,88(s7) # 1058 <_entry-0x7fffefa8>
    80004f14:	0727bc23          	sd	s2,120(a5)
  for(last=s=path; *s; s++)
    80004f18:	de843783          	ld	a5,-536(s0)
    80004f1c:	0007c703          	lbu	a4,0(a5)
    80004f20:	cf11                	beqz	a4,80004f3c <exec+0x292>
    80004f22:	0785                	addi	a5,a5,1
    if(*s == '/')
    80004f24:	02f00693          	li	a3,47
    80004f28:	a039                	j	80004f36 <exec+0x28c>
      last = s+1;
    80004f2a:	def43423          	sd	a5,-536(s0)
  for(last=s=path; *s; s++)
    80004f2e:	0785                	addi	a5,a5,1
    80004f30:	fff7c703          	lbu	a4,-1(a5)
    80004f34:	c701                	beqz	a4,80004f3c <exec+0x292>
    if(*s == '/')
    80004f36:	fed71ce3          	bne	a4,a3,80004f2e <exec+0x284>
    80004f3a:	bfc5                	j	80004f2a <exec+0x280>
  safestrcpy(p->name, last, sizeof(p->name));
    80004f3c:	4641                	li	a2,16
    80004f3e:	de843583          	ld	a1,-536(s0)
    80004f42:	158b8513          	addi	a0,s7,344
    80004f46:	ffffc097          	auipc	ra,0xffffc
    80004f4a:	ed6080e7          	jalr	-298(ra) # 80000e1c <safestrcpy>
 if(p->fb_va != 0){
    80004f4e:	168bb583          	ld	a1,360(s7)
    80004f52:	ed8d                	bnez	a1,80004f8c <exec+0x2e2>
  virtio_gpu_release(p);
    80004f54:	855e                	mv	a0,s7
    80004f56:	00002097          	auipc	ra,0x2
    80004f5a:	d40080e7          	jalr	-704(ra) # 80006c96 <virtio_gpu_release>
  oldpagetable = p->pagetable;
    80004f5e:	050bb503          	ld	a0,80(s7)
  p->pagetable = pagetable;
    80004f62:	056bb823          	sd	s6,80(s7)
  p->sz = sz;
    80004f66:	058bb423          	sd	s8,72(s7)
  p->trapframe->epc = elf.entry;  // initial program counter = main
    80004f6a:	058bb783          	ld	a5,88(s7)
    80004f6e:	e6843703          	ld	a4,-408(s0)
    80004f72:	ef98                	sd	a4,24(a5)
  p->trapframe->sp = sp; // initial stack pointer
    80004f74:	058bb783          	ld	a5,88(s7)
    80004f78:	0327b823          	sd	s2,48(a5)
  proc_freepagetable(oldpagetable, oldsz);
    80004f7c:	85ea                	mv	a1,s10
    80004f7e:	ffffd097          	auipc	ra,0xffffd
    80004f82:	bc4080e7          	jalr	-1084(ra) # 80001b42 <proc_freepagetable>
  return argc; // this ends up in a0, the first argument to main(argc, argv)
    80004f86:	0004851b          	sext.w	a0,s1
    80004f8a:	bb75                	j	80004d46 <exec+0x9c>
    virtio_gpu_unmap_user(p->pagetable, p->fb_va);
    80004f8c:	050bb503          	ld	a0,80(s7)
    80004f90:	00002097          	auipc	ra,0x2
    80004f94:	c18080e7          	jalr	-1000(ra) # 80006ba8 <virtio_gpu_unmap_user>
    p->fb_va = 0;
    80004f98:	160bb423          	sd	zero,360(s7)
    80004f9c:	bf65                	j	80004f54 <exec+0x2aa>
    80004f9e:	df243c23          	sd	s2,-520(s0)
    proc_freepagetable(pagetable, sz);
    80004fa2:	df843583          	ld	a1,-520(s0)
    80004fa6:	855a                	mv	a0,s6
    80004fa8:	ffffd097          	auipc	ra,0xffffd
    80004fac:	b9a080e7          	jalr	-1126(ra) # 80001b42 <proc_freepagetable>
  if(ip){
    80004fb0:	d80a91e3          	bnez	s5,80004d32 <exec+0x88>
  return -1;
    80004fb4:	557d                	li	a0,-1
    80004fb6:	bb41                	j	80004d46 <exec+0x9c>
    80004fb8:	df243c23          	sd	s2,-520(s0)
    80004fbc:	b7dd                	j	80004fa2 <exec+0x2f8>
    80004fbe:	df243c23          	sd	s2,-520(s0)
    80004fc2:	b7c5                	j	80004fa2 <exec+0x2f8>
    80004fc4:	df243c23          	sd	s2,-520(s0)
    80004fc8:	bfe9                	j	80004fa2 <exec+0x2f8>
    80004fca:	df243c23          	sd	s2,-520(s0)
    80004fce:	bfd1                	j	80004fa2 <exec+0x2f8>
  sz = sz1;
    80004fd0:	df843c23          	sd	s8,-520(s0)
  ip = 0;
    80004fd4:	4a81                	li	s5,0
    80004fd6:	b7f1                	j	80004fa2 <exec+0x2f8>
  sz = sz1;
    80004fd8:	df843c23          	sd	s8,-520(s0)
  ip = 0;
    80004fdc:	4a81                	li	s5,0
    80004fde:	b7d1                	j	80004fa2 <exec+0x2f8>
  sz = sz1;
    80004fe0:	df843c23          	sd	s8,-520(s0)
  ip = 0;
    80004fe4:	4a81                	li	s5,0
    80004fe6:	bf75                	j	80004fa2 <exec+0x2f8>
    if((sz1 = uvmalloc(pagetable, sz, ph.vaddr + ph.memsz, flags2perm(ph.flags))) == 0)
    80004fe8:	df843903          	ld	s2,-520(s0)
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    80004fec:	e0843783          	ld	a5,-504(s0)
    80004ff0:	0017869b          	addiw	a3,a5,1
    80004ff4:	e0d43423          	sd	a3,-504(s0)
    80004ff8:	e0043783          	ld	a5,-512(s0)
    80004ffc:	0387879b          	addiw	a5,a5,56
    80005000:	e8845703          	lhu	a4,-376(s0)
    80005004:	dee6dde3          	bge	a3,a4,80004dfe <exec+0x154>
    if(readi(ip, 0, (uint64)&ph, off, sizeof(ph)) != sizeof(ph))
    80005008:	2781                	sext.w	a5,a5
    8000500a:	e0f43023          	sd	a5,-512(s0)
    8000500e:	03800713          	li	a4,56
    80005012:	86be                	mv	a3,a5
    80005014:	e1840613          	addi	a2,s0,-488
    80005018:	4581                	li	a1,0
    8000501a:	8556                	mv	a0,s5
    8000501c:	fffff097          	auipc	ra,0xfffff
    80005020:	a3a080e7          	jalr	-1478(ra) # 80003a56 <readi>
    80005024:	03800793          	li	a5,56
    80005028:	f6f51be3          	bne	a0,a5,80004f9e <exec+0x2f4>
    if(ph.type != ELF_PROG_LOAD)
    8000502c:	e1842783          	lw	a5,-488(s0)
    80005030:	4705                	li	a4,1
    80005032:	fae79de3          	bne	a5,a4,80004fec <exec+0x342>
    if(ph.memsz < ph.filesz)
    80005036:	e4043483          	ld	s1,-448(s0)
    8000503a:	e3843783          	ld	a5,-456(s0)
    8000503e:	f6f4ede3          	bltu	s1,a5,80004fb8 <exec+0x30e>
    if(ph.vaddr + ph.memsz < ph.vaddr)
    80005042:	e2843783          	ld	a5,-472(s0)
    80005046:	94be                	add	s1,s1,a5
    80005048:	f6f4ebe3          	bltu	s1,a5,80004fbe <exec+0x314>
    if(ph.vaddr % PGSIZE != 0)
    8000504c:	de043703          	ld	a4,-544(s0)
    80005050:	8ff9                	and	a5,a5,a4
    80005052:	fbad                	bnez	a5,80004fc4 <exec+0x31a>
    if((sz1 = uvmalloc(pagetable, sz, ph.vaddr + ph.memsz, flags2perm(ph.flags))) == 0)
    80005054:	e1c42503          	lw	a0,-484(s0)
    80005058:	00000097          	auipc	ra,0x0
    8000505c:	c36080e7          	jalr	-970(ra) # 80004c8e <flags2perm>
    80005060:	86aa                	mv	a3,a0
    80005062:	8626                	mv	a2,s1
    80005064:	85ca                	mv	a1,s2
    80005066:	855a                	mv	a0,s6
    80005068:	ffffc097          	auipc	ra,0xffffc
    8000506c:	3de080e7          	jalr	990(ra) # 80001446 <uvmalloc>
    80005070:	dea43c23          	sd	a0,-520(s0)
    80005074:	d939                	beqz	a0,80004fca <exec+0x320>
    if(loadseg(pagetable, ph.vaddr, ip, ph.off, ph.filesz) < 0)
    80005076:	e2843c03          	ld	s8,-472(s0)
    8000507a:	e2042c83          	lw	s9,-480(s0)
    8000507e:	e3842b83          	lw	s7,-456(s0)
  for(i = 0; i < sz; i += PGSIZE){
    80005082:	f60b83e3          	beqz	s7,80004fe8 <exec+0x33e>
    80005086:	89de                	mv	s3,s7
    80005088:	4481                	li	s1,0
    8000508a:	bb89                	j	80004ddc <exec+0x132>

000000008000508c <argfd>:

// Fetch the nth word-sized system call argument as a file descriptor
// and return both the descriptor and the corresponding struct file.
static int
argfd(int n, int *pfd, struct file **pf)
{
    8000508c:	7179                	addi	sp,sp,-48
    8000508e:	f406                	sd	ra,40(sp)
    80005090:	f022                	sd	s0,32(sp)
    80005092:	ec26                	sd	s1,24(sp)
    80005094:	e84a                	sd	s2,16(sp)
    80005096:	1800                	addi	s0,sp,48
    80005098:	892e                	mv	s2,a1
    8000509a:	84b2                	mv	s1,a2
  int fd;
  struct file *f;

  argint(n, &fd);
    8000509c:	fdc40593          	addi	a1,s0,-36
    800050a0:	ffffe097          	auipc	ra,0xffffe
    800050a4:	ae0080e7          	jalr	-1312(ra) # 80002b80 <argint>
  if(fd < 0 || fd >= NOFILE || (f=myproc()->ofile[fd]) == 0)
    800050a8:	fdc42703          	lw	a4,-36(s0)
    800050ac:	47bd                	li	a5,15
    800050ae:	02e7eb63          	bltu	a5,a4,800050e4 <argfd+0x58>
    800050b2:	ffffd097          	auipc	ra,0xffffd
    800050b6:	930080e7          	jalr	-1744(ra) # 800019e2 <myproc>
    800050ba:	fdc42703          	lw	a4,-36(s0)
    800050be:	01a70793          	addi	a5,a4,26
    800050c2:	078e                	slli	a5,a5,0x3
    800050c4:	953e                	add	a0,a0,a5
    800050c6:	611c                	ld	a5,0(a0)
    800050c8:	c385                	beqz	a5,800050e8 <argfd+0x5c>
    return -1;
  if(pfd)
    800050ca:	00090463          	beqz	s2,800050d2 <argfd+0x46>
    *pfd = fd;
    800050ce:	00e92023          	sw	a4,0(s2)
  if(pf)
    *pf = f;
  return 0;
    800050d2:	4501                	li	a0,0
  if(pf)
    800050d4:	c091                	beqz	s1,800050d8 <argfd+0x4c>
    *pf = f;
    800050d6:	e09c                	sd	a5,0(s1)
}
    800050d8:	70a2                	ld	ra,40(sp)
    800050da:	7402                	ld	s0,32(sp)
    800050dc:	64e2                	ld	s1,24(sp)
    800050de:	6942                	ld	s2,16(sp)
    800050e0:	6145                	addi	sp,sp,48
    800050e2:	8082                	ret
    return -1;
    800050e4:	557d                	li	a0,-1
    800050e6:	bfcd                	j	800050d8 <argfd+0x4c>
    800050e8:	557d                	li	a0,-1
    800050ea:	b7fd                	j	800050d8 <argfd+0x4c>

00000000800050ec <fdalloc>:

// Allocate a file descriptor for the given file.
// Takes over file reference from caller on success.
static int
fdalloc(struct file *f)
{
    800050ec:	1101                	addi	sp,sp,-32
    800050ee:	ec06                	sd	ra,24(sp)
    800050f0:	e822                	sd	s0,16(sp)
    800050f2:	e426                	sd	s1,8(sp)
    800050f4:	1000                	addi	s0,sp,32
    800050f6:	84aa                	mv	s1,a0
  int fd;
  struct proc *p = myproc();
    800050f8:	ffffd097          	auipc	ra,0xffffd
    800050fc:	8ea080e7          	jalr	-1814(ra) # 800019e2 <myproc>
    80005100:	862a                	mv	a2,a0

  for(fd = 0; fd < NOFILE; fd++){
    80005102:	0d050793          	addi	a5,a0,208
    80005106:	4501                	li	a0,0
    80005108:	46c1                	li	a3,16
    if(p->ofile[fd] == 0){
    8000510a:	6398                	ld	a4,0(a5)
    8000510c:	cb19                	beqz	a4,80005122 <fdalloc+0x36>
  for(fd = 0; fd < NOFILE; fd++){
    8000510e:	2505                	addiw	a0,a0,1
    80005110:	07a1                	addi	a5,a5,8
    80005112:	fed51ce3          	bne	a0,a3,8000510a <fdalloc+0x1e>
      p->ofile[fd] = f;
      return fd;
    }
  }
  return -1;
    80005116:	557d                	li	a0,-1
}
    80005118:	60e2                	ld	ra,24(sp)
    8000511a:	6442                	ld	s0,16(sp)
    8000511c:	64a2                	ld	s1,8(sp)
    8000511e:	6105                	addi	sp,sp,32
    80005120:	8082                	ret
      p->ofile[fd] = f;
    80005122:	01a50793          	addi	a5,a0,26
    80005126:	078e                	slli	a5,a5,0x3
    80005128:	963e                	add	a2,a2,a5
    8000512a:	e204                	sd	s1,0(a2)
      return fd;
    8000512c:	b7f5                	j	80005118 <fdalloc+0x2c>

000000008000512e <create>:
  return -1;
}

static struct inode*
create(char *path, short type, short major, short minor)
{
    8000512e:	715d                	addi	sp,sp,-80
    80005130:	e486                	sd	ra,72(sp)
    80005132:	e0a2                	sd	s0,64(sp)
    80005134:	fc26                	sd	s1,56(sp)
    80005136:	f84a                	sd	s2,48(sp)
    80005138:	f44e                	sd	s3,40(sp)
    8000513a:	f052                	sd	s4,32(sp)
    8000513c:	ec56                	sd	s5,24(sp)
    8000513e:	e85a                	sd	s6,16(sp)
    80005140:	0880                	addi	s0,sp,80
    80005142:	8b2e                	mv	s6,a1
    80005144:	89b2                	mv	s3,a2
    80005146:	8936                	mv	s2,a3
  struct inode *ip, *dp;
  char name[DIRSIZ];

  if((dp = nameiparent(path, name)) == 0)
    80005148:	fb040593          	addi	a1,s0,-80
    8000514c:	fffff097          	auipc	ra,0xfffff
    80005150:	e1a080e7          	jalr	-486(ra) # 80003f66 <nameiparent>
    80005154:	84aa                	mv	s1,a0
    80005156:	14050f63          	beqz	a0,800052b4 <create+0x186>
    return 0;

  ilock(dp);
    8000515a:	ffffe097          	auipc	ra,0xffffe
    8000515e:	648080e7          	jalr	1608(ra) # 800037a2 <ilock>

  if((ip = dirlookup(dp, name, 0)) != 0){
    80005162:	4601                	li	a2,0
    80005164:	fb040593          	addi	a1,s0,-80
    80005168:	8526                	mv	a0,s1
    8000516a:	fffff097          	auipc	ra,0xfffff
    8000516e:	b1c080e7          	jalr	-1252(ra) # 80003c86 <dirlookup>
    80005172:	8aaa                	mv	s5,a0
    80005174:	c931                	beqz	a0,800051c8 <create+0x9a>
    iunlockput(dp);
    80005176:	8526                	mv	a0,s1
    80005178:	fffff097          	auipc	ra,0xfffff
    8000517c:	88c080e7          	jalr	-1908(ra) # 80003a04 <iunlockput>
    ilock(ip);
    80005180:	8556                	mv	a0,s5
    80005182:	ffffe097          	auipc	ra,0xffffe
    80005186:	620080e7          	jalr	1568(ra) # 800037a2 <ilock>
    if(type == T_FILE && (ip->type == T_FILE || ip->type == T_DEVICE))
    8000518a:	000b059b          	sext.w	a1,s6
    8000518e:	4789                	li	a5,2
    80005190:	02f59563          	bne	a1,a5,800051ba <create+0x8c>
    80005194:	044ad783          	lhu	a5,68(s5) # fffffffffffff044 <end+0xffffffff7ffd71ac>
    80005198:	37f9                	addiw	a5,a5,-2
    8000519a:	17c2                	slli	a5,a5,0x30
    8000519c:	93c1                	srli	a5,a5,0x30
    8000519e:	4705                	li	a4,1
    800051a0:	00f76d63          	bltu	a4,a5,800051ba <create+0x8c>
  ip->nlink = 0;
  iupdate(ip);
  iunlockput(ip);
  iunlockput(dp);
  return 0;
}
    800051a4:	8556                	mv	a0,s5
    800051a6:	60a6                	ld	ra,72(sp)
    800051a8:	6406                	ld	s0,64(sp)
    800051aa:	74e2                	ld	s1,56(sp)
    800051ac:	7942                	ld	s2,48(sp)
    800051ae:	79a2                	ld	s3,40(sp)
    800051b0:	7a02                	ld	s4,32(sp)
    800051b2:	6ae2                	ld	s5,24(sp)
    800051b4:	6b42                	ld	s6,16(sp)
    800051b6:	6161                	addi	sp,sp,80
    800051b8:	8082                	ret
    iunlockput(ip);
    800051ba:	8556                	mv	a0,s5
    800051bc:	fffff097          	auipc	ra,0xfffff
    800051c0:	848080e7          	jalr	-1976(ra) # 80003a04 <iunlockput>
    return 0;
    800051c4:	4a81                	li	s5,0
    800051c6:	bff9                	j	800051a4 <create+0x76>
  if((ip = ialloc(dp->dev, type)) == 0){
    800051c8:	85da                	mv	a1,s6
    800051ca:	4088                	lw	a0,0(s1)
    800051cc:	ffffe097          	auipc	ra,0xffffe
    800051d0:	43a080e7          	jalr	1082(ra) # 80003606 <ialloc>
    800051d4:	8a2a                	mv	s4,a0
    800051d6:	c539                	beqz	a0,80005224 <create+0xf6>
  ilock(ip);
    800051d8:	ffffe097          	auipc	ra,0xffffe
    800051dc:	5ca080e7          	jalr	1482(ra) # 800037a2 <ilock>
  ip->major = major;
    800051e0:	053a1323          	sh	s3,70(s4)
  ip->minor = minor;
    800051e4:	052a1423          	sh	s2,72(s4)
  ip->nlink = 1;
    800051e8:	4905                	li	s2,1
    800051ea:	052a1523          	sh	s2,74(s4)
  iupdate(ip);
    800051ee:	8552                	mv	a0,s4
    800051f0:	ffffe097          	auipc	ra,0xffffe
    800051f4:	4e8080e7          	jalr	1256(ra) # 800036d8 <iupdate>
  if(type == T_DIR){  // Create . and .. entries.
    800051f8:	000b059b          	sext.w	a1,s6
    800051fc:	03258b63          	beq	a1,s2,80005232 <create+0x104>
  if(dirlink(dp, name, ip->inum) < 0)
    80005200:	004a2603          	lw	a2,4(s4)
    80005204:	fb040593          	addi	a1,s0,-80
    80005208:	8526                	mv	a0,s1
    8000520a:	fffff097          	auipc	ra,0xfffff
    8000520e:	c8c080e7          	jalr	-884(ra) # 80003e96 <dirlink>
    80005212:	06054f63          	bltz	a0,80005290 <create+0x162>
  iunlockput(dp);
    80005216:	8526                	mv	a0,s1
    80005218:	ffffe097          	auipc	ra,0xffffe
    8000521c:	7ec080e7          	jalr	2028(ra) # 80003a04 <iunlockput>
  return ip;
    80005220:	8ad2                	mv	s5,s4
    80005222:	b749                	j	800051a4 <create+0x76>
    iunlockput(dp);
    80005224:	8526                	mv	a0,s1
    80005226:	ffffe097          	auipc	ra,0xffffe
    8000522a:	7de080e7          	jalr	2014(ra) # 80003a04 <iunlockput>
    return 0;
    8000522e:	8ad2                	mv	s5,s4
    80005230:	bf95                	j	800051a4 <create+0x76>
    if(dirlink(ip, ".", ip->inum) < 0 || dirlink(ip, "..", dp->inum) < 0)
    80005232:	004a2603          	lw	a2,4(s4)
    80005236:	00003597          	auipc	a1,0x3
    8000523a:	4ea58593          	addi	a1,a1,1258 # 80008720 <syscalls+0x2b0>
    8000523e:	8552                	mv	a0,s4
    80005240:	fffff097          	auipc	ra,0xfffff
    80005244:	c56080e7          	jalr	-938(ra) # 80003e96 <dirlink>
    80005248:	04054463          	bltz	a0,80005290 <create+0x162>
    8000524c:	40d0                	lw	a2,4(s1)
    8000524e:	00003597          	auipc	a1,0x3
    80005252:	4da58593          	addi	a1,a1,1242 # 80008728 <syscalls+0x2b8>
    80005256:	8552                	mv	a0,s4
    80005258:	fffff097          	auipc	ra,0xfffff
    8000525c:	c3e080e7          	jalr	-962(ra) # 80003e96 <dirlink>
    80005260:	02054863          	bltz	a0,80005290 <create+0x162>
  if(dirlink(dp, name, ip->inum) < 0)
    80005264:	004a2603          	lw	a2,4(s4)
    80005268:	fb040593          	addi	a1,s0,-80
    8000526c:	8526                	mv	a0,s1
    8000526e:	fffff097          	auipc	ra,0xfffff
    80005272:	c28080e7          	jalr	-984(ra) # 80003e96 <dirlink>
    80005276:	00054d63          	bltz	a0,80005290 <create+0x162>
    dp->nlink++;  // for ".."
    8000527a:	04a4d783          	lhu	a5,74(s1)
    8000527e:	2785                	addiw	a5,a5,1
    80005280:	04f49523          	sh	a5,74(s1)
    iupdate(dp);
    80005284:	8526                	mv	a0,s1
    80005286:	ffffe097          	auipc	ra,0xffffe
    8000528a:	452080e7          	jalr	1106(ra) # 800036d8 <iupdate>
    8000528e:	b761                	j	80005216 <create+0xe8>
  ip->nlink = 0;
    80005290:	040a1523          	sh	zero,74(s4)
  iupdate(ip);
    80005294:	8552                	mv	a0,s4
    80005296:	ffffe097          	auipc	ra,0xffffe
    8000529a:	442080e7          	jalr	1090(ra) # 800036d8 <iupdate>
  iunlockput(ip);
    8000529e:	8552                	mv	a0,s4
    800052a0:	ffffe097          	auipc	ra,0xffffe
    800052a4:	764080e7          	jalr	1892(ra) # 80003a04 <iunlockput>
  iunlockput(dp);
    800052a8:	8526                	mv	a0,s1
    800052aa:	ffffe097          	auipc	ra,0xffffe
    800052ae:	75a080e7          	jalr	1882(ra) # 80003a04 <iunlockput>
  return 0;
    800052b2:	bdcd                	j	800051a4 <create+0x76>
    return 0;
    800052b4:	8aaa                	mv	s5,a0
    800052b6:	b5fd                	j	800051a4 <create+0x76>

00000000800052b8 <sys_dup>:
{
    800052b8:	7179                	addi	sp,sp,-48
    800052ba:	f406                	sd	ra,40(sp)
    800052bc:	f022                	sd	s0,32(sp)
    800052be:	ec26                	sd	s1,24(sp)
    800052c0:	1800                	addi	s0,sp,48
  if(argfd(0, 0, &f) < 0)
    800052c2:	fd840613          	addi	a2,s0,-40
    800052c6:	4581                	li	a1,0
    800052c8:	4501                	li	a0,0
    800052ca:	00000097          	auipc	ra,0x0
    800052ce:	dc2080e7          	jalr	-574(ra) # 8000508c <argfd>
    return -1;
    800052d2:	57fd                	li	a5,-1
  if(argfd(0, 0, &f) < 0)
    800052d4:	02054363          	bltz	a0,800052fa <sys_dup+0x42>
  if((fd=fdalloc(f)) < 0)
    800052d8:	fd843503          	ld	a0,-40(s0)
    800052dc:	00000097          	auipc	ra,0x0
    800052e0:	e10080e7          	jalr	-496(ra) # 800050ec <fdalloc>
    800052e4:	84aa                	mv	s1,a0
    return -1;
    800052e6:	57fd                	li	a5,-1
  if((fd=fdalloc(f)) < 0)
    800052e8:	00054963          	bltz	a0,800052fa <sys_dup+0x42>
  filedup(f);
    800052ec:	fd843503          	ld	a0,-40(s0)
    800052f0:	fffff097          	auipc	ra,0xfffff
    800052f4:	2ee080e7          	jalr	750(ra) # 800045de <filedup>
  return fd;
    800052f8:	87a6                	mv	a5,s1
}
    800052fa:	853e                	mv	a0,a5
    800052fc:	70a2                	ld	ra,40(sp)
    800052fe:	7402                	ld	s0,32(sp)
    80005300:	64e2                	ld	s1,24(sp)
    80005302:	6145                	addi	sp,sp,48
    80005304:	8082                	ret

0000000080005306 <sys_read>:
{
    80005306:	7179                	addi	sp,sp,-48
    80005308:	f406                	sd	ra,40(sp)
    8000530a:	f022                	sd	s0,32(sp)
    8000530c:	1800                	addi	s0,sp,48
  argaddr(1, &p);
    8000530e:	fd840593          	addi	a1,s0,-40
    80005312:	4505                	li	a0,1
    80005314:	ffffe097          	auipc	ra,0xffffe
    80005318:	88c080e7          	jalr	-1908(ra) # 80002ba0 <argaddr>
  argint(2, &n);
    8000531c:	fe440593          	addi	a1,s0,-28
    80005320:	4509                	li	a0,2
    80005322:	ffffe097          	auipc	ra,0xffffe
    80005326:	85e080e7          	jalr	-1954(ra) # 80002b80 <argint>
  if(argfd(0, 0, &f) < 0)
    8000532a:	fe840613          	addi	a2,s0,-24
    8000532e:	4581                	li	a1,0
    80005330:	4501                	li	a0,0
    80005332:	00000097          	auipc	ra,0x0
    80005336:	d5a080e7          	jalr	-678(ra) # 8000508c <argfd>
    8000533a:	87aa                	mv	a5,a0
    return -1;
    8000533c:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    8000533e:	0007cc63          	bltz	a5,80005356 <sys_read+0x50>
  return fileread(f, p, n);
    80005342:	fe442603          	lw	a2,-28(s0)
    80005346:	fd843583          	ld	a1,-40(s0)
    8000534a:	fe843503          	ld	a0,-24(s0)
    8000534e:	fffff097          	auipc	ra,0xfffff
    80005352:	41c080e7          	jalr	1052(ra) # 8000476a <fileread>
}
    80005356:	70a2                	ld	ra,40(sp)
    80005358:	7402                	ld	s0,32(sp)
    8000535a:	6145                	addi	sp,sp,48
    8000535c:	8082                	ret

000000008000535e <sys_write>:
{
    8000535e:	7179                	addi	sp,sp,-48
    80005360:	f406                	sd	ra,40(sp)
    80005362:	f022                	sd	s0,32(sp)
    80005364:	1800                	addi	s0,sp,48
  argaddr(1, &p);
    80005366:	fd840593          	addi	a1,s0,-40
    8000536a:	4505                	li	a0,1
    8000536c:	ffffe097          	auipc	ra,0xffffe
    80005370:	834080e7          	jalr	-1996(ra) # 80002ba0 <argaddr>
  argint(2, &n);
    80005374:	fe440593          	addi	a1,s0,-28
    80005378:	4509                	li	a0,2
    8000537a:	ffffe097          	auipc	ra,0xffffe
    8000537e:	806080e7          	jalr	-2042(ra) # 80002b80 <argint>
  if(argfd(0, 0, &f) < 0)
    80005382:	fe840613          	addi	a2,s0,-24
    80005386:	4581                	li	a1,0
    80005388:	4501                	li	a0,0
    8000538a:	00000097          	auipc	ra,0x0
    8000538e:	d02080e7          	jalr	-766(ra) # 8000508c <argfd>
    80005392:	87aa                	mv	a5,a0
    return -1;
    80005394:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    80005396:	0007cc63          	bltz	a5,800053ae <sys_write+0x50>
  return filewrite(f, p, n);
    8000539a:	fe442603          	lw	a2,-28(s0)
    8000539e:	fd843583          	ld	a1,-40(s0)
    800053a2:	fe843503          	ld	a0,-24(s0)
    800053a6:	fffff097          	auipc	ra,0xfffff
    800053aa:	486080e7          	jalr	1158(ra) # 8000482c <filewrite>
}
    800053ae:	70a2                	ld	ra,40(sp)
    800053b0:	7402                	ld	s0,32(sp)
    800053b2:	6145                	addi	sp,sp,48
    800053b4:	8082                	ret

00000000800053b6 <sys_close>:
{
    800053b6:	1101                	addi	sp,sp,-32
    800053b8:	ec06                	sd	ra,24(sp)
    800053ba:	e822                	sd	s0,16(sp)
    800053bc:	1000                	addi	s0,sp,32
  if(argfd(0, &fd, &f) < 0)
    800053be:	fe040613          	addi	a2,s0,-32
    800053c2:	fec40593          	addi	a1,s0,-20
    800053c6:	4501                	li	a0,0
    800053c8:	00000097          	auipc	ra,0x0
    800053cc:	cc4080e7          	jalr	-828(ra) # 8000508c <argfd>
    return -1;
    800053d0:	57fd                	li	a5,-1
  if(argfd(0, &fd, &f) < 0)
    800053d2:	02054463          	bltz	a0,800053fa <sys_close+0x44>
  myproc()->ofile[fd] = 0;
    800053d6:	ffffc097          	auipc	ra,0xffffc
    800053da:	60c080e7          	jalr	1548(ra) # 800019e2 <myproc>
    800053de:	fec42783          	lw	a5,-20(s0)
    800053e2:	07e9                	addi	a5,a5,26
    800053e4:	078e                	slli	a5,a5,0x3
    800053e6:	97aa                	add	a5,a5,a0
    800053e8:	0007b023          	sd	zero,0(a5)
  fileclose(f);
    800053ec:	fe043503          	ld	a0,-32(s0)
    800053f0:	fffff097          	auipc	ra,0xfffff
    800053f4:	240080e7          	jalr	576(ra) # 80004630 <fileclose>
  return 0;
    800053f8:	4781                	li	a5,0
}
    800053fa:	853e                	mv	a0,a5
    800053fc:	60e2                	ld	ra,24(sp)
    800053fe:	6442                	ld	s0,16(sp)
    80005400:	6105                	addi	sp,sp,32
    80005402:	8082                	ret

0000000080005404 <sys_fstat>:
{
    80005404:	1101                	addi	sp,sp,-32
    80005406:	ec06                	sd	ra,24(sp)
    80005408:	e822                	sd	s0,16(sp)
    8000540a:	1000                	addi	s0,sp,32
  argaddr(1, &st);
    8000540c:	fe040593          	addi	a1,s0,-32
    80005410:	4505                	li	a0,1
    80005412:	ffffd097          	auipc	ra,0xffffd
    80005416:	78e080e7          	jalr	1934(ra) # 80002ba0 <argaddr>
  if(argfd(0, 0, &f) < 0)
    8000541a:	fe840613          	addi	a2,s0,-24
    8000541e:	4581                	li	a1,0
    80005420:	4501                	li	a0,0
    80005422:	00000097          	auipc	ra,0x0
    80005426:	c6a080e7          	jalr	-918(ra) # 8000508c <argfd>
    8000542a:	87aa                	mv	a5,a0
    return -1;
    8000542c:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    8000542e:	0007ca63          	bltz	a5,80005442 <sys_fstat+0x3e>
  return filestat(f, st);
    80005432:	fe043583          	ld	a1,-32(s0)
    80005436:	fe843503          	ld	a0,-24(s0)
    8000543a:	fffff097          	auipc	ra,0xfffff
    8000543e:	2be080e7          	jalr	702(ra) # 800046f8 <filestat>
}
    80005442:	60e2                	ld	ra,24(sp)
    80005444:	6442                	ld	s0,16(sp)
    80005446:	6105                	addi	sp,sp,32
    80005448:	8082                	ret

000000008000544a <sys_link>:
{
    8000544a:	7169                	addi	sp,sp,-304
    8000544c:	f606                	sd	ra,296(sp)
    8000544e:	f222                	sd	s0,288(sp)
    80005450:	ee26                	sd	s1,280(sp)
    80005452:	ea4a                	sd	s2,272(sp)
    80005454:	1a00                	addi	s0,sp,304
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    80005456:	08000613          	li	a2,128
    8000545a:	ed040593          	addi	a1,s0,-304
    8000545e:	4501                	li	a0,0
    80005460:	ffffd097          	auipc	ra,0xffffd
    80005464:	760080e7          	jalr	1888(ra) # 80002bc0 <argstr>
    return -1;
    80005468:	57fd                	li	a5,-1
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    8000546a:	10054e63          	bltz	a0,80005586 <sys_link+0x13c>
    8000546e:	08000613          	li	a2,128
    80005472:	f5040593          	addi	a1,s0,-176
    80005476:	4505                	li	a0,1
    80005478:	ffffd097          	auipc	ra,0xffffd
    8000547c:	748080e7          	jalr	1864(ra) # 80002bc0 <argstr>
    return -1;
    80005480:	57fd                	li	a5,-1
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    80005482:	10054263          	bltz	a0,80005586 <sys_link+0x13c>
  begin_op();
    80005486:	fffff097          	auipc	ra,0xfffff
    8000548a:	cde080e7          	jalr	-802(ra) # 80004164 <begin_op>
  if((ip = namei(old)) == 0){
    8000548e:	ed040513          	addi	a0,s0,-304
    80005492:	fffff097          	auipc	ra,0xfffff
    80005496:	ab6080e7          	jalr	-1354(ra) # 80003f48 <namei>
    8000549a:	84aa                	mv	s1,a0
    8000549c:	c551                	beqz	a0,80005528 <sys_link+0xde>
  ilock(ip);
    8000549e:	ffffe097          	auipc	ra,0xffffe
    800054a2:	304080e7          	jalr	772(ra) # 800037a2 <ilock>
  if(ip->type == T_DIR){
    800054a6:	04449703          	lh	a4,68(s1)
    800054aa:	4785                	li	a5,1
    800054ac:	08f70463          	beq	a4,a5,80005534 <sys_link+0xea>
  ip->nlink++;
    800054b0:	04a4d783          	lhu	a5,74(s1)
    800054b4:	2785                	addiw	a5,a5,1
    800054b6:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    800054ba:	8526                	mv	a0,s1
    800054bc:	ffffe097          	auipc	ra,0xffffe
    800054c0:	21c080e7          	jalr	540(ra) # 800036d8 <iupdate>
  iunlock(ip);
    800054c4:	8526                	mv	a0,s1
    800054c6:	ffffe097          	auipc	ra,0xffffe
    800054ca:	39e080e7          	jalr	926(ra) # 80003864 <iunlock>
  if((dp = nameiparent(new, name)) == 0)
    800054ce:	fd040593          	addi	a1,s0,-48
    800054d2:	f5040513          	addi	a0,s0,-176
    800054d6:	fffff097          	auipc	ra,0xfffff
    800054da:	a90080e7          	jalr	-1392(ra) # 80003f66 <nameiparent>
    800054de:	892a                	mv	s2,a0
    800054e0:	c935                	beqz	a0,80005554 <sys_link+0x10a>
  ilock(dp);
    800054e2:	ffffe097          	auipc	ra,0xffffe
    800054e6:	2c0080e7          	jalr	704(ra) # 800037a2 <ilock>
  if(dp->dev != ip->dev || dirlink(dp, name, ip->inum) < 0){
    800054ea:	00092703          	lw	a4,0(s2)
    800054ee:	409c                	lw	a5,0(s1)
    800054f0:	04f71d63          	bne	a4,a5,8000554a <sys_link+0x100>
    800054f4:	40d0                	lw	a2,4(s1)
    800054f6:	fd040593          	addi	a1,s0,-48
    800054fa:	854a                	mv	a0,s2
    800054fc:	fffff097          	auipc	ra,0xfffff
    80005500:	99a080e7          	jalr	-1638(ra) # 80003e96 <dirlink>
    80005504:	04054363          	bltz	a0,8000554a <sys_link+0x100>
  iunlockput(dp);
    80005508:	854a                	mv	a0,s2
    8000550a:	ffffe097          	auipc	ra,0xffffe
    8000550e:	4fa080e7          	jalr	1274(ra) # 80003a04 <iunlockput>
  iput(ip);
    80005512:	8526                	mv	a0,s1
    80005514:	ffffe097          	auipc	ra,0xffffe
    80005518:	448080e7          	jalr	1096(ra) # 8000395c <iput>
  end_op();
    8000551c:	fffff097          	auipc	ra,0xfffff
    80005520:	cc8080e7          	jalr	-824(ra) # 800041e4 <end_op>
  return 0;
    80005524:	4781                	li	a5,0
    80005526:	a085                	j	80005586 <sys_link+0x13c>
    end_op();
    80005528:	fffff097          	auipc	ra,0xfffff
    8000552c:	cbc080e7          	jalr	-836(ra) # 800041e4 <end_op>
    return -1;
    80005530:	57fd                	li	a5,-1
    80005532:	a891                	j	80005586 <sys_link+0x13c>
    iunlockput(ip);
    80005534:	8526                	mv	a0,s1
    80005536:	ffffe097          	auipc	ra,0xffffe
    8000553a:	4ce080e7          	jalr	1230(ra) # 80003a04 <iunlockput>
    end_op();
    8000553e:	fffff097          	auipc	ra,0xfffff
    80005542:	ca6080e7          	jalr	-858(ra) # 800041e4 <end_op>
    return -1;
    80005546:	57fd                	li	a5,-1
    80005548:	a83d                	j	80005586 <sys_link+0x13c>
    iunlockput(dp);
    8000554a:	854a                	mv	a0,s2
    8000554c:	ffffe097          	auipc	ra,0xffffe
    80005550:	4b8080e7          	jalr	1208(ra) # 80003a04 <iunlockput>
  ilock(ip);
    80005554:	8526                	mv	a0,s1
    80005556:	ffffe097          	auipc	ra,0xffffe
    8000555a:	24c080e7          	jalr	588(ra) # 800037a2 <ilock>
  ip->nlink--;
    8000555e:	04a4d783          	lhu	a5,74(s1)
    80005562:	37fd                	addiw	a5,a5,-1
    80005564:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    80005568:	8526                	mv	a0,s1
    8000556a:	ffffe097          	auipc	ra,0xffffe
    8000556e:	16e080e7          	jalr	366(ra) # 800036d8 <iupdate>
  iunlockput(ip);
    80005572:	8526                	mv	a0,s1
    80005574:	ffffe097          	auipc	ra,0xffffe
    80005578:	490080e7          	jalr	1168(ra) # 80003a04 <iunlockput>
  end_op();
    8000557c:	fffff097          	auipc	ra,0xfffff
    80005580:	c68080e7          	jalr	-920(ra) # 800041e4 <end_op>
  return -1;
    80005584:	57fd                	li	a5,-1
}
    80005586:	853e                	mv	a0,a5
    80005588:	70b2                	ld	ra,296(sp)
    8000558a:	7412                	ld	s0,288(sp)
    8000558c:	64f2                	ld	s1,280(sp)
    8000558e:	6952                	ld	s2,272(sp)
    80005590:	6155                	addi	sp,sp,304
    80005592:	8082                	ret

0000000080005594 <sys_unlink>:
{
    80005594:	7151                	addi	sp,sp,-240
    80005596:	f586                	sd	ra,232(sp)
    80005598:	f1a2                	sd	s0,224(sp)
    8000559a:	eda6                	sd	s1,216(sp)
    8000559c:	e9ca                	sd	s2,208(sp)
    8000559e:	e5ce                	sd	s3,200(sp)
    800055a0:	1980                	addi	s0,sp,240
  if(argstr(0, path, MAXPATH) < 0)
    800055a2:	08000613          	li	a2,128
    800055a6:	f3040593          	addi	a1,s0,-208
    800055aa:	4501                	li	a0,0
    800055ac:	ffffd097          	auipc	ra,0xffffd
    800055b0:	614080e7          	jalr	1556(ra) # 80002bc0 <argstr>
    800055b4:	18054163          	bltz	a0,80005736 <sys_unlink+0x1a2>
  begin_op();
    800055b8:	fffff097          	auipc	ra,0xfffff
    800055bc:	bac080e7          	jalr	-1108(ra) # 80004164 <begin_op>
  if((dp = nameiparent(path, name)) == 0){
    800055c0:	fb040593          	addi	a1,s0,-80
    800055c4:	f3040513          	addi	a0,s0,-208
    800055c8:	fffff097          	auipc	ra,0xfffff
    800055cc:	99e080e7          	jalr	-1634(ra) # 80003f66 <nameiparent>
    800055d0:	84aa                	mv	s1,a0
    800055d2:	c979                	beqz	a0,800056a8 <sys_unlink+0x114>
  ilock(dp);
    800055d4:	ffffe097          	auipc	ra,0xffffe
    800055d8:	1ce080e7          	jalr	462(ra) # 800037a2 <ilock>
  if(namecmp(name, ".") == 0 || namecmp(name, "..") == 0)
    800055dc:	00003597          	auipc	a1,0x3
    800055e0:	14458593          	addi	a1,a1,324 # 80008720 <syscalls+0x2b0>
    800055e4:	fb040513          	addi	a0,s0,-80
    800055e8:	ffffe097          	auipc	ra,0xffffe
    800055ec:	684080e7          	jalr	1668(ra) # 80003c6c <namecmp>
    800055f0:	14050a63          	beqz	a0,80005744 <sys_unlink+0x1b0>
    800055f4:	00003597          	auipc	a1,0x3
    800055f8:	13458593          	addi	a1,a1,308 # 80008728 <syscalls+0x2b8>
    800055fc:	fb040513          	addi	a0,s0,-80
    80005600:	ffffe097          	auipc	ra,0xffffe
    80005604:	66c080e7          	jalr	1644(ra) # 80003c6c <namecmp>
    80005608:	12050e63          	beqz	a0,80005744 <sys_unlink+0x1b0>
  if((ip = dirlookup(dp, name, &off)) == 0)
    8000560c:	f2c40613          	addi	a2,s0,-212
    80005610:	fb040593          	addi	a1,s0,-80
    80005614:	8526                	mv	a0,s1
    80005616:	ffffe097          	auipc	ra,0xffffe
    8000561a:	670080e7          	jalr	1648(ra) # 80003c86 <dirlookup>
    8000561e:	892a                	mv	s2,a0
    80005620:	12050263          	beqz	a0,80005744 <sys_unlink+0x1b0>
  ilock(ip);
    80005624:	ffffe097          	auipc	ra,0xffffe
    80005628:	17e080e7          	jalr	382(ra) # 800037a2 <ilock>
  if(ip->nlink < 1)
    8000562c:	04a91783          	lh	a5,74(s2)
    80005630:	08f05263          	blez	a5,800056b4 <sys_unlink+0x120>
  if(ip->type == T_DIR && !isdirempty(ip)){
    80005634:	04491703          	lh	a4,68(s2)
    80005638:	4785                	li	a5,1
    8000563a:	08f70563          	beq	a4,a5,800056c4 <sys_unlink+0x130>
  memset(&de, 0, sizeof(de));
    8000563e:	4641                	li	a2,16
    80005640:	4581                	li	a1,0
    80005642:	fc040513          	addi	a0,s0,-64
    80005646:	ffffb097          	auipc	ra,0xffffb
    8000564a:	68c080e7          	jalr	1676(ra) # 80000cd2 <memset>
  if(writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    8000564e:	4741                	li	a4,16
    80005650:	f2c42683          	lw	a3,-212(s0)
    80005654:	fc040613          	addi	a2,s0,-64
    80005658:	4581                	li	a1,0
    8000565a:	8526                	mv	a0,s1
    8000565c:	ffffe097          	auipc	ra,0xffffe
    80005660:	4f2080e7          	jalr	1266(ra) # 80003b4e <writei>
    80005664:	47c1                	li	a5,16
    80005666:	0af51563          	bne	a0,a5,80005710 <sys_unlink+0x17c>
  if(ip->type == T_DIR){
    8000566a:	04491703          	lh	a4,68(s2)
    8000566e:	4785                	li	a5,1
    80005670:	0af70863          	beq	a4,a5,80005720 <sys_unlink+0x18c>
  iunlockput(dp);
    80005674:	8526                	mv	a0,s1
    80005676:	ffffe097          	auipc	ra,0xffffe
    8000567a:	38e080e7          	jalr	910(ra) # 80003a04 <iunlockput>
  ip->nlink--;
    8000567e:	04a95783          	lhu	a5,74(s2)
    80005682:	37fd                	addiw	a5,a5,-1
    80005684:	04f91523          	sh	a5,74(s2)
  iupdate(ip);
    80005688:	854a                	mv	a0,s2
    8000568a:	ffffe097          	auipc	ra,0xffffe
    8000568e:	04e080e7          	jalr	78(ra) # 800036d8 <iupdate>
  iunlockput(ip);
    80005692:	854a                	mv	a0,s2
    80005694:	ffffe097          	auipc	ra,0xffffe
    80005698:	370080e7          	jalr	880(ra) # 80003a04 <iunlockput>
  end_op();
    8000569c:	fffff097          	auipc	ra,0xfffff
    800056a0:	b48080e7          	jalr	-1208(ra) # 800041e4 <end_op>
  return 0;
    800056a4:	4501                	li	a0,0
    800056a6:	a84d                	j	80005758 <sys_unlink+0x1c4>
    end_op();
    800056a8:	fffff097          	auipc	ra,0xfffff
    800056ac:	b3c080e7          	jalr	-1220(ra) # 800041e4 <end_op>
    return -1;
    800056b0:	557d                	li	a0,-1
    800056b2:	a05d                	j	80005758 <sys_unlink+0x1c4>
    panic("unlink: nlink < 1");
    800056b4:	00003517          	auipc	a0,0x3
    800056b8:	07c50513          	addi	a0,a0,124 # 80008730 <syscalls+0x2c0>
    800056bc:	ffffb097          	auipc	ra,0xffffb
    800056c0:	e82080e7          	jalr	-382(ra) # 8000053e <panic>
  for(off=2*sizeof(de); off<dp->size; off+=sizeof(de)){
    800056c4:	04c92703          	lw	a4,76(s2)
    800056c8:	02000793          	li	a5,32
    800056cc:	f6e7f9e3          	bgeu	a5,a4,8000563e <sys_unlink+0xaa>
    800056d0:	02000993          	li	s3,32
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    800056d4:	4741                	li	a4,16
    800056d6:	86ce                	mv	a3,s3
    800056d8:	f1840613          	addi	a2,s0,-232
    800056dc:	4581                	li	a1,0
    800056de:	854a                	mv	a0,s2
    800056e0:	ffffe097          	auipc	ra,0xffffe
    800056e4:	376080e7          	jalr	886(ra) # 80003a56 <readi>
    800056e8:	47c1                	li	a5,16
    800056ea:	00f51b63          	bne	a0,a5,80005700 <sys_unlink+0x16c>
    if(de.inum != 0)
    800056ee:	f1845783          	lhu	a5,-232(s0)
    800056f2:	e7a1                	bnez	a5,8000573a <sys_unlink+0x1a6>
  for(off=2*sizeof(de); off<dp->size; off+=sizeof(de)){
    800056f4:	29c1                	addiw	s3,s3,16
    800056f6:	04c92783          	lw	a5,76(s2)
    800056fa:	fcf9ede3          	bltu	s3,a5,800056d4 <sys_unlink+0x140>
    800056fe:	b781                	j	8000563e <sys_unlink+0xaa>
      panic("isdirempty: readi");
    80005700:	00003517          	auipc	a0,0x3
    80005704:	04850513          	addi	a0,a0,72 # 80008748 <syscalls+0x2d8>
    80005708:	ffffb097          	auipc	ra,0xffffb
    8000570c:	e36080e7          	jalr	-458(ra) # 8000053e <panic>
    panic("unlink: writei");
    80005710:	00003517          	auipc	a0,0x3
    80005714:	05050513          	addi	a0,a0,80 # 80008760 <syscalls+0x2f0>
    80005718:	ffffb097          	auipc	ra,0xffffb
    8000571c:	e26080e7          	jalr	-474(ra) # 8000053e <panic>
    dp->nlink--;
    80005720:	04a4d783          	lhu	a5,74(s1)
    80005724:	37fd                	addiw	a5,a5,-1
    80005726:	04f49523          	sh	a5,74(s1)
    iupdate(dp);
    8000572a:	8526                	mv	a0,s1
    8000572c:	ffffe097          	auipc	ra,0xffffe
    80005730:	fac080e7          	jalr	-84(ra) # 800036d8 <iupdate>
    80005734:	b781                	j	80005674 <sys_unlink+0xe0>
    return -1;
    80005736:	557d                	li	a0,-1
    80005738:	a005                	j	80005758 <sys_unlink+0x1c4>
    iunlockput(ip);
    8000573a:	854a                	mv	a0,s2
    8000573c:	ffffe097          	auipc	ra,0xffffe
    80005740:	2c8080e7          	jalr	712(ra) # 80003a04 <iunlockput>
  iunlockput(dp);
    80005744:	8526                	mv	a0,s1
    80005746:	ffffe097          	auipc	ra,0xffffe
    8000574a:	2be080e7          	jalr	702(ra) # 80003a04 <iunlockput>
  end_op();
    8000574e:	fffff097          	auipc	ra,0xfffff
    80005752:	a96080e7          	jalr	-1386(ra) # 800041e4 <end_op>
  return -1;
    80005756:	557d                	li	a0,-1
}
    80005758:	70ae                	ld	ra,232(sp)
    8000575a:	740e                	ld	s0,224(sp)
    8000575c:	64ee                	ld	s1,216(sp)
    8000575e:	694e                	ld	s2,208(sp)
    80005760:	69ae                	ld	s3,200(sp)
    80005762:	616d                	addi	sp,sp,240
    80005764:	8082                	ret

0000000080005766 <sys_open>:

uint64
sys_open(void)
{
    80005766:	7131                	addi	sp,sp,-192
    80005768:	fd06                	sd	ra,184(sp)
    8000576a:	f922                	sd	s0,176(sp)
    8000576c:	f526                	sd	s1,168(sp)
    8000576e:	f14a                	sd	s2,160(sp)
    80005770:	ed4e                	sd	s3,152(sp)
    80005772:	0180                	addi	s0,sp,192
  int fd, omode;
  struct file *f;
  struct inode *ip;
  int n;

  argint(1, &omode);
    80005774:	f4c40593          	addi	a1,s0,-180
    80005778:	4505                	li	a0,1
    8000577a:	ffffd097          	auipc	ra,0xffffd
    8000577e:	406080e7          	jalr	1030(ra) # 80002b80 <argint>
  if((n = argstr(0, path, MAXPATH)) < 0)
    80005782:	08000613          	li	a2,128
    80005786:	f5040593          	addi	a1,s0,-176
    8000578a:	4501                	li	a0,0
    8000578c:	ffffd097          	auipc	ra,0xffffd
    80005790:	434080e7          	jalr	1076(ra) # 80002bc0 <argstr>
    80005794:	87aa                	mv	a5,a0
    return -1;
    80005796:	557d                	li	a0,-1
  if((n = argstr(0, path, MAXPATH)) < 0)
    80005798:	0a07c963          	bltz	a5,8000584a <sys_open+0xe4>

  begin_op();
    8000579c:	fffff097          	auipc	ra,0xfffff
    800057a0:	9c8080e7          	jalr	-1592(ra) # 80004164 <begin_op>

  if(omode & O_CREATE){
    800057a4:	f4c42783          	lw	a5,-180(s0)
    800057a8:	2007f793          	andi	a5,a5,512
    800057ac:	cfc5                	beqz	a5,80005864 <sys_open+0xfe>
    ip = create(path, T_FILE, 0, 0);
    800057ae:	4681                	li	a3,0
    800057b0:	4601                	li	a2,0
    800057b2:	4589                	li	a1,2
    800057b4:	f5040513          	addi	a0,s0,-176
    800057b8:	00000097          	auipc	ra,0x0
    800057bc:	976080e7          	jalr	-1674(ra) # 8000512e <create>
    800057c0:	84aa                	mv	s1,a0
    if(ip == 0){
    800057c2:	c959                	beqz	a0,80005858 <sys_open+0xf2>
      end_op();
      return -1;
    }
  }

  if(ip->type == T_DEVICE && (ip->major < 0 || ip->major >= NDEV)){
    800057c4:	04449703          	lh	a4,68(s1)
    800057c8:	478d                	li	a5,3
    800057ca:	00f71763          	bne	a4,a5,800057d8 <sys_open+0x72>
    800057ce:	0464d703          	lhu	a4,70(s1)
    800057d2:	47a5                	li	a5,9
    800057d4:	0ce7ed63          	bltu	a5,a4,800058ae <sys_open+0x148>
    iunlockput(ip);
    end_op();
    return -1;
  }

  if((f = filealloc()) == 0 || (fd = fdalloc(f)) < 0){
    800057d8:	fffff097          	auipc	ra,0xfffff
    800057dc:	d9c080e7          	jalr	-612(ra) # 80004574 <filealloc>
    800057e0:	89aa                	mv	s3,a0
    800057e2:	10050363          	beqz	a0,800058e8 <sys_open+0x182>
    800057e6:	00000097          	auipc	ra,0x0
    800057ea:	906080e7          	jalr	-1786(ra) # 800050ec <fdalloc>
    800057ee:	892a                	mv	s2,a0
    800057f0:	0e054763          	bltz	a0,800058de <sys_open+0x178>
    iunlockput(ip);
    end_op();
    return -1;
  }

  if(ip->type == T_DEVICE){
    800057f4:	04449703          	lh	a4,68(s1)
    800057f8:	478d                	li	a5,3
    800057fa:	0cf70563          	beq	a4,a5,800058c4 <sys_open+0x15e>
    f->type = FD_DEVICE;
    f->major = ip->major;
  } else {
    f->type = FD_INODE;
    800057fe:	4789                	li	a5,2
    80005800:	00f9a023          	sw	a5,0(s3)
    f->off = 0;
    80005804:	0209a023          	sw	zero,32(s3)
  }
  f->ip = ip;
    80005808:	0099bc23          	sd	s1,24(s3)
  f->readable = !(omode & O_WRONLY);
    8000580c:	f4c42783          	lw	a5,-180(s0)
    80005810:	0017c713          	xori	a4,a5,1
    80005814:	8b05                	andi	a4,a4,1
    80005816:	00e98423          	sb	a4,8(s3)
  f->writable = (omode & O_WRONLY) || (omode & O_RDWR);
    8000581a:	0037f713          	andi	a4,a5,3
    8000581e:	00e03733          	snez	a4,a4
    80005822:	00e984a3          	sb	a4,9(s3)

  if((omode & O_TRUNC) && ip->type == T_FILE){
    80005826:	4007f793          	andi	a5,a5,1024
    8000582a:	c791                	beqz	a5,80005836 <sys_open+0xd0>
    8000582c:	04449703          	lh	a4,68(s1)
    80005830:	4789                	li	a5,2
    80005832:	0af70063          	beq	a4,a5,800058d2 <sys_open+0x16c>
    itrunc(ip);
  }

  iunlock(ip);
    80005836:	8526                	mv	a0,s1
    80005838:	ffffe097          	auipc	ra,0xffffe
    8000583c:	02c080e7          	jalr	44(ra) # 80003864 <iunlock>
  end_op();
    80005840:	fffff097          	auipc	ra,0xfffff
    80005844:	9a4080e7          	jalr	-1628(ra) # 800041e4 <end_op>

  return fd;
    80005848:	854a                	mv	a0,s2
}
    8000584a:	70ea                	ld	ra,184(sp)
    8000584c:	744a                	ld	s0,176(sp)
    8000584e:	74aa                	ld	s1,168(sp)
    80005850:	790a                	ld	s2,160(sp)
    80005852:	69ea                	ld	s3,152(sp)
    80005854:	6129                	addi	sp,sp,192
    80005856:	8082                	ret
      end_op();
    80005858:	fffff097          	auipc	ra,0xfffff
    8000585c:	98c080e7          	jalr	-1652(ra) # 800041e4 <end_op>
      return -1;
    80005860:	557d                	li	a0,-1
    80005862:	b7e5                	j	8000584a <sys_open+0xe4>
    if((ip = namei(path)) == 0){
    80005864:	f5040513          	addi	a0,s0,-176
    80005868:	ffffe097          	auipc	ra,0xffffe
    8000586c:	6e0080e7          	jalr	1760(ra) # 80003f48 <namei>
    80005870:	84aa                	mv	s1,a0
    80005872:	c905                	beqz	a0,800058a2 <sys_open+0x13c>
    ilock(ip);
    80005874:	ffffe097          	auipc	ra,0xffffe
    80005878:	f2e080e7          	jalr	-210(ra) # 800037a2 <ilock>
    if(ip->type == T_DIR && omode != O_RDONLY){
    8000587c:	04449703          	lh	a4,68(s1)
    80005880:	4785                	li	a5,1
    80005882:	f4f711e3          	bne	a4,a5,800057c4 <sys_open+0x5e>
    80005886:	f4c42783          	lw	a5,-180(s0)
    8000588a:	d7b9                	beqz	a5,800057d8 <sys_open+0x72>
      iunlockput(ip);
    8000588c:	8526                	mv	a0,s1
    8000588e:	ffffe097          	auipc	ra,0xffffe
    80005892:	176080e7          	jalr	374(ra) # 80003a04 <iunlockput>
      end_op();
    80005896:	fffff097          	auipc	ra,0xfffff
    8000589a:	94e080e7          	jalr	-1714(ra) # 800041e4 <end_op>
      return -1;
    8000589e:	557d                	li	a0,-1
    800058a0:	b76d                	j	8000584a <sys_open+0xe4>
      end_op();
    800058a2:	fffff097          	auipc	ra,0xfffff
    800058a6:	942080e7          	jalr	-1726(ra) # 800041e4 <end_op>
      return -1;
    800058aa:	557d                	li	a0,-1
    800058ac:	bf79                	j	8000584a <sys_open+0xe4>
    iunlockput(ip);
    800058ae:	8526                	mv	a0,s1
    800058b0:	ffffe097          	auipc	ra,0xffffe
    800058b4:	154080e7          	jalr	340(ra) # 80003a04 <iunlockput>
    end_op();
    800058b8:	fffff097          	auipc	ra,0xfffff
    800058bc:	92c080e7          	jalr	-1748(ra) # 800041e4 <end_op>
    return -1;
    800058c0:	557d                	li	a0,-1
    800058c2:	b761                	j	8000584a <sys_open+0xe4>
    f->type = FD_DEVICE;
    800058c4:	00f9a023          	sw	a5,0(s3)
    f->major = ip->major;
    800058c8:	04649783          	lh	a5,70(s1)
    800058cc:	02f99223          	sh	a5,36(s3)
    800058d0:	bf25                	j	80005808 <sys_open+0xa2>
    itrunc(ip);
    800058d2:	8526                	mv	a0,s1
    800058d4:	ffffe097          	auipc	ra,0xffffe
    800058d8:	fdc080e7          	jalr	-36(ra) # 800038b0 <itrunc>
    800058dc:	bfa9                	j	80005836 <sys_open+0xd0>
      fileclose(f);
    800058de:	854e                	mv	a0,s3
    800058e0:	fffff097          	auipc	ra,0xfffff
    800058e4:	d50080e7          	jalr	-688(ra) # 80004630 <fileclose>
    iunlockput(ip);
    800058e8:	8526                	mv	a0,s1
    800058ea:	ffffe097          	auipc	ra,0xffffe
    800058ee:	11a080e7          	jalr	282(ra) # 80003a04 <iunlockput>
    end_op();
    800058f2:	fffff097          	auipc	ra,0xfffff
    800058f6:	8f2080e7          	jalr	-1806(ra) # 800041e4 <end_op>
    return -1;
    800058fa:	557d                	li	a0,-1
    800058fc:	b7b9                	j	8000584a <sys_open+0xe4>

00000000800058fe <sys_mkdir>:

uint64
sys_mkdir(void)
{
    800058fe:	7175                	addi	sp,sp,-144
    80005900:	e506                	sd	ra,136(sp)
    80005902:	e122                	sd	s0,128(sp)
    80005904:	0900                	addi	s0,sp,144
  char path[MAXPATH];
  struct inode *ip;

  begin_op();
    80005906:	fffff097          	auipc	ra,0xfffff
    8000590a:	85e080e7          	jalr	-1954(ra) # 80004164 <begin_op>
  if(argstr(0, path, MAXPATH) < 0 || (ip = create(path, T_DIR, 0, 0)) == 0){
    8000590e:	08000613          	li	a2,128
    80005912:	f7040593          	addi	a1,s0,-144
    80005916:	4501                	li	a0,0
    80005918:	ffffd097          	auipc	ra,0xffffd
    8000591c:	2a8080e7          	jalr	680(ra) # 80002bc0 <argstr>
    80005920:	02054963          	bltz	a0,80005952 <sys_mkdir+0x54>
    80005924:	4681                	li	a3,0
    80005926:	4601                	li	a2,0
    80005928:	4585                	li	a1,1
    8000592a:	f7040513          	addi	a0,s0,-144
    8000592e:	00000097          	auipc	ra,0x0
    80005932:	800080e7          	jalr	-2048(ra) # 8000512e <create>
    80005936:	cd11                	beqz	a0,80005952 <sys_mkdir+0x54>
    end_op();
    return -1;
  }
  iunlockput(ip);
    80005938:	ffffe097          	auipc	ra,0xffffe
    8000593c:	0cc080e7          	jalr	204(ra) # 80003a04 <iunlockput>
  end_op();
    80005940:	fffff097          	auipc	ra,0xfffff
    80005944:	8a4080e7          	jalr	-1884(ra) # 800041e4 <end_op>
  return 0;
    80005948:	4501                	li	a0,0
}
    8000594a:	60aa                	ld	ra,136(sp)
    8000594c:	640a                	ld	s0,128(sp)
    8000594e:	6149                	addi	sp,sp,144
    80005950:	8082                	ret
    end_op();
    80005952:	fffff097          	auipc	ra,0xfffff
    80005956:	892080e7          	jalr	-1902(ra) # 800041e4 <end_op>
    return -1;
    8000595a:	557d                	li	a0,-1
    8000595c:	b7fd                	j	8000594a <sys_mkdir+0x4c>

000000008000595e <sys_mknod>:

uint64
sys_mknod(void)
{
    8000595e:	7135                	addi	sp,sp,-160
    80005960:	ed06                	sd	ra,152(sp)
    80005962:	e922                	sd	s0,144(sp)
    80005964:	1100                	addi	s0,sp,160
  struct inode *ip;
  char path[MAXPATH];
  int major, minor;

  begin_op();
    80005966:	ffffe097          	auipc	ra,0xffffe
    8000596a:	7fe080e7          	jalr	2046(ra) # 80004164 <begin_op>
  argint(1, &major);
    8000596e:	f6c40593          	addi	a1,s0,-148
    80005972:	4505                	li	a0,1
    80005974:	ffffd097          	auipc	ra,0xffffd
    80005978:	20c080e7          	jalr	524(ra) # 80002b80 <argint>
  argint(2, &minor);
    8000597c:	f6840593          	addi	a1,s0,-152
    80005980:	4509                	li	a0,2
    80005982:	ffffd097          	auipc	ra,0xffffd
    80005986:	1fe080e7          	jalr	510(ra) # 80002b80 <argint>
  if((argstr(0, path, MAXPATH)) < 0 ||
    8000598a:	08000613          	li	a2,128
    8000598e:	f7040593          	addi	a1,s0,-144
    80005992:	4501                	li	a0,0
    80005994:	ffffd097          	auipc	ra,0xffffd
    80005998:	22c080e7          	jalr	556(ra) # 80002bc0 <argstr>
    8000599c:	02054b63          	bltz	a0,800059d2 <sys_mknod+0x74>
     (ip = create(path, T_DEVICE, major, minor)) == 0){
    800059a0:	f6841683          	lh	a3,-152(s0)
    800059a4:	f6c41603          	lh	a2,-148(s0)
    800059a8:	458d                	li	a1,3
    800059aa:	f7040513          	addi	a0,s0,-144
    800059ae:	fffff097          	auipc	ra,0xfffff
    800059b2:	780080e7          	jalr	1920(ra) # 8000512e <create>
  if((argstr(0, path, MAXPATH)) < 0 ||
    800059b6:	cd11                	beqz	a0,800059d2 <sys_mknod+0x74>
    end_op();
    return -1;
  }
  iunlockput(ip);
    800059b8:	ffffe097          	auipc	ra,0xffffe
    800059bc:	04c080e7          	jalr	76(ra) # 80003a04 <iunlockput>
  end_op();
    800059c0:	fffff097          	auipc	ra,0xfffff
    800059c4:	824080e7          	jalr	-2012(ra) # 800041e4 <end_op>
  return 0;
    800059c8:	4501                	li	a0,0
}
    800059ca:	60ea                	ld	ra,152(sp)
    800059cc:	644a                	ld	s0,144(sp)
    800059ce:	610d                	addi	sp,sp,160
    800059d0:	8082                	ret
    end_op();
    800059d2:	fffff097          	auipc	ra,0xfffff
    800059d6:	812080e7          	jalr	-2030(ra) # 800041e4 <end_op>
    return -1;
    800059da:	557d                	li	a0,-1
    800059dc:	b7fd                	j	800059ca <sys_mknod+0x6c>

00000000800059de <sys_chdir>:

uint64
sys_chdir(void)
{
    800059de:	7135                	addi	sp,sp,-160
    800059e0:	ed06                	sd	ra,152(sp)
    800059e2:	e922                	sd	s0,144(sp)
    800059e4:	e526                	sd	s1,136(sp)
    800059e6:	e14a                	sd	s2,128(sp)
    800059e8:	1100                	addi	s0,sp,160
  char path[MAXPATH];
  struct inode *ip;
  struct proc *p = myproc();
    800059ea:	ffffc097          	auipc	ra,0xffffc
    800059ee:	ff8080e7          	jalr	-8(ra) # 800019e2 <myproc>
    800059f2:	892a                	mv	s2,a0
  
  begin_op();
    800059f4:	ffffe097          	auipc	ra,0xffffe
    800059f8:	770080e7          	jalr	1904(ra) # 80004164 <begin_op>
  if(argstr(0, path, MAXPATH) < 0 || (ip = namei(path)) == 0){
    800059fc:	08000613          	li	a2,128
    80005a00:	f6040593          	addi	a1,s0,-160
    80005a04:	4501                	li	a0,0
    80005a06:	ffffd097          	auipc	ra,0xffffd
    80005a0a:	1ba080e7          	jalr	442(ra) # 80002bc0 <argstr>
    80005a0e:	04054b63          	bltz	a0,80005a64 <sys_chdir+0x86>
    80005a12:	f6040513          	addi	a0,s0,-160
    80005a16:	ffffe097          	auipc	ra,0xffffe
    80005a1a:	532080e7          	jalr	1330(ra) # 80003f48 <namei>
    80005a1e:	84aa                	mv	s1,a0
    80005a20:	c131                	beqz	a0,80005a64 <sys_chdir+0x86>
    end_op();
    return -1;
  }
  ilock(ip);
    80005a22:	ffffe097          	auipc	ra,0xffffe
    80005a26:	d80080e7          	jalr	-640(ra) # 800037a2 <ilock>
  if(ip->type != T_DIR){
    80005a2a:	04449703          	lh	a4,68(s1)
    80005a2e:	4785                	li	a5,1
    80005a30:	04f71063          	bne	a4,a5,80005a70 <sys_chdir+0x92>
    iunlockput(ip);
    end_op();
    return -1;
  }
  iunlock(ip);
    80005a34:	8526                	mv	a0,s1
    80005a36:	ffffe097          	auipc	ra,0xffffe
    80005a3a:	e2e080e7          	jalr	-466(ra) # 80003864 <iunlock>
  iput(p->cwd);
    80005a3e:	15093503          	ld	a0,336(s2)
    80005a42:	ffffe097          	auipc	ra,0xffffe
    80005a46:	f1a080e7          	jalr	-230(ra) # 8000395c <iput>
  end_op();
    80005a4a:	ffffe097          	auipc	ra,0xffffe
    80005a4e:	79a080e7          	jalr	1946(ra) # 800041e4 <end_op>
  p->cwd = ip;
    80005a52:	14993823          	sd	s1,336(s2)
  return 0;
    80005a56:	4501                	li	a0,0
}
    80005a58:	60ea                	ld	ra,152(sp)
    80005a5a:	644a                	ld	s0,144(sp)
    80005a5c:	64aa                	ld	s1,136(sp)
    80005a5e:	690a                	ld	s2,128(sp)
    80005a60:	610d                	addi	sp,sp,160
    80005a62:	8082                	ret
    end_op();
    80005a64:	ffffe097          	auipc	ra,0xffffe
    80005a68:	780080e7          	jalr	1920(ra) # 800041e4 <end_op>
    return -1;
    80005a6c:	557d                	li	a0,-1
    80005a6e:	b7ed                	j	80005a58 <sys_chdir+0x7a>
    iunlockput(ip);
    80005a70:	8526                	mv	a0,s1
    80005a72:	ffffe097          	auipc	ra,0xffffe
    80005a76:	f92080e7          	jalr	-110(ra) # 80003a04 <iunlockput>
    end_op();
    80005a7a:	ffffe097          	auipc	ra,0xffffe
    80005a7e:	76a080e7          	jalr	1898(ra) # 800041e4 <end_op>
    return -1;
    80005a82:	557d                	li	a0,-1
    80005a84:	bfd1                	j	80005a58 <sys_chdir+0x7a>

0000000080005a86 <sys_exec>:

uint64
sys_exec(void)
{
    80005a86:	7145                	addi	sp,sp,-464
    80005a88:	e786                	sd	ra,456(sp)
    80005a8a:	e3a2                	sd	s0,448(sp)
    80005a8c:	ff26                	sd	s1,440(sp)
    80005a8e:	fb4a                	sd	s2,432(sp)
    80005a90:	f74e                	sd	s3,424(sp)
    80005a92:	f352                	sd	s4,416(sp)
    80005a94:	ef56                	sd	s5,408(sp)
    80005a96:	0b80                	addi	s0,sp,464
  char path[MAXPATH], *argv[MAXARG];
  int i;
  uint64 uargv, uarg;

  argaddr(1, &uargv);
    80005a98:	e3840593          	addi	a1,s0,-456
    80005a9c:	4505                	li	a0,1
    80005a9e:	ffffd097          	auipc	ra,0xffffd
    80005aa2:	102080e7          	jalr	258(ra) # 80002ba0 <argaddr>
  if(argstr(0, path, MAXPATH) < 0) {
    80005aa6:	08000613          	li	a2,128
    80005aaa:	f4040593          	addi	a1,s0,-192
    80005aae:	4501                	li	a0,0
    80005ab0:	ffffd097          	auipc	ra,0xffffd
    80005ab4:	110080e7          	jalr	272(ra) # 80002bc0 <argstr>
    80005ab8:	87aa                	mv	a5,a0
    return -1;
    80005aba:	557d                	li	a0,-1
  if(argstr(0, path, MAXPATH) < 0) {
    80005abc:	0c07c263          	bltz	a5,80005b80 <sys_exec+0xfa>
  }
  memset(argv, 0, sizeof(argv));
    80005ac0:	10000613          	li	a2,256
    80005ac4:	4581                	li	a1,0
    80005ac6:	e4040513          	addi	a0,s0,-448
    80005aca:	ffffb097          	auipc	ra,0xffffb
    80005ace:	208080e7          	jalr	520(ra) # 80000cd2 <memset>
  for(i=0;; i++){
    if(i >= NELEM(argv)){
    80005ad2:	e4040493          	addi	s1,s0,-448
  memset(argv, 0, sizeof(argv));
    80005ad6:	89a6                	mv	s3,s1
    80005ad8:	4901                	li	s2,0
    if(i >= NELEM(argv)){
    80005ada:	02000a13          	li	s4,32
    80005ade:	00090a9b          	sext.w	s5,s2
      goto bad;
    }
    if(fetchaddr(uargv+sizeof(uint64)*i, (uint64*)&uarg) < 0){
    80005ae2:	00391793          	slli	a5,s2,0x3
    80005ae6:	e3040593          	addi	a1,s0,-464
    80005aea:	e3843503          	ld	a0,-456(s0)
    80005aee:	953e                	add	a0,a0,a5
    80005af0:	ffffd097          	auipc	ra,0xffffd
    80005af4:	ff2080e7          	jalr	-14(ra) # 80002ae2 <fetchaddr>
    80005af8:	02054a63          	bltz	a0,80005b2c <sys_exec+0xa6>
      goto bad;
    }
    if(uarg == 0){
    80005afc:	e3043783          	ld	a5,-464(s0)
    80005b00:	c3b9                	beqz	a5,80005b46 <sys_exec+0xc0>
      argv[i] = 0;
      break;
    }
    argv[i] = kalloc();
    80005b02:	ffffb097          	auipc	ra,0xffffb
    80005b06:	fe4080e7          	jalr	-28(ra) # 80000ae6 <kalloc>
    80005b0a:	85aa                	mv	a1,a0
    80005b0c:	00a9b023          	sd	a0,0(s3)
    if(argv[i] == 0)
    80005b10:	cd11                	beqz	a0,80005b2c <sys_exec+0xa6>
      goto bad;
    if(fetchstr(uarg, argv[i], PGSIZE) < 0)
    80005b12:	6605                	lui	a2,0x1
    80005b14:	e3043503          	ld	a0,-464(s0)
    80005b18:	ffffd097          	auipc	ra,0xffffd
    80005b1c:	01c080e7          	jalr	28(ra) # 80002b34 <fetchstr>
    80005b20:	00054663          	bltz	a0,80005b2c <sys_exec+0xa6>
    if(i >= NELEM(argv)){
    80005b24:	0905                	addi	s2,s2,1
    80005b26:	09a1                	addi	s3,s3,8
    80005b28:	fb491be3          	bne	s2,s4,80005ade <sys_exec+0x58>
    kfree(argv[i]);

  return ret;

 bad:
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    80005b2c:	10048913          	addi	s2,s1,256
    80005b30:	6088                	ld	a0,0(s1)
    80005b32:	c531                	beqz	a0,80005b7e <sys_exec+0xf8>
    kfree(argv[i]);
    80005b34:	ffffb097          	auipc	ra,0xffffb
    80005b38:	eb6080e7          	jalr	-330(ra) # 800009ea <kfree>
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    80005b3c:	04a1                	addi	s1,s1,8
    80005b3e:	ff2499e3          	bne	s1,s2,80005b30 <sys_exec+0xaa>
  return -1;
    80005b42:	557d                	li	a0,-1
    80005b44:	a835                	j	80005b80 <sys_exec+0xfa>
      argv[i] = 0;
    80005b46:	0a8e                	slli	s5,s5,0x3
    80005b48:	fc040793          	addi	a5,s0,-64
    80005b4c:	9abe                	add	s5,s5,a5
    80005b4e:	e80ab023          	sd	zero,-384(s5)
  int ret = exec(path, argv);
    80005b52:	e4040593          	addi	a1,s0,-448
    80005b56:	f4040513          	addi	a0,s0,-192
    80005b5a:	fffff097          	auipc	ra,0xfffff
    80005b5e:	150080e7          	jalr	336(ra) # 80004caa <exec>
    80005b62:	892a                	mv	s2,a0
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    80005b64:	10048993          	addi	s3,s1,256
    80005b68:	6088                	ld	a0,0(s1)
    80005b6a:	c901                	beqz	a0,80005b7a <sys_exec+0xf4>
    kfree(argv[i]);
    80005b6c:	ffffb097          	auipc	ra,0xffffb
    80005b70:	e7e080e7          	jalr	-386(ra) # 800009ea <kfree>
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    80005b74:	04a1                	addi	s1,s1,8
    80005b76:	ff3499e3          	bne	s1,s3,80005b68 <sys_exec+0xe2>
  return ret;
    80005b7a:	854a                	mv	a0,s2
    80005b7c:	a011                	j	80005b80 <sys_exec+0xfa>
  return -1;
    80005b7e:	557d                	li	a0,-1
}
    80005b80:	60be                	ld	ra,456(sp)
    80005b82:	641e                	ld	s0,448(sp)
    80005b84:	74fa                	ld	s1,440(sp)
    80005b86:	795a                	ld	s2,432(sp)
    80005b88:	79ba                	ld	s3,424(sp)
    80005b8a:	7a1a                	ld	s4,416(sp)
    80005b8c:	6afa                	ld	s5,408(sp)
    80005b8e:	6179                	addi	sp,sp,464
    80005b90:	8082                	ret

0000000080005b92 <sys_pipe>:

uint64
sys_pipe(void)
{
    80005b92:	7139                	addi	sp,sp,-64
    80005b94:	fc06                	sd	ra,56(sp)
    80005b96:	f822                	sd	s0,48(sp)
    80005b98:	f426                	sd	s1,40(sp)
    80005b9a:	0080                	addi	s0,sp,64
  uint64 fdarray; // user pointer to array of two integers
  struct file *rf, *wf;
  int fd0, fd1;
  struct proc *p = myproc();
    80005b9c:	ffffc097          	auipc	ra,0xffffc
    80005ba0:	e46080e7          	jalr	-442(ra) # 800019e2 <myproc>
    80005ba4:	84aa                	mv	s1,a0

  argaddr(0, &fdarray);
    80005ba6:	fd840593          	addi	a1,s0,-40
    80005baa:	4501                	li	a0,0
    80005bac:	ffffd097          	auipc	ra,0xffffd
    80005bb0:	ff4080e7          	jalr	-12(ra) # 80002ba0 <argaddr>
  if(pipealloc(&rf, &wf) < 0)
    80005bb4:	fc840593          	addi	a1,s0,-56
    80005bb8:	fd040513          	addi	a0,s0,-48
    80005bbc:	fffff097          	auipc	ra,0xfffff
    80005bc0:	da4080e7          	jalr	-604(ra) # 80004960 <pipealloc>
    return -1;
    80005bc4:	57fd                	li	a5,-1
  if(pipealloc(&rf, &wf) < 0)
    80005bc6:	0c054463          	bltz	a0,80005c8e <sys_pipe+0xfc>
  fd0 = -1;
    80005bca:	fcf42223          	sw	a5,-60(s0)
  if((fd0 = fdalloc(rf)) < 0 || (fd1 = fdalloc(wf)) < 0){
    80005bce:	fd043503          	ld	a0,-48(s0)
    80005bd2:	fffff097          	auipc	ra,0xfffff
    80005bd6:	51a080e7          	jalr	1306(ra) # 800050ec <fdalloc>
    80005bda:	fca42223          	sw	a0,-60(s0)
    80005bde:	08054b63          	bltz	a0,80005c74 <sys_pipe+0xe2>
    80005be2:	fc843503          	ld	a0,-56(s0)
    80005be6:	fffff097          	auipc	ra,0xfffff
    80005bea:	506080e7          	jalr	1286(ra) # 800050ec <fdalloc>
    80005bee:	fca42023          	sw	a0,-64(s0)
    80005bf2:	06054863          	bltz	a0,80005c62 <sys_pipe+0xd0>
      p->ofile[fd0] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  if(copyout(p->pagetable, fdarray, (char*)&fd0, sizeof(fd0)) < 0 ||
    80005bf6:	4691                	li	a3,4
    80005bf8:	fc440613          	addi	a2,s0,-60
    80005bfc:	fd843583          	ld	a1,-40(s0)
    80005c00:	68a8                	ld	a0,80(s1)
    80005c02:	ffffc097          	auipc	ra,0xffffc
    80005c06:	a9c080e7          	jalr	-1380(ra) # 8000169e <copyout>
    80005c0a:	02054063          	bltz	a0,80005c2a <sys_pipe+0x98>
     copyout(p->pagetable, fdarray+sizeof(fd0), (char *)&fd1, sizeof(fd1)) < 0){
    80005c0e:	4691                	li	a3,4
    80005c10:	fc040613          	addi	a2,s0,-64
    80005c14:	fd843583          	ld	a1,-40(s0)
    80005c18:	0591                	addi	a1,a1,4
    80005c1a:	68a8                	ld	a0,80(s1)
    80005c1c:	ffffc097          	auipc	ra,0xffffc
    80005c20:	a82080e7          	jalr	-1406(ra) # 8000169e <copyout>
    p->ofile[fd1] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  return 0;
    80005c24:	4781                	li	a5,0
  if(copyout(p->pagetable, fdarray, (char*)&fd0, sizeof(fd0)) < 0 ||
    80005c26:	06055463          	bgez	a0,80005c8e <sys_pipe+0xfc>
    p->ofile[fd0] = 0;
    80005c2a:	fc442783          	lw	a5,-60(s0)
    80005c2e:	07e9                	addi	a5,a5,26
    80005c30:	078e                	slli	a5,a5,0x3
    80005c32:	97a6                	add	a5,a5,s1
    80005c34:	0007b023          	sd	zero,0(a5)
    p->ofile[fd1] = 0;
    80005c38:	fc042503          	lw	a0,-64(s0)
    80005c3c:	0569                	addi	a0,a0,26
    80005c3e:	050e                	slli	a0,a0,0x3
    80005c40:	94aa                	add	s1,s1,a0
    80005c42:	0004b023          	sd	zero,0(s1)
    fileclose(rf);
    80005c46:	fd043503          	ld	a0,-48(s0)
    80005c4a:	fffff097          	auipc	ra,0xfffff
    80005c4e:	9e6080e7          	jalr	-1562(ra) # 80004630 <fileclose>
    fileclose(wf);
    80005c52:	fc843503          	ld	a0,-56(s0)
    80005c56:	fffff097          	auipc	ra,0xfffff
    80005c5a:	9da080e7          	jalr	-1574(ra) # 80004630 <fileclose>
    return -1;
    80005c5e:	57fd                	li	a5,-1
    80005c60:	a03d                	j	80005c8e <sys_pipe+0xfc>
    if(fd0 >= 0)
    80005c62:	fc442783          	lw	a5,-60(s0)
    80005c66:	0007c763          	bltz	a5,80005c74 <sys_pipe+0xe2>
      p->ofile[fd0] = 0;
    80005c6a:	07e9                	addi	a5,a5,26
    80005c6c:	078e                	slli	a5,a5,0x3
    80005c6e:	94be                	add	s1,s1,a5
    80005c70:	0004b023          	sd	zero,0(s1)
    fileclose(rf);
    80005c74:	fd043503          	ld	a0,-48(s0)
    80005c78:	fffff097          	auipc	ra,0xfffff
    80005c7c:	9b8080e7          	jalr	-1608(ra) # 80004630 <fileclose>
    fileclose(wf);
    80005c80:	fc843503          	ld	a0,-56(s0)
    80005c84:	fffff097          	auipc	ra,0xfffff
    80005c88:	9ac080e7          	jalr	-1620(ra) # 80004630 <fileclose>
    return -1;
    80005c8c:	57fd                	li	a5,-1
}
    80005c8e:	853e                	mv	a0,a5
    80005c90:	70e2                	ld	ra,56(sp)
    80005c92:	7442                	ld	s0,48(sp)
    80005c94:	74a2                	ld	s1,40(sp)
    80005c96:	6121                	addi	sp,sp,64
    80005c98:	8082                	ret
    80005c9a:	0000                	unimp
    80005c9c:	0000                	unimp
	...

0000000080005ca0 <kernelvec>:
    80005ca0:	7111                	addi	sp,sp,-256
    80005ca2:	e006                	sd	ra,0(sp)
    80005ca4:	e40a                	sd	sp,8(sp)
    80005ca6:	e80e                	sd	gp,16(sp)
    80005ca8:	ec12                	sd	tp,24(sp)
    80005caa:	f016                	sd	t0,32(sp)
    80005cac:	f41a                	sd	t1,40(sp)
    80005cae:	f81e                	sd	t2,48(sp)
    80005cb0:	fc22                	sd	s0,56(sp)
    80005cb2:	e0a6                	sd	s1,64(sp)
    80005cb4:	e4aa                	sd	a0,72(sp)
    80005cb6:	e8ae                	sd	a1,80(sp)
    80005cb8:	ecb2                	sd	a2,88(sp)
    80005cba:	f0b6                	sd	a3,96(sp)
    80005cbc:	f4ba                	sd	a4,104(sp)
    80005cbe:	f8be                	sd	a5,112(sp)
    80005cc0:	fcc2                	sd	a6,120(sp)
    80005cc2:	e146                	sd	a7,128(sp)
    80005cc4:	e54a                	sd	s2,136(sp)
    80005cc6:	e94e                	sd	s3,144(sp)
    80005cc8:	ed52                	sd	s4,152(sp)
    80005cca:	f156                	sd	s5,160(sp)
    80005ccc:	f55a                	sd	s6,168(sp)
    80005cce:	f95e                	sd	s7,176(sp)
    80005cd0:	fd62                	sd	s8,184(sp)
    80005cd2:	e1e6                	sd	s9,192(sp)
    80005cd4:	e5ea                	sd	s10,200(sp)
    80005cd6:	e9ee                	sd	s11,208(sp)
    80005cd8:	edf2                	sd	t3,216(sp)
    80005cda:	f1f6                	sd	t4,224(sp)
    80005cdc:	f5fa                	sd	t5,232(sp)
    80005cde:	f9fe                	sd	t6,240(sp)
    80005ce0:	ccffc0ef          	jal	ra,800029ae <kerneltrap>
    80005ce4:	6082                	ld	ra,0(sp)
    80005ce6:	6122                	ld	sp,8(sp)
    80005ce8:	61c2                	ld	gp,16(sp)
    80005cea:	7282                	ld	t0,32(sp)
    80005cec:	7322                	ld	t1,40(sp)
    80005cee:	73c2                	ld	t2,48(sp)
    80005cf0:	7462                	ld	s0,56(sp)
    80005cf2:	6486                	ld	s1,64(sp)
    80005cf4:	6526                	ld	a0,72(sp)
    80005cf6:	65c6                	ld	a1,80(sp)
    80005cf8:	6666                	ld	a2,88(sp)
    80005cfa:	7686                	ld	a3,96(sp)
    80005cfc:	7726                	ld	a4,104(sp)
    80005cfe:	77c6                	ld	a5,112(sp)
    80005d00:	7866                	ld	a6,120(sp)
    80005d02:	688a                	ld	a7,128(sp)
    80005d04:	692a                	ld	s2,136(sp)
    80005d06:	69ca                	ld	s3,144(sp)
    80005d08:	6a6a                	ld	s4,152(sp)
    80005d0a:	7a8a                	ld	s5,160(sp)
    80005d0c:	7b2a                	ld	s6,168(sp)
    80005d0e:	7bca                	ld	s7,176(sp)
    80005d10:	7c6a                	ld	s8,184(sp)
    80005d12:	6c8e                	ld	s9,192(sp)
    80005d14:	6d2e                	ld	s10,200(sp)
    80005d16:	6dce                	ld	s11,208(sp)
    80005d18:	6e6e                	ld	t3,216(sp)
    80005d1a:	7e8e                	ld	t4,224(sp)
    80005d1c:	7f2e                	ld	t5,232(sp)
    80005d1e:	7fce                	ld	t6,240(sp)
    80005d20:	6111                	addi	sp,sp,256
    80005d22:	10200073          	sret
    80005d26:	00000013          	nop
    80005d2a:	00000013          	nop
    80005d2e:	0001                	nop

0000000080005d30 <timervec>:
    80005d30:	34051573          	csrrw	a0,mscratch,a0
    80005d34:	e10c                	sd	a1,0(a0)
    80005d36:	e510                	sd	a2,8(a0)
    80005d38:	e914                	sd	a3,16(a0)
    80005d3a:	6d0c                	ld	a1,24(a0)
    80005d3c:	7110                	ld	a2,32(a0)
    80005d3e:	6194                	ld	a3,0(a1)
    80005d40:	96b2                	add	a3,a3,a2
    80005d42:	e194                	sd	a3,0(a1)
    80005d44:	4589                	li	a1,2
    80005d46:	14459073          	csrw	sip,a1
    80005d4a:	6914                	ld	a3,16(a0)
    80005d4c:	6510                	ld	a2,8(a0)
    80005d4e:	610c                	ld	a1,0(a0)
    80005d50:	34051573          	csrrw	a0,mscratch,a0
    80005d54:	30200073          	mret
	...

0000000080005d5a <plicinit>:
// the riscv Platform Level Interrupt Controller (PLIC).
//

void
plicinit(void)
{
    80005d5a:	1141                	addi	sp,sp,-16
    80005d5c:	e422                	sd	s0,8(sp)
    80005d5e:	0800                	addi	s0,sp,16
  // set desired IRQ priorities non-zero (otherwise disabled).
  *(uint32*)(PLIC + UART0_IRQ*4) = 1;
    80005d60:	0c0007b7          	lui	a5,0xc000
    80005d64:	4705                	li	a4,1
    80005d66:	d798                	sw	a4,40(a5)
  *(uint32*)(PLIC + VIRTIO0_IRQ*4) = 1;
    80005d68:	c3d8                	sw	a4,4(a5)
}
    80005d6a:	6422                	ld	s0,8(sp)
    80005d6c:	0141                	addi	sp,sp,16
    80005d6e:	8082                	ret

0000000080005d70 <plicinithart>:

void
plicinithart(void)
{
    80005d70:	1141                	addi	sp,sp,-16
    80005d72:	e406                	sd	ra,8(sp)
    80005d74:	e022                	sd	s0,0(sp)
    80005d76:	0800                	addi	s0,sp,16
  int hart = cpuid();
    80005d78:	ffffc097          	auipc	ra,0xffffc
    80005d7c:	c3e080e7          	jalr	-962(ra) # 800019b6 <cpuid>
  
  // set enable bits for this hart's S-mode
  // for the uart and virtio disk.
  *(uint32*)PLIC_SENABLE(hart) = (1 << UART0_IRQ) | (1 << VIRTIO0_IRQ);
    80005d80:	0085171b          	slliw	a4,a0,0x8
    80005d84:	0c0027b7          	lui	a5,0xc002
    80005d88:	97ba                	add	a5,a5,a4
    80005d8a:	40200713          	li	a4,1026
    80005d8e:	08e7a023          	sw	a4,128(a5) # c002080 <_entry-0x73ffdf80>

  // set this hart's S-mode priority threshold to 0.
  *(uint32*)PLIC_SPRIORITY(hart) = 0;
    80005d92:	00d5151b          	slliw	a0,a0,0xd
    80005d96:	0c2017b7          	lui	a5,0xc201
    80005d9a:	953e                	add	a0,a0,a5
    80005d9c:	00052023          	sw	zero,0(a0)
}
    80005da0:	60a2                	ld	ra,8(sp)
    80005da2:	6402                	ld	s0,0(sp)
    80005da4:	0141                	addi	sp,sp,16
    80005da6:	8082                	ret

0000000080005da8 <plic_claim>:

// ask the PLIC what interrupt we should serve.
int
plic_claim(void)
{
    80005da8:	1141                	addi	sp,sp,-16
    80005daa:	e406                	sd	ra,8(sp)
    80005dac:	e022                	sd	s0,0(sp)
    80005dae:	0800                	addi	s0,sp,16
  int hart = cpuid();
    80005db0:	ffffc097          	auipc	ra,0xffffc
    80005db4:	c06080e7          	jalr	-1018(ra) # 800019b6 <cpuid>
  int irq = *(uint32*)PLIC_SCLAIM(hart);
    80005db8:	00d5179b          	slliw	a5,a0,0xd
    80005dbc:	0c201537          	lui	a0,0xc201
    80005dc0:	953e                	add	a0,a0,a5
  return irq;
}
    80005dc2:	4148                	lw	a0,4(a0)
    80005dc4:	60a2                	ld	ra,8(sp)
    80005dc6:	6402                	ld	s0,0(sp)
    80005dc8:	0141                	addi	sp,sp,16
    80005dca:	8082                	ret

0000000080005dcc <plic_complete>:

// tell the PLIC we've served this IRQ.
void
plic_complete(int irq)
{
    80005dcc:	1101                	addi	sp,sp,-32
    80005dce:	ec06                	sd	ra,24(sp)
    80005dd0:	e822                	sd	s0,16(sp)
    80005dd2:	e426                	sd	s1,8(sp)
    80005dd4:	1000                	addi	s0,sp,32
    80005dd6:	84aa                	mv	s1,a0
  int hart = cpuid();
    80005dd8:	ffffc097          	auipc	ra,0xffffc
    80005ddc:	bde080e7          	jalr	-1058(ra) # 800019b6 <cpuid>
  *(uint32*)PLIC_SCLAIM(hart) = irq;
    80005de0:	00d5151b          	slliw	a0,a0,0xd
    80005de4:	0c2017b7          	lui	a5,0xc201
    80005de8:	97aa                	add	a5,a5,a0
    80005dea:	c3c4                	sw	s1,4(a5)
}
    80005dec:	60e2                	ld	ra,24(sp)
    80005dee:	6442                	ld	s0,16(sp)
    80005df0:	64a2                	ld	s1,8(sp)
    80005df2:	6105                	addi	sp,sp,32
    80005df4:	8082                	ret

0000000080005df6 <free_desc>:
}

// mark a descriptor as free.
static void
free_desc(int i)
{
    80005df6:	1141                	addi	sp,sp,-16
    80005df8:	e406                	sd	ra,8(sp)
    80005dfa:	e022                	sd	s0,0(sp)
    80005dfc:	0800                	addi	s0,sp,16
  if(i >= NUM)
    80005dfe:	479d                	li	a5,7
    80005e00:	04a7cc63          	blt	a5,a0,80005e58 <free_desc+0x62>
    panic("free_desc 1");
  if(disk.free[i])
    80005e04:	0001d797          	auipc	a5,0x1d
    80005e08:	99c78793          	addi	a5,a5,-1636 # 800227a0 <disk>
    80005e0c:	97aa                	add	a5,a5,a0
    80005e0e:	0187c783          	lbu	a5,24(a5)
    80005e12:	ebb9                	bnez	a5,80005e68 <free_desc+0x72>
    panic("free_desc 2");
  disk.desc[i].addr = 0;
    80005e14:	00451613          	slli	a2,a0,0x4
    80005e18:	0001d797          	auipc	a5,0x1d
    80005e1c:	98878793          	addi	a5,a5,-1656 # 800227a0 <disk>
    80005e20:	6394                	ld	a3,0(a5)
    80005e22:	96b2                	add	a3,a3,a2
    80005e24:	0006b023          	sd	zero,0(a3)
  disk.desc[i].len = 0;
    80005e28:	6398                	ld	a4,0(a5)
    80005e2a:	9732                	add	a4,a4,a2
    80005e2c:	00072423          	sw	zero,8(a4)
  disk.desc[i].flags = 0;
    80005e30:	00071623          	sh	zero,12(a4)
  disk.desc[i].next = 0;
    80005e34:	00071723          	sh	zero,14(a4)
  disk.free[i] = 1;
    80005e38:	953e                	add	a0,a0,a5
    80005e3a:	4785                	li	a5,1
    80005e3c:	00f50c23          	sb	a5,24(a0) # c201018 <_entry-0x73dfefe8>
  wakeup(&disk.free[0]);
    80005e40:	0001d517          	auipc	a0,0x1d
    80005e44:	97850513          	addi	a0,a0,-1672 # 800227b8 <disk+0x18>
    80005e48:	ffffc097          	auipc	ra,0xffffc
    80005e4c:	330080e7          	jalr	816(ra) # 80002178 <wakeup>
}
    80005e50:	60a2                	ld	ra,8(sp)
    80005e52:	6402                	ld	s0,0(sp)
    80005e54:	0141                	addi	sp,sp,16
    80005e56:	8082                	ret
    panic("free_desc 1");
    80005e58:	00003517          	auipc	a0,0x3
    80005e5c:	91850513          	addi	a0,a0,-1768 # 80008770 <syscalls+0x300>
    80005e60:	ffffa097          	auipc	ra,0xffffa
    80005e64:	6de080e7          	jalr	1758(ra) # 8000053e <panic>
    panic("free_desc 2");
    80005e68:	00003517          	auipc	a0,0x3
    80005e6c:	91850513          	addi	a0,a0,-1768 # 80008780 <syscalls+0x310>
    80005e70:	ffffa097          	auipc	ra,0xffffa
    80005e74:	6ce080e7          	jalr	1742(ra) # 8000053e <panic>

0000000080005e78 <virtio_disk_init>:
{
    80005e78:	1101                	addi	sp,sp,-32
    80005e7a:	ec06                	sd	ra,24(sp)
    80005e7c:	e822                	sd	s0,16(sp)
    80005e7e:	e426                	sd	s1,8(sp)
    80005e80:	e04a                	sd	s2,0(sp)
    80005e82:	1000                	addi	s0,sp,32
  initlock(&disk.vdisk_lock, "virtio_disk");
    80005e84:	00003597          	auipc	a1,0x3
    80005e88:	90c58593          	addi	a1,a1,-1780 # 80008790 <syscalls+0x320>
    80005e8c:	0001d517          	auipc	a0,0x1d
    80005e90:	a3c50513          	addi	a0,a0,-1476 # 800228c8 <disk+0x128>
    80005e94:	ffffb097          	auipc	ra,0xffffb
    80005e98:	cb2080e7          	jalr	-846(ra) # 80000b46 <initlock>
  if(*R(VIRTIO_MMIO_MAGIC_VALUE) != 0x74726976 ||
    80005e9c:	100017b7          	lui	a5,0x10001
    80005ea0:	4398                	lw	a4,0(a5)
    80005ea2:	2701                	sext.w	a4,a4
    80005ea4:	747277b7          	lui	a5,0x74727
    80005ea8:	97678793          	addi	a5,a5,-1674 # 74726976 <_entry-0xb8d968a>
    80005eac:	14f71c63          	bne	a4,a5,80006004 <virtio_disk_init+0x18c>
     *R(VIRTIO_MMIO_VERSION) != 2 ||
    80005eb0:	100017b7          	lui	a5,0x10001
    80005eb4:	43dc                	lw	a5,4(a5)
    80005eb6:	2781                	sext.w	a5,a5
  if(*R(VIRTIO_MMIO_MAGIC_VALUE) != 0x74726976 ||
    80005eb8:	4709                	li	a4,2
    80005eba:	14e79563          	bne	a5,a4,80006004 <virtio_disk_init+0x18c>
     *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    80005ebe:	100017b7          	lui	a5,0x10001
    80005ec2:	479c                	lw	a5,8(a5)
    80005ec4:	2781                	sext.w	a5,a5
     *R(VIRTIO_MMIO_VERSION) != 2 ||
    80005ec6:	12e79f63          	bne	a5,a4,80006004 <virtio_disk_init+0x18c>
     *R(VIRTIO_MMIO_VENDOR_ID) != 0x554d4551){
    80005eca:	100017b7          	lui	a5,0x10001
    80005ece:	47d8                	lw	a4,12(a5)
    80005ed0:	2701                	sext.w	a4,a4
     *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    80005ed2:	554d47b7          	lui	a5,0x554d4
    80005ed6:	55178793          	addi	a5,a5,1361 # 554d4551 <_entry-0x2ab2baaf>
    80005eda:	12f71563          	bne	a4,a5,80006004 <virtio_disk_init+0x18c>
  *R(VIRTIO_MMIO_STATUS) = status;
    80005ede:	100017b7          	lui	a5,0x10001
    80005ee2:	0607a823          	sw	zero,112(a5) # 10001070 <_entry-0x6fffef90>
  *R(VIRTIO_MMIO_STATUS) = status;
    80005ee6:	4705                	li	a4,1
    80005ee8:	dbb8                	sw	a4,112(a5)
  *R(VIRTIO_MMIO_STATUS) = status;
    80005eea:	470d                	li	a4,3
    80005eec:	dbb8                	sw	a4,112(a5)
  uint64 features = *R(VIRTIO_MMIO_DEVICE_FEATURES);
    80005eee:	4b94                	lw	a3,16(a5)
  features &= ~(1 << VIRTIO_RING_F_INDIRECT_DESC);
    80005ef0:	c7ffe737          	lui	a4,0xc7ffe
    80005ef4:	75f70713          	addi	a4,a4,1887 # ffffffffc7ffe75f <end+0xffffffff47fd68c7>
    80005ef8:	8f75                	and	a4,a4,a3
  *R(VIRTIO_MMIO_DRIVER_FEATURES) = features;
    80005efa:	2701                	sext.w	a4,a4
    80005efc:	d398                	sw	a4,32(a5)
  *R(VIRTIO_MMIO_STATUS) = status;
    80005efe:	472d                	li	a4,11
    80005f00:	dbb8                	sw	a4,112(a5)
  status = *R(VIRTIO_MMIO_STATUS);
    80005f02:	5bbc                	lw	a5,112(a5)
    80005f04:	0007891b          	sext.w	s2,a5
  if(!(status & VIRTIO_CONFIG_S_FEATURES_OK))
    80005f08:	8ba1                	andi	a5,a5,8
    80005f0a:	10078563          	beqz	a5,80006014 <virtio_disk_init+0x19c>
  *R(VIRTIO_MMIO_QUEUE_SEL) = 0;
    80005f0e:	100017b7          	lui	a5,0x10001
    80005f12:	0207a823          	sw	zero,48(a5) # 10001030 <_entry-0x6fffefd0>
  if(*R(VIRTIO_MMIO_QUEUE_READY))
    80005f16:	43fc                	lw	a5,68(a5)
    80005f18:	2781                	sext.w	a5,a5
    80005f1a:	10079563          	bnez	a5,80006024 <virtio_disk_init+0x1ac>
  uint32 max = *R(VIRTIO_MMIO_QUEUE_NUM_MAX);
    80005f1e:	100017b7          	lui	a5,0x10001
    80005f22:	5bdc                	lw	a5,52(a5)
    80005f24:	2781                	sext.w	a5,a5
  if(max == 0)
    80005f26:	10078763          	beqz	a5,80006034 <virtio_disk_init+0x1bc>
  if(max < NUM)
    80005f2a:	471d                	li	a4,7
    80005f2c:	10f77c63          	bgeu	a4,a5,80006044 <virtio_disk_init+0x1cc>
  disk.desc = kalloc();
    80005f30:	ffffb097          	auipc	ra,0xffffb
    80005f34:	bb6080e7          	jalr	-1098(ra) # 80000ae6 <kalloc>
    80005f38:	0001d497          	auipc	s1,0x1d
    80005f3c:	86848493          	addi	s1,s1,-1944 # 800227a0 <disk>
    80005f40:	e088                	sd	a0,0(s1)
  disk.avail = kalloc();
    80005f42:	ffffb097          	auipc	ra,0xffffb
    80005f46:	ba4080e7          	jalr	-1116(ra) # 80000ae6 <kalloc>
    80005f4a:	e488                	sd	a0,8(s1)
  disk.used = kalloc();
    80005f4c:	ffffb097          	auipc	ra,0xffffb
    80005f50:	b9a080e7          	jalr	-1126(ra) # 80000ae6 <kalloc>
    80005f54:	87aa                	mv	a5,a0
    80005f56:	e888                	sd	a0,16(s1)
  if(!disk.desc || !disk.avail || !disk.used)
    80005f58:	6088                	ld	a0,0(s1)
    80005f5a:	cd6d                	beqz	a0,80006054 <virtio_disk_init+0x1dc>
    80005f5c:	0001d717          	auipc	a4,0x1d
    80005f60:	84c73703          	ld	a4,-1972(a4) # 800227a8 <disk+0x8>
    80005f64:	cb65                	beqz	a4,80006054 <virtio_disk_init+0x1dc>
    80005f66:	c7fd                	beqz	a5,80006054 <virtio_disk_init+0x1dc>
  memset(disk.desc, 0, PGSIZE);
    80005f68:	6605                	lui	a2,0x1
    80005f6a:	4581                	li	a1,0
    80005f6c:	ffffb097          	auipc	ra,0xffffb
    80005f70:	d66080e7          	jalr	-666(ra) # 80000cd2 <memset>
  memset(disk.avail, 0, PGSIZE);
    80005f74:	0001d497          	auipc	s1,0x1d
    80005f78:	82c48493          	addi	s1,s1,-2004 # 800227a0 <disk>
    80005f7c:	6605                	lui	a2,0x1
    80005f7e:	4581                	li	a1,0
    80005f80:	6488                	ld	a0,8(s1)
    80005f82:	ffffb097          	auipc	ra,0xffffb
    80005f86:	d50080e7          	jalr	-688(ra) # 80000cd2 <memset>
  memset(disk.used, 0, PGSIZE);
    80005f8a:	6605                	lui	a2,0x1
    80005f8c:	4581                	li	a1,0
    80005f8e:	6888                	ld	a0,16(s1)
    80005f90:	ffffb097          	auipc	ra,0xffffb
    80005f94:	d42080e7          	jalr	-702(ra) # 80000cd2 <memset>
  *R(VIRTIO_MMIO_QUEUE_NUM) = NUM;
    80005f98:	100017b7          	lui	a5,0x10001
    80005f9c:	4721                	li	a4,8
    80005f9e:	df98                	sw	a4,56(a5)
  *R(VIRTIO_MMIO_QUEUE_DESC_LOW) = (uint64)disk.desc;
    80005fa0:	4098                	lw	a4,0(s1)
    80005fa2:	08e7a023          	sw	a4,128(a5) # 10001080 <_entry-0x6fffef80>
  *R(VIRTIO_MMIO_QUEUE_DESC_HIGH) = (uint64)disk.desc >> 32;
    80005fa6:	40d8                	lw	a4,4(s1)
    80005fa8:	08e7a223          	sw	a4,132(a5)
  *R(VIRTIO_MMIO_DRIVER_DESC_LOW) = (uint64)disk.avail;
    80005fac:	6498                	ld	a4,8(s1)
    80005fae:	0007069b          	sext.w	a3,a4
    80005fb2:	08d7a823          	sw	a3,144(a5)
  *R(VIRTIO_MMIO_DRIVER_DESC_HIGH) = (uint64)disk.avail >> 32;
    80005fb6:	9701                	srai	a4,a4,0x20
    80005fb8:	08e7aa23          	sw	a4,148(a5)
  *R(VIRTIO_MMIO_DEVICE_DESC_LOW) = (uint64)disk.used;
    80005fbc:	6898                	ld	a4,16(s1)
    80005fbe:	0007069b          	sext.w	a3,a4
    80005fc2:	0ad7a023          	sw	a3,160(a5)
  *R(VIRTIO_MMIO_DEVICE_DESC_HIGH) = (uint64)disk.used >> 32;
    80005fc6:	9701                	srai	a4,a4,0x20
    80005fc8:	0ae7a223          	sw	a4,164(a5)
  *R(VIRTIO_MMIO_QUEUE_READY) = 0x1;
    80005fcc:	4705                	li	a4,1
    80005fce:	c3f8                	sw	a4,68(a5)
    disk.free[i] = 1;
    80005fd0:	00e48c23          	sb	a4,24(s1)
    80005fd4:	00e48ca3          	sb	a4,25(s1)
    80005fd8:	00e48d23          	sb	a4,26(s1)
    80005fdc:	00e48da3          	sb	a4,27(s1)
    80005fe0:	00e48e23          	sb	a4,28(s1)
    80005fe4:	00e48ea3          	sb	a4,29(s1)
    80005fe8:	00e48f23          	sb	a4,30(s1)
    80005fec:	00e48fa3          	sb	a4,31(s1)
  status |= VIRTIO_CONFIG_S_DRIVER_OK;
    80005ff0:	00496913          	ori	s2,s2,4
  *R(VIRTIO_MMIO_STATUS) = status;
    80005ff4:	0727a823          	sw	s2,112(a5)
}
    80005ff8:	60e2                	ld	ra,24(sp)
    80005ffa:	6442                	ld	s0,16(sp)
    80005ffc:	64a2                	ld	s1,8(sp)
    80005ffe:	6902                	ld	s2,0(sp)
    80006000:	6105                	addi	sp,sp,32
    80006002:	8082                	ret
    panic("could not find virtio disk");
    80006004:	00002517          	auipc	a0,0x2
    80006008:	79c50513          	addi	a0,a0,1948 # 800087a0 <syscalls+0x330>
    8000600c:	ffffa097          	auipc	ra,0xffffa
    80006010:	532080e7          	jalr	1330(ra) # 8000053e <panic>
    panic("virtio disk FEATURES_OK unset");
    80006014:	00002517          	auipc	a0,0x2
    80006018:	7ac50513          	addi	a0,a0,1964 # 800087c0 <syscalls+0x350>
    8000601c:	ffffa097          	auipc	ra,0xffffa
    80006020:	522080e7          	jalr	1314(ra) # 8000053e <panic>
    panic("virtio disk should not be ready");
    80006024:	00002517          	auipc	a0,0x2
    80006028:	7bc50513          	addi	a0,a0,1980 # 800087e0 <syscalls+0x370>
    8000602c:	ffffa097          	auipc	ra,0xffffa
    80006030:	512080e7          	jalr	1298(ra) # 8000053e <panic>
    panic("virtio disk has no queue 0");
    80006034:	00002517          	auipc	a0,0x2
    80006038:	7cc50513          	addi	a0,a0,1996 # 80008800 <syscalls+0x390>
    8000603c:	ffffa097          	auipc	ra,0xffffa
    80006040:	502080e7          	jalr	1282(ra) # 8000053e <panic>
    panic("virtio disk max queue too short");
    80006044:	00002517          	auipc	a0,0x2
    80006048:	7dc50513          	addi	a0,a0,2012 # 80008820 <syscalls+0x3b0>
    8000604c:	ffffa097          	auipc	ra,0xffffa
    80006050:	4f2080e7          	jalr	1266(ra) # 8000053e <panic>
    panic("virtio disk kalloc");
    80006054:	00002517          	auipc	a0,0x2
    80006058:	7ec50513          	addi	a0,a0,2028 # 80008840 <syscalls+0x3d0>
    8000605c:	ffffa097          	auipc	ra,0xffffa
    80006060:	4e2080e7          	jalr	1250(ra) # 8000053e <panic>

0000000080006064 <virtio_disk_rw>:
  return 0;
}

void
virtio_disk_rw(struct buf *b, int write)
{
    80006064:	7119                	addi	sp,sp,-128
    80006066:	fc86                	sd	ra,120(sp)
    80006068:	f8a2                	sd	s0,112(sp)
    8000606a:	f4a6                	sd	s1,104(sp)
    8000606c:	f0ca                	sd	s2,96(sp)
    8000606e:	ecce                	sd	s3,88(sp)
    80006070:	e8d2                	sd	s4,80(sp)
    80006072:	e4d6                	sd	s5,72(sp)
    80006074:	e0da                	sd	s6,64(sp)
    80006076:	fc5e                	sd	s7,56(sp)
    80006078:	f862                	sd	s8,48(sp)
    8000607a:	f466                	sd	s9,40(sp)
    8000607c:	f06a                	sd	s10,32(sp)
    8000607e:	ec6e                	sd	s11,24(sp)
    80006080:	0100                	addi	s0,sp,128
    80006082:	8aaa                	mv	s5,a0
    80006084:	8c2e                	mv	s8,a1
  uint64 sector = b->blockno * (BSIZE / 512);
    80006086:	00c52d03          	lw	s10,12(a0)
    8000608a:	001d1d1b          	slliw	s10,s10,0x1
    8000608e:	1d02                	slli	s10,s10,0x20
    80006090:	020d5d13          	srli	s10,s10,0x20

  acquire(&disk.vdisk_lock);
    80006094:	0001d517          	auipc	a0,0x1d
    80006098:	83450513          	addi	a0,a0,-1996 # 800228c8 <disk+0x128>
    8000609c:	ffffb097          	auipc	ra,0xffffb
    800060a0:	b3a080e7          	jalr	-1222(ra) # 80000bd6 <acquire>
  for(int i = 0; i < 3; i++){
    800060a4:	4981                	li	s3,0
  for(int i = 0; i < NUM; i++){
    800060a6:	44a1                	li	s1,8
      disk.free[i] = 0;
    800060a8:	0001cb97          	auipc	s7,0x1c
    800060ac:	6f8b8b93          	addi	s7,s7,1784 # 800227a0 <disk>
  for(int i = 0; i < 3; i++){
    800060b0:	4b0d                	li	s6,3
  int idx[3];
  while(1){
    if(alloc3_desc(idx) == 0) {
      break;
    }
    sleep(&disk.free[0], &disk.vdisk_lock);
    800060b2:	0001dc97          	auipc	s9,0x1d
    800060b6:	816c8c93          	addi	s9,s9,-2026 # 800228c8 <disk+0x128>
    800060ba:	a08d                	j	8000611c <virtio_disk_rw+0xb8>
      disk.free[i] = 0;
    800060bc:	00fb8733          	add	a4,s7,a5
    800060c0:	00070c23          	sb	zero,24(a4)
    idx[i] = alloc_desc();
    800060c4:	c19c                	sw	a5,0(a1)
    if(idx[i] < 0){
    800060c6:	0207c563          	bltz	a5,800060f0 <virtio_disk_rw+0x8c>
  for(int i = 0; i < 3; i++){
    800060ca:	2905                	addiw	s2,s2,1
    800060cc:	0611                	addi	a2,a2,4
    800060ce:	05690c63          	beq	s2,s6,80006126 <virtio_disk_rw+0xc2>
    idx[i] = alloc_desc();
    800060d2:	85b2                	mv	a1,a2
  for(int i = 0; i < NUM; i++){
    800060d4:	0001c717          	auipc	a4,0x1c
    800060d8:	6cc70713          	addi	a4,a4,1740 # 800227a0 <disk>
    800060dc:	87ce                	mv	a5,s3
    if(disk.free[i]){
    800060de:	01874683          	lbu	a3,24(a4)
    800060e2:	fee9                	bnez	a3,800060bc <virtio_disk_rw+0x58>
  for(int i = 0; i < NUM; i++){
    800060e4:	2785                	addiw	a5,a5,1
    800060e6:	0705                	addi	a4,a4,1
    800060e8:	fe979be3          	bne	a5,s1,800060de <virtio_disk_rw+0x7a>
    idx[i] = alloc_desc();
    800060ec:	57fd                	li	a5,-1
    800060ee:	c19c                	sw	a5,0(a1)
      for(int j = 0; j < i; j++)
    800060f0:	01205d63          	blez	s2,8000610a <virtio_disk_rw+0xa6>
    800060f4:	8dce                	mv	s11,s3
        free_desc(idx[j]);
    800060f6:	000a2503          	lw	a0,0(s4)
    800060fa:	00000097          	auipc	ra,0x0
    800060fe:	cfc080e7          	jalr	-772(ra) # 80005df6 <free_desc>
      for(int j = 0; j < i; j++)
    80006102:	2d85                	addiw	s11,s11,1
    80006104:	0a11                	addi	s4,s4,4
    80006106:	ffb918e3          	bne	s2,s11,800060f6 <virtio_disk_rw+0x92>
    sleep(&disk.free[0], &disk.vdisk_lock);
    8000610a:	85e6                	mv	a1,s9
    8000610c:	0001c517          	auipc	a0,0x1c
    80006110:	6ac50513          	addi	a0,a0,1708 # 800227b8 <disk+0x18>
    80006114:	ffffc097          	auipc	ra,0xffffc
    80006118:	000080e7          	jalr	ra # 80002114 <sleep>
  for(int i = 0; i < 3; i++){
    8000611c:	f8040a13          	addi	s4,s0,-128
{
    80006120:	8652                	mv	a2,s4
  for(int i = 0; i < 3; i++){
    80006122:	894e                	mv	s2,s3
    80006124:	b77d                	j	800060d2 <virtio_disk_rw+0x6e>
  }

  // format the three descriptors.
  // qemu's virtio-blk.c reads them.

  struct virtio_blk_req *buf0 = &disk.ops[idx[0]];
    80006126:	f8042583          	lw	a1,-128(s0)
    8000612a:	00a58793          	addi	a5,a1,10
    8000612e:	0792                	slli	a5,a5,0x4

  if(write)
    80006130:	0001c617          	auipc	a2,0x1c
    80006134:	67060613          	addi	a2,a2,1648 # 800227a0 <disk>
    80006138:	00f60733          	add	a4,a2,a5
    8000613c:	018036b3          	snez	a3,s8
    80006140:	c714                	sw	a3,8(a4)
    buf0->type = VIRTIO_BLK_T_OUT; // write the disk
  else
    buf0->type = VIRTIO_BLK_T_IN; // read the disk
  buf0->reserved = 0;
    80006142:	00072623          	sw	zero,12(a4)
  buf0->sector = sector;
    80006146:	01a73823          	sd	s10,16(a4)

  disk.desc[idx[0]].addr = (uint64) buf0;
    8000614a:	f6078693          	addi	a3,a5,-160
    8000614e:	6218                	ld	a4,0(a2)
    80006150:	9736                	add	a4,a4,a3
  struct virtio_blk_req *buf0 = &disk.ops[idx[0]];
    80006152:	00878513          	addi	a0,a5,8
    80006156:	9532                	add	a0,a0,a2
  disk.desc[idx[0]].addr = (uint64) buf0;
    80006158:	e308                	sd	a0,0(a4)
  disk.desc[idx[0]].len = sizeof(struct virtio_blk_req);
    8000615a:	6208                	ld	a0,0(a2)
    8000615c:	96aa                	add	a3,a3,a0
    8000615e:	4741                	li	a4,16
    80006160:	c698                	sw	a4,8(a3)
  disk.desc[idx[0]].flags = VRING_DESC_F_NEXT;
    80006162:	4705                	li	a4,1
    80006164:	00e69623          	sh	a4,12(a3)
  disk.desc[idx[0]].next = idx[1];
    80006168:	f8442703          	lw	a4,-124(s0)
    8000616c:	00e69723          	sh	a4,14(a3)

  disk.desc[idx[1]].addr = (uint64) b->data;
    80006170:	0712                	slli	a4,a4,0x4
    80006172:	953a                	add	a0,a0,a4
    80006174:	058a8693          	addi	a3,s5,88
    80006178:	e114                	sd	a3,0(a0)
  disk.desc[idx[1]].len = BSIZE;
    8000617a:	6208                	ld	a0,0(a2)
    8000617c:	972a                	add	a4,a4,a0
    8000617e:	40000693          	li	a3,1024
    80006182:	c714                	sw	a3,8(a4)
  if(write)
    disk.desc[idx[1]].flags = 0; // device reads b->data
  else
    disk.desc[idx[1]].flags = VRING_DESC_F_WRITE; // device writes b->data
    80006184:	001c3c13          	seqz	s8,s8
    80006188:	0c06                	slli	s8,s8,0x1
  disk.desc[idx[1]].flags |= VRING_DESC_F_NEXT;
    8000618a:	001c6c13          	ori	s8,s8,1
    8000618e:	01871623          	sh	s8,12(a4)
  disk.desc[idx[1]].next = idx[2];
    80006192:	f8842603          	lw	a2,-120(s0)
    80006196:	00c71723          	sh	a2,14(a4)

  disk.info[idx[0]].status = 0xff; // device writes 0 on success
    8000619a:	0001c697          	auipc	a3,0x1c
    8000619e:	60668693          	addi	a3,a3,1542 # 800227a0 <disk>
    800061a2:	00258713          	addi	a4,a1,2
    800061a6:	0712                	slli	a4,a4,0x4
    800061a8:	9736                	add	a4,a4,a3
    800061aa:	587d                	li	a6,-1
    800061ac:	01070823          	sb	a6,16(a4)
  disk.desc[idx[2]].addr = (uint64) &disk.info[idx[0]].status;
    800061b0:	0612                	slli	a2,a2,0x4
    800061b2:	9532                	add	a0,a0,a2
    800061b4:	f9078793          	addi	a5,a5,-112
    800061b8:	97b6                	add	a5,a5,a3
    800061ba:	e11c                	sd	a5,0(a0)
  disk.desc[idx[2]].len = 1;
    800061bc:	629c                	ld	a5,0(a3)
    800061be:	97b2                	add	a5,a5,a2
    800061c0:	4605                	li	a2,1
    800061c2:	c790                	sw	a2,8(a5)
  disk.desc[idx[2]].flags = VRING_DESC_F_WRITE; // device writes the status
    800061c4:	4509                	li	a0,2
    800061c6:	00a79623          	sh	a0,12(a5)
  disk.desc[idx[2]].next = 0;
    800061ca:	00079723          	sh	zero,14(a5)

  // record struct buf for virtio_disk_intr().
  b->disk = 1;
    800061ce:	00caa223          	sw	a2,4(s5)
  disk.info[idx[0]].b = b;
    800061d2:	01573423          	sd	s5,8(a4)

  // tell the device the first index in our chain of descriptors.
  disk.avail->ring[disk.avail->idx % NUM] = idx[0];
    800061d6:	6698                	ld	a4,8(a3)
    800061d8:	00275783          	lhu	a5,2(a4)
    800061dc:	8b9d                	andi	a5,a5,7
    800061de:	0786                	slli	a5,a5,0x1
    800061e0:	97ba                	add	a5,a5,a4
    800061e2:	00b79223          	sh	a1,4(a5)

  __sync_synchronize();
    800061e6:	0ff0000f          	fence

  // tell the device another avail ring entry is available.
  disk.avail->idx += 1; // not % NUM ...
    800061ea:	6698                	ld	a4,8(a3)
    800061ec:	00275783          	lhu	a5,2(a4)
    800061f0:	2785                	addiw	a5,a5,1
    800061f2:	00f71123          	sh	a5,2(a4)

  __sync_synchronize();
    800061f6:	0ff0000f          	fence

  *R(VIRTIO_MMIO_QUEUE_NOTIFY) = 0; // value is queue number
    800061fa:	100017b7          	lui	a5,0x10001
    800061fe:	0407a823          	sw	zero,80(a5) # 10001050 <_entry-0x6fffefb0>

  // Wait for virtio_disk_intr() to say request has finished.
  while(b->disk == 1) {
    80006202:	004aa783          	lw	a5,4(s5)
    80006206:	02c79163          	bne	a5,a2,80006228 <virtio_disk_rw+0x1c4>
    sleep(b, &disk.vdisk_lock);
    8000620a:	0001c917          	auipc	s2,0x1c
    8000620e:	6be90913          	addi	s2,s2,1726 # 800228c8 <disk+0x128>
  while(b->disk == 1) {
    80006212:	4485                	li	s1,1
    sleep(b, &disk.vdisk_lock);
    80006214:	85ca                	mv	a1,s2
    80006216:	8556                	mv	a0,s5
    80006218:	ffffc097          	auipc	ra,0xffffc
    8000621c:	efc080e7          	jalr	-260(ra) # 80002114 <sleep>
  while(b->disk == 1) {
    80006220:	004aa783          	lw	a5,4(s5)
    80006224:	fe9788e3          	beq	a5,s1,80006214 <virtio_disk_rw+0x1b0>
  }

  disk.info[idx[0]].b = 0;
    80006228:	f8042903          	lw	s2,-128(s0)
    8000622c:	00290793          	addi	a5,s2,2
    80006230:	00479713          	slli	a4,a5,0x4
    80006234:	0001c797          	auipc	a5,0x1c
    80006238:	56c78793          	addi	a5,a5,1388 # 800227a0 <disk>
    8000623c:	97ba                	add	a5,a5,a4
    8000623e:	0007b423          	sd	zero,8(a5)
    int flag = disk.desc[i].flags;
    80006242:	0001c997          	auipc	s3,0x1c
    80006246:	55e98993          	addi	s3,s3,1374 # 800227a0 <disk>
    8000624a:	00491713          	slli	a4,s2,0x4
    8000624e:	0009b783          	ld	a5,0(s3)
    80006252:	97ba                	add	a5,a5,a4
    80006254:	00c7d483          	lhu	s1,12(a5)
    int nxt = disk.desc[i].next;
    80006258:	854a                	mv	a0,s2
    8000625a:	00e7d903          	lhu	s2,14(a5)
    free_desc(i);
    8000625e:	00000097          	auipc	ra,0x0
    80006262:	b98080e7          	jalr	-1128(ra) # 80005df6 <free_desc>
    if(flag & VRING_DESC_F_NEXT)
    80006266:	8885                	andi	s1,s1,1
    80006268:	f0ed                	bnez	s1,8000624a <virtio_disk_rw+0x1e6>
  free_chain(idx[0]);

  release(&disk.vdisk_lock);
    8000626a:	0001c517          	auipc	a0,0x1c
    8000626e:	65e50513          	addi	a0,a0,1630 # 800228c8 <disk+0x128>
    80006272:	ffffb097          	auipc	ra,0xffffb
    80006276:	a18080e7          	jalr	-1512(ra) # 80000c8a <release>
}
    8000627a:	70e6                	ld	ra,120(sp)
    8000627c:	7446                	ld	s0,112(sp)
    8000627e:	74a6                	ld	s1,104(sp)
    80006280:	7906                	ld	s2,96(sp)
    80006282:	69e6                	ld	s3,88(sp)
    80006284:	6a46                	ld	s4,80(sp)
    80006286:	6aa6                	ld	s5,72(sp)
    80006288:	6b06                	ld	s6,64(sp)
    8000628a:	7be2                	ld	s7,56(sp)
    8000628c:	7c42                	ld	s8,48(sp)
    8000628e:	7ca2                	ld	s9,40(sp)
    80006290:	7d02                	ld	s10,32(sp)
    80006292:	6de2                	ld	s11,24(sp)
    80006294:	6109                	addi	sp,sp,128
    80006296:	8082                	ret

0000000080006298 <virtio_disk_intr>:

void
virtio_disk_intr()
{
    80006298:	1101                	addi	sp,sp,-32
    8000629a:	ec06                	sd	ra,24(sp)
    8000629c:	e822                	sd	s0,16(sp)
    8000629e:	e426                	sd	s1,8(sp)
    800062a0:	1000                	addi	s0,sp,32
  acquire(&disk.vdisk_lock);
    800062a2:	0001c497          	auipc	s1,0x1c
    800062a6:	4fe48493          	addi	s1,s1,1278 # 800227a0 <disk>
    800062aa:	0001c517          	auipc	a0,0x1c
    800062ae:	61e50513          	addi	a0,a0,1566 # 800228c8 <disk+0x128>
    800062b2:	ffffb097          	auipc	ra,0xffffb
    800062b6:	924080e7          	jalr	-1756(ra) # 80000bd6 <acquire>
  // we've seen this interrupt, which the following line does.
  // this may race with the device writing new entries to
  // the "used" ring, in which case we may process the new
  // completion entries in this interrupt, and have nothing to do
  // in the next interrupt, which is harmless.
  *R(VIRTIO_MMIO_INTERRUPT_ACK) = *R(VIRTIO_MMIO_INTERRUPT_STATUS) & 0x3;
    800062ba:	10001737          	lui	a4,0x10001
    800062be:	533c                	lw	a5,96(a4)
    800062c0:	8b8d                	andi	a5,a5,3
    800062c2:	d37c                	sw	a5,100(a4)

  __sync_synchronize();
    800062c4:	0ff0000f          	fence

  // the device increments disk.used->idx when it
  // adds an entry to the used ring.

  while(disk.used_idx != disk.used->idx){
    800062c8:	689c                	ld	a5,16(s1)
    800062ca:	0204d703          	lhu	a4,32(s1)
    800062ce:	0027d783          	lhu	a5,2(a5)
    800062d2:	04f70863          	beq	a4,a5,80006322 <virtio_disk_intr+0x8a>
    __sync_synchronize();
    800062d6:	0ff0000f          	fence
    int id = disk.used->ring[disk.used_idx % NUM].id;
    800062da:	6898                	ld	a4,16(s1)
    800062dc:	0204d783          	lhu	a5,32(s1)
    800062e0:	8b9d                	andi	a5,a5,7
    800062e2:	078e                	slli	a5,a5,0x3
    800062e4:	97ba                	add	a5,a5,a4
    800062e6:	43dc                	lw	a5,4(a5)

    if(disk.info[id].status != 0)
    800062e8:	00278713          	addi	a4,a5,2
    800062ec:	0712                	slli	a4,a4,0x4
    800062ee:	9726                	add	a4,a4,s1
    800062f0:	01074703          	lbu	a4,16(a4) # 10001010 <_entry-0x6fffeff0>
    800062f4:	e721                	bnez	a4,8000633c <virtio_disk_intr+0xa4>
      panic("virtio_disk_intr status");

    struct buf *b = disk.info[id].b;
    800062f6:	0789                	addi	a5,a5,2
    800062f8:	0792                	slli	a5,a5,0x4
    800062fa:	97a6                	add	a5,a5,s1
    800062fc:	6788                	ld	a0,8(a5)
    b->disk = 0;   // disk is done with buf
    800062fe:	00052223          	sw	zero,4(a0)
    wakeup(b);
    80006302:	ffffc097          	auipc	ra,0xffffc
    80006306:	e76080e7          	jalr	-394(ra) # 80002178 <wakeup>

    disk.used_idx += 1;
    8000630a:	0204d783          	lhu	a5,32(s1)
    8000630e:	2785                	addiw	a5,a5,1
    80006310:	17c2                	slli	a5,a5,0x30
    80006312:	93c1                	srli	a5,a5,0x30
    80006314:	02f49023          	sh	a5,32(s1)
  while(disk.used_idx != disk.used->idx){
    80006318:	6898                	ld	a4,16(s1)
    8000631a:	00275703          	lhu	a4,2(a4)
    8000631e:	faf71ce3          	bne	a4,a5,800062d6 <virtio_disk_intr+0x3e>
  }

  release(&disk.vdisk_lock);
    80006322:	0001c517          	auipc	a0,0x1c
    80006326:	5a650513          	addi	a0,a0,1446 # 800228c8 <disk+0x128>
    8000632a:	ffffb097          	auipc	ra,0xffffb
    8000632e:	960080e7          	jalr	-1696(ra) # 80000c8a <release>
}
    80006332:	60e2                	ld	ra,24(sp)
    80006334:	6442                	ld	s0,16(sp)
    80006336:	64a2                	ld	s1,8(sp)
    80006338:	6105                	addi	sp,sp,32
    8000633a:	8082                	ret
      panic("virtio_disk_intr status");
    8000633c:	00002517          	auipc	a0,0x2
    80006340:	51c50513          	addi	a0,a0,1308 # 80008858 <syscalls+0x3e8>
    80006344:	ffffa097          	auipc	ra,0xffffa
    80006348:	1fa080e7          	jalr	506(ra) # 8000053e <panic>

000000008000634c <free_desc>:
    panic("virtio_gpu: no free descriptors");
}

static void
free_desc(int i)
{
    8000634c:	1141                	addi	sp,sp,-16
    8000634e:	e422                	sd	s0,8(sp)
    80006350:	0800                	addi	s0,sp,16
    gq.desc[i].addr = 0;
    80006352:	0001c717          	auipc	a4,0x1c
    80006356:	58e70713          	addi	a4,a4,1422 # 800228e0 <gq>
    8000635a:	00451693          	slli	a3,a0,0x4
    8000635e:	631c                	ld	a5,0(a4)
    80006360:	97b6                	add	a5,a5,a3
    80006362:	0007b023          	sd	zero,0(a5)
    gq.desc[i].len = 0;
    80006366:	0007a423          	sw	zero,8(a5)
    gq.desc[i].flags = 0;
    8000636a:	00079623          	sh	zero,12(a5)
    gq.desc[i].next = 0;
    8000636e:	00079723          	sh	zero,14(a5)
    gq.free[i] = 1;
    80006372:	972a                	add	a4,a4,a0
    80006374:	4785                	li	a5,1
    80006376:	00f70c23          	sb	a5,24(a4)
}
    8000637a:	6422                	ld	s0,8(sp)
    8000637c:	0141                	addi	sp,sp,16
    8000637e:	8082                	ret

0000000080006380 <alloc_desc>:
    for (int i = 0; i < GPU_NUM; i++)
    80006380:	0001c797          	auipc	a5,0x1c
    80006384:	56078793          	addi	a5,a5,1376 # 800228e0 <gq>
    80006388:	4501                	li	a0,0
    8000638a:	46a1                	li	a3,8
        if (gq.free[i])
    8000638c:	0187c703          	lbu	a4,24(a5)
    80006390:	e30d                	bnez	a4,800063b2 <alloc_desc+0x32>
    for (int i = 0; i < GPU_NUM; i++)
    80006392:	2505                	addiw	a0,a0,1
    80006394:	0785                	addi	a5,a5,1
    80006396:	fed51be3          	bne	a0,a3,8000638c <alloc_desc+0xc>
{
    8000639a:	1141                	addi	sp,sp,-16
    8000639c:	e406                	sd	ra,8(sp)
    8000639e:	e022                	sd	s0,0(sp)
    800063a0:	0800                	addi	s0,sp,16
    panic("virtio_gpu: no free descriptors");
    800063a2:	00002517          	auipc	a0,0x2
    800063a6:	4ce50513          	addi	a0,a0,1230 # 80008870 <syscalls+0x400>
    800063aa:	ffffa097          	auipc	ra,0xffffa
    800063ae:	194080e7          	jalr	404(ra) # 8000053e <panic>
            gq.free[i] = 0;
    800063b2:	0001c797          	auipc	a5,0x1c
    800063b6:	52e78793          	addi	a5,a5,1326 # 800228e0 <gq>
    800063ba:	97aa                	add	a5,a5,a0
    800063bc:	00078c23          	sb	zero,24(a5)
}
    800063c0:	8082                	ret

00000000800063c2 <gpu_send>:

// Submit a 2-descriptor command (request + shared response) and block
// until the device completes it by advancing the used ring.
static void
gpu_send(void *req, int req_len)
{
    800063c2:	7139                	addi	sp,sp,-64
    800063c4:	fc06                	sd	ra,56(sp)
    800063c6:	f822                	sd	s0,48(sp)
    800063c8:	f426                	sd	s1,40(sp)
    800063ca:	f04a                	sd	s2,32(sp)
    800063cc:	ec4e                	sd	s3,24(sp)
    800063ce:	e852                	sd	s4,16(sp)
    800063d0:	e456                	sd	s5,8(sp)
    800063d2:	0080                	addi	s0,sp,64
    800063d4:	8aaa                	mv	s5,a0
    800063d6:	8a2e                	mv	s4,a1
    acquire(&gpu_lock);
    800063d8:	0001c997          	auipc	s3,0x1c
    800063dc:	50898993          	addi	s3,s3,1288 # 800228e0 <gq>
    800063e0:	0001c517          	auipc	a0,0x1c
    800063e4:	52850513          	addi	a0,a0,1320 # 80022908 <gpu_lock>
    800063e8:	ffffa097          	auipc	ra,0xffffa
    800063ec:	7ee080e7          	jalr	2030(ra) # 80000bd6 <acquire>
    int d0 = alloc_desc();
    800063f0:	00000097          	auipc	ra,0x0
    800063f4:	f90080e7          	jalr	-112(ra) # 80006380 <alloc_desc>
    800063f8:	892a                	mv	s2,a0
    int d1 = alloc_desc();
    800063fa:	00000097          	auipc	ra,0x0
    800063fe:	f86080e7          	jalr	-122(ra) # 80006380 <alloc_desc>
    80006402:	84aa                	mv	s1,a0

    gq.desc[d0].addr = (uint64)req;
    80006404:	00491793          	slli	a5,s2,0x4
    80006408:	0009b703          	ld	a4,0(s3)
    8000640c:	973e                	add	a4,a4,a5
    8000640e:	01573023          	sd	s5,0(a4)
    gq.desc[d0].len = (uint32)req_len;
    80006412:	0009b703          	ld	a4,0(s3)
    80006416:	97ba                	add	a5,a5,a4
    80006418:	0147a423          	sw	s4,8(a5)
    gq.desc[d0].flags = VRING_DESC_F_NEXT;
    8000641c:	4685                	li	a3,1
    8000641e:	00d79623          	sh	a3,12(a5)
    gq.desc[d0].next = d1;
    80006422:	00a79723          	sh	a0,14(a5)

    gq.desc[d1].addr = (uint64)&cmd_resp;
    80006426:	00451693          	slli	a3,a0,0x4
    8000642a:	9736                	add	a4,a4,a3
    8000642c:	0001c797          	auipc	a5,0x1c
    80006430:	4f478793          	addi	a5,a5,1268 # 80022920 <cmd_resp>
    80006434:	e31c                	sd	a5,0(a4)
    gq.desc[d1].len = sizeof(cmd_resp);
    80006436:	0009b783          	ld	a5,0(s3)
    8000643a:	97b6                	add	a5,a5,a3
    8000643c:	4761                	li	a4,24
    8000643e:	c798                	sw	a4,8(a5)
    gq.desc[d1].flags = VRING_DESC_F_WRITE;
    80006440:	4709                	li	a4,2
    80006442:	00e79623          	sh	a4,12(a5)
    gq.desc[d1].next = 0;
    80006446:	00079723          	sh	zero,14(a5)

    // Place head descriptor index in the available ring.
    gq.avail->ring[gq.avail->idx % GPU_NUM] = d0;
    8000644a:	0089b703          	ld	a4,8(s3)
    8000644e:	00275783          	lhu	a5,2(a4)
    80006452:	8b9d                	andi	a5,a5,7
    80006454:	0786                	slli	a5,a5,0x1
    80006456:	97ba                	add	a5,a5,a4
    80006458:	01279223          	sh	s2,4(a5)
    __sync_synchronize();
    8000645c:	0ff0000f          	fence
    gq.avail->idx++;
    80006460:	0089b703          	ld	a4,8(s3)
    80006464:	00275783          	lhu	a5,2(a4)
    80006468:	2785                	addiw	a5,a5,1
    8000646a:	00f71123          	sh	a5,2(a4)
    __sync_synchronize();
    8000646e:	0ff0000f          	fence

    // Notify device (queue index 0 = controlq).
    *R1(VIRTIO_MMIO_QUEUE_NOTIFY) = 0;
    80006472:	100027b7          	lui	a5,0x10002
    80006476:	0407a823          	sw	zero,80(a5) # 10002050 <_entry-0x6fffdfb0>

    // Poll until the device advances the used ring.
    while (1)
    {
        __sync_synchronize();
        if (gq.used->idx != gq.used_idx)
    8000647a:	874e                	mv	a4,s3
        __sync_synchronize();
    8000647c:	0ff0000f          	fence
        if (gq.used->idx != gq.used_idx)
    80006480:	02075783          	lhu	a5,32(a4)
    80006484:	6b14                	ld	a3,16(a4)
    80006486:	0026d683          	lhu	a3,2(a3)
    8000648a:	fef689e3          	beq	a3,a5,8000647c <gpu_send+0xba>
            break;
    }
    gq.used_idx++;
    8000648e:	2785                	addiw	a5,a5,1
    80006490:	0001c717          	auipc	a4,0x1c
    80006494:	46f71823          	sh	a5,1136(a4) # 80022900 <gq+0x20>

    free_desc(d0);
    80006498:	854a                	mv	a0,s2
    8000649a:	00000097          	auipc	ra,0x0
    8000649e:	eb2080e7          	jalr	-334(ra) # 8000634c <free_desc>
    free_desc(d1);
    800064a2:	8526                	mv	a0,s1
    800064a4:	00000097          	auipc	ra,0x0
    800064a8:	ea8080e7          	jalr	-344(ra) # 8000634c <free_desc>
    release(&gpu_lock);
    800064ac:	0001c517          	auipc	a0,0x1c
    800064b0:	45c50513          	addi	a0,a0,1116 # 80022908 <gpu_lock>
    800064b4:	ffffa097          	auipc	ra,0xffffa
    800064b8:	7d6080e7          	jalr	2006(ra) # 80000c8a <release>
}
    800064bc:	70e2                	ld	ra,56(sp)
    800064be:	7442                	ld	s0,48(sp)
    800064c0:	74a2                	ld	s1,40(sp)
    800064c2:	7902                	ld	s2,32(sp)
    800064c4:	69e2                	ld	s3,24(sp)
    800064c6:	6a42                	ld	s4,16(sp)
    800064c8:	6aa2                	ld	s5,8(sp)
    800064ca:	6121                	addi	sp,sp,64
    800064cc:	8082                	ret

00000000800064ce <gpu_cmd_attach>:
{
    800064ce:	1141                	addi	sp,sp,-16
    800064d0:	e406                	sd	ra,8(sp)
    800064d2:	e022                	sd	s0,0(sp)
    800064d4:	0800                	addi	s0,sp,16
    attach_buf.backing.hdr.type = VIRTIO_GPU_CMD_RESOURCE_ATTACH_BACKING;
    800064d6:	00020797          	auipc	a5,0x20
    800064da:	d8278793          	addi	a5,a5,-638 # 80026258 <attach_buf>
    800064de:	10600713          	li	a4,262
    800064e2:	c398                	sw	a4,0(a5)
    attach_buf.backing.resource_id = RESOURCE_ID;
    800064e4:	4705                	li	a4,1
    800064e6:	cf98                	sw	a4,24(a5)
    attach_buf.backing.nr_entries = n;
    800064e8:	0005861b          	sext.w	a2,a1
    800064ec:	cfd0                	sw	a2,28(a5)
    for (int i = 0; i < n; i++)
    800064ee:	02b05663          	blez	a1,8000651a <gpu_cmd_attach+0x4c>
    800064f2:	87aa                	mv	a5,a0
    800064f4:	00020717          	auipc	a4,0x20
    800064f8:	d8470713          	addi	a4,a4,-636 # 80026278 <attach_buf+0x20>
    800064fc:	fff6069b          	addiw	a3,a2,-1
    80006500:	1682                	slli	a3,a3,0x20
    80006502:	9281                	srli	a3,a3,0x20
    80006504:	0692                	slli	a3,a3,0x4
    80006506:	0541                	addi	a0,a0,16
    80006508:	96aa                	add	a3,a3,a0
        attach_buf.entries[i] = entries[i];
    8000650a:	6390                	ld	a2,0(a5)
    8000650c:	e310                	sd	a2,0(a4)
    8000650e:	6790                	ld	a2,8(a5)
    80006510:	e710                	sd	a2,8(a4)
    for (int i = 0; i < n; i++)
    80006512:	07c1                	addi	a5,a5,16
    80006514:	0741                	addi	a4,a4,16
    80006516:	fed79ae3          	bne	a5,a3,8000650a <gpu_cmd_attach+0x3c>
    gpu_send(&attach_buf, sizeof(attach_buf));
    8000651a:	6585                	lui	a1,0x1
    8000651c:	2e058593          	addi	a1,a1,736 # 12e0 <_entry-0x7fffed20>
    80006520:	00020517          	auipc	a0,0x20
    80006524:	d3850513          	addi	a0,a0,-712 # 80026258 <attach_buf>
    80006528:	00000097          	auipc	ra,0x0
    8000652c:	e9a080e7          	jalr	-358(ra) # 800063c2 <gpu_send>
}
    80006530:	60a2                	ld	ra,8(sp)
    80006532:	6402                	ld	s0,0(sp)
    80006534:	0141                	addi	sp,sp,16
    80006536:	8082                	ret

0000000080006538 <gpu_transfer_flush>:
{
    80006538:	7139                	addi	sp,sp,-64
    8000653a:	fc06                	sd	ra,56(sp)
    8000653c:	f822                	sd	s0,48(sp)
    8000653e:	f426                	sd	s1,40(sp)
    80006540:	f04a                	sd	s2,32(sp)
    80006542:	ec4e                	sd	s3,24(sp)
    80006544:	e852                	sd	s4,16(sp)
    80006546:	e456                	sd	s5,8(sp)
    80006548:	0080                	addi	s0,sp,64
    memset(&xfer, 0, sizeof(xfer));
    8000654a:	0001c497          	auipc	s1,0x1c
    8000654e:	39648493          	addi	s1,s1,918 # 800228e0 <gq>
    80006552:	0001c917          	auipc	s2,0x1c
    80006556:	3e690913          	addi	s2,s2,998 # 80022938 <xfer.4>
    8000655a:	03800613          	li	a2,56
    8000655e:	4581                	li	a1,0
    80006560:	854a                	mv	a0,s2
    80006562:	ffffa097          	auipc	ra,0xffffa
    80006566:	770080e7          	jalr	1904(ra) # 80000cd2 <memset>
    xfer.hdr.type = VIRTIO_GPU_CMD_TRANSFER_TO_HOST_2D;
    8000656a:	10500793          	li	a5,261
    8000656e:	ccbc                	sw	a5,88(s1)
    xfer.r.x = 0;
    80006570:	0604a823          	sw	zero,112(s1)
    xfer.r.y = 0;
    80006574:	0604aa23          	sw	zero,116(s1)
    xfer.r.width = SCREEN_W;
    80006578:	28000a93          	li	s5,640
    8000657c:	0754ac23          	sw	s5,120(s1)
    xfer.r.height = SCREEN_H;
    80006580:	1e000a13          	li	s4,480
    80006584:	0744ae23          	sw	s4,124(s1)
    xfer.resource_id = RESOURCE_ID;
    80006588:	4985                	li	s3,1
    8000658a:	0934a423          	sw	s3,136(s1)
    gpu_send(&xfer, sizeof(xfer));
    8000658e:	03800593          	li	a1,56
    80006592:	854a                	mv	a0,s2
    80006594:	00000097          	auipc	ra,0x0
    80006598:	e2e080e7          	jalr	-466(ra) # 800063c2 <gpu_send>
    memset(&flush, 0, sizeof(flush));
    8000659c:	0001c917          	auipc	s2,0x1c
    800065a0:	3d490913          	addi	s2,s2,980 # 80022970 <flush.3>
    800065a4:	03000613          	li	a2,48
    800065a8:	4581                	li	a1,0
    800065aa:	854a                	mv	a0,s2
    800065ac:	ffffa097          	auipc	ra,0xffffa
    800065b0:	726080e7          	jalr	1830(ra) # 80000cd2 <memset>
    flush.hdr.type = VIRTIO_GPU_CMD_RESOURCE_FLUSH;
    800065b4:	10400793          	li	a5,260
    800065b8:	08f4a823          	sw	a5,144(s1)
    flush.r.x = 0;
    800065bc:	0a04a423          	sw	zero,168(s1)
    flush.r.y = 0;
    800065c0:	0a04a623          	sw	zero,172(s1)
    flush.r.width = SCREEN_W;
    800065c4:	0b54a823          	sw	s5,176(s1)
    flush.r.height = SCREEN_H;
    800065c8:	0b44aa23          	sw	s4,180(s1)
    flush.resource_id = RESOURCE_ID;
    800065cc:	0b34ac23          	sw	s3,184(s1)
    gpu_send(&flush, sizeof(flush));
    800065d0:	03000593          	li	a1,48
    800065d4:	854a                	mv	a0,s2
    800065d6:	00000097          	auipc	ra,0x0
    800065da:	dec080e7          	jalr	-532(ra) # 800063c2 <gpu_send>
}
    800065de:	70e2                	ld	ra,56(sp)
    800065e0:	7442                	ld	s0,48(sp)
    800065e2:	74a2                	ld	s1,40(sp)
    800065e4:	7902                	ld	s2,32(sp)
    800065e6:	69e2                	ld	s3,24(sp)
    800065e8:	6a42                	ld	s4,16(sp)
    800065ea:	6aa2                	ld	s5,8(sp)
    800065ec:	6121                	addi	sp,sp,64
    800065ee:	8082                	ret

00000000800065f0 <gpu_cmd_detach>:
{
    800065f0:	1101                	addi	sp,sp,-32
    800065f2:	ec06                	sd	ra,24(sp)
    800065f4:	e822                	sd	s0,16(sp)
    800065f6:	e426                	sd	s1,8(sp)
    800065f8:	e04a                	sd	s2,0(sp)
    800065fa:	1000                	addi	s0,sp,32
    memset(&detach, 0, sizeof(detach));
    800065fc:	0001c917          	auipc	s2,0x1c
    80006600:	2e490913          	addi	s2,s2,740 # 800228e0 <gq>
    80006604:	0001c497          	auipc	s1,0x1c
    80006608:	39c48493          	addi	s1,s1,924 # 800229a0 <detach.1>
    8000660c:	02000613          	li	a2,32
    80006610:	4581                	li	a1,0
    80006612:	8526                	mv	a0,s1
    80006614:	ffffa097          	auipc	ra,0xffffa
    80006618:	6be080e7          	jalr	1726(ra) # 80000cd2 <memset>
    detach.hdr.type = VIRTIO_GPU_CMD_RESOURCE_DETACH_BACKING;
    8000661c:	10700793          	li	a5,263
    80006620:	0cf92023          	sw	a5,192(s2)
    detach.resource_id = RESOURCE_ID;
    80006624:	4785                	li	a5,1
    80006626:	0cf92c23          	sw	a5,216(s2)
    gpu_send(&detach, sizeof(detach));
    8000662a:	02000593          	li	a1,32
    8000662e:	8526                	mv	a0,s1
    80006630:	00000097          	auipc	ra,0x0
    80006634:	d92080e7          	jalr	-622(ra) # 800063c2 <gpu_send>
}
    80006638:	60e2                	ld	ra,24(sp)
    8000663a:	6442                	ld	s0,16(sp)
    8000663c:	64a2                	ld	s1,8(sp)
    8000663e:	6902                	ld	s2,0(sp)
    80006640:	6105                	addi	sp,sp,32
    80006642:	8082                	ret

0000000080006644 <virtio_gpu_init>:

// ── Public init ───────────────────────────────────────────────────────

void virtio_gpu_init(void)
{
    80006644:	7159                	addi	sp,sp,-112
    80006646:	f486                	sd	ra,104(sp)
    80006648:	f0a2                	sd	s0,96(sp)
    8000664a:	eca6                	sd	s1,88(sp)
    8000664c:	e8ca                	sd	s2,80(sp)
    8000664e:	e4ce                	sd	s3,72(sp)
    80006650:	e0d2                	sd	s4,64(sp)
    80006652:	fc56                	sd	s5,56(sp)
    80006654:	f85a                	sd	s6,48(sp)
    80006656:	f45e                	sd	s7,40(sp)
    80006658:	f062                	sd	s8,32(sp)
    8000665a:	ec66                	sd	s9,24(sp)
    8000665c:	e86a                	sd	s10,16(sp)
    8000665e:	e46e                	sd	s11,8(sp)
    80006660:	1880                	addi	s0,sp,112
    uint32 status = 0;
    initlock(&gpu_lock, "vgpu");
    80006662:	00002597          	auipc	a1,0x2
    80006666:	22e58593          	addi	a1,a1,558 # 80008890 <syscalls+0x420>
    8000666a:	0001c517          	auipc	a0,0x1c
    8000666e:	29e50513          	addi	a0,a0,670 # 80022908 <gpu_lock>
    80006672:	ffffa097          	auipc	ra,0xffffa
    80006676:	4d4080e7          	jalr	1236(ra) # 80000b46 <initlock>

    // ── 1. VirtIO device handshake ──────────────────────────────────────
    if (*R1(VIRTIO_MMIO_MAGIC_VALUE) != 0x74726976 ||
    8000667a:	100027b7          	lui	a5,0x10002
    8000667e:	4398                	lw	a4,0(a5)
    80006680:	2701                	sext.w	a4,a4
    80006682:	747277b7          	lui	a5,0x74727
    80006686:	97678793          	addi	a5,a5,-1674 # 74726976 <_entry-0xb8d968a>
    8000668a:	02f71a63          	bne	a4,a5,800066be <virtio_gpu_init+0x7a>
        *R1(VIRTIO_MMIO_VERSION) != 2 ||
    8000668e:	100027b7          	lui	a5,0x10002
    80006692:	43dc                	lw	a5,4(a5)
    80006694:	2781                	sext.w	a5,a5
    if (*R1(VIRTIO_MMIO_MAGIC_VALUE) != 0x74726976 ||
    80006696:	4709                	li	a4,2
    80006698:	02e79363          	bne	a5,a4,800066be <virtio_gpu_init+0x7a>
        *R1(VIRTIO_MMIO_DEVICE_ID) != VIRTIO_ID_GPU ||
    8000669c:	100027b7          	lui	a5,0x10002
    800066a0:	479c                	lw	a5,8(a5)
    800066a2:	2781                	sext.w	a5,a5
        *R1(VIRTIO_MMIO_VERSION) != 2 ||
    800066a4:	4741                	li	a4,16
    800066a6:	00e79c63          	bne	a5,a4,800066be <virtio_gpu_init+0x7a>
        *R1(VIRTIO_MMIO_VENDOR_ID) != 0x554d4551)
    800066aa:	100027b7          	lui	a5,0x10002
    800066ae:	47d8                	lw	a4,12(a5)
    800066b0:	2701                	sext.w	a4,a4
        *R1(VIRTIO_MMIO_DEVICE_ID) != VIRTIO_ID_GPU ||
    800066b2:	554d47b7          	lui	a5,0x554d4
    800066b6:	55178793          	addi	a5,a5,1361 # 554d4551 <_entry-0x2ab2baaf>
    800066ba:	02f70963          	beq	a4,a5,800066ec <virtio_gpu_init+0xa8>
    {
        printf("virtio_gpu_init: GPU not found\n");
    800066be:	00002517          	auipc	a0,0x2
    800066c2:	1da50513          	addi	a0,a0,474 # 80008898 <syscalls+0x428>
    800066c6:	ffffa097          	auipc	ra,0xffffa
    800066ca:	ec2080e7          	jalr	-318(ra) # 80000588 <printf>
    gpu_send(&scanout_req, sizeof(scanout_req));

    // ── 8. TRANSFER_TO_HOST_2D (upload guest memory -> host GPU) ─────────
    gpu_transfer_flush();
    printf("virtio_gpu: \"Hello World\" displayed on 640x480 window\n");
}
    800066ce:	70a6                	ld	ra,104(sp)
    800066d0:	7406                	ld	s0,96(sp)
    800066d2:	64e6                	ld	s1,88(sp)
    800066d4:	6946                	ld	s2,80(sp)
    800066d6:	69a6                	ld	s3,72(sp)
    800066d8:	6a06                	ld	s4,64(sp)
    800066da:	7ae2                	ld	s5,56(sp)
    800066dc:	7b42                	ld	s6,48(sp)
    800066de:	7ba2                	ld	s7,40(sp)
    800066e0:	7c02                	ld	s8,32(sp)
    800066e2:	6ce2                	ld	s9,24(sp)
    800066e4:	6d42                	ld	s10,16(sp)
    800066e6:	6da2                	ld	s11,8(sp)
    800066e8:	6165                	addi	sp,sp,112
    800066ea:	8082                	ret
    *R1(VIRTIO_MMIO_STATUS) = status;
    800066ec:	100027b7          	lui	a5,0x10002
    800066f0:	0607a823          	sw	zero,112(a5) # 10002070 <_entry-0x6fffdf90>
    *R1(VIRTIO_MMIO_STATUS) = status;
    800066f4:	4705                	li	a4,1
    800066f6:	dbb8                	sw	a4,112(a5)
    *R1(VIRTIO_MMIO_STATUS) = status;
    800066f8:	470d                	li	a4,3
    800066fa:	dbb8                	sw	a4,112(a5)
    *R1(VIRTIO_MMIO_DRIVER_FEATURES) = 0;
    800066fc:	0207a023          	sw	zero,32(a5)
    *R1(VIRTIO_MMIO_STATUS) = status;
    80006700:	472d                	li	a4,11
    80006702:	dbb8                	sw	a4,112(a5)
    if (!(*R1(VIRTIO_MMIO_STATUS) & VIRTIO_CONFIG_S_FEATURES_OK))
    80006704:	5bbc                	lw	a5,112(a5)
    80006706:	8ba1                	andi	a5,a5,8
    80006708:	1e078963          	beqz	a5,800068fa <virtio_gpu_init+0x2b6>
    *R1(VIRTIO_MMIO_QUEUE_SEL) = 0;
    8000670c:	100027b7          	lui	a5,0x10002
    80006710:	0207a823          	sw	zero,48(a5) # 10002030 <_entry-0x6fffdfd0>
    if (*R1(VIRTIO_MMIO_QUEUE_READY))
    80006714:	43fc                	lw	a5,68(a5)
    80006716:	2781                	sext.w	a5,a5
    80006718:	1e079963          	bnez	a5,8000690a <virtio_gpu_init+0x2c6>
    if (*R1(VIRTIO_MMIO_QUEUE_NUM_MAX) < GPU_NUM)
    8000671c:	100027b7          	lui	a5,0x10002
    80006720:	5bdc                	lw	a5,52(a5)
    80006722:	2781                	sext.w	a5,a5
    80006724:	471d                	li	a4,7
    80006726:	1ef77a63          	bgeu	a4,a5,8000691a <virtio_gpu_init+0x2d6>
    gq.desc = kalloc();
    8000672a:	ffffa097          	auipc	ra,0xffffa
    8000672e:	3bc080e7          	jalr	956(ra) # 80000ae6 <kalloc>
    80006732:	0001c497          	auipc	s1,0x1c
    80006736:	1ae48493          	addi	s1,s1,430 # 800228e0 <gq>
    8000673a:	e088                	sd	a0,0(s1)
    gq.avail = kalloc();
    8000673c:	ffffa097          	auipc	ra,0xffffa
    80006740:	3aa080e7          	jalr	938(ra) # 80000ae6 <kalloc>
    80006744:	e488                	sd	a0,8(s1)
    gq.used = kalloc();
    80006746:	ffffa097          	auipc	ra,0xffffa
    8000674a:	3a0080e7          	jalr	928(ra) # 80000ae6 <kalloc>
    8000674e:	87aa                	mv	a5,a0
    80006750:	e888                	sd	a0,16(s1)
    if (!gq.desc || !gq.avail || !gq.used)
    80006752:	6088                	ld	a0,0(s1)
    80006754:	1c050b63          	beqz	a0,8000692a <virtio_gpu_init+0x2e6>
    80006758:	0001c717          	auipc	a4,0x1c
    8000675c:	19073703          	ld	a4,400(a4) # 800228e8 <gq+0x8>
    80006760:	1c070563          	beqz	a4,8000692a <virtio_gpu_init+0x2e6>
    80006764:	1c078363          	beqz	a5,8000692a <virtio_gpu_init+0x2e6>
    memset(gq.desc, 0, PGSIZE);
    80006768:	6605                	lui	a2,0x1
    8000676a:	4581                	li	a1,0
    8000676c:	ffffa097          	auipc	ra,0xffffa
    80006770:	566080e7          	jalr	1382(ra) # 80000cd2 <memset>
    memset(gq.avail, 0, PGSIZE);
    80006774:	0001c497          	auipc	s1,0x1c
    80006778:	16c48493          	addi	s1,s1,364 # 800228e0 <gq>
    8000677c:	6605                	lui	a2,0x1
    8000677e:	4581                	li	a1,0
    80006780:	6488                	ld	a0,8(s1)
    80006782:	ffffa097          	auipc	ra,0xffffa
    80006786:	550080e7          	jalr	1360(ra) # 80000cd2 <memset>
    memset(gq.used, 0, PGSIZE);
    8000678a:	6605                	lui	a2,0x1
    8000678c:	4581                	li	a1,0
    8000678e:	6888                	ld	a0,16(s1)
    80006790:	ffffa097          	auipc	ra,0xffffa
    80006794:	542080e7          	jalr	1346(ra) # 80000cd2 <memset>
    *R1(VIRTIO_MMIO_QUEUE_NUM) = GPU_NUM;
    80006798:	100027b7          	lui	a5,0x10002
    8000679c:	4721                	li	a4,8
    8000679e:	df98                	sw	a4,56(a5)
    *R1(VIRTIO_MMIO_QUEUE_DESC_LOW) = (uint64)gq.desc;
    800067a0:	4098                	lw	a4,0(s1)
    800067a2:	08e7a023          	sw	a4,128(a5) # 10002080 <_entry-0x6fffdf80>
    *R1(VIRTIO_MMIO_QUEUE_DESC_HIGH) = (uint64)gq.desc >> 32;
    800067a6:	40d8                	lw	a4,4(s1)
    800067a8:	08e7a223          	sw	a4,132(a5)
    *R1(VIRTIO_MMIO_DRIVER_DESC_LOW) = (uint64)gq.avail;
    800067ac:	6498                	ld	a4,8(s1)
    800067ae:	0007069b          	sext.w	a3,a4
    800067b2:	08d7a823          	sw	a3,144(a5)
    *R1(VIRTIO_MMIO_DRIVER_DESC_HIGH) = (uint64)gq.avail >> 32;
    800067b6:	9701                	srai	a4,a4,0x20
    800067b8:	08e7aa23          	sw	a4,148(a5)
    *R1(VIRTIO_MMIO_DEVICE_DESC_LOW) = (uint64)gq.used;
    800067bc:	6898                	ld	a4,16(s1)
    800067be:	0007069b          	sext.w	a3,a4
    800067c2:	0ad7a023          	sw	a3,160(a5)
    *R1(VIRTIO_MMIO_DEVICE_DESC_HIGH) = (uint64)gq.used >> 32;
    800067c6:	9701                	srai	a4,a4,0x20
    800067c8:	0ae7a223          	sw	a4,164(a5)
    *R1(VIRTIO_MMIO_QUEUE_READY) = 1;
    800067cc:	4705                	li	a4,1
    800067ce:	c3f8                	sw	a4,68(a5)
        gq.free[i] = 1;
    800067d0:	00e48c23          	sb	a4,24(s1)
    800067d4:	00e48ca3          	sb	a4,25(s1)
    800067d8:	00e48d23          	sb	a4,26(s1)
    800067dc:	00e48da3          	sb	a4,27(s1)
    800067e0:	00e48e23          	sb	a4,28(s1)
    800067e4:	00e48ea3          	sb	a4,29(s1)
    800067e8:	00e48f23          	sb	a4,30(s1)
    800067ec:	00e48fa3          	sb	a4,31(s1)
    *R1(VIRTIO_MMIO_STATUS) = status;
    800067f0:	473d                	li	a4,15
    800067f2:	dbb8                	sw	a4,112(a5)
    for (int i = 0; i < FB_PAGES; i++)
    800067f4:	00021917          	auipc	s2,0x21
    800067f8:	d4490913          	addi	s2,s2,-700 # 80027538 <fb>
    800067fc:	00021997          	auipc	s3,0x21
    80006800:	69c98993          	addi	s3,s3,1692 # 80027e98 <end>
    *R1(VIRTIO_MMIO_STATUS) = status;
    80006804:	84ca                	mv	s1,s2
        fb[i] = kalloc();
    80006806:	ffffa097          	auipc	ra,0xffffa
    8000680a:	2e0080e7          	jalr	736(ra) # 80000ae6 <kalloc>
    8000680e:	e088                	sd	a0,0(s1)
        if (!fb[i])
    80006810:	12050563          	beqz	a0,8000693a <virtio_gpu_init+0x2f6>
        memset(fb[i], 0, PGSIZE); // fill with COLOR_BG (0 = black)
    80006814:	6605                	lui	a2,0x1
    80006816:	4581                	li	a1,0
    80006818:	ffffa097          	auipc	ra,0xffffa
    8000681c:	4ba080e7          	jalr	1210(ra) # 80000cd2 <memset>
    for (int i = 0; i < FB_PAGES; i++)
    80006820:	04a1                	addi	s1,s1,8
    80006822:	ff3492e3          	bne	s1,s3,80006806 <virtio_gpu_init+0x1c2>
    memset(&create_req, 0, sizeof(create_req));
    80006826:	0001c497          	auipc	s1,0x1c
    8000682a:	0ba48493          	addi	s1,s1,186 # 800228e0 <gq>
    8000682e:	0001c997          	auipc	s3,0x1c
    80006832:	19298993          	addi	s3,s3,402 # 800229c0 <create_req.7>
    80006836:	02800613          	li	a2,40
    8000683a:	4581                	li	a1,0
    8000683c:	854e                	mv	a0,s3
    8000683e:	ffffa097          	auipc	ra,0xffffa
    80006842:	494080e7          	jalr	1172(ra) # 80000cd2 <memset>
    create_req.hdr.type = VIRTIO_GPU_CMD_RESOURCE_CREATE_2D;
    80006846:	10100793          	li	a5,257
    8000684a:	0ef4a023          	sw	a5,224(s1)
    create_req.resource_id = RESOURCE_ID;
    8000684e:	4785                	li	a5,1
    80006850:	0ef4ac23          	sw	a5,248(s1)
    create_req.format = VIRTIO_GPU_FORMAT_B8G8R8X8_UNORM;
    80006854:	4789                	li	a5,2
    80006856:	0ef4ae23          	sw	a5,252(s1)
    create_req.width = SCREEN_W;
    8000685a:	28000793          	li	a5,640
    8000685e:	10f4a023          	sw	a5,256(s1)
    create_req.height = SCREEN_H;
    80006862:	1e000793          	li	a5,480
    80006866:	10f4a223          	sw	a5,260(s1)
    gpu_send(&create_req, sizeof(create_req));
    8000686a:	02800593          	li	a1,40
    8000686e:	854e                	mv	a0,s3
    80006870:	00000097          	auipc	ra,0x0
    80006874:	b52080e7          	jalr	-1198(ra) # 800063c2 <gpu_send>
    for (int i = 0; i < FB_PAGES; i++) {
    80006878:	0001e797          	auipc	a5,0x1e
    8000687c:	72078793          	addi	a5,a5,1824 # 80024f98 <fb_entries.6>
    80006880:	00020617          	auipc	a2,0x20
    80006884:	9d860613          	addi	a2,a2,-1576 # 80026258 <attach_buf>
        fb_entries[i].length = PGSIZE;
    80006888:	6685                	lui	a3,0x1
        fb_entries[i].addr   = (uint64)fb[i];
    8000688a:	00093703          	ld	a4,0(s2)
    8000688e:	e398                	sd	a4,0(a5)
        fb_entries[i].length = PGSIZE;
    80006890:	c794                	sw	a3,8(a5)
    for (int i = 0; i < FB_PAGES; i++) {
    80006892:	0921                	addi	s2,s2,8
    80006894:	07c1                	addi	a5,a5,16
    80006896:	fec79ae3          	bne	a5,a2,8000688a <virtio_gpu_init+0x246>
    gpu_cmd_attach(fb_entries, FB_PAGES);
    8000689a:	12c00593          	li	a1,300
    8000689e:	0001e517          	auipc	a0,0x1e
    800068a2:	6fa50513          	addi	a0,a0,1786 # 80024f98 <fb_entries.6>
    800068a6:	00000097          	auipc	ra,0x0
    800068aa:	c28080e7          	jalr	-984(ra) # 800064ce <gpu_cmd_attach>
        for (int i = 0; msg[i]; i++)
    800068ae:	00002c17          	auipc	s8,0x2
    800068b2:	0c2c0c13          	addi	s8,s8,194 # 80008970 <syscalls+0x500>
    gpu_cmd_attach(fb_entries, FB_PAGES);
    800068b6:	0008cbb7          	lui	s7,0x8c
    800068ba:	250b8b93          	addi	s7,s7,592 # 8c250 <_entry-0x7ff73db0>
        for (int i = 0; msg[i]; i++)
    800068be:	04800793          	li	a5,72
    const uint8 *rows = font8x8[ch];
    800068c2:	00002c97          	auipc	s9,0x2
    800068c6:	0f6c8c93          	addi	s9,s9,246 # 800089b8 <font8x8>
    800068ca:	00024737          	lui	a4,0x24
    800068ce:	a0070d93          	addi	s11,a4,-1536 # 23a00 <_entry-0x7ffdc600>
        for (int col = 0; col < 8; col++)
    800068d2:	4d01                	li	s10,0
            uint32 color = (rows[row] & (1u << col)) ? COLOR_FG : COLOR_BG;
    800068d4:	010004b7          	lui	s1,0x1000
    800068d8:	14fd                	addi	s1,s1,-1
    uint32 *p = (uint32 *)((uint8 *)fb[pg] + off);
    800068da:	00021897          	auipc	a7,0x21
    800068de:	c5e88893          	addi	a7,a7,-930 # 80027538 <fb>
    int off = byte_off % PGSIZE;
    800068e2:	6805                	lui	a6,0x1
    800068e4:	187d                	addi	a6,a6,-1
            for (int dy = 0; dy < SCALE; dy++)
    800068e6:	6e05                	lui	t3,0x1
    800068e8:	a00e0e1b          	addiw	t3,t3,-1536
        for (int col = 0; col < 8; col++)
    800068ec:	40a1                	li	ra,8
    for (int row = 0; row < 8; row++)
    800068ee:	6a8d                	lui	s5,0x3
    800068f0:	800a8a9b          	addiw	s5,s5,-2048
    800068f4:	10000b13          	li	s6,256
    800068f8:	a0f1                	j	800069c4 <virtio_gpu_init+0x380>
        panic("virtio_gpu: FEATURES_OK not set");
    800068fa:	00002517          	auipc	a0,0x2
    800068fe:	fbe50513          	addi	a0,a0,-66 # 800088b8 <syscalls+0x448>
    80006902:	ffffa097          	auipc	ra,0xffffa
    80006906:	c3c080e7          	jalr	-964(ra) # 8000053e <panic>
        panic("virtio_gpu: queue already ready");
    8000690a:	00002517          	auipc	a0,0x2
    8000690e:	fce50513          	addi	a0,a0,-50 # 800088d8 <syscalls+0x468>
    80006912:	ffffa097          	auipc	ra,0xffffa
    80006916:	c2c080e7          	jalr	-980(ra) # 8000053e <panic>
        panic("virtio_gpu: queue too small");
    8000691a:	00002517          	auipc	a0,0x2
    8000691e:	fde50513          	addi	a0,a0,-34 # 800088f8 <syscalls+0x488>
    80006922:	ffffa097          	auipc	ra,0xffffa
    80006926:	c1c080e7          	jalr	-996(ra) # 8000053e <panic>
        panic("virtio_gpu: kalloc failed for queue");
    8000692a:	00002517          	auipc	a0,0x2
    8000692e:	fee50513          	addi	a0,a0,-18 # 80008918 <syscalls+0x4a8>
    80006932:	ffffa097          	auipc	ra,0xffffa
    80006936:	c0c080e7          	jalr	-1012(ra) # 8000053e <panic>
            panic("virtio_gpu: kalloc failed for framebuffer");
    8000693a:	00002517          	auipc	a0,0x2
    8000693e:	00650513          	addi	a0,a0,6 # 80008940 <syscalls+0x4d0>
    80006942:	ffffa097          	auipc	ra,0xffffa
    80006946:	bfc080e7          	jalr	-1028(ra) # 8000053e <panic>
            uint32 color = (rows[row] & (1u << col)) ? COLOR_FG : COLOR_BG;
    8000694a:	85fe                	mv	a1,t6
    8000694c:	831e                	mv	t1,t2
                for (int dx = 0; dx < SCALE; dx++)
    8000694e:	ff05869b          	addiw	a3,a1,-16
    int pg = byte_off / PGSIZE;
    80006952:	43f6d613          	srai	a2,a3,0x3f
    80006956:	0146561b          	srliw	a2,a2,0x14
    8000695a:	00d607bb          	addw	a5,a2,a3
    uint32 *p = (uint32 *)((uint8 *)fb[pg] + off);
    8000695e:	40c7d71b          	sraiw	a4,a5,0xc
    80006962:	070e                	slli	a4,a4,0x3
    80006964:	9746                	add	a4,a4,a7
    int off = byte_off % PGSIZE;
    80006966:	0107f7b3          	and	a5,a5,a6
    uint32 *p = (uint32 *)((uint8 *)fb[pg] + off);
    8000696a:	9f91                	subw	a5,a5,a2
    *p = color;
    8000696c:	6310                	ld	a2,0(a4)
    8000696e:	97b2                	add	a5,a5,a2
    80006970:	c388                	sw	a0,0(a5)
                for (int dx = 0; dx < SCALE; dx++)
    80006972:	2691                	addiw	a3,a3,4
    80006974:	fcd59fe3          	bne	a1,a3,80006952 <virtio_gpu_init+0x30e>
            for (int dy = 0; dy < SCALE; dy++)
    80006978:	2803031b          	addiw	t1,t1,640
    8000697c:	00be05bb          	addw	a1,t3,a1
    80006980:	fdd317e3          	bne	t1,t4,8000694e <virtio_gpu_init+0x30a>
        for (int col = 0; col < 8; col++)
    80006984:	2f05                	addiw	t5,t5,1
    80006986:	2fc1                	addiw	t6,t6,16
    80006988:	001f0a63          	beq	t5,ra,8000699c <virtio_gpu_init+0x358>
            uint32 color = (rows[row] & (1u << col)) ? COLOR_FG : COLOR_BG;
    8000698c:	0002c503          	lbu	a0,0(t0)
    80006990:	01e5553b          	srlw	a0,a0,t5
    80006994:	8905                	andi	a0,a0,1
    80006996:	d955                	beqz	a0,8000694a <virtio_gpu_init+0x306>
    80006998:	8526                	mv	a0,s1
    8000699a:	bf45                	j	8000694a <virtio_gpu_init+0x306>
    for (int row = 0; row < 8; row++)
    8000699c:	01de0ebb          	addw	t4,t3,t4
    800069a0:	012e093b          	addw	s2,t3,s2
    800069a4:	2991                	addiw	s3,s3,4
    800069a6:	014a8a3b          	addw	s4,s5,s4
    800069aa:	0285                	addi	t0,t0,1
    800069ac:	01698663          	beq	s3,s6,800069b8 <virtio_gpu_init+0x374>
        for (int i = 0; msg[i]; i++)
    800069b0:	8fd2                	mv	t6,s4
        for (int col = 0; col < 8; col++)
    800069b2:	8f6a                	mv	t5,s10
            uint32 color = (rows[row] & (1u << col)) ? COLOR_FG : COLOR_BG;
    800069b4:	83ca                	mv	t2,s2
    800069b6:	bfd9                	j	8000698c <virtio_gpu_init+0x348>
        for (int i = 0; msg[i]; i++)
    800069b8:	001c4783          	lbu	a5,1(s8)
    800069bc:	0c05                	addi	s8,s8,1
    800069be:	080b8b9b          	addiw	s7,s7,128
    800069c2:	cb99                	beqz	a5,800069d8 <virtio_gpu_init+0x394>
    const uint8 *rows = font8x8[ch];
    800069c4:	078e                	slli	a5,a5,0x3
    800069c6:	019782b3          	add	t0,a5,s9
    800069ca:	8a5e                	mv	s4,s7
    800069cc:	0e000993          	li	s3,224
    800069d0:	00023937          	lui	s2,0x23
    800069d4:	8eee                	mv	t4,s11
    800069d6:	bfe9                	j	800069b0 <virtio_gpu_init+0x36c>
    memset(&scanout_req, 0, sizeof(scanout_req));
    800069d8:	0001c497          	auipc	s1,0x1c
    800069dc:	f0848493          	addi	s1,s1,-248 # 800228e0 <gq>
    800069e0:	0001c917          	auipc	s2,0x1c
    800069e4:	00890913          	addi	s2,s2,8 # 800229e8 <scanout_req.5>
    800069e8:	03000613          	li	a2,48
    800069ec:	4581                	li	a1,0
    800069ee:	854a                	mv	a0,s2
    800069f0:	ffffa097          	auipc	ra,0xffffa
    800069f4:	2e2080e7          	jalr	738(ra) # 80000cd2 <memset>
    scanout_req.hdr.type = VIRTIO_GPU_CMD_SET_SCANOUT;
    800069f8:	10300793          	li	a5,259
    800069fc:	10f4a423          	sw	a5,264(s1)
    scanout_req.r.x = 0;
    80006a00:	1204a023          	sw	zero,288(s1)
    scanout_req.r.y = 0;
    80006a04:	1204a223          	sw	zero,292(s1)
    scanout_req.r.width = SCREEN_W;
    80006a08:	28000793          	li	a5,640
    80006a0c:	12f4a423          	sw	a5,296(s1)
    scanout_req.r.height = SCREEN_H;
    80006a10:	1e000793          	li	a5,480
    80006a14:	12f4a623          	sw	a5,300(s1)
    scanout_req.scanout_id = SCANOUT_ID;
    80006a18:	1204a823          	sw	zero,304(s1)
    scanout_req.resource_id = RESOURCE_ID;
    80006a1c:	4785                	li	a5,1
    80006a1e:	12f4aa23          	sw	a5,308(s1)
    gpu_send(&scanout_req, sizeof(scanout_req));
    80006a22:	03000593          	li	a1,48
    80006a26:	854a                	mv	a0,s2
    80006a28:	00000097          	auipc	ra,0x0
    80006a2c:	99a080e7          	jalr	-1638(ra) # 800063c2 <gpu_send>
    gpu_transfer_flush();
    80006a30:	00000097          	auipc	ra,0x0
    80006a34:	b08080e7          	jalr	-1272(ra) # 80006538 <gpu_transfer_flush>
    printf("virtio_gpu: \"Hello World\" displayed on 640x480 window\n");
    80006a38:	00002517          	auipc	a0,0x2
    80006a3c:	f4850513          	addi	a0,a0,-184 # 80008980 <syscalls+0x510>
    80006a40:	ffffa097          	auipc	ra,0xffffa
    80006a44:	b48080e7          	jalr	-1208(ra) # 80000588 <printf>
    80006a48:	b159                	j	800066ce <virtio_gpu_init+0x8a>

0000000080006a4a <virtio_gpu_commit>:

// ── Public: flush the kernel fb[] to the display ─────────────────────
// Called by display_daemon.  Sends TRANSFER_TO_HOST_2D + RESOURCE_FLUSH.
void virtio_gpu_commit(void)
{
    80006a4a:	1141                	addi	sp,sp,-16
    80006a4c:	e406                	sd	ra,8(sp)
    80006a4e:	e022                	sd	s0,0(sp)
    80006a50:	0800                	addi	s0,sp,16
    gpu_transfer_flush();
    80006a52:	00000097          	auipc	ra,0x0
    80006a56:	ae6080e7          	jalr	-1306(ra) # 80006538 <gpu_transfer_flush>
}
    80006a5a:	60a2                	ld	ra,8(sp)
    80006a5c:	6402                	ld	s0,0(sp)
    80006a5e:	0141                	addi	sp,sp,16
    80006a60:	8082                	ret

0000000080006a62 <display_daemon>:
// Commit period: DISPLAY_DAEMON_TICKS ticks.  xv6's timer fires every
// ~1/10th of a second at QEMU's default rate, giving ~10fps.
#define DISPLAY_DAEMON_TICKS 1

void display_daemon(void)
{
    80006a62:	7179                	addi	sp,sp,-48
    80006a64:	f406                	sd	ra,40(sp)
    80006a66:	f022                	sd	s0,32(sp)
    80006a68:	ec26                	sd	s1,24(sp)
    80006a6a:	e84a                	sd	s2,16(sp)
    80006a6c:	e44e                	sd	s3,8(sp)
    80006a6e:	1800                	addi	s0,sp,48
    // The scheduler holds p->lock across swtch into a new process.
    // Release it here, just like forkret does for user processes.
    struct proc *p = myproc();
    80006a70:	ffffb097          	auipc	ra,0xffffb
    80006a74:	f72080e7          	jalr	-142(ra) # 800019e2 <myproc>
    release(&p->lock);
    80006a78:	ffffa097          	auipc	ra,0xffffa
    80006a7c:	212080e7          	jalr	530(ra) # 80000c8a <release>

    acquire(&tickslock);
    80006a80:	00011517          	auipc	a0,0x11
    80006a84:	a8050513          	addi	a0,a0,-1408 # 80017500 <tickslock>
    80006a88:	ffffa097          	auipc	ra,0xffffa
    80006a8c:	14e080e7          	jalr	334(ra) # 80000bd6 <acquire>
    for (;;)
    {
        // Sleep until DISPLAY_DAEMON_TICKS ticks have elapsed.
        uint deadline = ticks + DISPLAY_DAEMON_TICKS;
    80006a90:	00002917          	auipc	s2,0x2
    80006a94:	7d090913          	addi	s2,s2,2000 # 80009260 <ticks>
        while (ticks < deadline)
            sleep(&ticks, &tickslock);
    80006a98:	00011497          	auipc	s1,0x11
    80006a9c:	a6848493          	addi	s1,s1,-1432 # 80017500 <tickslock>
    80006aa0:	a839                	j	80006abe <display_daemon+0x5c>

        release(&tickslock);
    80006aa2:	8526                	mv	a0,s1
    80006aa4:	ffffa097          	auipc	ra,0xffffa
    80006aa8:	1e6080e7          	jalr	486(ra) # 80000c8a <release>
    gpu_transfer_flush();
    80006aac:	00000097          	auipc	ra,0x0
    80006ab0:	a8c080e7          	jalr	-1396(ra) # 80006538 <gpu_transfer_flush>
        virtio_gpu_commit();
        acquire(&tickslock);
    80006ab4:	8526                	mv	a0,s1
    80006ab6:	ffffa097          	auipc	ra,0xffffa
    80006aba:	120080e7          	jalr	288(ra) # 80000bd6 <acquire>
        uint deadline = ticks + DISPLAY_DAEMON_TICKS;
    80006abe:	00092783          	lw	a5,0(s2)
    80006ac2:	0017899b          	addiw	s3,a5,1
        while (ticks < deadline)
    80006ac6:	fd37fee3          	bgeu	a5,s3,80006aa2 <display_daemon+0x40>
            sleep(&ticks, &tickslock);
    80006aca:	85a6                	mv	a1,s1
    80006acc:	854a                	mv	a0,s2
    80006ace:	ffffb097          	auipc	ra,0xffffb
    80006ad2:	646080e7          	jalr	1606(ra) # 80002114 <sleep>
        while (ticks < deadline)
    80006ad6:	00092783          	lw	a5,0(s2)
    80006ada:	ff37e8e3          	bltu	a5,s3,80006aca <display_daemon+0x68>
    80006ade:	b7d1                	j	80006aa2 <display_daemon+0x40>

0000000080006ae0 <virtio_gpu_map_user>:
//   - On success returns 0.
int
virtio_gpu_map_user(pagetable_t pagetable, uint64 va)
{
    // Alignment check.
    if (va % PGSIZE != 0)
    80006ae0:	03459793          	slli	a5,a1,0x34
    80006ae4:	efd5                	bnez	a5,80006ba0 <virtio_gpu_map_user+0xc0>
{
    80006ae6:	715d                	addi	sp,sp,-80
    80006ae8:	e486                	sd	ra,72(sp)
    80006aea:	e0a2                	sd	s0,64(sp)
    80006aec:	fc26                	sd	s1,56(sp)
    80006aee:	f84a                	sd	s2,48(sp)
    80006af0:	f44e                	sd	s3,40(sp)
    80006af2:	f052                	sd	s4,32(sp)
    80006af4:	ec56                	sd	s5,24(sp)
    80006af6:	e85a                	sd	s6,16(sp)
    80006af8:	e45e                	sd	s7,8(sp)
    80006afa:	0880                	addi	s0,sp,80
    80006afc:	892a                	mv	s2,a0
    80006afe:	8b2e                	mv	s6,a1
    80006b00:	0347da93          	srli	s5,a5,0x34
        return -1;
    // Sanity: don't allow wrap-around or overlap with TRAMPOLINE/TRAPFRAME.
    if (va + (uint64)FB_PAGES * PGSIZE > TRAPFRAME)
    80006b04:	0012c9b7          	lui	s3,0x12c
    80006b08:	99ae                	add	s3,s3,a1
    80006b0a:	020007b7          	lui	a5,0x2000
    80006b0e:	17fd                	addi	a5,a5,-1
    80006b10:	07b6                	slli	a5,a5,0xd
    80006b12:	0937e963          	bltu	a5,s3,80006ba4 <virtio_gpu_map_user+0xc4>
    80006b16:	84ae                	mv	s1,a1
        return -1;

    // Pre-flight: verify the whole VA range is free.  mappages() would
    // panic on remap, so we must check ourselves before mapping anything.
    for (int i = 0; i < FB_PAGES; i++) {
    80006b18:	6a05                	lui	s4,0x1
    80006b1a:	a021                	j	80006b22 <virtio_gpu_map_user+0x42>
    80006b1c:	94d2                	add	s1,s1,s4
    80006b1e:	02998963          	beq	s3,s1,80006b50 <virtio_gpu_map_user+0x70>
        pte_t *pte = walk(pagetable, va + (uint64)i * PGSIZE, 0);
    80006b22:	4601                	li	a2,0
    80006b24:	85a6                	mv	a1,s1
    80006b26:	854a                	mv	a0,s2
    80006b28:	ffffa097          	auipc	ra,0xffffa
    80006b2c:	4ae080e7          	jalr	1198(ra) # 80000fd6 <walk>
        if (pte && (*pte & PTE_V))
    80006b30:	d575                	beqz	a0,80006b1c <virtio_gpu_map_user+0x3c>
    80006b32:	611c                	ld	a5,0(a0)
    80006b34:	8b85                	andi	a5,a5,1
    80006b36:	d3fd                	beqz	a5,80006b1c <virtio_gpu_map_user+0x3c>
            return -1;
    80006b38:	557d                	li	a0,-1
                uvmunmap(pagetable, va, i, 0);   // do_free = 0 !
            return -1;
        }
    }
    return 0;
}
    80006b3a:	60a6                	ld	ra,72(sp)
    80006b3c:	6406                	ld	s0,64(sp)
    80006b3e:	74e2                	ld	s1,56(sp)
    80006b40:	7942                	ld	s2,48(sp)
    80006b42:	79a2                	ld	s3,40(sp)
    80006b44:	7a02                	ld	s4,32(sp)
    80006b46:	6ae2                	ld	s5,24(sp)
    80006b48:	6b42                	ld	s6,16(sp)
    80006b4a:	6ba2                	ld	s7,8(sp)
    80006b4c:	6161                	addi	sp,sp,80
    80006b4e:	8082                	ret
    80006b50:	00021997          	auipc	s3,0x21
    80006b54:	9e898993          	addi	s3,s3,-1560 # 80027538 <fb>
    for (int i = 0; i < FB_PAGES; i++) {
    80006b58:	84da                	mv	s1,s6
    for (int i = 0; i < FB_PAGES; i++) {
    80006b5a:	12c00b93          	li	s7,300
    80006b5e:	000a8a1b          	sext.w	s4,s5
        if (mappages(pagetable, va + (uint64)i * PGSIZE, PGSIZE,
    80006b62:	4759                	li	a4,22
    80006b64:	0009b683          	ld	a3,0(s3)
    80006b68:	6605                	lui	a2,0x1
    80006b6a:	85a6                	mv	a1,s1
    80006b6c:	854a                	mv	a0,s2
    80006b6e:	ffffa097          	auipc	ra,0xffffa
    80006b72:	550080e7          	jalr	1360(ra) # 800010be <mappages>
    80006b76:	e901                	bnez	a0,80006b86 <virtio_gpu_map_user+0xa6>
    for (int i = 0; i < FB_PAGES; i++) {
    80006b78:	0a85                	addi	s5,s5,1
    80006b7a:	09a1                	addi	s3,s3,8
    80006b7c:	6785                	lui	a5,0x1
    80006b7e:	94be                	add	s1,s1,a5
    80006b80:	fd7a9fe3          	bne	s5,s7,80006b5e <virtio_gpu_map_user+0x7e>
    80006b84:	bf5d                	j	80006b3a <virtio_gpu_map_user+0x5a>
            return -1;
    80006b86:	557d                	li	a0,-1
            if (i > 0)
    80006b88:	fb4059e3          	blez	s4,80006b3a <virtio_gpu_map_user+0x5a>
                uvmunmap(pagetable, va, i, 0);   // do_free = 0 !
    80006b8c:	4681                	li	a3,0
    80006b8e:	8656                	mv	a2,s5
    80006b90:	85da                	mv	a1,s6
    80006b92:	854a                	mv	a0,s2
    80006b94:	ffffa097          	auipc	ra,0xffffa
    80006b98:	706080e7          	jalr	1798(ra) # 8000129a <uvmunmap>
            return -1;
    80006b9c:	557d                	li	a0,-1
    80006b9e:	bf71                	j	80006b3a <virtio_gpu_map_user+0x5a>
        return -1;
    80006ba0:	557d                	li	a0,-1
}
    80006ba2:	8082                	ret
        return -1;
    80006ba4:	557d                	li	a0,-1
    80006ba6:	bf51                	j	80006b3a <virtio_gpu_map_user+0x5a>

0000000080006ba8 <virtio_gpu_unmap_user>:
// Importantly we pass do_free=0: the physical pages fb[] are owned by
// the kernel (allocated in virtio_gpu_init) and MUST NOT be returned
// to the page allocator.
void
virtio_gpu_unmap_user(pagetable_t pagetable, uint64 va)
{
    80006ba8:	1141                	addi	sp,sp,-16
    80006baa:	e406                	sd	ra,8(sp)
    80006bac:	e022                	sd	s0,0(sp)
    80006bae:	0800                	addi	s0,sp,16
    uvmunmap(pagetable, va, FB_PAGES, 0);   // do_free = 0 — kernel pages!
    80006bb0:	4681                	li	a3,0
    80006bb2:	12c00613          	li	a2,300
    80006bb6:	ffffa097          	auipc	ra,0xffffa
    80006bba:	6e4080e7          	jalr	1764(ra) # 8000129a <uvmunmap>
}
    80006bbe:	60a2                	ld	ra,8(sp)
    80006bc0:	6402                	ld	s0,0(sp)
    80006bc2:	0141                	addi	sp,sp,16
    80006bc4:	8082                	ret

0000000080006bc6 <virtio_gpu_flip>:
    // is already true of attach_buf inside gpu_cmd_attach(); fixing it
    // is outside this assignment's scope.
    static struct virtio_gpu_mem_entry user_entries[FB_PAGES];

    // Alignment check.
    if (va % PGSIZE != 0)
    80006bc6:	03459793          	slli	a5,a1,0x34
    80006bca:	e3dd                	bnez	a5,80006c70 <virtio_gpu_flip+0xaa>
{
    80006bcc:	7139                	addi	sp,sp,-64
    80006bce:	fc06                	sd	ra,56(sp)
    80006bd0:	f822                	sd	s0,48(sp)
    80006bd2:	f426                	sd	s1,40(sp)
    80006bd4:	f04a                	sd	s2,32(sp)
    80006bd6:	ec4e                	sd	s3,24(sp)
    80006bd8:	e852                	sd	s4,16(sp)
    80006bda:	e456                	sd	s5,8(sp)
    80006bdc:	e05a                	sd	s6,0(sp)
    80006bde:	0080                	addi	s0,sp,64
    80006be0:	8a2a                	mv	s4,a0
    80006be2:	892e                	mv	s2,a1
        return -1;
    // Bounds: don't allow wrap-around or overlap with TRAMPOLINE/TRAPFRAME.
    if (va + (uint64)FB_PAGES * PGSIZE > TRAPFRAME)
    80006be4:	0012c737          	lui	a4,0x12c
    80006be8:	972e                	add	a4,a4,a1
    80006bea:	020007b7          	lui	a5,0x2000
    80006bee:	17fd                	addi	a5,a5,-1
    80006bf0:	07b6                	slli	a5,a5,0xd
    80006bf2:	08e7e163          	bltu	a5,a4,80006c74 <virtio_gpu_flip+0xae>
    80006bf6:	0001d497          	auipc	s1,0x1d
    80006bfa:	0e248493          	addi	s1,s1,226 # 80023cd8 <user_entries.2>
    80006bfe:	0001eb17          	auipc	s6,0x1e
    80006c02:	39ab0b13          	addi	s6,s6,922 # 80024f98 <fb_entries.6>
        pte_t *pte = walk(pagetable, va + (uint64)i * PGSIZE, 0);
        if (pte == 0 || (*pte & PTE_V) == 0)
            return -1;
        // Must be a user-accessible R/W page.  PTE_U keeps us from
        // accidentally exposing kernel-only pages to the device.
        if ((*pte & (PTE_U | PTE_R | PTE_W)) != (PTE_U | PTE_R | PTE_W))
    80006c06:	4ad9                	li	s5,22
            return -1;
        user_entries[i].addr    = PTE2PA(*pte);
        user_entries[i].length  = PGSIZE;
    80006c08:	6985                	lui	s3,0x1
        pte_t *pte = walk(pagetable, va + (uint64)i * PGSIZE, 0);
    80006c0a:	4601                	li	a2,0
    80006c0c:	85ca                	mv	a1,s2
    80006c0e:	8552                	mv	a0,s4
    80006c10:	ffffa097          	auipc	ra,0xffffa
    80006c14:	3c6080e7          	jalr	966(ra) # 80000fd6 <walk>
        if (pte == 0 || (*pte & PTE_V) == 0)
    80006c18:	c125                	beqz	a0,80006c78 <virtio_gpu_flip+0xb2>
    80006c1a:	611c                	ld	a5,0(a0)
    80006c1c:	0017f713          	andi	a4,a5,1
    80006c20:	c73d                	beqz	a4,80006c8e <virtio_gpu_flip+0xc8>
        if ((*pte & (PTE_U | PTE_R | PTE_W)) != (PTE_U | PTE_R | PTE_W))
    80006c22:	0167f713          	andi	a4,a5,22
    80006c26:	07571663          	bne	a4,s5,80006c92 <virtio_gpu_flip+0xcc>
        user_entries[i].addr    = PTE2PA(*pte);
    80006c2a:	83a9                	srli	a5,a5,0xa
    80006c2c:	07b2                	slli	a5,a5,0xc
    80006c2e:	e09c                	sd	a5,0(s1)
        user_entries[i].length  = PGSIZE;
    80006c30:	0134a423          	sw	s3,8(s1)
        user_entries[i].padding = 0;
    80006c34:	0004a623          	sw	zero,12(s1)
    for (int i = 0; i < FB_PAGES; i++) {
    80006c38:	994e                	add	s2,s2,s3
    80006c3a:	04c1                	addi	s1,s1,16
    80006c3c:	fd6497e3          	bne	s1,s6,80006c0a <virtio_gpu_flip+0x44>
    }

    // Atomically (from the user's perspective) swap the backing:
    // detach the old list, attach the new one.  gpu_send() serialises
    // both commands against the display daemon via gpu_lock.
    gpu_cmd_detach();
    80006c40:	00000097          	auipc	ra,0x0
    80006c44:	9b0080e7          	jalr	-1616(ra) # 800065f0 <gpu_cmd_detach>
    gpu_cmd_attach(user_entries, FB_PAGES);
    80006c48:	12c00593          	li	a1,300
    80006c4c:	0001d517          	auipc	a0,0x1d
    80006c50:	08c50513          	addi	a0,a0,140 # 80023cd8 <user_entries.2>
    80006c54:	00000097          	auipc	ra,0x0
    80006c58:	87a080e7          	jalr	-1926(ra) # 800064ce <gpu_cmd_attach>

    // Record the new owner so we can restore fb[] if this process dies
    // while the device is still pointing at its pages.
    fb_owner = myproc();
    80006c5c:	ffffb097          	auipc	ra,0xffffb
    80006c60:	d86080e7          	jalr	-634(ra) # 800019e2 <myproc>
    80006c64:	00002797          	auipc	a5,0x2
    80006c68:	60a7b223          	sd	a0,1540(a5) # 80009268 <fb_owner>
    return 0;
    80006c6c:	4501                	li	a0,0
    80006c6e:	a031                	j	80006c7a <virtio_gpu_flip+0xb4>
        return -1;
    80006c70:	557d                	li	a0,-1
}
    80006c72:	8082                	ret
        return -1;
    80006c74:	557d                	li	a0,-1
    80006c76:	a011                	j	80006c7a <virtio_gpu_flip+0xb4>
            return -1;
    80006c78:	557d                	li	a0,-1
}
    80006c7a:	70e2                	ld	ra,56(sp)
    80006c7c:	7442                	ld	s0,48(sp)
    80006c7e:	74a2                	ld	s1,40(sp)
    80006c80:	7902                	ld	s2,32(sp)
    80006c82:	69e2                	ld	s3,24(sp)
    80006c84:	6a42                	ld	s4,16(sp)
    80006c86:	6aa2                	ld	s5,8(sp)
    80006c88:	6b02                	ld	s6,0(sp)
    80006c8a:	6121                	addi	sp,sp,64
    80006c8c:	8082                	ret
            return -1;
    80006c8e:	557d                	li	a0,-1
    80006c90:	b7ed                	j	80006c7a <virtio_gpu_flip+0xb4>
            return -1;
    80006c92:	557d                	li	a0,-1
    80006c94:	b7dd                	j	80006c7a <virtio_gpu_flip+0xb4>

0000000080006c96 <virtio_gpu_release>:
// Called from freeproc() and exec() BEFORE p's user pages are freed, so
// the device stops reading pages that are about to be recycled.
void
virtio_gpu_release(struct proc *p)
{
    if (fb_owner != p)
    80006c96:	00002797          	auipc	a5,0x2
    80006c9a:	5d27b783          	ld	a5,1490(a5) # 80009268 <fb_owner>
    80006c9e:	00a78363          	beq	a5,a0,80006ca4 <virtio_gpu_release+0xe>
    80006ca2:	8082                	ret
{
    80006ca4:	1141                	addi	sp,sp,-16
    80006ca6:	e406                	sd	ra,8(sp)
    80006ca8:	e022                	sd	s0,0(sp)
    80006caa:	0800                	addi	s0,sp,16
    80006cac:	00021717          	auipc	a4,0x21
    80006cb0:	88c70713          	addi	a4,a4,-1908 # 80027538 <fb>
    80006cb4:	0001c797          	auipc	a5,0x1c
    80006cb8:	d6478793          	addi	a5,a5,-668 # 80022a18 <fb_entries.0>
    80006cbc:	0001d597          	auipc	a1,0x1d
    80006cc0:	01c58593          	addi	a1,a1,28 # 80023cd8 <user_entries.2>
        return;

    static struct virtio_gpu_mem_entry fb_entries[FB_PAGES];
    for (int i = 0; i < FB_PAGES; i++) {
        fb_entries[i].addr    = (uint64)fb[i];
        fb_entries[i].length  = PGSIZE;
    80006cc4:	6605                	lui	a2,0x1
        fb_entries[i].addr    = (uint64)fb[i];
    80006cc6:	6314                	ld	a3,0(a4)
    80006cc8:	e394                	sd	a3,0(a5)
        fb_entries[i].length  = PGSIZE;
    80006cca:	c790                	sw	a2,8(a5)
        fb_entries[i].padding = 0;
    80006ccc:	0007a623          	sw	zero,12(a5)
    for (int i = 0; i < FB_PAGES; i++) {
    80006cd0:	0721                	addi	a4,a4,8
    80006cd2:	07c1                	addi	a5,a5,16
    80006cd4:	feb799e3          	bne	a5,a1,80006cc6 <virtio_gpu_release+0x30>
    }
    gpu_cmd_detach();
    80006cd8:	00000097          	auipc	ra,0x0
    80006cdc:	918080e7          	jalr	-1768(ra) # 800065f0 <gpu_cmd_detach>
    gpu_cmd_attach(fb_entries, FB_PAGES);
    80006ce0:	12c00593          	li	a1,300
    80006ce4:	0001c517          	auipc	a0,0x1c
    80006ce8:	d3450513          	addi	a0,a0,-716 # 80022a18 <fb_entries.0>
    80006cec:	fffff097          	auipc	ra,0xfffff
    80006cf0:	7e2080e7          	jalr	2018(ra) # 800064ce <gpu_cmd_attach>
    fb_owner = 0;
    80006cf4:	00002797          	auipc	a5,0x2
    80006cf8:	5607ba23          	sd	zero,1396(a5) # 80009268 <fb_owner>
    80006cfc:	60a2                	ld	ra,8(sp)
    80006cfe:	6402                	ld	s0,0(sp)
    80006d00:	0141                	addi	sp,sp,16
    80006d02:	8082                	ret
	...

0000000080007000 <_trampoline>:
    80007000:	14051073          	csrw	sscratch,a0
    80007004:	02000537          	lui	a0,0x2000
    80007008:	357d                	addiw	a0,a0,-1
    8000700a:	0536                	slli	a0,a0,0xd
    8000700c:	02153423          	sd	ra,40(a0) # 2000028 <_entry-0x7dffffd8>
    80007010:	02253823          	sd	sp,48(a0)
    80007014:	02353c23          	sd	gp,56(a0)
    80007018:	04453023          	sd	tp,64(a0)
    8000701c:	04553423          	sd	t0,72(a0)
    80007020:	04653823          	sd	t1,80(a0)
    80007024:	04753c23          	sd	t2,88(a0)
    80007028:	f120                	sd	s0,96(a0)
    8000702a:	f524                	sd	s1,104(a0)
    8000702c:	fd2c                	sd	a1,120(a0)
    8000702e:	e150                	sd	a2,128(a0)
    80007030:	e554                	sd	a3,136(a0)
    80007032:	e958                	sd	a4,144(a0)
    80007034:	ed5c                	sd	a5,152(a0)
    80007036:	0b053023          	sd	a6,160(a0)
    8000703a:	0b153423          	sd	a7,168(a0)
    8000703e:	0b253823          	sd	s2,176(a0)
    80007042:	0b353c23          	sd	s3,184(a0)
    80007046:	0d453023          	sd	s4,192(a0)
    8000704a:	0d553423          	sd	s5,200(a0)
    8000704e:	0d653823          	sd	s6,208(a0)
    80007052:	0d753c23          	sd	s7,216(a0)
    80007056:	0f853023          	sd	s8,224(a0)
    8000705a:	0f953423          	sd	s9,232(a0)
    8000705e:	0fa53823          	sd	s10,240(a0)
    80007062:	0fb53c23          	sd	s11,248(a0)
    80007066:	11c53023          	sd	t3,256(a0)
    8000706a:	11d53423          	sd	t4,264(a0)
    8000706e:	11e53823          	sd	t5,272(a0)
    80007072:	11f53c23          	sd	t6,280(a0)
    80007076:	140022f3          	csrr	t0,sscratch
    8000707a:	06553823          	sd	t0,112(a0)
    8000707e:	00853103          	ld	sp,8(a0)
    80007082:	02053203          	ld	tp,32(a0)
    80007086:	01053283          	ld	t0,16(a0)
    8000708a:	00053303          	ld	t1,0(a0)
    8000708e:	12000073          	sfence.vma
    80007092:	18031073          	csrw	satp,t1
    80007096:	12000073          	sfence.vma
    8000709a:	8282                	jr	t0

000000008000709c <userret>:
    8000709c:	12000073          	sfence.vma
    800070a0:	18051073          	csrw	satp,a0
    800070a4:	12000073          	sfence.vma
    800070a8:	02000537          	lui	a0,0x2000
    800070ac:	357d                	addiw	a0,a0,-1
    800070ae:	0536                	slli	a0,a0,0xd
    800070b0:	02853083          	ld	ra,40(a0) # 2000028 <_entry-0x7dffffd8>
    800070b4:	03053103          	ld	sp,48(a0)
    800070b8:	03853183          	ld	gp,56(a0)
    800070bc:	04053203          	ld	tp,64(a0)
    800070c0:	04853283          	ld	t0,72(a0)
    800070c4:	05053303          	ld	t1,80(a0)
    800070c8:	05853383          	ld	t2,88(a0)
    800070cc:	7120                	ld	s0,96(a0)
    800070ce:	7524                	ld	s1,104(a0)
    800070d0:	7d2c                	ld	a1,120(a0)
    800070d2:	6150                	ld	a2,128(a0)
    800070d4:	6554                	ld	a3,136(a0)
    800070d6:	6958                	ld	a4,144(a0)
    800070d8:	6d5c                	ld	a5,152(a0)
    800070da:	0a053803          	ld	a6,160(a0)
    800070de:	0a853883          	ld	a7,168(a0)
    800070e2:	0b053903          	ld	s2,176(a0)
    800070e6:	0b853983          	ld	s3,184(a0)
    800070ea:	0c053a03          	ld	s4,192(a0)
    800070ee:	0c853a83          	ld	s5,200(a0)
    800070f2:	0d053b03          	ld	s6,208(a0)
    800070f6:	0d853b83          	ld	s7,216(a0)
    800070fa:	0e053c03          	ld	s8,224(a0)
    800070fe:	0e853c83          	ld	s9,232(a0)
    80007102:	0f053d03          	ld	s10,240(a0)
    80007106:	0f853d83          	ld	s11,248(a0)
    8000710a:	10053e03          	ld	t3,256(a0)
    8000710e:	10853e83          	ld	t4,264(a0)
    80007112:	11053f03          	ld	t5,272(a0)
    80007116:	11853f83          	ld	t6,280(a0)
    8000711a:	7928                	ld	a0,112(a0)
    8000711c:	10200073          	sret
	...
